<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_modify_column_nama_cabang_on_barang_keluar extends CI_Migration
{


    public function up()
    {
        $fields = array(
            'nama_cabang' => array(
                'name' => 'cabang_id',
                'type' => 'BIGINT(44)',
            ),
        );
        $this->dbforge->modify_column('barang_keluar', $fields);
    }


    public function down()
    {
    }
}
