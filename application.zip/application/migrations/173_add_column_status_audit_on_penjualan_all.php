<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_add_column_status_audit_on_penjualan_all extends CI_Migration
{


    public function up()
    {

        $fields = array(
            'status_audit'      => ['type' => 'INT(5)', 'default' => 0],            
        );
        $this->dbforge->add_column('transaksi_sepuhan', $fields);
        $this->dbforge->add_column('transaksi_kotak_cincin', $fields);
        $this->dbforge->add_column('uang_laci', $fields);
        $this->dbforge->add_column('insentif', $fields);
    }


    public function down()
    {
    }
}
