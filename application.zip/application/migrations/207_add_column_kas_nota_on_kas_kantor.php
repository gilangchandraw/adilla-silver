<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_add_column_kas_nota_on_kas_kantor extends CI_Migration {


	public function up()
	{ 

		$fields = array(
		        'kas_nota' => array('type' => 'DECIMAL(40)','default' =>0),
		);
		$this->dbforge->add_column('kas_kantor', $fields);
	 
	}


	public function down()
	{
		
	}

}