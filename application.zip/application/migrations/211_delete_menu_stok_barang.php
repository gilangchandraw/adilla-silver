<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_delete_menu_stok_barang extends CI_Migration
{


    public function up()
    {
        $this->db->delete('menu', array('id' => 48));
        // insert function value
        // $data_menu = array(
        //     array('id' => 48, 'module_id' => 1, 'name' => 'Stok Barang', 'url' => 'stok_barang', 'parent_id' => 38, 'icon' => "", 'sequence' => 4, 'description' => 'Logistik - Stok Barang'),
        // );
        // $this->db->insert_batch('menu', $data_menu);
    }

    public function down()
    {
    }
}
