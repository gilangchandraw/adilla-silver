<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */

class Migration_add_column_harga_on_barang_kotak_cincin extends CI_Migration
{

    public function up()
    {

        $fields = array(
            'harga' => array('type' => 'INT(40)', 'default' => NULL),
        );
        $this->dbforge->add_column('barang_kotak_cincin', $fields);
    }


    public function down()
    {
    }
}
