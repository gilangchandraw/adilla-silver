<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_modify_harga_and_reinsert_barang extends CI_Migration
{


    public function up()
    {
        $fields = array(
                'harga' => array(
                        'name' => 'jenis',
                        'type' => 'VARCHAR(10)',
                ),
        );
        $this->dbforge->modify_column('barang', $fields);
        $this->db->truncate('barang');

        // insert function value
        $data = array(
            array(
                'id' => 1, 'kode_barang' => '01A',
                'nama_barang' => 'Kalung 925',
                'stok' => 0,
                'jenis' => '925'
            ),
            array(
                'id' => 2, 'kode_barang' => '01B',
                'nama_barang' => 'Kalung SP',
                'stok' => 0,
                'jenis' => 'SP'
            ),
            array(
                'id' => 3, 'kode_barang' => '02A',
                'nama_barang' => 'Kalung Koye 925',
                'stok' => 0,
                'jenis' => '925'
            ),
            array(
                'id' => 4, 'kode_barang' => '02B',
                'nama_barang' => 'Kalung Koye SP',
                'stok' => 0,
                'jenis' => 'SP'
            ),
            array(
                'id' => 5, 'kode_barang' => '03A',
                'nama_barang' => 'Gelang Rantai 925',
                'stok' => 0,
                'jenis' => '925'
            ),
            array(
                'id' => 6, 'kode_barang' => '03B',
                'nama_barang' => 'Gelang Rantai SP',
                'stok' => 0,
                'jenis' => 'SP'
            ),
            array(
                'id' => 7, 'kode_barang' => '04A',
                'nama_barang' => 'Gelang BK 925',
                'stok' => 0,
                'jenis' => '925'
            ),
            array(
                'id' => 8, 'kode_barang' => '04B',
                'nama_barang' => 'Gelang BK SP',
                'stok' => 0,
                'jenis' => 'SP'
            ),
            array(
                'id' => 9, 'kode_barang' => '05A',
                'nama_barang' => 'Gelang Keroncong 925',
                'stok' => 0,
                'jenis' => '925'
            ),
            array(
                'id' => 10, 'kode_barang' => '05B',
                'nama_barang' => 'Gelang Keroncong SP',
                'stok' => 0,
                'jenis' => 'SP'
            ),
            array(
                'id' => 11, 'kode_barang' => '06A',
                'nama_barang' => 'Gelang Kaki 925',
                'stok' => 0,
                'jenis' => '925'
            ),
            array(
                'id' => 12, 'kode_barang' => '06B',
                'nama_barang' => 'Gelang Kaki SP',
                'stok' => 0,
                'jenis' => 'SP'
            ),
            array(
                'id' => 13, 'kode_barang' => '07A',
                'nama_barang' => 'Cincin 925',
                'stok' => 0,
                'jenis' => '925'
            ),
            array(
                'id' => 14, 'kode_barang' => '07B',
                'nama_barang' => 'Cincin SP',
                'stok' => 0,
                'jenis' => 'SP'
            ),
            array(
                'id' => 15, 'kode_barang' => '08A',
                'nama_barang' => 'Liontin 925',
                'stok' => 0,
                'jenis' => '925'
            ),
            array(
                'id' => 16, 'kode_barang' => '08B',
                'nama_barang' => 'Liontin SP',
                'stok' => 0,
                'jenis' => 'SP'
            ),
            array(
                'id' => 17, 'kode_barang' => '09A',
                'nama_barang' => 'Anting Jepit 925',
                'stok' => 0,
                'jenis' => '925'
            ),
            array(
                'id' => 18, 'kode_barang' => '09B',
                'nama_barang' => 'Anting Jepit SP',
                'stok' => 0,
                'jenis' => 'SP'
            ),
            array(
                'id' => 19, 'kode_barang' => '10A',
                'nama_barang' => 'Anting Dasi 925',
                'stok' => 0,
                'jenis' => '925'
            ),
            array(
                'id' => 20, 'kode_barang' => '10B',
                'nama_barang' => 'Anting Dasi SP',
                'stok' => 0,
                'jenis' => 'SP'
            ),
            array(
                'id' => 21, 'kode_barang' => '11A',
                'nama_barang' => 'Anting Gibsy 925',
                'stok' => 0,
                'jenis' => '925'
            ),
            array(
                'id' => 22, 'kode_barang' => '11B',
                'nama_barang' => 'Anting Gibsy SP',
                'stok' => 0,
                'jenis' => 'SP'
            ),
            array(
                'id' => 23, 'kode_barang' => '12A',
                'nama_barang' => 'Anting Panjang 925',
                'stok' => 0,
                'jenis' => '925'
            ),
            array(
                'id' => 24, 'kode_barang' => '12B',
                'nama_barang' => 'Anting Panjang SP',
                'stok' => 0,
                'jenis' => 'SP'
            ),
            array(
                'id' => 25, 'kode_barang' => '13A',
                'nama_barang' => 'Giwang 925',
                'stok' => 0,
                'jenis' => '925'
            ),
            array(
                'id' => 26, 'kode_barang' => '13B',
                'nama_barang' => 'Giwang SP',
                'stok' => 0,
                'jenis' => 'SP'
            ),
            array(
                'id' => 27, 'kode_barang' => '14A',
                'nama_barang' => 'Rongsok 925',
                'stok' => 0,
                'jenis' => '925'
            ),
            array(
                'id' => 28, 'kode_barang' => '14B',
                'nama_barang' => 'Rongsok SP',
                'stok' => 0,
                'jenis' => 'SP'
            ),

        );
        $this->db->insert_batch('barang', $data);
    }

    public function down()
    {
    }
}
