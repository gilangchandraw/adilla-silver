<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_modify_no_telepon_data_karyawan extends CI_Migration {


	public function up()
	{ 

		//migrasi
		$fields = array(
		        'no_telepon' => array(
		                'name' => 'no_telepon',
		                'type' => 'VARCHAR(20)',
		        ),
		);
		$this->dbforge->modify_column('data_karyawan', $fields);
	 
	}


	public function down()
	{
		
	}

}