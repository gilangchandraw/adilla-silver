<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_insert_menu_laporan extends CI_Migration
{


    public function up()
    {
        // insert function value
        $data_menu = array(

            array('id' => 35, 'module_id' => 1, 'name' => 'Laporan', 'url' => 'laporan', 'parent_id' => 1, 'icon' => "fa fa-clipboard", 'sequence' => 9, 'description' => 'Laporan'),
            array('id' => 36, 'module_id' => 1, 'name' => 'Laporan Harian', 'url' => 'laporan_harian', 'parent_id' => 35, 'icon' => "", 'sequence' => 1, 'description' => 'Laporan Harian'),
            array('id' => 37, 'module_id' => 1, 'name' => 'Laporan Bulanan', 'url' => 'laporan_bulanan', 'parent_id' => 35, 'icon' => "", 'sequence' => 2, 'description' => 'Laporan Bulanan'),


        );
        $this->db->insert_batch('menu', $data_menu);
    }

    public function down()
    {
    }
}
