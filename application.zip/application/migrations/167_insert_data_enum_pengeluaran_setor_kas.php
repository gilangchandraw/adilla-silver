<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_insert_data_enum_pengeluaran_setor_kas extends CI_Migration
{


    public function up()
    {
        $this->db->delete('enum_pengeluaran', array('id' => 4));

        $data = array(
            array(
                'id' => 4,
                'nama' => 'GAJI KARYAWAN',
            ),
            array(
                'id' => 11,
                'nama' => 'BONUS',
            ),
            array(
                'id' => 12,
                'nama' => 'SETOR KAS',
            ),
            
        );
        $this->db->insert_batch('enum_pengeluaran', $data);
    }

    public function down()
    {
    }
}
