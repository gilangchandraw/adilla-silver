<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_insert_role_again extends CI_Migration {


	public function up()
	{
		// insert function value
		 $data_role = array(
            array('id'=> 3, 'name'=>'Audit', 'description'=> 'AUditor Ke Cabang', 'is_deleted' => 0, 'group_id' => 0),
            array('id'=> 4, 'name'=>'Cabang', 'description'=> 'Kepala Cabang', 'is_deleted' => 0, 'group_id' => 0),
            
        );
        $this->db->insert_batch('roles', $data_role);
	}

	public function down()
	{

	}

}
