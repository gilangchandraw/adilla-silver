<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_reinsert_data_enum_pengeluaran extends CI_Migration
{


    public function up()
    {
        // insert function value
        $this->db->truncate('enum_pengeluaran');
        $data = array(
            array(
                'id' => 1,
                'nama' => 'KARYAWAN',
            ),
            array(
                'id' => 2,
                'nama' => 'KONTRAK TOKO',
            ),
            array(
                'id' => 3,
                'nama' => 'MOBIL',
            ),
            array(
                'id' => 4,
                'nama' => 'GAJI / BONUS',
            ),
            array(
                'id' => 5,
                'nama' => 'LISTRIK',
            ),
            array(
                'id' => 6,
                'nama' => 'SANITIZER',
            ),
            array(
                'id' => 7,
                'nama' => 'PDAM',
            ),
            array(
                'id' => 8,
                'nama' => 'WIFI',
            ),
            array(
                'id' => 9,
                'nama' => 'SEPUHAN',
            ),
            array(
                'id' => 10,
                'nama' => 'BIAYA TIDAK TERDUGA',
            ),
        );
        $this->db->insert_batch('enum_pengeluaran', $data);
    }

    public function down()
    {
    }
}
