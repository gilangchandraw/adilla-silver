<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_delete_menu_audit extends CI_Migration
{


    public function up()
    {
        $this->db->delete('menu', array('id' => 13));
    }


    public function down()
    {
    }
}
