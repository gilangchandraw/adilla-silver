<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_insert_data_cabang extends CI_Migration
{


	public function up()
	{
		// insert function value
		// $data = array(
		// 	array(
		// 		'id' => 1,
		// 		'kode_cabang' => 'BJR-I',
		// 		'nama_cabang' => 'Banjaran Pasar',
		// 		'alamat' => 'Pasar Banjaran Kios No. 419 - Bandung',
		// 		'kas' => 0
		// 	),
		// 	array(
		// 		'id' => 2,
		// 		'kode_cabang' => 'BJR-II',
		// 		'nama_cabang' => 'Banjaran II',
		// 		'alamat' => 'Jln. Raya Banjaran No.195 - Bandung',
		// 		'kas' => 0
		// 	),
		// 	array(
		// 		'id' => 3,
		// 		'kode_cabang' => 'CRJG',
		// 		'nama_cabang' => 'Ciranjang',
		// 		'alamat' => 'Pasar Ciranjang - Cianjur',
		// 		'kas' => 0
		// 	),
		// 	array(
		// 		'id' => 4,
		// 		'kode_cabang' => 'PSB',
		// 		'nama_cabang' => 'Pasar Baru',
		// 		'alamat' => 'Pasar Baru Trade Cender Lt. Dasar Blok M, No.21 (Pintu Samping)',
		// 		'kas' => 0
		// 	),
		// 	array(
		// 		'id' => 5,
		// 		'kode_cabang' => 'CMD',
		// 		'nama_cabang' => 'Cimindi',
		// 		'alamat' => 'Jln. Maharmartanegara No. 8 A rt 04 rw 15 Kecamatan Cimahi Tengah - Kota Cimahi',
		// 		'kas' => 0
		// 	),
		// 	array(
		// 		'id' => 6,
		// 		'kode_cabang' => 'PDLG-I',
		// 		'nama_cabang' => 'Padalarang I',
		// 		'alamat' => 'Jln. Raya Purwakarta No.18 Padalarang - Bandung',
		// 		'kas' => 0
		// 	),
		// 	array(
		// 		'id' => 7,
		// 		'kode_cabang' => 'BTJR',
		// 		'nama_cabang' => 'Batujajar',
		// 		'alamat' => 'Jln. Raya Batujajar No.3 Bandung',
		// 		'kas' => 0
		// 	),
		// 	array(
		// 		'id' => 8,
		// 		'kode_cabang' => 'MJL-II',
		// 		'nama_cabang' => 'Majalaya II',
		// 		'alamat' => 'Jln. Alun-Alun Utara No.23 - Majalaya',
		// 		'kas' => 0
		// 	),
		// 	array(
		// 		'id' => 9,
		// 		'kode_cabang' => 'MJL-I',
		// 		'nama_cabang' => 'Majalaya I',
		// 		'alamat' => 'Jln. Alun-Alun Utara No.57 - Majalaya',
		// 		'kas' => 0
		// 	),
		// 	array(
		// 		'id' => 10,
		// 		'kode_cabang' => 'PDLG-II',
		// 		'nama_cabang' => 'Padalarang II',
		// 		'alamat' => 'Jln.Raya Tagog No.530 - Padalarang',
		// 		'kas' => 0
		// 	),
		// );
		// $this->db->insert_batch('cabang', $data);
	}

	public function down()
	{
	}
}
