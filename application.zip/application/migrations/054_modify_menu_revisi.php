<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 * @property CI_DB_query_builder $db
 */
class Migration_modify_menu_revisi extends CI_Migration {


	public function up()
	{ 
		$this->db->delete('menu', array('id' => 4));
		$this->db->delete('menu', array('id' => 21));
		$this->db->delete('menu', array('id' => 22));
		$this->db->delete('menu', array('id' => 23));
		$this->db->delete('menu', array('id' => 24));
		$this->db->delete('menu', array('id' => 25));
		$this->db->delete('menu', array('id' => 26));
		$this->db->delete('menu', array('id' => 27));
		$this->db->delete('menu', array('id' => 28));
		$this->db->delete('menu', array('id' => 29));
		$data = array(
            array('id' => 21, 'module_id' => 1, 'name' => 'Pengeluaran', 'url' => 'pengeluaran', 'parent_id' => 15, 'icon' => "", 'sequence' => 4, 'description' => 'Transaksi -  Pengeluaran'),
            array('id' => 28, 'module_id' => 1, 'name' => 'Barang Sepuhan', 'url' => 'barang_sepuhan', 'parent_id' => 9, 'icon' => "", 'sequence' => 5, 'description' => 'Master Data - Barang Sepuhan'),
            array('id' => 29, 'module_id' => 1, 'name' => 'Barang Kotak Cincin', 'url' => 'barang_kotak_cincin', 'parent_id' => 9, 'icon' => "", 'sequence' => 6, 'description' => 'Master Data - Barang Kotak Cincin'),
            array('id' => 27, 'module_id' => 1, 'name' => 'Nota', 'url' => 'nota', 'parent_id' => 9, 'icon' => "", 'sequence' => 7, 'description' => 'Master Data -  Nota'),
        );
        $this->db->insert_batch('menu', $data); 
	 
	}


	public function down()
	{
		
	}

}