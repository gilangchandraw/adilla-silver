<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */

class Migration_modify_harga_transaksi_2 extends CI_Migration {

	public function up()
	{ 
		$fields_detail = array(
		        'harga' => array(
		                'name' => 'harga',
		                'type' => 'DECIMAL(20)',
		        ),
		);
		$this->dbforge->modify_column('penjualan_detail', $fields_detail);
		$this->dbforge->modify_column('barang_kembali_detail', $fields_detail);
		$this->dbforge->modify_column('tukar_plus_detail', $fields_detail);
		$this->dbforge->modify_column('pengeluaran_detail', $fields_detail);

		$fields = array(
		        'total_harga_keseluruhan' => array(
		                'name' => 'total_harga_keseluruhan',
		                'type' => 'DECIMAL(20)',
		        ),
		);
		$this->dbforge->modify_column('penjualan', $fields);
		$this->dbforge->modify_column('barang_kembali', $fields);
		$this->dbforge->modify_column('tukar_plus', $fields);
		$this->dbforge->modify_column('pengeluaran', $fields);

	 
	}


	public function down()
	{
		
	}

}