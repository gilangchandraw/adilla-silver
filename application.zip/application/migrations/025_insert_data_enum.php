<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_insert_data_enum extends CI_Migration
{


	public function up()
	{
		// insert function value
		$data = array(
			array(
				'id' => 1, 'jenis_transaksi' =>
				'penjualan',
				'nama' => '25',
				'harga' => 25000
			),
			array(
				'id' => 2, 'jenis_transaksi' =>
				'penjualan',
				'nama' => '30',
				'harga' => 30000
			),
			array(
				'id' => 3, 'jenis_transaksi' =>
				'penjualan',
				'nama' => '35',
				'harga' => 35000
			),
			array(
				'id' => 4, 'jenis_transaksi' =>
				'tukar_barang',
				'nama' => '25',
				'harga' => 25000
			),
			array(
				'id' => 5, 'jenis_transaksi' =>
				'tukar_barang',
				'nama' => '30',
				'harga' => 30000
			),
			array(
				'id' => 6, 'jenis_transaksi' =>
				'tukar_barang',
				'nama' => '35',
				'harga' => 35000
			),
			array(
				'id' => 7, 'jenis_transaksi' =>
				'barang_kembali',
				'nama' => '20',
				'harga' => 20000
			),
			array(
				'id' => 8, 'jenis_transaksi' =>
				'barang_kembali',
				'nama' => '22',
				'harga' => 22000
			),
			array(
				'id' => 9, 'jenis_transaksi' =>
				'barang_kembali',
				'nama' => '23',
				'harga' => 23000
			),
			array(
				'id' => 10, 'jenis_transaksi' =>
				'barang_kembali',
				'nama' => '25',
				'harga' => 25000
			),
			array(
				'id' => 11, 'jenis_transaksi' =>
				'barang_kembali',
				'nama' => '27',
				'harga' => 27000
			),
			array(
				'id' => 12, 'jenis_transaksi' =>
				'barang_kembali',
				'nama' => '30',
				'harga' => 30000
			),
		);
		$this->db->insert_batch('enum_transaksi_barang', $data);
	}

	public function down()
	{
	}
}
