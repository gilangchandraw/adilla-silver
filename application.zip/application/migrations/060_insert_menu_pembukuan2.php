<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_insert_menu_pembukuan2 extends CI_Migration
{


    public function up()
    {
        $this->db->delete('menu', array('id' => 30));
        // insert function value
        $data_menu = array(
            array('id' => 30, 'module_id' => 1, 'name' => 'Pembukuan', 'url' => '#', 'parent_id' => 1, 'icon' => "fa-book-open", 'sequence' => 8, 'description' => 'Pembukuan'),
            array('id' => 31, 'module_id' => 1, 'name' => 'Penjualan', 'url' => 'pembukuan_penjualan', 'parent_id' => 30, 'icon' => "", 'sequence' => 1, 'description' => 'Pembukuan - Penjualan'),
            array('id' => 32, 'module_id' => 1, 'name' => 'Barang Kembali', 'url' => 'pembukuan_barang_kembali', 'parent_id' => 30, 'icon' => "", 'sequence' => 2, 'description' => 'Pembukuan - Barang Kembali'),
            array('id' => 33, 'module_id' => 1, 'name' => 'Tukar Plus', 'url' => 'pembukuan_tukar_plus', 'parent_id' => 30, 'icon' => "", 'sequence' => 3, 'description' => 'Pembukuan - Tukar Plus'),
            array('id' => 34, 'module_id' => 1, 'name' => 'Pengeluaran', 'url' => 'pembukuan_pengeluaran', 'parent_id' => 30, 'icon' => "", 'sequence' => 4, 'description' => 'Pembukuan - Pengeluaran'),
        );
        $this->db->insert_batch('menu', $data_menu);

        for ($j = 32; $j <= 45; $j++) {
            for ($i = 1; $i <= 5; $i++) {
                $data_menu_function = array(
                    'menu_id' => $j,
                    'function_id' => $i,
                );
                $this->db->insert('menu_function', $data_menu_function);
            }
        }
    }

    public function down()
    {
    }
}
