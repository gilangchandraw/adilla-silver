<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_insert_master_menu extends CI_Migration {


	public function up()
	{ 
		// insert function value
		 $data_menu = array(
            array('id'=>1,'module_id'=>1, 'name'=>'root', 'url'=>'#', 'parent_id'=>0, 'icon'=>" ", 'sequence'	=>0, 'description' => 'Root Aplikasi'),
            array('id'=>2,'module_id'=>1, 'name'=>'Dashboard', 'url'=>'dashboard', 'parent_id'=>1, 'icon'=>"fa-rocket", 'sequence'=>1, 'description' => 'Dashboard'),
            array('id'=>3,'module_id'=>1, 'name'=>'System Access', 'url'=>'#', 'parent_id'=>1, 'icon'=>"fa-universal-access", 'sequence'=>2, 'description' => 'System Access'),
            array('id'=>4,'module_id'=>1, 'name'=>'Group', 'url'=>'group', 'parent_id'=>3, 'icon'=>"", 'sequence'=>1, 'description' => 'System Access - Group'),
            array('id'=>5,'module_id'=>1, 'name'=>'Role', 'url'=>'role', 'parent_id'=>3, 'icon'=>"", 'sequence'=>2, 'description' => 'System Access - Role'),
            array('id'=>6,'module_id'=>1, 'name'=>'Privileges', 'url'=>'privileges', 'parent_id'=>3, 'icon'=>"", 'sequence'=>3, 'description' => 'System Access - Privileges'),
            array('id'=>7,'module_id'=>1, 'name'=>'Manage Account', 'url'=>'#', 'parent_id'=>1, 'icon'=>"fa-users", 'sequence'	=>3, 'description' => 'Manage Account'),  
            array('id'=>8,'module_id'=>1, 'name'=>'User', 'url'=>'user', 'parent_id'=>7, 'icon'=>"", 'sequence'=>1, 'description' => 'Manage Account -  User'),  
        );
        $this->db->insert_batch('menu', $data_menu); 
	} 

	public function down()
	{
		
	}

}