<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_insert_data_enum_kantor extends CI_Migration
{


    public function up()
    {
        $table = "enum_kantor";
        $fields = array(
            'id'           => [
                'type'           => 'BIGINT(44)',
                'auto_increment' => TRUE,
                'unsigned'       => TRUE,
            ],
            'nama'      => [
                'type' => 'VARCHAR(50)',
                'default' => NULL,
            ],
            'updated_by'      => [
                'type' => 'INT(11)',
                'default' => 0,
            ],
            'created_by'      => [
                'type' => 'INT(11)',
                'default' => 0,
            ],
            'created_at  timestamp DEFAULT CURRENT_TIMESTAMP',
            'updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
            'is_deleted'      => [
                'type' => 'INT(11)',
                'default' => 0,
            ],

        );
        $this->dbforge->add_field($fields);
        $this->dbforge->add_key('id', TRUE);
        $this->dbforge->create_table($table);
       $data = array(
            array(
                'id' => 1,
                'nama' => 'Alat Sepuh',
            ),
            array(
                'id' => 2,
                'nama' => 'Kotak Cincin',
            ),
            array(
                'id' => 3,
                'nama' => 'Patrian',
            ),
            array(
                'id' => 4,
                'nama' => 'Uang Setor Kantor',
            ),
            array(
                'id' => 5,
                'nama' => 'Uang Bayar Barang',
            ),
            array(
                'id' => 6,
                'nama' => 'Uang Baju Ciranjang',
            ),
            array(
                'id' => 7,
                'nama' => 'Uang Baju Banjaran',
            ),
            array(
                'id' => 8,
                'nama' => 'Uang KRW UDA',
            ),
            array(
                'id' => 9,
                'nama' => 'Uang Kontrak Toko',
            ),
            array(
                'id' => 10,
                'nama' => 'Uang Kantor',
            ),
            array(
                'id' => 11,
                'nama' => 'Uang Mobil',
            ),
            array(
                'id' => 12,
                'nama' => 'Uang DLL',
            ),
        );
        $this->db->insert_batch('enum_kantor', $data);
    }

    public function down()
    {
    }
}
