<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_recreate_menu_insentif extends CI_Migration
{


    public function up()
    {
        // insert function value
        $data_menu = array(
        array('id' => 19, 'module_id' => 1, 'name' => 'Aktivitas', 'url' => '#', 'parent_id' => 1, 'icon' => "fa-edit", 'sequence'  => 7, 'description' => 'Aktivitas Harian'),
            array('id' => 20, 'module_id' => 1, 'name' => 'Insentif', 'url' => 'insentif', 'parent_id' => 19, 'icon' => "", 'sequence' => 1, 'description' => 'Aktivitas Harian -  Insentif'),
        );
        $this->db->insert_batch('menu', $data_menu);
    }

    public function down()
    {
    }
}
