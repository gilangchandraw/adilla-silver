<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_create_table_sepuhan extends CI_Migration
{


	public function up()
	{
		$table = "sepuhan";
		$fields = array(
			'id'           => [
				'type'           => 'BIGINT(44)',
				'auto_increment' => TRUE,
				'unsigned'       => TRUE,
			],
			'tanggal'      => [
				'type' => 'DATE',
				'default' => NULL,
			],
			'nama_cabang'      => [
				'type' => 'VARCHAR(50)',
				'default' => NULL,
			],
			'nama_barang'      => [
				'type' => 'VARCHAR(50)',
				'default' => NULL,
			],
			'stok'      => [
				'type' => 'INT(20)',
				'default' => NULL,
			],
			'harga'      => [
				'type' => 'INT(20)',
				'default' => NULL,
			],
			'updated_by'      => [
				'type' => 'INT(11)',
				'default' => 0,
			],
			'created_by'      => [
				'type' => 'INT(11)',
				'default' => 0,
			],
			'created_at  timestamp DEFAULT CURRENT_TIMESTAMP',
			'updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
			'is_deleted'      => [
				'type' => 'INT(11)',
				'default' => 0,
			],

		);
		$this->dbforge->add_field($fields);
		$this->dbforge->add_key('id', TRUE);
		$this->dbforge->create_table($table);
	}


	public function down()
	{
	}
}
