<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_modify_column_tanggal_on_transaksi_nota extends CI_Migration
{


    public function up()
    {
        $fields = array(
            'tanggal_pemesanan' => array(
                'name' => 'tanggal',
                'type' => 'DATE',
            ),
        );
        $this->dbforge->modify_column('transaksi_nota', $fields);

        $fields = array(
            'tanggal' => array(
                'name' => 'transaksi_nota_id',
                'type' => 'BIGINT(44)',
                'default' => NULL,
            ),
        );
        $this->dbforge->modify_column('transaksi_nota_percetakan', $fields);
    }


    public function down()
    {
    }
}
