<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_insert_data_barang_sepuhan_lain_lain extends CI_Migration
{


    public function up()
    {
        $data = array(
            array(
                'kode_sepuhan' => 'S0050',
                'nama_barang' => 'LAIN-LAIN',
            ),
            
        );
        $this->db->insert_batch('barang_sepuhan', $data);
    }

    public function down()
    {
    }
}
