<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_modify_menu_nota_dan_insert_nota_kantor extends CI_Migration
{


    public function up()
    {
        $this->db->delete('menu', array('id' => 27));
        // insert function value
        $data_menu = array(
            array('id' => 27, 'module_id' => 1, 'name' => 'Nota Cabang', 'url' => 'nota', 'parent_id' => 9, 'icon' => "", 'sequence' => 7, 'description' => 'Master Data - Nota Cabang'),
            array('id' => 46, 'module_id' => 1, 'name' => 'Nota Kantor', 'url' => 'nota_kantor', 'parent_id' => 9, 'icon' => "", 'sequence' => 8, 'description' => 'Master Data - Nota Kantor'),
        );
        $this->db->insert_batch('menu', $data_menu);
    }

    public function down()
    {
    }
}
