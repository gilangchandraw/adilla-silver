<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_reinsert_data_barang_kotak_cincin extends CI_Migration
{


    public function up()
    {
        // insert function value
        $this->db->truncate('barang_kotak_cincin');
        $data = array(
            array(
                'id' => 1, 'kode_kotak_cincin' => 'KC0001',
                'nama_barang' => 'K.C LOVE BESAR',
                'stok' => 0,
                'harga' => 110000
            ),
            array(
                'id' => 2, 'kode_kotak_cincin' => 'KC0002',
                'nama_barang' => 'K.C LOVE SEDANG ',
                'stok' => 0,
                'harga' => 75000
            ),
            array(
                'id' => 3, 'kode_kotak_cincin' => 'KC0003',
                'nama_barang' => 'K.C LOVE KECIL',
                'stok' => 0,
                'harga' => 35000
            ),
            array(
                'id' => 4, 'kode_kotak_cincin' => 'KC0004',
                'nama_barang' => 'K.C PERSEGI BESAR',
                'stok' => 0,
                'harga' => 110000
            ),
            array(
                'id' => 5, 'kode_kotak_cincin' => 'KC0005',
                'nama_barang' => 'K.C PERSEGI SEDANG',
                'stok' => 0,
                'harga' => 75000
            ),
            array(
                'id' => 6, 'kode_kotak_cincin' => 'KC0006',
                'nama_barang' => 'K.C PERSEGI KECIL',
                'stok' => 0,
                'harga' => 35000
            ),
            array(
                'id' => 7, 'kode_kotak_cincin' => 'KC0007',
                'nama_barang' => 'K.C PERSEGI PANJANG BESAR',
                'stok' => 0,
                'harga' => 135000
            ),
            array(
                'id' => 8, 'kode_kotak_cincin' => 'KC0008',
                'nama_barang' => 'K.C PERSEGI SET SEDANG',
                'stok' => 0,
                'harga' => 90000
            ),
            array(
                'id' => 9, 'kode_kotak_cincin' => 'KC0009',
                'nama_barang' => 'K.C PERSEGI SET KECIL',
                'stok' => 0,
                'harga' => 45000
            ),
            array(
                'id' => 10, 'kode_kotak_cincin' => 'KC0010',
                'nama_barang' => 'K.C ANIMASI BESAR',
                'stok' => 0,
                'harga' => 45000
            ),
            array(
                'id' => 11, 'kode_kotak_cincin' => 'KC0011',
                'nama_barang' => 'K.C ANIMASI KECIL',
                'stok' => 0,
                'harga' => 35000
            ),
            array(
                'id' => 12, 'kode_kotak_cincin' => 'KC0012',
                'nama_barang' => 'K.C MIKA PERSEGI',
                'stok' => 0,
                'harga' => 45000
            ),
            array(
                'id' => 13, 'kode_kotak_cincin' => 'KC0013',
                'nama_barang' => 'K.C MIKA BULAT TEBAL',
                'stok' => 0,
                'harga' => 45000
            ),
            array(
                'id' => 14, 'kode_kotak_cincin' => 'KC0014',
                'nama_barang' => 'K.C MIKA BULAT BESAR',
                'stok' => 0,
                'harga' => 45000
            ),
            array(
                'id' => 15, 'kode_kotak_cincin' => 'KC0015',
                'nama_barang' => 'K.C MIKA BULAT KECIL',
                'stok' => 0,
                'harga' => 35000
            ),
            array(
                'id' => 16, 'kode_kotak_cincin' => 'KC0016',
                'nama_barang' => 'K.C KAYU UKIR',
                'stok' => 0,
                'harga' => 75000
            ),
            array(
                'id' => 17, 'kode_kotak_cincin' => 'KC0017',
                'nama_barang' => 'K.C SEMI KULIT',
                'stok' => 0,
                'harga' => 50000
            ),
            array(
                'id' => 18, 'kode_kotak_cincin' => 'KC0018',
                'nama_barang' => 'BULATAN GELANG',
                'stok' => 0,
                'harga' => 100000
            ),
            array(
                'id' => 19, 'kode_kotak_cincin' => 'KC0019',
                'nama_barang' => 'JEPITAN CINCIN',
                'stok' => 0,
                'harga' => 45000
            ),
            array(
                'id' => 20, 'kode_kotak_cincin' => 'KC0020',
                'nama_barang' => 'BULATAN GELANG BERTINGKAT',
                'stok' => 0,
                'harga' => 75000
            ),
            array(
                'id' => 21, 'kode_kotak_cincin' => 'KC0021',
                'nama_barang' => 'PATUNG LEHER KECIL',
                'stok' => 0,
                'harga' => 70000
            ),
            array(
                'id' => 22, 'kode_kotak_cincin' => 'KC0022',
                'nama_barang' => 'PATUNG LEHER BESAR',
                'stok' => 0,
                'harga' => 80000
            ),
            array(
                'id' => 23, 'kode_kotak_cincin' => 'KC0023',
                'nama_barang' => 'TEMPELAN KACA',
                'stok' => 0,
                'harga' => 50000
            ),
        );
        $this->db->insert_batch('barang_kotak_cincin', $data);
    }

    public function down()
    {
    }
}
