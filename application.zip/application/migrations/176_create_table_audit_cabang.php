<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_create_table_audit_cabang extends CI_Migration
{


	public function up()
	{
		$table = "audit_cabang";
		$fields = array(
			'id'           => [
				'type'           => 'BIGINT(44)',
				'auto_increment' => TRUE,
				'unsigned'       => TRUE,
			],
			'users_id'      => [
				'type' => 'INT(11)',
				'default' => 0,
			],
			'cabang_id'      => [
				'type' => 'INT(11)',
				'default' => 0,
			],
			'tanggal'      => [
				'type' => 'DATE',
				'default' => NULL,
			],
			'tanggal_awal'      => [
				'type' => 'DATE',
				'default' => NULL,
			],
			'tanggal_akhir'      => [
				'type' => 'DATE',
				'default' => NULL,
			],
			'krw_uda'      => [
				'type' => 'DECIMAL(20)',
				'default' => 0,
			],
			'k_toko'      => [
				'type' => 'DECIMAL(20)',
				'default' => 0,
			],
			'uang_kantor'      => [
				'type' => 'DECIMAL(20)',
				'default' => 0,
			],
			'dll'      => [
				'type' => 'DECIMAL(20)',
				'default' => 0,
			],
			'total'      => [
				'type' => 'DECIMAL(20)',
				'default' => 0,
			],
			'uang_potongan'      => [
				'type' => 'DECIMAL(20)',
				'default' => 0,
			],
			'uang_kotak_cincin'      => [
				'type' => 'DECIMAL(20)',
				'default' => 0,
			],
			'uang_setor'      => [
				'type' => 'DECIMAL(20)',
				'default' => 0,
			],
			'uang_bayar_barang'      => [
				'type' => 'DECIMAL(20)',
				'default' => 0,
			],
			'updated_by'      => [
				'type' => 'INT(11)',
				'default' => 0,
			],
			'created_by'      => [
				'type' => 'INT(11)',
				'default' => 0,
			],
			'created_at  timestamp DEFAULT CURRENT_TIMESTAMP',
			'updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
			'is_deleted'      => [
				'type' => 'INT(11)',
				'default' => 0,
			],

		);
		$this->dbforge->add_field($fields);
		$this->dbforge->add_key('id', TRUE);
		$this->dbforge->create_table($table);
	}


	public function down()
	{
	}
}
