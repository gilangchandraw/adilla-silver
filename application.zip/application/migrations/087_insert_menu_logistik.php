<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_insert_menu_logistik extends CI_Migration
{


    public function up()
    {
        // insert function value
        $data_menu = array(

            array('id' => 38, 'module_id' => 1, 'name' => 'Logistik', 'url' => 'logistik', 'parent_id' => 1, 'icon' => "fa fa-truck", 'sequence' => 10, 'description' => 'Logistik'),
            array('id' => 39, 'module_id' => 1, 'name' => 'Barang Masuk', 'url' => 'barang_masuk', 'parent_id' => 38, 'icon' => "", 'sequence' => 1, 'description' => 'Barang Masuk'),
            array('id' => 40, 'module_id' => 1, 'name' => 'Barang Keluar', 'url' => 'barang_keluar', 'parent_id' => 38, 'icon' => "", 'sequence' => 2, 'description' => 'Barang Keluar'),


        );
        $this->db->insert_batch('menu', $data_menu);
    }

    public function down()
    {
    }
}
