<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_insert_menu_transaksi_cabang extends CI_Migration
{


    public function up()
    {
        // insert function value
        $data_menu = array(

            array('id' => 44, 'module_id' => 1, 'name' => 'Transaksi Cabang', 'url' => 'transaksi_cabang', 'parent_id' => 1, 'icon' => "fa fa-store", 'sequence' => 12, 'description' => 'Transaksi Cabang'),
            array('id' => 45, 'module_id' => 1, 'name' => 'Transaksi Sepuhan', 'url' => 'transaksi_sepuhan', 'parent_id' => 44, 'icon' => "", 'sequence' => 1, 'description' => 'Transaksi Sepuhan'),
            array('id' => 46, 'module_id' => 1, 'name' => 'Transaksi Kotak Cincin', 'url' => 'transaksi_kotak_cincin', 'parent_id' => 44, 'icon' => "", 'sequence' => 2, 'description' => 'Transaksi Kotak Cincin'),


        );
        $this->db->insert_batch('menu', $data_menu);
    }

    public function down()
    {
    }
}
