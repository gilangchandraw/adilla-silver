<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_create_table_uang_nota extends CI_Migration
{


	public function up()
	{
		$table = "uang_nota";
		$fields = array(
			'id'           => [
                'type'           => 'BIGINT(44)',
                'auto_increment' => TRUE,
                'unsigned'       => TRUE,
            ],
			'cabang_id'      => [
				'type' => 'INT(11)',
				'default' => 0,
			],
			'total'      => [
				'type' => 'DECIMAL(20)',
				'default' => 0,
			],
			'created_at  timestamp DEFAULT CURRENT_TIMESTAMP',
            'updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',

		);
		$this->dbforge->add_field($fields);
		$this->dbforge->add_key('id', TRUE);
		$this->dbforge->create_table($table);
		// INPUT DATA CABANG
		for($i=1;$i<=20;$i++){
            $data = array(
                'cabang_id' => $i, 
            );
            $this->db->insert('uang_nota', $data);
        }

		$table = "uang_nota_detail";
		$fields = array(
			'id'           => [
                'type'           => 'BIGINT(44)',
                'auto_increment' => TRUE,
                'unsigned'       => TRUE,
            ],
			'cabang_id'      => [
				'type' => 'INT(11)',
				'default' => 0,
			],
			'tanggal'      => [
				'type' => 'DATE',
				'default' => NULL,
			],
			'total'      => [
				'type' => 'DECIMAL(20)',
				'default' => 0,
			],
			'created_at  timestamp DEFAULT CURRENT_TIMESTAMP',
            'updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',

		);
		$this->dbforge->add_field($fields);
		$this->dbforge->add_key('id', TRUE);
		$this->dbforge->create_table($table);

		
	}


	public function down()
	{
	}
}
