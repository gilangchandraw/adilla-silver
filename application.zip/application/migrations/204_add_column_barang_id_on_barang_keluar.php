<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_add_column_barang_id_on_barang_keluar extends CI_Migration {


	public function up()
	{ 

		$fields = array(
		        'barang_id' => array('type' => 'INT','default' =>0),
		);
		$this->dbforge->add_column('barang_keluar', $fields);
	 
	}


	public function down()
	{
		
	}

}