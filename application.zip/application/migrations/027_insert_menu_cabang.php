<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_insert_menu_cabang extends CI_Migration
{


    public function up()
    {
        // insert function value
        $data_menu = array(
            array('id' => 14, 'module_id' => 1, 'name' => 'Data Karyawan', 'url' => 'data_karyawan', 'parent_id' => 1, 'icon' => "fa-user", 'sequence'  => 5, 'description' => 'Data Karyawan'),
            array('id' => 15, 'module_id' => 1, 'name' => 'Transaksi', 'url' => '#', 'parent_id' => 1, 'icon' => "fa-credit-card", 'sequence'  => 6, 'description' => 'Transaksi'),
            array('id' => 16, 'module_id' => 1, 'name' => 'Penjualan', 'url' => 'penjualan', 'parent_id' => 15, 'icon' => "", 'sequence' => 1, 'description' => 'Transaksi -  Penjualan'),
            array('id' => 17, 'module_id' => 1, 'name' => 'Barang Kembali', 'url' => 'barang_kembali', 'parent_id' => 15, 'icon' => "", 'sequence' => 2, 'description' => 'Transaksi -  Barang Kembali'),
            array('id' => 18, 'module_id' => 1, 'name' => 'Tukar Plus', 'url' => 'tukar_plus', 'parent_id' => 15, 'icon' => "", 'sequence' => 3, 'description' => 'Transaksi -  Tukar Plus'),
            array('id' => 19, 'module_id' => 1, 'name' => 'Aktivitas', 'url' => '#', 'parent_id' => 1, 'icon' => "fa-edit", 'sequence'  => 7, 'description' => 'Aktivitas Harian'),
            array('id' => 20, 'module_id' => 1, 'name' => 'Insentif', 'url' => 'insentif', 'parent_id' => 19, 'icon' => "", 'sequence' => 1, 'description' => 'Aktivitas Harian -  Insentif'),
            array('id' => 21, 'module_id' => 1, 'name' => 'Pengeluaran', 'url' => 'pengeluaran', 'parent_id' => 19, 'icon' => "", 'sequence' => 2, 'description' => 'Aktivitas Harian -  Pengeluaran'),
            array('id' => 22, 'module_id' => 1, 'name' => 'Barang Rusak', 'url' => 'barang_rusak', 'parent_id' => 19, 'icon' => "", 'sequence' => 3, 'description' => 'Aktivitas Harian -  Barang Rusak'),
            array('id' => 23, 'module_id' => 1, 'name' => 'Barang Hilang', 'url' => 'barang_hilang', 'parent_id' => 19, 'icon' => "", 'sequence' => 4, 'description' => 'Aktivitas Harian -  Barang Hilang'),
            array('id' => 24, 'module_id' => 1, 'name' => 'Logistik', 'url' => '#', 'parent_id' => 1, 'icon' => "fa-archive", 'sequence'  => 8, 'description' => 'Logistik'),
            array('id' => 25, 'module_id' => 1, 'name' => 'Sepuhan', 'url' => 'sepuhan', 'parent_id' => 24, 'icon' => "", 'sequence' => 1, 'description' => 'Logistik -  Sepuhan'),
            array('id' => 26, 'module_id' => 1, 'name' => 'Kotak Cincin', 'url' => 'kotak_cincin', 'parent_id' => 24, 'icon' => "", 'sequence' => 2, 'description' => 'Logistik -  Kotak Cincin'),

        );
        $this->db->insert_batch('menu', $data_menu);
    }

    public function down()
    {
    }
}
