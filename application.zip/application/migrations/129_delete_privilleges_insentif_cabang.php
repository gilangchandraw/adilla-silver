<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_delete_privilleges_insentif_cabang extends CI_Migration {


	public function up()
	{ 
		$this->db->truncate('privilleges');
		$privilleges = array(
			array(
				"id" => 69,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 1,
			),
			array(
				"id" => 70,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 2,
			),
			array(
				"id" => 71,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 3,
			),
			array(
				"id" => 72,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 4,
			),
			array(
				"id" => 73,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 5,
			),
			array(
				"id" => 74,
				"role_id" => 4,
				"menu_id" => 35,
				"function_id" => 1,
			),
			array(
				"id" => 75,
				"role_id" => 4,
				"menu_id" => 38,
				"function_id" => 1,
			),
			array(
				"id" => 76,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 1,
			),
			array(
				"id" => 77,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 2,
			),
			array(
				"id" => 78,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 3,
			),
			array(
				"id" => 79,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 4,
			),
			array(
				"id" => 80,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 5,
			),
			array(
				"id" => 81,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 1,
			),
			array(
				"id" => 82,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 2,
			),
			array(
				"id" => 83,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 3,
			),
			array(
				"id" => 84,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 4,
			),
			array(
				"id" => 85,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 5,
			),
			array(
				"id" => 86,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 1,
			),
			array(
				"id" => 87,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 2,
			),
			array(
				"id" => 88,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 3,
			),
			array(
				"id" => 89,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 4,
			),
			array(
				"id" => 90,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 5,
			),
			array(
				"id" => 91,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 1,
			),
			array(
				"id" => 92,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 2,
			),
			array(
				"id" => 93,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 3,
			),
			array(
				"id" => 94,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 4,
			),
			array(
				"id" => 95,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 5,
			),
			array(
				"id" => 96,
				"role_id" => 4,
				"menu_id" => 44,
				"function_id" => 1,
			),
			array(
				"id" => 97,
				"role_id" => 4,
				"menu_id" => 44,
				"function_id" => 2,
			),
			array(
				"id" => 98,
				"role_id" => 4,
				"menu_id" => 44,
				"function_id" => 3,
			),
			array(
				"id" => 99,
				"role_id" => 4,
				"menu_id" => 44,
				"function_id" => 4,
			),
			array(
				"id" => 100,
				"role_id" => 4,
				"menu_id" => 44,
				"function_id" => 5,
			),
			array(
				"id" => 101,
				"role_id" => 4,
				"menu_id" => 45,
				"function_id" => 1,
			),
			array(
				"id" => 102,
				"role_id" => 4,
				"menu_id" => 45,
				"function_id" => 2,
			),
			array(
				"id" => 103,
				"role_id" => 4,
				"menu_id" => 45,
				"function_id" => 3,
			),
			array(
				"id" => 104,
				"role_id" => 4,
				"menu_id" => 45,
				"function_id" => 4,
			),
			array(
				"id" => 105,
				"role_id" => 4,
				"menu_id" => 45,
				"function_id" => 5,
			),
			array(
				"id" => 106,
				"role_id" => 4,
				"menu_id" => 47,
				"function_id" => 1,
			),
			array(
				"id" => 107,
				"role_id" => 4,
				"menu_id" => 47,
				"function_id" => 2,
			),
			array(
				"id" => 108,
				"role_id" => 4,
				"menu_id" => 47,
				"function_id" => 3,
			),
			array(
				"id" => 109,
				"role_id" => 4,
				"menu_id" => 47,
				"function_id" => 4,
			),
			array(
				"id" => 110,
				"role_id" => 4,
				"menu_id" => 47,
				"function_id" => 5,
			),
			array(
				"id" => 111,
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 1,
			),
			array(
				"id" => 112,
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 2,
			),
			array(
				"id" => 113,
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 3,
			),
			array(
				"id" => 114,
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 4,
			),
			array(
				"id" => 115,
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 5,
			),
			array(
				"id" => 116,
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 1,
			),
			array(
				"id" => 117,
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 2,
			),
			array(
				"id" => 118,
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 3,
			),
			array(
				"id" => 119,
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 4,
			),
			array(
				"id" => 120,
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 5,
			),
			array(
				"id" => 121,
				"role_id" => 4,
				"menu_id" => 48,
				"function_id" => 1,
			),
			array(
				"id" => 122,
				"role_id" => 4,
				"menu_id" => 48,
				"function_id" => 2,
			),
			array(
				"id" => 123,
				"role_id" => 4,
				"menu_id" => 48,
				"function_id" => 3,
			),
			array(
				"id" => 124,
				"role_id" => 4,
				"menu_id" => 48,
				"function_id" => 4,
			),
			array(
				"id" => 125,
				"role_id" => 4,
				"menu_id" => 48,
				"function_id" => 5,
			),
			array(
				"id" => 126,
				"role_id" => 4,
				"menu_id" => 1,
				"function_id" => 1,
			),
			array(
				"id" => 127,
				"role_id" => 4,
				"menu_id" => 1,
				"function_id" => 1,
			),
			array(
				"id" => 128,
				"role_id" => 4,
				"menu_id" => 15,
				"function_id" => 1,
			),
			array(
				"id" => 129,
				"role_id" => 4,
				"menu_id" => 35,
				"function_id" => 1,
			),
			array(
				"id" => 130,
				"role_id" => 4,
				"menu_id" => 38,
				"function_id" => 1,
			),
			array(
				"id" => 131,
				"role_id" => 4,
				"menu_id" => 1,
				"function_id" => 1,
			),
		);

		$this->db->insert_batch('privilleges', $privilleges); 
	 
	}


	public function down()
	{
		
	}

}