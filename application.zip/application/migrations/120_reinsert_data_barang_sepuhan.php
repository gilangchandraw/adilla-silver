<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_reinsert_data_barang_sepuhan extends CI_Migration
{


    public function up()
    {
        // insert function value
        $this->db->truncate('barang_sepuhan');
        $data = array(
            array(
                'id' => 1, 'kode_sepuhan' => 'S0001',
                'nama_barang' => 'AIR MAS',
                'stok' => 0,
                'harga' => 450000
            ),
            array(
                'id' => 2, 'kode_sepuhan' => 'S0002',
                'nama_barang' => 'AIR MERAH',
                'stok' => 0,
                'harga' => 50000
            ),
            array(
                'id' => 3, 'kode_sepuhan' => 'S0003',
                'nama_barang' => 'AIR PERAK',
                'stok' => 0,
                'harga' => 75000
            ),
            array(
                'id' => 4, 'kode_sepuhan' => 'S0004',
                'nama_barang' => 'AQUA BIDES',
                'stok' => 0,
                'harga' => 100000
            ),
            array(
                'id' => 5, 'kode_sepuhan' => 'S0005',
                'nama_barang' => 'BAHAN PATRI',
                'stok' => 0,
                'harga' => 10000
            ),
            array(
                'id' => 6, 'kode_sepuhan' => 'S0006',
                'nama_barang' => 'BIJI MOLEN',
                'stok' => 0,
                'harga' => 55000
            ),
            array(
                'id' => 7, 'kode_sepuhan' => 'S0007',
                'nama_barang' => 'PINSET',
                'stok' => 0,
                'harga' => 35000
            ),
            array(
                'id' => 8, 'kode_sepuhan' => 'S0008',
                'nama_barang' => 'PLATINA',
                'stok' => 0,
                'harga' => 675000
            ),
            array(
                'id' => 9, 'kode_sepuhan' => 'S0009',
                'nama_barang' => 'SIKAT KALUNG',
                'stok' => 0,
                'harga' => 10000
            ),
            array(
                'id' => 10, 'kode_sepuhan' => 'S0010',
                'nama_barang' => 'SIKAT CINCIN',
                'stok' => 0,
                'harga' => 30000
            ),
            array(
                'id' => 11, 'kode_sepuhan' => 'S0011',
                'nama_barang' => 'SIKAT MOLEN',
                'stok' => 0,
                'harga' => 35000
            ),
            array(
                'id' => 12, 'kode_sepuhan' => 'S0012',
                'nama_barang' => 'SABUN MOLEN',
                'stok' => 0,
                'harga' => 100000
            ),
            array(
                'id' => 13, 'kode_sepuhan' => 'S0013',
                'nama_barang' => 'KAIN MOLEN',
                'stok' => 0,
                'harga' => 75000
            ),
            array(
                'id' => 14, 'kode_sepuhan' => 'S0014',
                'nama_barang' => 'AMPLAS SANGLING',
                'stok' => 0,
                'harga' => 25000
            ),
            array(
                'id' => 15, 'kode_sepuhan' => 'S0015',
                'nama_barang' => 'AMPLAS KASAR',
                'stok' => 0,
                'harga' => 25000
            ),
            array(
                'id' => 16, 'kode_sepuhan' => 'S0016',
                'nama_barang' => 'KARET TABUNG MOLEN KECIL',
                'stok' => 0,
                'harga' => 15000
            ),
            array(
                'id' => 17, 'kode_sepuhan' => 'S0017',
                'nama_barang' => 'KARET TABUNG MOLEN BESAR',
                'stok' => 0,
                'harga' => 25000
            ),
            array(
                'id' => 18, 'kode_sepuhan' => 'S0018',
                'nama_barang' => 'KARET MESIN MOLEN',
                'stok' => 0,
                'harga' => 15000
            ),
            array(
                'id' => 19, 'kode_sepuhan' => 'S0019',
                'nama_barang' => 'POMPOK HITAM',
                'stok' => 0,
                'harga' => 15000
            ),
            array(
                'id' => 20, 'kode_sepuhan' => 'S0020',
                'nama_barang' => 'POMPOK PUTIH',
                'stok' => 0,
                'harga' => 15000
            ),
            array(
                'id' => 21, 'kode_sepuhan' => 'S0021',
                'nama_barang' => 'TANG PETAK',
                'stok' => 0,
                'harga' => 45000
            ),
            array(
                'id' => 22, 'kode_sepuhan' => 'S0022',
                'nama_barang' => 'TANG BULAT',
                'stok' => 0,
                'harga' => 45000
            ),
            array(
                'id' => 23, 'kode_sepuhan' => 'S0023',
                'nama_barang' => 'OBAT POLES',
                'stok' => 0,
                'harga' => 75000
            ),
            array(
                'id' => 24, 'kode_sepuhan' => 'S0024',
                'nama_barang' => 'PORTAS',
                'stok' => 0,
                'harga' => 500
            ),
            array(
                'id' => 25, 'kode_sepuhan' => 'S0025',
                'nama_barang' => 'PIJAR',
                'stok' => 0,
                'harga' => 3000
            ),
            array(
                'id' => 26, 'kode_sepuhan' => 'S0026',
                'nama_barang' => 'GUNTING HIJAU',
                'stok' => 0,
                'harga' => 55000
            ),
            array(
                'id' => 27, 'kode_sepuhan' => 'S0027',
                'nama_barang' => 'SANGLING BAJA',
                'stok' => 0,
                'harga' => 100000
            ),
            array(
                'id' => 28, 'kode_sepuhan' => 'S0028',
                'nama_barang' => 'KAWAT MOLEN',
                'stok' => 0,
                'harga' => 25000
            ),
            array(
                'id' => 29, 'kode_sepuhan' => 'S0029',
                'nama_barang' => 'MATA GERGAJI',
                'stok' => 0,
                'harga' => 5500
            ),
            array(
                'id' => 30, 'kode_sepuhan' => 'S0030',
                'nama_barang' => 'BATANG GERGAJI',
                'stok' => 0,
                'harga' => 175000
            ),
            array(
                'id' => 31, 'kode_sepuhan' => 'S0031',
                'nama_barang' => 'BULATAN CINCIN',
                'stok' => 0,
                'harga' => 90000
            ),
            array(
                'id' => 32, 'kode_sepuhan' => 'S0032',
                'nama_barang' => 'BULATAN GELANG KAYU',
                'stok' => 0,
                'harga' => 65000
            ),
            array(
                'id' => 33, 'kode_sepuhan' => 'S0033',
                'nama_barang' => 'KAWAT RING',
                'stok' => 0,
                'harga' => 15000
            ),
            array(
                'id' => 34, 'kode_sepuhan' => 'S0034',
                'nama_barang' => 'KUNCI SS',
                'stok' => 0,
                'harga' => 15000
            ),
            array(
                'id' => 35, 'kode_sepuhan' => 'S0035',
                'nama_barang' => 'LONCENG',
                'stok' => 0,
                'harga' => 15000
            ),
            array(
                'id' => 36, 'kode_sepuhan' => 'S0036',
                'nama_barang' => 'MATANG HITAN 0,7',
                'stok' => 0,
                'harga' => 44000
            ),
            array(
                'id' => 37, 'kode_sepuhan' => 'S0037',
                'nama_barang' => 'MATA HITAM 1',
                'stok' => 0,
                'harga' => 42000
            ),
            array(
                'id' => 38, 'kode_sepuhan' => 'S0038',
                'nama_barang' => 'MATA HITAM 1,25',
                'stok' => 0,
                'harga' => 40000
            ),
            array(
                'id' => 39, 'kode_sepuhan' => 'S0039',
                'nama_barang' => 'MATA HITAM 1,5',
                'stok' => 0,
                'harga' => 38000
            ),
            array(
                'id' => 40, 'kode_sepuhan' => 'S0040',
                'nama_barang' => 'MATA HITAM 1,75',
                'stok' => 0,
                'harga' => 35000
            ),
            array(
                'id' => 41, 'kode_sepuhan' => 'S0041',
                'nama_barang' => 'MATA HITAM 2',
                'stok' => 0,
                'harga' => 33000
            ),
            array(
                'id' => 42, 'kode_sepuhan' => 'S0042',
                'nama_barang' => 'MATA HITAM 2,5',
                'stok' => 0,
                'harga' => 30000
            ),
            array(
                'id' => 43, 'kode_sepuhan' => 'S0043',
                'nama_barang' => 'MATA PUTIH 0,7',
                'stok' => 0,
                'harga' => 42000
            ),
            array(
                'id' => 44, 'kode_sepuhan' => 'S0044',
                'nama_barang' => 'MATA PUTIH 1',
                'stok' => 0,
                'harga' => 40000
            ),
            array(
                'id' => 45, 'kode_sepuhan' => 'S0045',
                'nama_barang' => 'MATA PUTIH 1,25',
                'stok' => 0,
                'harga' => 38000
            ),
            array(
                'id' => 46, 'kode_sepuhan' => 'S0046',
                'nama_barang' => 'MATA PUTIH 1,5',
                'stok' => 0,
                'harga' => 35000
            ),
            array(
                'id' => 47, 'kode_sepuhan' => 'S0047',
                'nama_barang' => 'MATA PUTIH 1,75',
                'stok' => 0,
                'harga' => 32000

            ),
            array(
                'id' => 48, 'kode_sepuhan' => 'S0048',
                'nama_barang' => 'MATA PUTIH 2',
                'stok' => 0,
                'harga' => 28000
            ),
            array(
                'id' => 49, 'kode_sepuhan' => 'S0049',
                'nama_barang' => 'MATA PUTIH 2,5',
                'stok' => 0,
                'harga' => 25000
            ),
        );
        $this->db->insert_batch('barang_sepuhan', $data);
    }

    public function down()
    {
    }
}
