<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_insert_data_stok_sepuhan_dan_stok_kotak_cincin extends CI_Migration
{


    public function up()
    {
        // insert function value
        $this->db->truncate('stok_sepuhan_cabang');
        for ($x = 1; $x <= 10; $x++) {
            for ($y = 1; $y <= 49; $y++) {
                $data_stok_sepuhan_cabang = array(
                    'cabang_id' => $x,
                    'sepuhan_id' => $y,
                    'stok' => 0
                );
                $this->db->insert('stok_sepuhan_cabang', $data_stok_sepuhan_cabang);
            }
        }
        $this->db->truncate('stok_kotak_cincin_cabang');
        for ($x = 1; $x <= 10; $x++) {
            for ($y = 1; $y <= 23; $y++) {
                $data_stok_kotak_cincin_cabang = array(
                    'cabang_id' => $x,
                    'kotak_cincin_id' => $y,
                    'stok' => 0
                );
                $this->db->insert('stok_kotak_cincin_cabang', $data_stok_kotak_cincin_cabang);
            }
        }
    }
    public function down()
    {
    }
}
