<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_create_menu_laporan_barang_hilang extends CI_Migration
{


    public function up()
    {
        // insert function value
        $data_menu = array(



            array('id' => 57, 'module_id' => 1, 'name' => 'Laporan Barang Hilang', 'url' => 'laporan_barang_hilang', 'parent_id' => 35, 'icon' => "", 'sequence' => 7, 'description' => 'Laporan Barang Hilang'),


        );
        $this->db->insert_batch('menu', $data_menu);
    }

    public function down()
    {
    }
}
