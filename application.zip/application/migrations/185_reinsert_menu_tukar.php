<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_reinsert_menu_tukar extends CI_Migration {


	public function up()
	{ 
		$this->db->delete('menu', array('id' => 18));
		$this->db->delete('menu', array('id' => 33));
		$data_menu = array(
        	array('id' => 33, 'module_id' => 1, 'name' => 'Tukar', 'url' => 'pembukuan_tukar_plus', 'parent_id' => 30, 'icon' => "", 'sequence' => 3, 'description' => 'Pembukuan - Tukar'),
        	array('id' => 18, 'module_id' => 1, 'name' => 'Tukar', 'url' => 'tukar_plus', 'parent_id' => 15, 'icon' => "", 'sequence' => 3, 'description' => 'Transaksi - Tukar'),
        );
        $this->db->insert_batch('menu', $data_menu);
	 
	}


	public function down()
	{
		
	}

}