<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_modify_menu_transaksi_nota extends CI_Migration
{


    public function up()
    {
        $this->db->delete('menu', array('id' => 43));
        // insert function value
        $data_menu = array(

            array('id' => 43, 'module_id' => 1, 'name' => 'Transaksi Nota', 'url' => 'transaksi_nota', 'parent_id' => 42, 'icon' => "", 'sequence' => 1, 'description' => 'Transaksi Nota'),


        );
        $this->db->insert_batch('menu', $data_menu);
    }

    public function down()
    {
    }
}
