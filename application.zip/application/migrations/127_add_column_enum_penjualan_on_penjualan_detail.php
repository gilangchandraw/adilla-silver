<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */

class Migration_add_column_enum_penjualan_on_penjualan_detail extends CI_Migration
{

    public function up()
    {

        $fields = array(
            'enum_penjualan' => array('type' => 'INT(40)', 'default' => NULL),
        );
        $this->dbforge->add_column('penjualan_detail', $fields);
    }


    public function down()
    {
    }
}
