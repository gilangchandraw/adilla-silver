<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_insert_operasional_kantor extends CI_Migration {


	public function up()
	{ 
		$data_menu = array(
        	array('id' => 59, 'module_id' => 1, 'name' => 'Operasional Kantor', 'url' => '#', 'parent_id' => 1, 'icon' => "fa-random", 'sequence' => 13, 'description' => 'Operasional Kantor'),
        	array('id' => 60, 'module_id' => 1, 'name' => 'Pemasukan', 'url' => 'pemasukan', 'parent_id' => 59, 'icon' => "", 'sequence' => 1, 'description' => 'Operasional Kantor - Pemasukan'),
        	array('id' => 61, 'module_id' => 1, 'name' => 'Pengeluaran', 'url' => 'pengeluaran_kantor', 'parent_id' => 59, 'icon' => "", 'sequence' => 2, 'description' => 'Operasional Kantor - Pengeluaran'),
        );
        $this->db->insert_batch('menu', $data_menu);
	 
	}


	public function down()
	{
		
	}

}