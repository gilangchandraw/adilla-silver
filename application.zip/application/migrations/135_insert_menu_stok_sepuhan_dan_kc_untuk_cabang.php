<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_insert_menu_stok_sepuhan_dan_kc_untuk_cabang extends CI_Migration {


	public function up()
	{ 
		// insert function value
        $data_menu = array(
        	array('id' => 49, 'module_id' => 1, 'name' => 'Stok Sepuhan', 'url' => 'stok_sepuhan', 'parent_id' => 38, 'icon' => "", 'sequence' => 5, 'description' => 'Logistik - Stok Sepuhan'),
        	array('id' => 50, 'module_id' => 1, 'name' => 'Stok Kotak Cincin', 'url' => 'stok_kotak_cincin', 'parent_id' => 38, 'icon' => "", 'sequence' => 6, 'description' => 'Logistik - Stok Kotak Cincin'),
        );
        $this->db->insert_batch('menu', $data_menu);
	 
	}


	public function down()
	{
		
	}

}