<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_insert_menu_laporan_untuk_logistik extends CI_Migration {


	public function up()
	{ 
		$data_menu = array(
        	array('id' => 65, 'module_id' => 1, 'name' => 'Laporan Barang Keluar', 'url' => 'laporan_barang_keluar', 'parent_id' => 35, 'icon' => "", 'sequence' => 8, 'description' => 'Laporan - Laporan Barang Keluar'),
        	array('id' => 66, 'module_id' => 1, 'name' => 'Laporan Barang Masuk', 'url' => 'laporan_barang_masuk', 'parent_id' => 35, 'icon' => "", 'sequence' => 9, 'description' => 'Laporan - Laporan Barang Masuk'),
        	array('id' => 67, 'module_id' => 1, 'name' => 'Laporan Barang Retur', 'url' => 'laporan_barang_retur', 'parent_id' => 35, 'icon' => "", 'sequence' => 10, 'description' => 'Laporan - Laporan Barang Retur'),
        );
        $this->db->insert_batch('menu', $data_menu);
	 
	}


	public function down()
	{
		
	}

}