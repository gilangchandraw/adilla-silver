<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_insert_privilleges_laporan_insentif_dan_pengeluaran_cabang extends CI_Migration {


	public function up()
	{ 
		$this->db->truncate('privilleges');
		$privilleges = array(
			array(
				"id" => 284,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 1,
			),
			array(
				"id" => 285,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 2,
			),
			array(
				"id" => 286,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 3,
			),
			array(
				"id" => 287,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 4,
			),
			array(
				"id" => 288,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 5,
			),
			array(
				"id" => 289,
				"role_id" => 4,
				"menu_id" => 35,
				"function_id" => 1,
			),
			array(
				"id" => 290,
				"role_id" => 4,
				"menu_id" => 38,
				"function_id" => 1,
			),
			array(
				"id" => 291,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 1,
			),
			array(
				"id" => 292,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 2,
			),
			array(
				"id" => 293,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 3,
			),
			array(
				"id" => 294,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 4,
			),
			array(
				"id" => 295,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 5,
			),
			array(
				"id" => 296,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 1,
			),
			array(
				"id" => 297,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 2,
			),
			array(
				"id" => 298,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 3,
			),
			array(
				"id" => 299,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 4,
			),
			array(
				"id" => 300,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 5,
			),
			array(
				"id" => 301,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 1,
			),
			array(
				"id" => 302,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 2,
			),
			array(
				"id" => 303,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 3,
			),
			array(
				"id" => 304,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 4,
			),
			array(
				"id" => 305,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 5,
			),
			array(
				"id" => 306,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 1,
			),
			array(
				"id" => 307,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 2,
			),
			array(
				"id" => 308,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 3,
			),
			array(
				"id" => 309,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 4,
			),
			array(
				"id" => 310,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 5,
			),
			array(
				"id" => 311,
				"role_id" => 4,
				"menu_id" => 44,
				"function_id" => 1,
			),
			array(
				"id" => 312,
				"role_id" => 4,
				"menu_id" => 44,
				"function_id" => 2,
			),
			array(
				"id" => 313,
				"role_id" => 4,
				"menu_id" => 44,
				"function_id" => 3,
			),
			array(
				"id" => 314,
				"role_id" => 4,
				"menu_id" => 44,
				"function_id" => 4,
			),
			array(
				"id" => 315,
				"role_id" => 4,
				"menu_id" => 44,
				"function_id" => 5,
			),
			array(
				"id" => 316,
				"role_id" => 4,
				"menu_id" => 45,
				"function_id" => 1,
			),
			array(
				"id" => 317,
				"role_id" => 4,
				"menu_id" => 45,
				"function_id" => 2,
			),
			array(
				"id" => 318,
				"role_id" => 4,
				"menu_id" => 45,
				"function_id" => 3,
			),
			array(
				"id" => 319,
				"role_id" => 4,
				"menu_id" => 45,
				"function_id" => 4,
			),
			array(
				"id" => 320,
				"role_id" => 4,
				"menu_id" => 45,
				"function_id" => 5,
			),
			array(
				"id" => 321,
				"role_id" => 4,
				"menu_id" => 47,
				"function_id" => 1,
			),
			array(
				"id" => 322,
				"role_id" => 4,
				"menu_id" => 47,
				"function_id" => 2,
			),
			array(
				"id" => 323,
				"role_id" => 4,
				"menu_id" => 47,
				"function_id" => 3,
			),
			array(
				"id" => 324,
				"role_id" => 4,
				"menu_id" => 47,
				"function_id" => 4,
			),
			array(
				"id" => 325,
				"role_id" => 4,
				"menu_id" => 47,
				"function_id" => 5,
			),
			array(
				"id" => 326,
				"role_id" => 4,
				"menu_id" => 20,
				"function_id" => 1,
			),
			array(
				"id" => 327,
				"role_id" => 4,
				"menu_id" => 20,
				"function_id" => 2,
			),
			array(
				"id" => 328,
				"role_id" => 4,
				"menu_id" => 20,
				"function_id" => 3,
			),
			array(
				"id" => 329,
				"role_id" => 4,
				"menu_id" => 20,
				"function_id" => 4,
			),
			array(
				"id" => 330,
				"role_id" => 4,
				"menu_id" => 20,
				"function_id" => 5,
			),
			array(
				"id" => 331,
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 1,
			),
			array(
				"id" => 332,
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 2,
			),
			array(
				"id" => 333,
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 3,
			),
			array(
				"id" => 334,
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 4,
			),
			array(
				"id" => 335,
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 5,
			),
			array(
				"id" => 336,
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 1,
			),
			array(
				"id" => 337,
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 2,
			),
			array(
				"id" => 338,
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 3,
			),
			array(
				"id" => 339,
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 4,
			),
			array(
				"id" => 340,
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 5,
			),
			array(
				"id" => 341,
				"role_id" => 4,
				"menu_id" => 51,
				"function_id" => 1,
			),
			array(
				"id" => 342,
				"role_id" => 4,
				"menu_id" => 51,
				"function_id" => 2,
			),
			array(
				"id" => 343,
				"role_id" => 4,
				"menu_id" => 51,
				"function_id" => 3,
			),
			array(
				"id" => 344,
				"role_id" => 4,
				"menu_id" => 51,
				"function_id" => 4,
			),
			array(
				"id" => 345,
				"role_id" => 4,
				"menu_id" => 51,
				"function_id" => 5,
			),
			array(
				"id" => 346,
				"role_id" => 4,
				"menu_id" => 52,
				"function_id" => 1,
			),
			array(
				"id" => 347,
				"role_id" => 4,
				"menu_id" => 52,
				"function_id" => 2,
			),
			array(
				"id" => 348,
				"role_id" => 4,
				"menu_id" => 52,
				"function_id" => 3,
			),
			array(
				"id" => 349,
				"role_id" => 4,
				"menu_id" => 52,
				"function_id" => 4,
			),
			array(
				"id" => 350,
				"role_id" => 4,
				"menu_id" => 52,
				"function_id" => 5,
			),
			array(
				"id" => 351,
				"role_id" => 4,
				"menu_id" => 48,
				"function_id" => 1,
			),
			array(
				"id" => 352,
				"role_id" => 4,
				"menu_id" => 48,
				"function_id" => 2,
			),
			array(
				"id" => 353,
				"role_id" => 4,
				"menu_id" => 48,
				"function_id" => 3,
			),
			array(
				"id" => 354,
				"role_id" => 4,
				"menu_id" => 48,
				"function_id" => 4,
			),
			array(
				"id" => 355,
				"role_id" => 4,
				"menu_id" => 48,
				"function_id" => 5,
			),
			array(
				"id" => 356,
				"role_id" => 4,
				"menu_id" => 49,
				"function_id" => 1,
			),
			array(
				"id" => 357,
				"role_id" => 4,
				"menu_id" => 49,
				"function_id" => 2,
			),
			array(
				"id" => 358,
				"role_id" => 4,
				"menu_id" => 49,
				"function_id" => 3,
			),
			array(
				"id" => 359,
				"role_id" => 4,
				"menu_id" => 49,
				"function_id" => 4,
			),
			array(
				"id" => 360,
				"role_id" => 4,
				"menu_id" => 49,
				"function_id" => 5,
			),
			array(
				"id" => 361,
				"role_id" => 4,
				"menu_id" => 50,
				"function_id" => 1,
			),
			array(
				"id" => 362,
				"role_id" => 4,
				"menu_id" => 50,
				"function_id" => 2,
			),
			array(
				"id" => 363,
				"role_id" => 4,
				"menu_id" => 50,
				"function_id" => 3,
			),
			array(
				"id" => 364,
				"role_id" => 4,
				"menu_id" => 50,
				"function_id" => 4,
			),
			array(
				"id" => 365,
				"role_id" => 4,
				"menu_id" => 50,
				"function_id" => 5,
			),
			array(
				"id" => 366,
				"role_id" => 4,
				"menu_id" => 1,
				"function_id" => 1,
			),
			array(
				"id" => 367,
				"role_id" => 4,
				"menu_id" => 1,
				"function_id" => 1,
			),
			array(
				"id" => 368,
				"role_id" => 4,
				"menu_id" => 15,
				"function_id" => 1,
			),
			array(
				"id" => 369,
				"role_id" => 4,
				"menu_id" => 19,
				"function_id" => 1,
			),
			array(
				"id" => 370,
				"role_id" => 4,
				"menu_id" => 35,
				"function_id" => 1,
			),
			array(
				"id" => 371,
				"role_id" => 4,
				"menu_id" => 38,
				"function_id" => 1,
			),
			array(
				"id" => 372,
				"role_id" => 4,
				"menu_id" => 1,
				"function_id" => 1,
			),
		);



		$this->db->insert_batch('privilleges', $privilleges); 
	 
	}


	public function down()
	{
		
	}

}