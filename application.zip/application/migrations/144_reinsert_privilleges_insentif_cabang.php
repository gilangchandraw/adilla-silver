<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_reinsert_privilleges_insentif_cabang extends CI_Migration {


	public function up()
	{ 
		$this->db->truncate('privilleges');
		$privilleges = array(
			array(
				"id" => 205,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 1,
			),
			array(
				"id" => 206,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 2,
			),
			array(
				"id" => 207,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 3,
			),
			array(
				"id" => 208,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 4,
			),
			array(
				"id" => 209,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 5,
			),
			array(
				"id" => 210,
				"role_id" => 4,
				"menu_id" => 35,
				"function_id" => 1,
			),
			array(
				"id" => 211,
				"role_id" => 4,
				"menu_id" => 38,
				"function_id" => 1,
			),
			array(
				"id" => 212,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 1,
			),
			array(
				"id" => 213,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 2,
			),
			array(
				"id" => 214,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 3,
			),
			array(
				"id" => 215,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 4,
			),
			array(
				"id" => 216,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 5,
			),
			array(
				"id" => 217,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 1,
			),
			array(
				"id" => 218,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 2,
			),
			array(
				"id" => 219,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 3,
			),
			array(
				"id" => 220,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 4,
			),
			array(
				"id" => 221,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 5,
			),
			array(
				"id" => 222,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 1,
			),
			array(
				"id" => 223,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 2,
			),
			array(
				"id" => 224,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 3,
			),
			array(
				"id" => 225,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 4,
			),
			array(
				"id" => 226,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 5,
			),
			array(
				"id" => 227,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 1,
			),
			array(
				"id" => 228,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 2,
			),
			array(
				"id" => 229,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 3,
			),
			array(
				"id" => 230,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 4,
			),
			array(
				"id" => 231,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 5,
			),
			array(
				"id" => 232,
				"role_id" => 4,
				"menu_id" => 44,
				"function_id" => 1,
			),
			array(
				"id" => 233,
				"role_id" => 4,
				"menu_id" => 44,
				"function_id" => 2,
			),
			array(
				"id" => 234,
				"role_id" => 4,
				"menu_id" => 44,
				"function_id" => 3,
			),
			array(
				"id" => 235,
				"role_id" => 4,
				"menu_id" => 44,
				"function_id" => 4,
			),
			array(
				"id" => 236,
				"role_id" => 4,
				"menu_id" => 44,
				"function_id" => 5,
			),
			array(
				"id" => 237,
				"role_id" => 4,
				"menu_id" => 45,
				"function_id" => 1,
			),
			array(
				"id" => 238,
				"role_id" => 4,
				"menu_id" => 45,
				"function_id" => 2,
			),
			array(
				"id" => 239,
				"role_id" => 4,
				"menu_id" => 45,
				"function_id" => 3,
			),
			array(
				"id" => 240,
				"role_id" => 4,
				"menu_id" => 45,
				"function_id" => 4,
			),
			array(
				"id" => 241,
				"role_id" => 4,
				"menu_id" => 45,
				"function_id" => 5,
			),
			array(
				"id" => 242,
				"role_id" => 4,
				"menu_id" => 47,
				"function_id" => 1,
			),
			array(
				"id" => 243,
				"role_id" => 4,
				"menu_id" => 47,
				"function_id" => 2,
			),
			array(
				"id" => 244,
				"role_id" => 4,
				"menu_id" => 47,
				"function_id" => 3,
			),
			array(
				"id" => 245,
				"role_id" => 4,
				"menu_id" => 47,
				"function_id" => 4,
			),
			array(
				"id" => 246,
				"role_id" => 4,
				"menu_id" => 47,
				"function_id" => 5,
			),
			array(
				"id" => 247,
				"role_id" => 4,
				"menu_id" => 20,
				"function_id" => 1,
			),
			array(
				"id" => 248,
				"role_id" => 4,
				"menu_id" => 20,
				"function_id" => 2,
			),
			array(
				"id" => 249,
				"role_id" => 4,
				"menu_id" => 20,
				"function_id" => 3,
			),
			array(
				"id" => 250,
				"role_id" => 4,
				"menu_id" => 20,
				"function_id" => 4,
			),
			array(
				"id" => 251,
				"role_id" => 4,
				"menu_id" => 20,
				"function_id" => 5,
			),
			array(
				"id" => 252,
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 1,
			),
			array(
				"id" => 253,
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 2,
			),
			array(
				"id" => 254,
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 3,
			),
			array(
				"id" => 255,
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 4,
			),
			array(
				"id" => 256,
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 5,
			),
			array(
				"id" => 257,
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 1,
			),
			array(
				"id" => 258,
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 2,
			),
			array(
				"id" => 259,
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 3,
			),
			array(
				"id" => 260,
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 4,
			),
			array(
				"id" => 261,
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 5,
			),
			array(
				"id" => 262,
				"role_id" => 4,
				"menu_id" => 48,
				"function_id" => 1,
			),
			array(
				"id" => 263,
				"role_id" => 4,
				"menu_id" => 48,
				"function_id" => 2,
			),
			array(
				"id" => 264,
				"role_id" => 4,
				"menu_id" => 48,
				"function_id" => 3,
			),
			array(
				"id" => 265,
				"role_id" => 4,
				"menu_id" => 48,
				"function_id" => 4,
			),
			array(
				"id" => 266,
				"role_id" => 4,
				"menu_id" => 48,
				"function_id" => 5,
			),
			array(
				"id" => 267,
				"role_id" => 4,
				"menu_id" => 49,
				"function_id" => 1,
			),
			array(
				"id" => 268,
				"role_id" => 4,
				"menu_id" => 49,
				"function_id" => 2,
			),
			array(
				"id" => 269,
				"role_id" => 4,
				"menu_id" => 49,
				"function_id" => 3,
			),
			array(
				"id" => 270,
				"role_id" => 4,
				"menu_id" => 49,
				"function_id" => 4,
			),
			array(
				"id" => 271,
				"role_id" => 4,
				"menu_id" => 49,
				"function_id" => 5,
			),
			array(
				"id" => 272,
				"role_id" => 4,
				"menu_id" => 50,
				"function_id" => 1,
			),
			array(
				"id" => 273,
				"role_id" => 4,
				"menu_id" => 50,
				"function_id" => 2,
			),
			array(
				"id" => 274,
				"role_id" => 4,
				"menu_id" => 50,
				"function_id" => 3,
			),
			array(
				"id" => 275,
				"role_id" => 4,
				"menu_id" => 50,
				"function_id" => 4,
			),
			array(
				"id" => 276,
				"role_id" => 4,
				"menu_id" => 50,
				"function_id" => 5,
			),
			array(
				"id" => 277,
				"role_id" => 4,
				"menu_id" => 1,
				"function_id" => 1,
			),
			array(
				"id" => 278,
				"role_id" => 4,
				"menu_id" => 1,
				"function_id" => 1,
			),
			array(
				"id" => 279,
				"role_id" => 4,
				"menu_id" => 15,
				"function_id" => 1,
			),
			array(
				"id" => 280,
				"role_id" => 4,
				"menu_id" => 19,
				"function_id" => 1,
			),
			array(
				"id" => 281,
				"role_id" => 4,
				"menu_id" => 35,
				"function_id" => 1,
			),
			array(
				"id" => 282,
				"role_id" => 4,
				"menu_id" => 38,
				"function_id" => 1,
			),
			array(
				"id" => 283,
				"role_id" => 4,
				"menu_id" => 1,
				"function_id" => 1,
			),
		);


		$this->db->insert_batch('privilleges', $privilleges); 
	 
	}


	public function down()
	{
		
	}

}