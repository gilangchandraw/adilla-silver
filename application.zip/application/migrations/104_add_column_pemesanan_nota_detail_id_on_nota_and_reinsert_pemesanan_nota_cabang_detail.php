<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */

class Migration_add_column_pemesanan_nota_detail_id_on_nota_and_reinsert_pemesanan_nota_cabang_detail extends CI_Migration {

	public function up()
	{ 

		$fields = array(
                'pemesanan_nota_detail_id' => array('type' => 'INT(11)','default' =>0),
		        'pemesanan_nota_cabang_id' => array('type' => 'INT(11)','default' =>0),
		);
		$this->dbforge->add_column('nota', $fields);

		//delete
		$this->dbforge->drop_table('pemesanan_nota_cabang_detail');

		$table = "pemesanan_nota_cabang_detail";
        $fields = array(
            'id'           => [
                'type'           => 'BIGINT(44)',
                'auto_increment' => TRUE,
                'unsigned'       => TRUE,
            ],
            'pemesanan_nota_cabang_id'      => [
                'type'           => 'BIGINT(44)',
                'default' => NULL,
            ],
            'pemesanan_nota_detail_id'      => [
                'type'           => 'BIGINT(44)',
                'default' => NULL,
            ],
            'updated_by'      => [
                'type' => 'INT(11)',
                'default' => 0,
            ],
            'created_by'      => [
                'type' => 'INT(11)',
                'default' => 0,
            ],
            'created_at  timestamp DEFAULT CURRENT_TIMESTAMP',
            'updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
            'is_deleted'      => [
                'type' => 'INT(11)',
                'default' => 0,
            ],

        );
        $this->dbforge->add_field($fields);
        $this->dbforge->add_key('id', TRUE);
        $this->dbforge->create_table($table);
	 
	}


	public function down()
	{
		
	}

}