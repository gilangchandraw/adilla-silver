<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_insert_menu_transaksi_supplier extends CI_Migration
{


    public function up()
    {
        // insert function value
        $data_menu = array(

            array('id' => 42, 'module_id' => 1, 'name' => 'Transaksi Supplier', 'url' => 'transaksi_supplier', 'parent_id' => 1, 'icon' => "fa fa-cart-plus", 'sequence' => 11, 'description' => 'Transaksi Supplier'),
            array('id' => 43, 'module_id' => 1, 'name' => 'Pemesanan Nota', 'url' => 'pemesanan_nota', 'parent_id' => 42, 'icon' => "", 'sequence' => 1, 'description' => 'Pemesanan Nota'),


        );
        $this->db->insert_batch('menu', $data_menu);
    }

    public function down()
    {
    }
}
