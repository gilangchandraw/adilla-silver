<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_delete_barang extends CI_Migration
{


    public function up()
    {
        $this->db->delete('barang', array('id' => 29));
        $this->db->delete('barang', array('id' => 30));
    }

    public function down()
    {
    }
}
