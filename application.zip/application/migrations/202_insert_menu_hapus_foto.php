<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_insert_menu_hapus_foto extends CI_Migration
{


    public function up()
    {
        // insert function value
        $data_menu = array(

            array('id' => 63, 'module_id' => 1, 'name' => 'Hapus Foto', 'url' => 'hapus_foto', 'parent_id' => 1, 'icon' => "fa fa-times", 'sequence' => 15, 'description' => 'Hapus Foto'),


        );
        $this->db->insert_batch('menu', $data_menu);
    }

    public function down()
    {
    }
}
