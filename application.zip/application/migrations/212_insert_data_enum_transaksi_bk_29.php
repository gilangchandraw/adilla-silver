<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_insert_data_enum_transaksi_bk_29 extends CI_Migration
{


	public function up()
	{
		// insert function value
		$data = array(
			array(
				'id' => 17, 
				'jenis_transaksi' => 'barang_kembali',
				'nama' => '29',
				'harga' => 29000
			),

		);
		$this->db->insert_batch('enum_transaksi_barang', $data);
	}

	public function down()
	{
	}
}
