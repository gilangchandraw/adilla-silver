<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_truncate_transaksi extends CI_Migration {


	public function up()
	{ 
		$this->db->truncate('barang_kembali');
		$this->db->truncate('barang_kembali_detail');
		$this->db->truncate('barang_rusak');
		$this->db->truncate('barang_hilang');
		$this->db->truncate('histori_kas');
		$this->db->truncate('histori_stok_barang');
		$this->db->truncate('nota');
		$this->db->truncate('pemesanan_nota');
		$this->db->truncate('pemesanan_nota_cabang');
		$this->db->truncate('pemesanan_nota_cabang_detail');
		$this->db->truncate('pemesanan_nota_detail');
		$this->db->truncate('penjualan');
		$this->db->truncate('penjualan_detail');
		$this->db->truncate('tukar_plus');
		$this->db->truncate('tukar_plus_detail');
	 
	}


	public function down()
	{
		
	}

}