<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_create_table_pengeluaran_detail extends CI_Migration
{


    public function up()
    {
        $table = "pengeluaran";
        $fields = array(
            'id'           => [
                'type'           => 'BIGINT(44)',
                'auto_increment' => TRUE,
                'unsigned'       => TRUE,
            ],
            'users_id'      => [
                'type' => 'INT(11)',
                'default' => NULL,
            ],
            'tanggal'      => [
                'type' => 'DATE',
                'default' => NULL,
            ],
            'total_harga_keseluruhan'      => [
                'type' => 'BIGINT(44)',
                'default' => NULL,
            ],
            'updated_by'      => [
                'type' => 'INT(11)',
                'default' => 0,
            ],
            'created_by'      => [
                'type' => 'INT(11)',
                'default' => 0,
            ],
            'created_at  timestamp DEFAULT CURRENT_TIMESTAMP',
            'updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
            'is_deleted'      => [
                'type' => 'INT(11)',
                'default' => 0,
            ],

        );
        $this->dbforge->add_field($fields);
        $this->dbforge->add_key('id', TRUE);
        $this->dbforge->create_table($table);

        $table = "pengeluaran_detail";
        $fields = array(
            'id'           => [
                'type'           => 'BIGINT(44)',
                'auto_increment' => TRUE,
                'unsigned'       => TRUE,
            ],
            'pengeluaran_id'      => [
                'type' => 'BIGINT(44)',
                'default' => NULL,
            ],
            'enum_pengeluaran_id'      => [
                'type' => 'BIGINT(44)',
                'default' => NULL,
            ],
            'harga'      => [
                'type' => 'BIGINT(44)',
                'default' => NULL,
            ],
            'updated_by'      => [
                'type' => 'INT(11)',
                'default' => 0,
            ],
            'created_by'      => [
                'type' => 'INT(11)',
                'default' => 0,
            ],
            'created_at  timestamp DEFAULT CURRENT_TIMESTAMP',
            'updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
            'is_deleted'      => [
                'type' => 'INT(11)',
                'default' => 0,
            ],

        );
        $this->dbforge->add_field($fields);
        $this->dbforge->add_key('id', TRUE);
        $this->dbforge->create_table($table);
    }


    public function down()
    {
    }
}
