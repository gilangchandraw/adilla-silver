<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_insert_privilleges_stok_kc_sepuhan_untuk_cabang extends CI_Migration {


	public function up()
	{ 
		$this->db->truncate('privilleges');
		$privilleges = array(
			array(
				"id" => 132,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 1,
			),
			array(
				"id" => 133,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 2,
			),
			array(
				"id" => 134,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 3,
			),
			array(
				"id" => 135,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 4,
			),
			array(
				"id" => 136,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 5,
			),
			array(
				"id" => 137,
				"role_id" => 4,
				"menu_id" => 35,
				"function_id" => 1,
			),
			array(
				"id" => 138,
				"role_id" => 4,
				"menu_id" => 38,
				"function_id" => 1,
			),
			array(
				"id" => 139,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 1,
			),
			array(
				"id" => 140,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 2,
			),
			array(
				"id" => 141,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 3,
			),
			array(
				"id" => 142,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 4,
			),
			array(
				"id" => 143,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 5,
			),
			array(
				"id" => 144,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 1,
			),
			array(
				"id" => 145,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 2,
			),
			array(
				"id" => 146,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 3,
			),
			array(
				"id" => 147,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 4,
			),
			array(
				"id" => 148,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 5,
			),
			array(
				"id" => 149,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 1,
			),
			array(
				"id" => 150,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 2,
			),
			array(
				"id" => 151,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 3,
			),
			array(
				"id" => 152,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 4,
			),
			array(
				"id" => 153,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 5,
			),
			array(
				"id" => 154,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 1,
			),
			array(
				"id" => 155,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 2,
			),
			array(
				"id" => 156,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 3,
			),
			array(
				"id" => 157,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 4,
			),
			array(
				"id" => 158,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 5,
			),
			array(
				"id" => 159,
				"role_id" => 4,
				"menu_id" => 44,
				"function_id" => 1,
			),
			array(
				"id" => 160,
				"role_id" => 4,
				"menu_id" => 44,
				"function_id" => 2,
			),
			array(
				"id" => 161,
				"role_id" => 4,
				"menu_id" => 44,
				"function_id" => 3,
			),
			array(
				"id" => 162,
				"role_id" => 4,
				"menu_id" => 44,
				"function_id" => 4,
			),
			array(
				"id" => 163,
				"role_id" => 4,
				"menu_id" => 44,
				"function_id" => 5,
			),
			array(
				"id" => 164,
				"role_id" => 4,
				"menu_id" => 45,
				"function_id" => 1,
			),
			array(
				"id" => 165,
				"role_id" => 4,
				"menu_id" => 45,
				"function_id" => 2,
			),
			array(
				"id" => 166,
				"role_id" => 4,
				"menu_id" => 45,
				"function_id" => 3,
			),
			array(
				"id" => 167,
				"role_id" => 4,
				"menu_id" => 45,
				"function_id" => 4,
			),
			array(
				"id" => 168,
				"role_id" => 4,
				"menu_id" => 45,
				"function_id" => 5,
			),
			array(
				"id" => 169,
				"role_id" => 4,
				"menu_id" => 47,
				"function_id" => 1,
			),
			array(
				"id" => 170,
				"role_id" => 4,
				"menu_id" => 47,
				"function_id" => 2,
			),
			array(
				"id" => 171,
				"role_id" => 4,
				"menu_id" => 47,
				"function_id" => 3,
			),
			array(
				"id" => 172,
				"role_id" => 4,
				"menu_id" => 47,
				"function_id" => 4,
			),
			array(
				"id" => 173,
				"role_id" => 4,
				"menu_id" => 47,
				"function_id" => 5,
			),
			array(
				"id" => 174,
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 1,
			),
			array(
				"id" => 175,
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 2,
			),
			array(
				"id" => 176,
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 3,
			),
			array(
				"id" => 177,
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 4,
			),
			array(
				"id" => 178,
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 5,
			),
			array(
				"id" => 179,
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 1,
			),
			array(
				"id" => 180,
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 2,
			),
			array(
				"id" => 181,
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 3,
			),
			array(
				"id" => 182,
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 4,
			),
			array(
				"id" => 183,
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 5,
			),
			array(
				"id" => 184,
				"role_id" => 4,
				"menu_id" => 48,
				"function_id" => 1,
			),
			array(
				"id" => 185,
				"role_id" => 4,
				"menu_id" => 48,
				"function_id" => 2,
			),
			array(
				"id" => 186,
				"role_id" => 4,
				"menu_id" => 48,
				"function_id" => 3,
			),
			array(
				"id" => 187,
				"role_id" => 4,
				"menu_id" => 48,
				"function_id" => 4,
			),
			array(
				"id" => 188,
				"role_id" => 4,
				"menu_id" => 48,
				"function_id" => 5,
			),
			array(
				"id" => 189,
				"role_id" => 4,
				"menu_id" => 49,
				"function_id" => 1,
			),
			array(
				"id" => 190,
				"role_id" => 4,
				"menu_id" => 49,
				"function_id" => 2,
			),
			array(
				"id" => 191,
				"role_id" => 4,
				"menu_id" => 49,
				"function_id" => 3,
			),
			array(
				"id" => 192,
				"role_id" => 4,
				"menu_id" => 49,
				"function_id" => 4,
			),
			array(
				"id" => 193,
				"role_id" => 4,
				"menu_id" => 49,
				"function_id" => 5,
			),
			array(
				"id" => 194,
				"role_id" => 4,
				"menu_id" => 50,
				"function_id" => 1,
			),
			array(
				"id" => 195,
				"role_id" => 4,
				"menu_id" => 50,
				"function_id" => 2,
			),
			array(
				"id" => 196,
				"role_id" => 4,
				"menu_id" => 50,
				"function_id" => 3,
			),
			array(
				"id" => 197,
				"role_id" => 4,
				"menu_id" => 50,
				"function_id" => 4,
			),
			array(
				"id" => 198,
				"role_id" => 4,
				"menu_id" => 50,
				"function_id" => 5,
			),
			array(
				"id" => 199,
				"role_id" => 4,
				"menu_id" => 1,
				"function_id" => 1,
			),
			array(
				"id" => 200,
				"role_id" => 4,
				"menu_id" => 1,
				"function_id" => 1,
			),
			array(
				"id" => 201,
				"role_id" => 4,
				"menu_id" => 15,
				"function_id" => 1,
			),
			array(
				"id" => 202,
				"role_id" => 4,
				"menu_id" => 35,
				"function_id" => 1,
			),
			array(
				"id" => 203,
				"role_id" => 4,
				"menu_id" => 38,
				"function_id" => 1,
			),
			array(
				"id" => 204,
				"role_id" => 4,
				"menu_id" => 1,
				"function_id" => 1,
			),
		);

		$this->db->insert_batch('privilleges', $privilleges); 
	 
	}


	public function down()
	{
		
	}

}