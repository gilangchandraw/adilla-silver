<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_add_column_potongan_on_tukar_plus_detail extends CI_Migration {


	public function up()
	{ 

		$fields = array(
		        'potongan' => array('type' => 'VARCHAR(20)','default' =>0),
		);
		$this->dbforge->add_column('tukar_plus_detail', $fields);
	 
	}


	public function down()
	{
		
	}

}