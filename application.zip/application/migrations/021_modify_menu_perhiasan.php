<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_modify_menu_perhiasan extends CI_Migration {


	public function up()
	{ 
		$this->db->delete('menu', array('id' => 10));
		$data = array(
            array('id'=>10,'module_id'=>1, 'name'=>'Barang', 'url'=>'barang', 'parent_id'=>9, 'icon'=>"", 'sequence'=>1, 'description' => 'Master Data -  Barang'),  
        );
        $this->db->insert_batch('menu', $data); 
	 
	}


	public function down()
	{
		
	}

}