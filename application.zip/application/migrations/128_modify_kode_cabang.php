<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_modify_kode_cabang extends CI_Migration
{


    public function up()
    {
        $this->dbforge->drop_column('cabang', 'kas_awal');
        $this->db->truncate('cabang');
        $cabang = array(
            array(
                "id" => 1,
                "kode_cabang" => "BJR-1",
                "nama_cabang" => "Banjaran Pasar",
                "alamat" => "Pasar Banjaran Kios No. 419 - Bandung",
                "updated_by" => 1,
                "created_by" => 0,
                "created_at" => "2020-04-27 12:30:47",
                "updated_at" => "2020-04-27 12:31:10",
                "is_deleted" => 0,
                "kas" => 0,
                "users_id" => 2,
                "stok_925" => 0,
                "stok_sp" => 0,
            ),
            array(
                "id" => 2,
                "kode_cabang" => "BJR-2",
                "nama_cabang" => "Banjaran 2",
                "alamat" => "Jln. Raya Banjaran No.195 - Bandung",
                "updated_by" => 1,
                "created_by" => 0,
                "created_at" => "2020-04-27 12:30:47",
                "updated_at" => "2020-04-27 12:31:33",
                "is_deleted" => 0,
                "kas" => 0,
                "users_id" => 3,
                "stok_925" => 0,
                "stok_sp" => 0,
            ),
            array(
                "id" => 3,
                "kode_cabang" => "CRJG",
                "nama_cabang" => "Ciranjang",
                "alamat" => "Pasar Ciranjang - Cianjur",
                "updated_by" => 1,
                "created_by" => 0,
                "created_at" => "2020-04-27 12:30:47",
                "updated_at" => "2020-04-27 12:31:47",
                "is_deleted" => 0,
                "kas" => 0,
                "users_id" => 6,
                "stok_925" => 0,
                "stok_sp" => 0,
            ),
            array(
                "id" => 4,
                "kode_cabang" => "PSB",
                "nama_cabang" => "Pasar Baru",
                "alamat" => "Pasar Baru Trade Cender Lt. Dasar Blok M, No.21 (Pintu Samping)",
                "updated_by" => 1,
                "created_by" => 0,
                "created_at" => "2020-04-27 12:30:47",
                "updated_at" => "2020-04-27 12:32:04",
                "is_deleted" => 0,
                "kas" => 0,
                "users_id" => 11,
                "stok_925" => 0,
                "stok_sp" => 0,
            ),
            array(
                "id" => 5,
                "kode_cabang" => "CMD",
                "nama_cabang" => "Cimindi",
                "alamat" => "Jln. Maharmartanegara No. 8 A rt 04 rw 15 Kecamatan Cimahi Tengah - Kota Cimahi",
                "updated_by" => 1,
                "created_by" => 0,
                "created_at" => "2020-04-27 12:30:47",
                "updated_at" => "2020-04-27 12:32:13",
                "is_deleted" => 0,
                "kas" => 0,
                "users_id" => 5,
                "stok_925" => 0,
                "stok_sp" => 0,
            ),
            array(
                "id" => 6,
                "kode_cabang" => "PDLG-1",
                "nama_cabang" => "Padalarang 1",
                "alamat" => "Jln. Raya Purwakarta No.18 Padalarang - Bandung",
                "updated_by" => 1,
                "created_by" => 0,
                "created_at" => "2020-04-27 12:30:47",
                "updated_at" => "2020-04-27 12:32:23",
                "is_deleted" => 0,
                "kas" => 0,
                "users_id" => 9,
                "stok_925" => 0,
                "stok_sp" => 0,
            ),
            array(
                "id" => 7,
                "kode_cabang" => "BTJR",
                "nama_cabang" => "Batujajar",
                "alamat" => "Jln. Raya Batujajar No.3 Bandung",
                "updated_by" => 1,
                "created_by" => 0,
                "created_at" => "2020-04-27 12:30:47",
                "updated_at" => "2020-04-27 12:32:45",
                "is_deleted" => 0,
                "kas" => 0,
                "users_id" => 4,
                "stok_925" => 0,
                "stok_sp" => 0,
            ),
            array(
                "id" => 8,
                "kode_cabang" => "MJL-2",
                "nama_cabang" => "Majalaya 2",
                "alamat" => "Jln. Alun-Alun Utara No.23 - Majalaya",
                "updated_by" => 1,
                "created_by" => 0,
                "created_at" => "2020-04-27 12:30:47",
                "updated_at" => "2020-04-27 12:33:27",
                "is_deleted" => 0,
                "kas" => 0,
                "users_id" => 8,
                "stok_925" => 0,
                "stok_sp" => 0,
            ),
            array(
                "id" => 9,
                "kode_cabang" => "MJL-1",
                "nama_cabang" => "Majalaya 1",
                "alamat" => "Jln. Alun-Alun Utara No.57 - Majalaya",
                "updated_by" => 1,
                "created_by" => 0,
                "created_at" => "2020-04-27 12:30:47",
                "updated_at" => "2020-04-27 12:33:35",
                "is_deleted" => 0,
                "kas" => 0,
                "users_id" => 7,
                "stok_925" => 0,
                "stok_sp" => 0,
            ),
            array(
                "id" => 10,
                "kode_cabang" => "PDLG-2",
                "nama_cabang" => "Padalarang 2",
                "alamat" => "Jln.Raya Tagog No.530 - Padalarang",
                "updated_by" => 1,
                "created_by" => 0,
                "created_at" => "2020-04-27 12:30:47",
                "updated_at" => "2020-04-27 12:33:46",
                "is_deleted" => 0,
                "kas" => 0,
                "users_id" => 10,
                "stok_925" => 0,
                "stok_sp" => 0,
            ),
        );
        $this->db->insert_batch('cabang', $cabang);
    }


    public function down()
    {
    }
}
