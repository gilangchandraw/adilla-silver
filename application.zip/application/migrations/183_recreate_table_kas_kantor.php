<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_recreate_table_kas_kantor extends CI_Migration
{


	public function up()
	{
		$this->dbforge->drop_table('kas_kantor');
		$table = "kas_kantor";
		$fields = array(
			'id'           => [
                'type'           => 'BIGINT(44)',
                'auto_increment' => TRUE,
                'unsigned'       => TRUE,
            ],
			'kas_sepuhan'      => [
				'type' => 'DECIMAL(40)',
				'default' => 0,
			],
			'kas_kotak_cincin'      => [
				'type' => 'DECIMAL(40)',
				'default' => 0,
			],
			'kas_patrian'      => [
				'type' => 'DECIMAL(40)',
				'default' => 0,
			],

			'kas_setor_kantor'      => [
				'type' => 'DECIMAL(40)',
				'default' => 0,
			],
			'kas_bayar_barang'      => [
				'type' => 'DECIMAL(40)',
				'default' => 0,
			],
			'kas_baju_ciranjang'      => [
				'type' => 'DECIMAL(40)',
				'default' => 0,
			],
			'kas_baju_banjaran'      => [
				'type' => 'DECIMAL(40)',
				'default' => 0,
			],
			'kas_krw_uda'      => [
				'type' => 'DECIMAL(40)',
				'default' => 0,
			],
			'kas_kontrak_toko'      => [
				'type' => 'DECIMAL(40)',
				'default' => 0,
			],
			'kas_kantor'      => [
				'type' => 'DECIMAL(40)',
				'default' => 0,
			],
			'kas_mobil'      => [
				'type' => 'DECIMAL(40)',
				'default' => 0,
			],
			'kas_dll'      => [
				'type' => 'DECIMAL(40)',
				'default' => 0,
			],
			'total_kas'      => [
				'type' => 'DECIMAL(40)',
				'default' => 0,
			],
			'created_at  timestamp DEFAULT CURRENT_TIMESTAMP',
            'updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',

		);
		$this->dbforge->add_field($fields);
		$this->dbforge->add_key('id', TRUE);
		$this->dbforge->create_table($table);

		$datakas = array(
        	array('kas_sepuhan' => 0),
        );
        $this->db->insert_batch('kas_kantor', $datakas);
	}


	public function down()
	{
	}
}
