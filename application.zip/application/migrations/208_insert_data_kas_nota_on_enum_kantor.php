<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_insert_data_kas_nota_on_enum_kantor extends CI_Migration
{


    public function up()
    {
        $data = array(
            'id' => 13,
            'nama' => 'Kas Nota',
        );
        $this->db->insert('enum_kantor', $data);
    }
    public function down()
    {
    }
}
