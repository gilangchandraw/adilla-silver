<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_add_column_plus_on_tukar_plus_detail extends CI_Migration
{


    public function up()
    {

        $fields = array(
            'berat_plus'      => ['type' => 'DECIMAL(20,2)', 'default' => 0,],
            'harga_plus'      => ['type' => 'BIGINT(44)', 'default' => 0,],
        );
        $this->dbforge->add_column('tukar_plus_detail', $fields);
    }


    public function down()
    {
    }
}
