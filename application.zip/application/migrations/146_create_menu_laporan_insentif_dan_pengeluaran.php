<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_create_menu_laporan_insentif_dan_pengeluaran extends CI_Migration
{


    public function up()
    {
        // insert function value
        $data_menu = array(
        array('id' => 51, 'module_id' => 1, 'name' => 'Laporan Insentif', 'url' => 'laporan_insentif', 'parent_id' => 35, 'icon' => "", 'sequence' => 3, 'description' => 'Laporan -  Insentif'),
        array('id' => 52, 'module_id' => 1, 'name' => 'Laporan Pengeluaran', 'url' => 'laporan_pengeluaran', 'parent_id' => 35, 'icon' => "", 'sequence' => 3, 'description' => 'Laporan -  pengeluaran'),
        );
        $this->db->insert_batch('menu', $data_menu);
    }

    public function down()
    {
    }
}
