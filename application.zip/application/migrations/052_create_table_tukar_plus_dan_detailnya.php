<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_create_table_tukar_plus_dan_detailnya extends CI_Migration
{


    public function up()
    {
        $table = "tukar_plus";
        $fields = array(
            'id'           => [
                'type'           => 'BIGINT(44)',
                'auto_increment' => TRUE,
                'unsigned'       => TRUE,
            ],
            'users_id'      => [
                'type' => 'INT(11)',
                'default' => NULL,
            ],
            'tanggal'      => [
                'type' => 'DATE',
                'default' => NULL,
            ],
            'jumlah_transaksi'      => [
                'type' => 'INT(11)',
                'default' => NULL,
            ],
            'total_berat'      => [
                'type' => 'DECIMAL(20,2)',
                'default' => NULL,
            ],
            'total_harga_keseluruhan'      => [
                'type' => 'BIGINT(44)',
                'default' => NULL,
            ],
            'updated_by'      => [
                'type' => 'INT(11)',
                'default' => 0,
            ],
            'created_by'      => [
                'type' => 'INT(11)',
                'default' => 0,
            ],
            'created_at  timestamp DEFAULT CURRENT_TIMESTAMP',
            'updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
            'is_deleted'      => [
                'type' => 'INT(11)',
                'default' => 0,
            ],

        );
        $this->dbforge->add_field($fields);
        $this->dbforge->add_key('id', TRUE);
        $this->dbforge->create_table($table);

        $table = "tukar_plus_detail";
        $fields = array(
            'id'           => [
                'type'           => 'BIGINT(44)',
                'auto_increment' => TRUE,
                'unsigned'       => TRUE,
            ],
            'tukar_plus_id'      => [
                'type' => 'BIGINT(44)',
                'default' => NULL,
            ],
            'karyawan_id'      => [
                'type' => 'BIGINT(44)',
                'default' => NULL,
            ],
            'no_nota'      => [
                'type' => 'VARCHAR(50)',
                'default' => NULL,
            ],
            'jenis_transaksi_id'      => [
                'type' => 'INT(11)',
                'default' => NULL,
            ],
            'barang_id'      => [
                'type' => 'INT(11)',
                'default' => NULL,
            ],
            'berat'      => [
                'type' => 'DECIMAL(20,2)',
                'default' => NULL,
            ],
            'potong'      => [
                'type' => 'BIGINT(44)',
                'default' => NULL,
            ],
            'harga'      => [
                'type' => 'BIGINT(44)',
                'default' => NULL,
            ],
            'updated_by'      => [
                'type' => 'INT(11)',
                'default' => 0,
            ],
            'created_by'      => [
                'type' => 'INT(11)',
                'default' => 0,
            ],
            'created_at  timestamp DEFAULT CURRENT_TIMESTAMP',
            'updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
            'is_deleted'      => [
                'type' => 'INT(11)',
                'default' => 0,
            ],

        );
        $this->dbforge->add_field($fields);
        $this->dbforge->add_key('id', TRUE);
        $this->dbforge->create_table($table);
    }


    public function down()
    {
    }
}
