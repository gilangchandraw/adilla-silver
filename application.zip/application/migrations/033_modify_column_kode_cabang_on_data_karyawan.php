<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_modify_column_kode_cabang_on_data_karyawan extends CI_Migration {


	public function up()
	{ 
		$this->dbforge->drop_column('data_karyawan', 'kode_cabang');
		$fields = array(
		        'users_id' => array('type' => 'INT(11)','default' =>NULL),
		);
		$this->dbforge->add_column('data_karyawan', $fields);
	 
	}


	public function down()
	{
		
	}

}