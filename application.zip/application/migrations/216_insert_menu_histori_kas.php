<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_insert_menu_histori_kas extends CI_Migration {


	public function up()
	{ 
		$data_menu = array(
        	array('id' => 64, 'module_id' => 1, 'name' => 'Histori Kas', 'url' => 'histori_kas', 'parent_id' => 1, 'icon' => "fa-wallet", 'sequence' => 16, 'description' => 'Histori Kas'),
        );
        $this->db->insert_batch('menu', $data_menu);
	 
	}


	public function down()
	{
		
	}

}