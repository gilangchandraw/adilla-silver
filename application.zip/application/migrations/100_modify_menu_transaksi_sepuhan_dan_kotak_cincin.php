<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_modify_menu_transaksi_sepuhan_dan_kotak_cincin extends CI_Migration
{


    public function up()
    {
        $this->db->delete('menu', array('id' => 44));
        $this->db->delete('menu', array('id' => 45));
        $this->db->delete('menu', array('id' => 46));
        $this->db->delete('menu', array('id' => 47));
        $this->db->delete('menu', array('id' => 48));
        // insert function value
        $data_menu = array(

            array('id' => 44, 'module_id' => 1, 'name' => 'Transaksi Sepuhan', 'url' => 'transaksi_sepuhan', 'parent_id' => 15, 'icon' => "", 'sequence' => 5, 'description' => 'Transaksi Sepuhan'),
            array('id' => 45, 'module_id' => 1, 'name' => 'Transaksi Kotak Cincin', 'url' => 'transaksi_kotak_cincin', 'parent_id' => 15, 'icon' => "", 'sequence' => 6, 'description' => 'Transaksi Kotak Cincin'),


        );
        $this->db->insert_batch('menu', $data_menu);
    }

    public function down()
    {
    }
}
