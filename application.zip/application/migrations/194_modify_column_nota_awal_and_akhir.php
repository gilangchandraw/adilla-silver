<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_modify_column_nota_awal_and_akhir extends CI_Migration {


	public function up()
	{ 
		$fields = array(
	        'no_nota_awal' => array(
	                'name' => 'no_nota_awal',
	                'type' => 'TEXT',
	        ),
		);
		$this->dbforge->modify_column('insentif_detail', $fields);

		$fields_2 = array(
	        'no_nota_akhir' => array(
	                'name' => 'no_nota_akhir',
	                'type' => 'TEXT',
	        ),
		);
		$this->dbforge->modify_column('insentif_detail', $fields_2);
	 
	}


	public function down()
	{
		
	}

}