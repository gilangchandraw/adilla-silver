<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_reinsert_data_karyawan_menu extends CI_Migration
{


    public function up()
    {
        $this->db->delete('menu', array('id' => 14));
        // insert function value
        $data_menu = array(
            array('id' => 14, 'module_id' => 1, 'name' => 'Data Karyawan', 'url' => 'data_karyawan', 'parent_id' => 1, 'icon' => "fa-user", 'sequence'  => 5, 'description' => 'Data Karyawan'),

        );
        $this->db->insert_batch('menu', $data_menu);
    }

    public function down()
    {
    }
}
