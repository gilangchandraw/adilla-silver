<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_modify_data_dll_enum_pengeluaran extends CI_Migration
{


    public function up()
    {
        $this->db->delete('enum_pengeluaran', array('id' => 11));
        // insert function value
        $data = array(
            array('id' => 11, 'nama' => 'BIAYA TIDAK TERDUGA'),
            
        );
        $this->db->insert_batch('enum_pengeluaran', $data);
    }

    public function down()
    {
    }
}
