<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_create_table_stok_sepuhan_dan_kotak_cincin extends CI_Migration
{


    public function up()
    {

        $table = "stok_sepuhan_cabang";
        $fields = array(
            'id'           => [
                'type'           => 'BIGINT(44)',
                'auto_increment' => TRUE,
                'unsigned'       => TRUE,
            ],
            'cabang_id'      => [
                'type' => 'BIGINT(44)',
                'default' => NULL,
            ],
            'sepuhan_id'      => [
                'type' => 'BIGINT(44)',
                'default' => NULL,
            ],
            'stok'      => [
                'type' => 'VARCHAR(50)',
                'default' => 0,
            ],
            'updated_by'      => [
                'type' => 'INT(11)',
                'default' => 0,
            ],
            'created_by'      => [
                'type' => 'INT(11)',
                'default' => 0,
            ],
            'created_at  timestamp DEFAULT CURRENT_TIMESTAMP',
            'updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
            'is_deleted'      => [
                'type' => 'INT(11)',
                'default' => 0,
            ],

        );
        $this->dbforge->add_field($fields);
        $this->dbforge->add_key('id', TRUE);
        $this->dbforge->create_table($table);

        $table = "stok_kotak_cincin_cabang";
        $fields = array(
            'id'           => [
                'type'           => 'BIGINT(44)',
                'auto_increment' => TRUE,
                'unsigned'       => TRUE,
            ],
            'cabang_id'      => [
                'type' => 'BIGINT(44)',
                'default' => NULL,
            ],
            'kotak_cincin_id'      => [
                'type' => 'BIGINT(44)',
                'default' => NULL,
            ],
            'stok'      => [
                'type' => 'VARCHAR(50)',
                'default' => 0,
            ],
            'updated_by'      => [
                'type' => 'INT(11)',
                'default' => 0,
            ],
            'created_by'      => [
                'type' => 'INT(11)',
                'default' => 0,
            ],
            'created_at  timestamp DEFAULT CURRENT_TIMESTAMP',
            'updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP',
            'is_deleted'      => [
                'type' => 'INT(11)',
                'default' => 0,
            ],

        );
        $this->dbforge->add_field($fields);
        $this->dbforge->add_key('id', TRUE);
        $this->dbforge->create_table($table);
    }



    public function down()
    {
    }
}
