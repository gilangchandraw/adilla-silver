<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_add_column_status_audit_on_penjualan extends CI_Migration
{


    public function up()
    {

        $fields = array(
            'status_audit'      => ['type' => 'INT(5)', 'default' => 0],            
        );
        $this->dbforge->add_column('penjualan', $fields);
        $this->dbforge->add_column('barang_kembali', $fields);
        $this->dbforge->add_column('tukar_plus', $fields);
        $this->dbforge->add_column('pengeluaran', $fields);
    }


    public function down()
    {
    }
}
