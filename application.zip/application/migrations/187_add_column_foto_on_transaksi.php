<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_add_column_foto_on_transaksi extends CI_Migration {


	public function up()
	{ 

		$fields = array(
		        'foto' => array('type' => 'TEXT','default' =>NULL),
		);
		$this->dbforge->add_column('penjualan_detail', $fields);
		$this->dbforge->add_column('tukar_plus_detail', $fields);
	 
	}


	public function down()
	{
		
	}

}