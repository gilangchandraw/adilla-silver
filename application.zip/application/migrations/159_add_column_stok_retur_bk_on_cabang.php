<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_add_column_stok_retur_bk_on_cabang extends CI_Migration
{


    public function up()
    {

        $fields = array(
            'stok_retur_bk_925'      => ['type' => 'DECIMAL(20,2)', 'default' => 0],
            'stok_retur_pajang_925'      => ['type' => 'DECIMAL(20,2)', 'default' => 0],
            'stok_retur_bk_sp'      => ['type' => 'DECIMAL(20,2)', 'default' => 0],
            'stok_retur_pajang_sp'      => ['type' => 'DECIMAL(20,2)', 'default' => 0],
        );
        $this->dbforge->add_column('cabang', $fields);
    }


    public function down()
    {
    }
}
