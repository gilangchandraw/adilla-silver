<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_privileges_cabang extends CI_Migration {


	public function up()
	{ 
		$this->db->truncate('privilleges');
		$privilleges = array(
			array(
				"id" => 1,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 1,
			),
			array(
				"id" => 2,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 2,
			),
			array(
				"id" => 3,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 3,
			),
			array(
				"id" => 4,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 4,
			),
			array(
				"id" => 5,
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 5,
			),
			array(
				"id" => 6,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 1,
			),
			array(
				"id" => 7,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 2,
			),
			array(
				"id" => 8,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 3,
			),
			array(
				"id" => 9,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 4,
			),
			array(
				"id" => 10,
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 5,
			),
			array(
				"id" => 11,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 1,
			),
			array(
				"id" => 12,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 2,
			),
			array(
				"id" => 13,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 3,
			),
			array(
				"id" => 14,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 4,
			),
			array(
				"id" => 15,
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 5,
			),
			array(
				"id" => 16,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 1,
			),
			array(
				"id" => 17,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 2,
			),
			array(
				"id" => 18,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 3,
			),
			array(
				"id" => 19,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 4,
			),
			array(
				"id" => 20,
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 5,
			),
			array(
				"id" => 21,
				"role_id" => 4,
				"menu_id" => 20,
				"function_id" => 1,
			),
			array(
				"id" => 22,
				"role_id" => 4,
				"menu_id" => 20,
				"function_id" => 2,
			),
			array(
				"id" => 23,
				"role_id" => 4,
				"menu_id" => 20,
				"function_id" => 3,
			),
			array(
				"id" => 24,
				"role_id" => 4,
				"menu_id" => 20,
				"function_id" => 4,
			),
			array(
				"id" => 25,
				"role_id" => 4,
				"menu_id" => 20,
				"function_id" => 5,
			),
			array(
				"id" => 26,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 1,
			),
			array(
				"id" => 27,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 2,
			),
			array(
				"id" => 28,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 3,
			),
			array(
				"id" => 29,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 4,
			),
			array(
				"id" => 30,
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 5,
			),
			array(
				"id" => 31,
				"role_id" => 4,
				"menu_id" => 22,
				"function_id" => 1,
			),
			array(
				"id" => 32,
				"role_id" => 4,
				"menu_id" => 22,
				"function_id" => 2,
			),
			array(
				"id" => 33,
				"role_id" => 4,
				"menu_id" => 22,
				"function_id" => 3,
			),
			array(
				"id" => 34,
				"role_id" => 4,
				"menu_id" => 22,
				"function_id" => 4,
			),
			array(
				"id" => 35,
				"role_id" => 4,
				"menu_id" => 22,
				"function_id" => 5,
			),
			array(
				"id" => 36,
				"role_id" => 4,
				"menu_id" => 23,
				"function_id" => 1,
			),
			array(
				"id" => 37,
				"role_id" => 4,
				"menu_id" => 23,
				"function_id" => 2,
			),
			array(
				"id" => 38,
				"role_id" => 4,
				"menu_id" => 23,
				"function_id" => 3,
			),
			array(
				"id" => 39,
				"role_id" => 4,
				"menu_id" => 23,
				"function_id" => 4,
			),
			array(
				"id" => 40,
				"role_id" => 4,
				"menu_id" => 23,
				"function_id" => 5,
			),
			array(
				"id" => 41,
				"role_id" => 4,
				"menu_id" => 25,
				"function_id" => 1,
			),
			array(
				"id" => 42,
				"role_id" => 4,
				"menu_id" => 25,
				"function_id" => 2,
			),
			array(
				"id" => 43,
				"role_id" => 4,
				"menu_id" => 25,
				"function_id" => 3,
			),
			array(
				"id" => 44,
				"role_id" => 4,
				"menu_id" => 25,
				"function_id" => 4,
			),
			array(
				"id" => 45,
				"role_id" => 4,
				"menu_id" => 25,
				"function_id" => 5,
			),
			array(
				"id" => 46,
				"role_id" => 4,
				"menu_id" => 26,
				"function_id" => 1,
			),
			array(
				"id" => 47,
				"role_id" => 4,
				"menu_id" => 26,
				"function_id" => 2,
			),
			array(
				"id" => 48,
				"role_id" => 4,
				"menu_id" => 26,
				"function_id" => 3,
			),
			array(
				"id" => 49,
				"role_id" => 4,
				"menu_id" => 26,
				"function_id" => 4,
			),
			array(
				"id" => 50,
				"role_id" => 4,
				"menu_id" => 26,
				"function_id" => 5,
			),
			array(
				"id" => 51,
				"role_id" => 4,
				"menu_id" => 1,
				"function_id" => 1,
			),
			array(
				"id" => 52,
				"role_id" => 4,
				"menu_id" => 1,
				"function_id" => 1,
			),
			array(
				"id" => 53,
				"role_id" => 4,
				"menu_id" => 15,
				"function_id" => 1,
			),
			array(
				"id" => 54,
				"role_id" => 4,
				"menu_id" => 19,
				"function_id" => 1,
			),
			array(
				"id" => 55,
				"role_id" => 4,
				"menu_id" => 24,
				"function_id" => 1,
			),
			array(
				"id" => 56,
				"role_id" => 4,
				"menu_id" => 1,
				"function_id" => 1,
			),
		);

		$this->db->insert_batch('privilleges', $privilleges); 
	 
	}


	public function down()
	{
		
	}

}