<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_modify_role_cabang extends CI_Migration {


	public function up()
	{
		$this->db->delete('roles', array('id' => 4));
		$this->db->delete('roles', array('id' => 2));
		// insert function value
		 $data_role = array(
            array('id'=> 4, 'name'=>'Kasir Cabang', 'description'=> 'Kasir Cabang', 'is_deleted' => 0, 'group_id' => 0),
            array('id'=> 2, 'name'=>'Pimpinan', 'description'=> 'Pimpinan', 'is_deleted' => 0, 'group_id' => 0),
            
        );
        $this->db->insert_batch('roles', $data_role);
	}

	public function down()
	{

	}

}
