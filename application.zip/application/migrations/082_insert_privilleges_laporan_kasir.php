<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_insert_privilleges_laporan_kasir extends CI_Migration {


	public function up()
	{ 
		$this->db->truncate('privilleges');
		$privilleges = array(
			array(
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 1,
			),
			array(
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 2,
			),
			array(
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 3,
			),
			array(
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 4,
			),
			array(
				"role_id" => 4,
				"menu_id" => 14,
				"function_id" => 5,
			),
			array(
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 1,
			),
			array(
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 2,
			),
			array(
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 3,
			),
			array(
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 4,
			),
			array(
				"role_id" => 4,
				"menu_id" => 16,
				"function_id" => 5,
			),
			array(
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 1,
			),
			array(
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 2,
			),
			array(
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 3,
			),
			array(
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 4,
			),
			array(
				"role_id" => 4,
				"menu_id" => 17,
				"function_id" => 5,
			),
			array(
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 1,
			),
			array(
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 2,
			),
			array(
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 3,
			),
			array(
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 4,
			),
			array(
				"role_id" => 4,
				"menu_id" => 18,
				"function_id" => 5,
			),
			array(
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 1,
			),
			array(
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 2,
			),
			array(
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 3,
			),
			array(
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 4,
			),
			array(
				"role_id" => 4,
				"menu_id" => 21,
				"function_id" => 5,
			),
			array(
				"role_id" => 4,
				"menu_id" => 20,
				"function_id" => 1,
			),
			array(
				"role_id" => 4,
				"menu_id" => 20,
				"function_id" => 2,
			),
			array(
				"role_id" => 4,
				"menu_id" => 20,
				"function_id" => 3,
			),
			array(
				"role_id" => 4,
				"menu_id" => 20,
				"function_id" => 4,
			),
			array(
				"role_id" => 4,
				"menu_id" => 20,
				"function_id" => 5,
			),
			array(
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 1,
			),
			array(
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 2,
			),
			array(
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 3,
			),
			array(
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 4,
			),
			array(
				"role_id" => 4,
				"menu_id" => 36,
				"function_id" => 5,
			),
			array(
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 1,
			),
			array(
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 2,
			),
			array(
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 3,
			),
			array(
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 4,
			),
			array(
				"role_id" => 4,
				"menu_id" => 37,
				"function_id" => 5,
			),
			array(
				"role_id" => 4,
				"menu_id" => 1,
				"function_id" => 1,
			),
			array(
				"role_id" => 4,
				"menu_id" => 1,
				"function_id" => 1,
			),
			array(
				"role_id" => 4,
				"menu_id" => 15,
				"function_id" => 1,
			),
			array(
				"role_id" => 4,
				"menu_id" => 19,
				"function_id" => 1,
			),
			array(
				"role_id" => 4,
				"menu_id" => 35,
				"function_id" => 1,
			),
			array(
				"role_id" => 4,
				"menu_id" => 1,
				"function_id" => 1,
			),
		);

		$this->db->insert_batch('privilleges', $privilleges); 
	 
	}


	public function down()
	{
		
	}

}