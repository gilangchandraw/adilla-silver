<?php

/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */
class Migration_create_menu_laporan_sepuhan extends CI_Migration
{


    public function up()
    {
        // insert function value
        $data_menu = array(



            array('id' => 53, 'module_id' => 1, 'name' => 'Laporan Sepuhan', 'url' => 'laporan_sepuhan', 'parent_id' => 35, 'icon' => "", 'sequence' => 5, 'description' => 'Laporan Sepuhan'),


        );
        $this->db->insert_batch('menu', $data_menu);
    }

    public function down()
    {
    }
}
