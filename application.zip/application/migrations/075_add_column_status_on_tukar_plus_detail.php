<?php
/**
 * @author   Natan Felles <natanfelles@gmail.com>
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Class Migration_create_table_api_limits
 *
 * @property CI_DB_forge         $dbforge
 * @property CI_DB_query_builder $db
 */

class Migration_add_column_status_on_tukar_plus_detail extends CI_Migration {

	public function up()
	{ 

		$fields = array(
		        'status' => array('type' => 'VARCHAR(30)','default' =>NULL),
		);
		$this->dbforge->add_column('tukar_plus_detail', $fields);
		$this->dbforge->drop_column('penjualan_detail', 'enum_tukar');

	 
	}


	public function down()
	{
		
	}

}