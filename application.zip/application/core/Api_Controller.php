<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require(APPPATH.'/libraries/REST_Controller.php');
use Restserver\Libraries\REST_Controller;
require APPPATH . 'libraries/Format.php';

class Api_Controller extends REST_Controller {
    protected $useAPIKEY = TRUE;

 	public function __construct()
	{
		parent::__construct();
        if ($this->useAPIKEY === TRUE)
        {
            if (!$this->_detect_api_key())
            {
                return $this->response(['status' => FALSE, 'message' => 'API key tidak sesuai'], parent::HTTP_OK);
            }
        }
	}

}