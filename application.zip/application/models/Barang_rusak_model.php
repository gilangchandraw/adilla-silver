<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Barang_rusak_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}
	public function getAllById($where = array())
	{
		$this->db->select("
			barang_rusak.*,		
			data_karyawan.nama_karyawan as nama_karyawan, 
			enum_transaksi_barang.nama as nama_jenis,
			barang.nama_barang as nama_barang,
			cabang.nama_cabang as nama_cabang,
			")->from("barang_rusak");
		$this->db->join("data_karyawan", "data_karyawan.id = barang_rusak.karyawan_id", "left");
		$this->db->join("enum_transaksi_barang", "enum_transaksi_barang.id = barang_rusak.jenis_transaksi_id", "left");
		$this->db->join("barang", "barang.id = barang_rusak.barang_id", "left");
		$this->db->join("cabang", "cabang.id = barang_rusak.cabang_id_asal", "left");
		$this->db->where($where);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result();
		}
		return FALSE;
	}

	public function sum($where = array())
	{
		$this->db->select("SUM(barang_rusak.berat) as berat, SUM(barang_rusak.potongan_rusak) as harga,")->from("barang_rusak");
		$this->db->where($where);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->row();
		}
		return FALSE;
	}

	public function getOneBy($where = array())
	{
		$this->db->select("
			barang_rusak.*,		
			data_karyawan.nama_karyawan as nama_karyawan, 
			enum_transaksi_barang.nama as nama_jenis,
			barang.nama_barang as nama_barang,
			cabang.nama_cabang as nama_cabang,
			")->from("barang_rusak");
		$this->db->join("data_karyawan", "data_karyawan.id = barang_rusak.karyawan_id", "left");
		$this->db->join("enum_transaksi_barang", "enum_transaksi_barang.id = barang_rusak.jenis_transaksi_id", "left");
		$this->db->join("barang", "barang.id = barang_rusak.barang_id", "left");
		$this->db->join("cabang", "cabang.id = barang_rusak.cabang_id_asal", "left");
		$this->db->where($where);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->row();
		}
		return FALSE;
	}

	public function insert($data)
	{
		$this->db->insert('barang_rusak', $data);
		return $this->db->insert_id();
	}

	public function update($data, $where)
	{
		$this->db->update('barang_rusak', $data, $where);
		return $this->db->affected_rows();
	}

	public function delete($where)
	{
		$this->db->where($where);
		$this->db->delete('barang_rusak');
		if ($this->db->affected_rows()) {
			return TRUE;
		}
		return FALSE;
	}

	function getAllBy($limit, $start, $search, $col, $dir, $where = array())
	{
		$this->db->select("barang_rusak.*")->from("barang_rusak");
		$this->db->limit($limit, $start)->order_by($col, $dir);
		$this->db->where($where);
		if (!empty($search)) {
			foreach ($search as $key => $value) {
				$this->db->or_like($key, $value);
			}
		}
		$result = $this->db->get();
		if ($result->num_rows() > 0) {
			return $result->result();
		} else {
			return null;
		}
	}

	function getCountAllBy($limit, $start, $search, $order, $dir, $where = array())
	{
		$this->db->select("barang_rusak.*")->from("barang_rusak");
		$this->db->where($where);
		if (!empty($search)) {
			foreach ($search as $key => $value) {
				$this->db->or_like($key, $value);
			}
		}

		$result = $this->db->get();

		return $result->num_rows();
	}
}
