<?php 
defined('BASEPATH') OR exit('No direct script access allowed'); 
class Penjualan_detail_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct(); 
	}  
	public function getAllById($where = array()){
		$this->db->select("
			penjualan_detail.*,
			data_karyawan.nama_karyawan as nama_karyawan, 
			penjualan_detail.no_nota as no_nota,
			enum_transaksi_barang.nama as nama_jenis,
			enum_transaksi_barang.harga as harga_jenis,
			barang.nama_barang as nama_barang,
			barang.jenis as jenis_barang,
			cabang.nama_cabang as nama_cabang,
			")->from("penjualan_detail"); 
		$this->db->join("data_karyawan","data_karyawan.id = penjualan_detail.karyawan_id","left");
		$this->db->join("enum_transaksi_barang","enum_transaksi_barang.id = penjualan_detail.jenis_transaksi_id","left");
		$this->db->join("barang","barang.id = penjualan_detail.barang_id","left");
		$this->db->join("cabang","cabang.id = penjualan_detail.cabang_penjualan","left");
    	$this->db->where($where);
		$query = $this->db->get();
		if ($query->num_rows() >0){  
    		return $query->result(); 
    	} 
    	return FALSE;
	}

	public function sum($where = array())
	{
		$this->db->select("SUM(penjualan_detail.berat) as berat, SUM(penjualan_detail.harga) as harga, COUNT(penjualan_detail.id) as jumlah_transaksi")->from("penjualan_detail");
		$this->db->where($where);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->row();
		}
		return FALSE;
	}

	public function sum_potong($where = array())
	{
		$this->db->select("SUM(penjualan_detail.potong) as potong,")->from("penjualan_detail");
		$this->db->where($where);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->row();
		}
		return FALSE;
	}

	public function getOneBy($where = array()){
		$this->db->select("
			penjualan_detail.*,
			data_karyawan.nama_karyawan as nama_karyawan, 
			penjualan_detail.no_nota as no_nota,
			enum_transaksi_barang.nama as nama_jenis,
			enum_transaksi_barang.harga as harga_jenis,
			barang.nama_barang as nama_barang,
			barang.jenis as jenis_barang,
			")->from("penjualan_detail"); 
		$this->db->join("data_karyawan","data_karyawan.id = penjualan_detail.karyawan_id","left");
		$this->db->join("enum_transaksi_barang","enum_transaksi_barang.id = penjualan_detail.jenis_transaksi_id","left");
		$this->db->join("barang","barang.id = penjualan_detail.barang_id","left");
    	$this->db->where($where);
		$query = $this->db->get();
		if ($query->num_rows() >0){  
    		return $query->row(); 
    	} 
    	return FALSE;
	}

	public function insert($data){
		$this->db->insert('penjualan_detail', $data);
		return $this->db->insert_id();
	}

	public function update($data,$where){
		$this->db->update('penjualan_detail', $data, $where);
		return $this->db->affected_rows();
	}

	public function delete($where){
		$this->db->where($where);
		$this->db->delete('penjualan_detail'); 
		if($this->db->affected_rows()){
			return TRUE;
		}
		return FALSE;
	}

	function getAllBy($limit,$start,$search,$col,$dir,$where= array())
    {
    	$this->db->select("penjualan_detail.*")->from("penjualan_detail"); 
    	$this->db->limit($limit,$start)->order_by($col,$dir) ;
	   	$this->db->where($where);
		if(!empty($search)){
    		foreach($search as $key => $value){
				$this->db->or_like($key,$value);	
			} 	
    	} 
       	$result = $this->db->get();
        if($result->num_rows()>0)
        {
            return $result->result();  
        }
        else
        {
            return null;
        }
    }

    function getCountAllBy($limit,$start,$search,$order,$dir,$where= array())
    {
    	$this->db->select("penjualan_detail.*")->from("penjualan_detail"); 
    	$this->db->where($where);
		if(!empty($search)){
    		foreach($search as $key => $value){
				$this->db->or_like($key,$value);	
			} 	
    	}
		
        $result = $this->db->get();
    
        return $result->num_rows();
    } 
}
