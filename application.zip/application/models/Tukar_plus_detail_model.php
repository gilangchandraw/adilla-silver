<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Tukar_plus_detail_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}
	public function getAllById($where = array())
	{
		$this->db->select("
			tukar_plus_detail.*,		
			data_karyawan.nama_karyawan as nama_karyawan, 
			enum_transaksi_barang.nama as nama_jenis,
			barang.nama_barang as nama_barang,
			barang.jenis as jenis_barang,
			")->from("tukar_plus_detail");
		$this->db->join("data_karyawan", "data_karyawan.id = tukar_plus_detail.karyawan_id", "left");
		$this->db->join("enum_transaksi_barang", "enum_transaksi_barang.id = tukar_plus_detail.jenis_transaksi_id", "left");
		$this->db->join("barang", "barang.id = tukar_plus_detail.barang_id", "left");
		$this->db->order_by('tukar_plus_detail.no_nota', 'ASC');
		$this->db->where($where);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result();
		}
		return FALSE;
	}

	public function sum($where = array())
	{
		$this->db->select("SUM(tukar_plus_detail.berat_plus) as berat, SUM(tukar_plus_detail.harga_plus) as harga,")->from("tukar_plus_detail");
		$this->db->where($where);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->row();
		}
		return FALSE;
	}

	public function sum_potong($where = array())
	{
		$this->db->select("SUM(tukar_plus_detail.potong) as potong")->from("tukar_plus_detail");
		$this->db->where($where);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->row();
		}
		return FALSE;
	}

	public function getAllByIdBKMin($where = array())
	{
		$this->db->select("
			tukar_plus_detail.*,		
			data_karyawan.nama_karyawan as nama_karyawan, 
			enum_transaksi_barang.nama as nama_jenis,
			barang.nama_barang as nama_barang,
			barang.jenis as jenis_barang,
			barang_kembali_detail.harga as harga_bk,
			")->from("tukar_plus_detail");
		$this->db->join("data_karyawan", "data_karyawan.id = tukar_plus_detail.karyawan_id", "left");
		$this->db->join("barang", "barang.id = tukar_plus_detail.barang_id", "left");
		$this->db->join("barang_kembali_detail", "barang_kembali_detail.no_nota = tukar_plus_detail.no_nota_penjualan", "left");
		$this->db->join("enum_transaksi_barang", "enum_transaksi_barang.id = barang_kembali_detail.jenis_transaksi_id", "left");
		$this->db->order_by('tukar_plus_detail.no_nota', 'ASC');
		$this->db->where($where);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result();
		}
		return FALSE;
	}

	public function getOneBy($where = array())
	{
		$this->db->select("
			tukar_plus_detail.*,		
			data_karyawan.nama_karyawan as nama_karyawan, 
			enum_transaksi_barang.nama as nama_jenis,
			barang.nama_barang as nama_barang,
			barang.jenis as jenis_barang,
			enum_transaksi_barang.harga as harga_jenis,
			")->from("tukar_plus_detail");
		$this->db->join("data_karyawan", "data_karyawan.id = tukar_plus_detail.karyawan_id", "left");
		$this->db->join("enum_transaksi_barang", "enum_transaksi_barang.id = tukar_plus_detail.jenis_transaksi_id", "left");
		$this->db->join("barang", "barang.id = tukar_plus_detail.barang_id", "left");
		$this->db->where($where);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->row();
		}
		return FALSE;
	}

	public function getOneByMin($where = array())
	{
		$this->db->select("
			tukar_plus_detail.*,		
			data_karyawan.nama_karyawan as nama_karyawan, 
			enum_transaksi_barang.nama as nama_jenis,
			barang.nama_barang as nama_barang,
			barang.jenis as jenis_barang,
			barang_kembali_detail.harga as harga_bk,
			")->from("tukar_plus_detail");
		$this->db->join("data_karyawan", "data_karyawan.id = tukar_plus_detail.karyawan_id", "left");
		$this->db->join("barang", "barang.id = tukar_plus_detail.barang_id", "left");
		$this->db->join("barang_kembali_detail", "barang_kembali_detail.no_nota = tukar_plus_detail.no_nota_penjualan", "left");
		$this->db->join("enum_transaksi_barang", "enum_transaksi_barang.id = barang_kembali_detail.jenis_transaksi_id", "left");
		$this->db->where($where);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->row();
		}
		return FALSE;
	}

	public function insert($data)
	{
		$this->db->insert('tukar_plus_detail', $data);
		return $this->db->insert_id();
	}

	public function update($data, $where)
	{
		$this->db->update('tukar_plus_detail', $data, $where);
		return $this->db->affected_rows();
	}

	public function delete($where)
	{
		$this->db->where($where);
		$this->db->delete('tukar_plus_detail');
		if ($this->db->affected_rows()) {
			return TRUE;
		}
		return FALSE;
	}

	function getAllBy($limit, $start, $search, $col, $dir, $where = array())
	{
		$this->db->select("tukar_plus_detail.*")->from("tukar_plus_detail");
		$this->db->limit($limit, $start)->order_by($col, $dir);
		$this->db->where($where);
		if (!empty($search)) {
			foreach ($search as $key => $value) {
				$this->db->or_like($key, $value);
			}
		}
		$result = $this->db->get();
		if ($result->num_rows() > 0) {
			return $result->result();
		} else {
			return null;
		}
	}

	function getCountAllBy($limit, $start, $search, $order, $dir, $where = array())
	{
		$this->db->select("tukar_plus_detail.*")->from("tukar_plus_detail");
		$this->db->where($where);
		if (!empty($search)) {
			foreach ($search as $key => $value) {
				$this->db->or_like($key, $value);
			}
		}

		$result = $this->db->get();

		return $result->num_rows();
	}
}
