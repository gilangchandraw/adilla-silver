<?php
defined('BASEPATH') or exit('No direct script access allowed');
class Uang_laci_model extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}
	public function getAllById($where = array())
	{
		$this->db->select("uang_laci.*")->from("uang_laci");
		$this->db->where($where);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result();
		}
		return FALSE;
	}

	public function getOneBy($where = array())
	{
		$this->db->select("uang_laci.*")->from("uang_laci");
		$this->db->where($where);
		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->row();
		}
		return FALSE;
	}

	public function insert($data)
	{
		$this->db->insert('uang_laci', $data);
		return $this->db->insert_id();
	}

	public function update($data, $where)
	{
		$this->db->update('uang_laci', $data, $where);
		return $this->db->affected_rows();
	}

	public function delete($where)
	{
		$this->db->where($where);
		$this->db->delete('uang_laci');
		if ($this->db->affected_rows()) {
			return TRUE;
		}
		return FALSE;
	}

	function getAllBy($limit, $start, $search, $col, $dir, $where = array())
	{
		$this->db->select("uang_laci.*, cabang.kode_cabang as kode_cabang, cabang.nama_cabang as nama_cabang")->from("uang_laci");
		$this->db->join("cabang","cabang.id = uang_laci.cabang_id","left");
		$this->db->order_by('uang_laci.tanggal', 'DESC');
		$this->db->limit($limit, $start)->order_by($col, $dir);
		$this->db->where($where);
		if (!empty($search)) {
			foreach ($search as $key => $value) {
				$this->db->or_like($key, $value);
			}
		}
		$result = $this->db->get();
		if ($result->num_rows() > 0) {
			return $result->result();
		} else {
			return null;
		}
	}

	function getCountAllBy($limit, $start, $search, $order, $dir, $where = array())
	{
		$this->db->select("uang_laci.*")->from("uang_laci");
		$this->db->where($where);
		if (!empty($search)) {
			foreach ($search as $key => $value) {
				$this->db->or_like($key, $value);
			}
		}

		$result = $this->db->get();

		return $result->num_rows();
	}
}
