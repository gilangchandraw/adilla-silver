<div class="app-wrapper-footer">
    <div class="app-footer">
        <div class="app-footer__inner">
            <div class="app-footer-left footer-hp">
                <ul class="header-megamenu nav">
                    <li class="nav-item">
                        <a class="nav-link" href="https://api.whatsapp.com/send?phone=6281214817992">
                            <b>Dibuat Oleh </b>
                            <img width="100px" src="<?php echo base_url()."assets/images/jagif-fix.png"; ?>">
                        </a>
                    </li>
                </ul>
            </div>
            <div class="app-footer-right footer-web">
                <ul class="header-megamenu nav">
                    <li class="nav-item">
                        <a class="nav-link" href="https://api.whatsapp.com/send?phone=6281214817992">
                            <b>Dibuat Oleh </b>
                            <img width="100px" src="<?php echo base_url()."assets/images/jagif-fix.png"; ?>">                            
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div> 