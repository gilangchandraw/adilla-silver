<?php defined('BASEPATH') OR exit('No direct script access allowed');?>
<?php $this->load->view("admin/layouts/header");?>
<!-- <input type="hidden" name="groups_id" id="groups_id" value="<?php echo $this->data['users_groups']->group_id; ?>"> -->
<body>
    <div class="body-block-example-3 d-none">
        <div class="loader">
            <div class="line-scale-pulse-out-rapid">
                <div class="bg-danger"></div>
                <div class="bg-danger"></div>
                <div class="bg-danger"></div>
                <div class="bg-danger"></div>
                <div class="bg-danger"></div>
            </div>
        </div>
    </div>
    <div class="app-container app-theme-white body-tabs-shadow fixed-header fixed-sidebar">
        <?php $this->load->view("admin/layouts/topbar");?>
        <div class="app-main">
            <?php $this->load->view("admin/layouts/sidemenu");?>
            <div class="app-main__outer">
                <div class="app-main__inner">
                	<?php $this->load->view($content);?>
                </div>
                <?php $this->load->view("admin/layouts/footer");?>
            </div>
        </div>
    </div>

    <div id="alert_modal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <!-- <div class="modal-header">
                    <h5 class="modal-title"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div> -->
                <div class="modal-body">
                    <p class="alert-msg"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary alert-ok">Ok</button>
                </div>
            </div>
        </div>
    </div>
    <div id="alert_confirm" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <!-- <div class="modal-header">
                    <h5 class="modal-title"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div> -->
                <div class="modal-body">
                    <p class="alert-msg"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary alert-cancel" data-dismiss="modal">Tutup</button>
                    <button type="button" class="btn btn-primary alert-ok">Ok</button>
                </div>
            </div>
        </div>
    </div>
</body>
<input type="hidden" id="base_url" value="<?php echo base_url();?>">
</html>
