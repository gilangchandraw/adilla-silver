<div class="app-header header-shadow">
	<div class="app-header__logo">
		<h5>ADILLA-SILVER</h5>
		<!-- <div class="logo-src">
			<img src="<?php echo base_url();?>assets/images/logo-kota.png">
			<img src="<?php echo base_url();?>assets/images/logo-dlh-1.png">
		</div> -->
		<div class="header__pane ml-auto">
			<div>
				<button type="button" class="hamburger close-sidebar-btn hamburger--elastic" data-class="closed-sidebar">
					<span class="hamburger-box">
						<span class="hamburger-inner"></span>
					</span>
				</button>
			</div>
		</div>
	</div>
	<div class="app-header__mobile-menu">
		<div>
			<button type="button" class="hamburger hamburger--elastic mobile-toggle-nav">
				<span class="hamburger-box">
					<span class="hamburger-inner"></span>
				</span>
			</button>
		</div>
	</div>
	<div class="app-header__menu">
		<span>
			<button type="button" class="btn-icon btn-icon-only btn btn-primary btn-sm mobile-toggle-header-nav">
				<span class="btn-icon-wrapper">
					<i class="fa fa-ellipsis-v fa-w-6"></i>
				</span>
			</button>
		</span>
	</div>  
	<div class="app-header__content">
		<!-- <?php if ($this->data['map_module']) {?>
      		<div class="app-header-left">
				<div class="header-dots">
	                <a href="<?php echo base_url()?>map" class="mr-2 btn-icon btn-dashed btn btn-outline-primary go-to-map">
	                    <i class="fa fa-map-marker icon-anim-pulse icon-gradient bg-malibu-beach"></i>
	                	&nbsp;Map
	                </a>
	                <a href="<?php echo base_url()?>dashboard" class="mr-2 btn-icon btn-dashed btn btn-outline-primary go-to-menu hidden">
	                    <i class="fa fa-th icon-anim-pulse icon-gradient bg-malibu-beach"></i>
	                	&nbsp;SENJA-CINJA
	                </a>
	            </div>
			</div>
      	<?php } ?> -->
		<div class="app-header-right">
			<div class="header-btn-lg pr-0">
				<div class="widget-content p-0">
					<div class="widget-content-wrapper">
						<div class="widget-content-left">
							<div class="btn-group">
								<a data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="p-0 btn">
									<!-- <img width="42" class="rounded-circle" src="assets/images/avatars/1.jpg" alt="">
									<i class="fa fa-angle-down ml-2 opacity-8"></i> -->
									<i class="fa fa-users fa-2x icon-gradient bg-malibu-beach"> </i>
								</a>
								<div tabindex="-1" role="menu" aria-hidden="true" class="rm-pointers dropdown-menu-lg dropdown-menu dropdown-menu-right">
									<div class="dropdown-menu-header">
										<div class="dropdown-menu-header-inner bg-info">
											<!-- <div class="menu-header-image opacity-2" style="background-image: url('assets/images/dropdown-header/city3.jpg');"></div> -->
											<div class="menu-header-content text-left">
												<div class="widget-content p-0">
													<div class="widget-content-wrapper">
														<div class="widget-content-left mr-3">
															<!-- <img width="42" class="rounded-circle" src="assets/images/avatars/1.jpg"> -->
															<i class="fa fa-users fa-2x icon-gradient bg-malibu-beach"> </i>
														</div>
														<div class="widget-content-left">
															<div class="widget-heading">
																<?php echo $this->data['users']->first_name?>
															</div>
														</div>
														<div class="widget-content-right mr-2">
															<a href="<?php echo base_url('auth/logout')?>" class="btn-pill btn-shadow btn-shine btn btn-focus">Logout
															</a>
														</div>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="scroll-area-xs" style="height: 75px;">
										<div class="scrollbar-container ps">
											<ul class="nav flex-column">
												<li class="nav-item-header nav-item">Activity
												</li>
												<li class="nav-item">
													<a href="<?php echo base_url('profile')?>" class="btn-pill btn btn-shadow nav-link">Change Profile
														<!-- <div class="ml-auto badge badge-pill badge-info">
														</div> -->
													</a>
												</li>
											</ul>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="widget-content-left  ml-3 header-user-info">
							<div class="widget-heading">
								<?php echo $this->data['users']->first_name?>
							</div>
						</div>
					</div>
				</div>
			</div>        
		</div>
	</div>
</div>   