<!DOCTYPE html>
<html>
<head>
	<title>ADILLA-SILVER</title>
	<!-- Tell the browser to be responsive to screen width -->
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no, shrink-to-fit=no" />
	<!-- Disable tap highlight on IE -->
	<meta name="msapplication-tap-highlight" content="no">
	<!-- core architectui -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/base.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/architectui-core/metismenu/metisMenu.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/architectui-component/toastr/toastr.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/architectui-charts/Chart.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/architectui-form/select2/select2.min.css">
	<!-- highcharts -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/highcharts/css/highcharts.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/highcharts/css/themes/grid-light.css">
	<!-- datatables -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/architectui-tables/datatables/css/dataTables.bootstrap4.min.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/architectui-tables/datatables/css/responsive.dataTables.min.css">
	<!-- map osm -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/map/leaflet.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/map/MarkerCluster.Default.css">
	<link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/map/MarkerCluster.css">
	<!-- dropzone -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/dropzone/dropzone.min.css"> 
	<!-- Handsone -->
	<link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/handsontable/handsontable.full.min.css">
	<!-- my style -->
	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
	<!-- select2 -->
	<!-- <link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/select2/select2.min.css"> -->
</head>
