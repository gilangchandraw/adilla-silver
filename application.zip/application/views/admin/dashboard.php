<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-rocket icon-gradient bg-plum-plate"></i>
            </div>
            <div>Dashboard</div>
        </div>
    </div>
</div>
<ul class="body-tabs body-tabs-layout tabs-animated body-tabs-animated nav">
  <li class="nav-item">
    <a role="tab" class="nav-link active" data-toggle="tab" href="#tab-1">
        <?php 
            if($this->data['is_superadmin']) {
                echo '<span>Dashboard Kas</span>';
            }elseif ($this->data['users_groups']->id == 4) {
                echo '<span>Dashboard Kas & Info Cabang</span>';
            }
        ?>
    </a>
  </li>
  <?php if($this->data['is_superadmin']) { ?>
  <li class="nav-item">
    <a role="tab" class="nav-link" data-toggle="tab" href="#tab-2">
      <span>Dashboard Grafik</span>
    </a>
  </li>
<?php } ?>
</ul>
<div class="tab-content">
<div class="tab-pane tabs-animation fade active show" id="tab-1" role="tabpanel">
    <div class="row">
        <?php if ($this->data['users_groups']->id == 4) { ?>
        <div class="col-lg-6 col-xl-4">
            <div class="main-card mb-2 card widget-content">
                <div class="widget-content-wrapper">
                    <div class="widget-content-left">
                        <div class="widget-heading"><h4><b>Kas</b></h4></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-primary"><span><?php echo $kas; ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-4">
            <div class="main-card mb-2 card widget-content">
                <div class="widget-content-wrapper">
                    <div class="widget-content-left">
                        <div class="widget-heading"><h4><b>Kas Sepuhan</b></h4></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-success"><span><?php echo $kas_sepuhan; ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-4">
            <div class="main-card mb-2 card widget-content">
                <div class="widget-content-wrapper">
                    <div class="widget-content-left">
                        <div class="widget-heading"><h4><b> 925</b></h4></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-warning"><span><?php echo $stok_925; ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-4">
            <div class="main-card mb-2 card widget-content">
                <div class="widget-content-wrapper">
                    <div class="widget-content-left">
                        <div class="widget-heading"><h4><b> SP</b></h4></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-danger"><span><?php echo $stok_sp; ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-4">
            <div class="main-card mb-2 card widget-content">
                <div class="widget-content-wrapper">
                    <div class="widget-content-left">
                        <div class="widget-heading"><h4><b> Retur BK 925</b></h4></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-info"><span><?php echo $stok_retur_bk_925; ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-4">
            <div class="main-card mb-2 card widget-content">
                <div class="widget-content-wrapper">
                    <div class="widget-content-left">
                        <div class="widget-heading"><h4><b> Retur Pajang 925</b></h4></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-success"><span><?php echo $stok_retur_pajang_925; ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-4">
            <div class="main-card mb-2 card widget-content">
                <div class="widget-content-wrapper">
                    <div class="widget-content-left">
                        <div class="widget-heading"><h4><b> Retur BK SP</b></h4></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-info"><span><?php echo $stok_retur_bk_sp; ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-4">
            <div class="main-card mb-2 card widget-content">
                <div class="widget-content-wrapper">
                    <div class="widget-content-left">
                        <div class="widget-heading"><h4><b> Retur Pajang SP</b></h4></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-success"><span><?php echo $stok_retur_pajang_sp; ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-4">
            <div class="main-card mb-2 card widget-content">
                <div class="widget-content-wrapper">
                    <div class="widget-content-left">
                        <div class="widget-heading"><h4><b> Akhir Kontrak</b></h4></div>
                    </div><br>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-danger"><span><?php echo $tanggal_akhir_kontrak; ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-4">
            <div class="main-card mb-2 card widget-content">
                <div class="widget-content-wrapper">
                    <div class="widget-content-left">
                        <div class="widget-heading"><h4><b> Uang Nota</b></h4></div>
                    </div><br>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-danger"><span><?php echo number_format($uang_nota); ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <?php }elseif($this->data['is_superadmin']){ ?>
        <div class="col-lg-6 col-xl-12">
            <div class="main-card mb-2 card widget-content">
                <div class="widget-content-wrapper">
                    <div class="widget-content-left">
                        <div class="widget-heading"><h4><b>Total Kas Rp.</b></h4></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-primary"><span><?php echo $total_kas; ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-4">
            <div class="main-card mb-2 card widget-content">
                <div class="widget-content-wrapper">
                    <div class="widget-content-left">
                        <div class="widget-heading"><h4><b>Kas <br>Sepuhan Rp.</b></h4></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-danger"><span><?php echo $kas_sepuhan; ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-4">
            <div class="main-card mb-2 card widget-content">
                <div class="widget-content-wrapper">
                    <div class="widget-content-left">
                        <div class="widget-heading"><h4><b> Kas<br> Kotak Cincin Rp.</b></h4></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-success"><span><?php echo $kas_kotak_cincin; ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-4">
            <div class="main-card mb-2 card widget-content">
                <div class="widget-content-wrapper">
                    <div class="widget-content-left">
                        <div class="widget-heading"><h4><b> Kas<br> Patrian Rp.</b></h4></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-warning"><span><?php echo $kas_patrian; ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-4">
            <div class="main-card mb-2 card widget-content">
                <div class="widget-content-wrapper">
                    <div class="widget-content-left">
                        <div class="widget-heading"><h4><b>Kas <br>Setor Kantor Rp.</b></h4></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-danger"><span><?php echo $kas_setor_kantor; ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-4">
            <div class="main-card mb-2 card widget-content">
                <div class="widget-content-wrapper">
                    <div class="widget-content-left">
                        <div class="widget-heading"><h4><b> Kas<br> Bayar Barang Rp.</b></h4></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-success"><span><?php echo $kas_bayar_barang; ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-4">
            <div class="main-card mb-2 card widget-content">
                <div class="widget-content-wrapper">
                    <div class="widget-content-left">
                        <div class="widget-heading"><h4><b> Kas<br> Baju Ciranjang Rp.</b></h4></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-warning"><span><?php echo $kas_baju_ciranjang; ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-4">
            <div class="main-card mb-2 card widget-content">
                <div class="widget-content-wrapper">
                    <div class="widget-content-left">
                        <div class="widget-heading"><h4><b>Kas <br>Baju Banjaran Rp.</b></h4></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-danger"><span><?php echo $kas_baju_banjaran; ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-4">
            <div class="main-card mb-2 card widget-content">
                <div class="widget-content-wrapper">
                    <div class="widget-content-left">
                        <div class="widget-heading"><h4><b> Kas<br> KRW UDA Rp.</b></h4></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-success"><span><?php echo $kas_krw_uda; ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-4">
            <div class="main-card mb-2 card widget-content">
                <div class="widget-content-wrapper">
                    <div class="widget-content-left">
                        <div class="widget-heading"><h4><b> Kas<br> Kontrak Toko Rp.</b></h4></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-warning"><span><?php echo $kas_kontrak_toko; ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-4">
            <div class="main-card mb-2 card widget-content">
                <div class="widget-content-wrapper">
                    <div class="widget-content-left">
                        <div class="widget-heading"><h4><b>Kas <br>Kantor Rp.</b></h4></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-danger"><span><?php echo $kas_kantor; ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-4">
            <div class="main-card mb-2 card widget-content">
                <div class="widget-content-wrapper">
                    <div class="widget-content-left">
                        <div class="widget-heading"><h4><b> Kas<br> Mobil Rp.</b></h4></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-success"><span><?php echo $kas_mobil; ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-4">
            <div class="main-card mb-2 card widget-content">
                <div class="widget-content-wrapper">
                    <div class="widget-content-left">
                        <div class="widget-heading"><h4><b> Kas<br> DLL Rp.</b></h4></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-warning"><span><?php echo $kas_dll; ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-4">
            <div class="main-card mb-2 card widget-content">
                <div class="widget-content-wrapper">
                    <div class="widget-content-left">
                        <div class="widget-heading"><h4><b> Kas<br> Nota</b></h4></div>
                    </div>
                    <div class="widget-content-right">
                        <div class="widget-numbers text-danger"><span><?php echo $kas_nota; ?></span></div>
                    </div>
                </div>
            </div>
        </div>
        <?php } ?>
    </div>
</div>  
<!-- dashboard pedesaan -->
<div class="tab-pane tabs-animation fade" id="tab-2" role="tabpanel">
    <div class="row">
        <div class="col-lg-6 col-xl-6">
            <div class="main-card mb-2 card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <select class="form-control" id="bulan-harga-transaksi">
                                        <?php $month_now = date('m');
                                                if ($month_now != 10) {
                                                    $month_now = str_replace(0, '', $month_now);
                                                }
                                        ?>
                                        <option value="1" <?php echo $month_now == 1 ? 'selected' : ''; ?>>January</option>
                                        <option value="2" <?php echo $month_now == 2 ? 'selected' : ''; ?>>Februari</option>
                                        <option value="3" <?php echo $month_now == 3 ? 'selected' : ''; ?>>Maret</option>
                                        <option value="4" <?php echo $month_now == 4 ? 'selected' : ''; ?>>April</option>
                                        <option value="5" <?php echo $month_now == 5 ? 'selected' : ''; ?>>Mei</option>
                                        <option value="6" <?php echo $month_now == 6 ? 'selected' : ''; ?>>Juni</option>
                                        <option value="7" <?php echo $month_now == 7 ? 'selected' : ''; ?>>Juli</option>
                                        <option value="8" <?php echo $month_now == 8 ? 'selected' : ''; ?>>Agustus</option>
                                        <option value="9" <?php echo $month_now == 9 ? 'selected' : ''; ?>>September</option>
                                        <option value="10" <?php echo $month_now == 10 ? 'selected' : ''; ?>>Oktober</option>
                                        <option value="11" <?php echo $month_now == 11 ? 'selected' : ''; ?>>November</option>
                                        <option value="12" <?php echo $month_now == 12 ? 'selected' : ''; ?>>Desember</option>
                                    </select>
                        </div>
                        <div class="col-lg-6">
                            <select class="form-control" id="tahun-harga-transaksi">
                                <?php 
                                $year = date('Y');
                                $last_year = $year;
                                $next_year = $year + 10;
                                for ($i= $last_year; $i <= $next_year; $i++) { 
                                    $selected = '';
                                    if($i == $year){
                                        $selected = 'selected';
                                    }
                                    ?>
                                    <option value="<?php echo $i ?>" <?php echo $selected ?> ><?php echo $i?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div id="harga-transaksi" class="chart-display"></div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-6">
            <div class="main-card mb-2 card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6">
                            <select class="form-control" id="bulan-berat-transaksi">
                                        <?php $month_now = date('m');
                                                if ($month_now != 10) {
                                                    $month_now = str_replace(0, '', $month_now);
                                                }
                                        ?>
                                        <option value="1" <?php echo $month_now == 1 ? 'selected' : ''; ?>>January</option>
                                        <option value="2" <?php echo $month_now == 2 ? 'selected' : ''; ?>>Februari</option>
                                        <option value="3" <?php echo $month_now == 3 ? 'selected' : ''; ?>>Maret</option>
                                        <option value="4" <?php echo $month_now == 4 ? 'selected' : ''; ?>>April</option>
                                        <option value="5" <?php echo $month_now == 5 ? 'selected' : ''; ?>>Mei</option>
                                        <option value="6" <?php echo $month_now == 6 ? 'selected' : ''; ?>>Juni</option>
                                        <option value="7" <?php echo $month_now == 7 ? 'selected' : ''; ?>>Juli</option>
                                        <option value="8" <?php echo $month_now == 8 ? 'selected' : ''; ?>>Agustus</option>
                                        <option value="9" <?php echo $month_now == 9 ? 'selected' : ''; ?>>September</option>
                                        <option value="10" <?php echo $month_now == 10 ? 'selected' : ''; ?>>Oktober</option>
                                        <option value="11" <?php echo $month_now == 11 ? 'selected' : ''; ?>>November</option>
                                        <option value="12" <?php echo $month_now == 12 ? 'selected' : ''; ?>>Desember</option>
                                    </select>
                        </div>
                        <div class="col-lg-6">
                            <select class="form-control" id="tahun-berat-transaksi">
                                <?php 
                                $year = date('Y');
                                $last_year = $year;
                                $next_year = $year + 10;
                                for ($i= $last_year; $i <= $next_year; $i++) { 
                                    $selected = '';
                                    if($i == $year){
                                        $selected = 'selected';
                                    }
                                    ?>
                                    <option value="<?php echo $i ?>" <?php echo $selected ?> ><?php echo $i?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div id="berat-transaksi" class="chart-display"></div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-6">
            <div class="main-card mb-2 card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6">
                        </div>
                        <div class="col-lg-6">
                            <select class="form-control" id="tahun-total-harga-transaksi">
                                <?php 
                                $year = date('Y');
                                $last_year = $year;
                                $next_year = $year + 10;
                                for ($i= $last_year; $i <= $next_year; $i++) { 
                                    $selected = '';
                                    if($i == $year){
                                        $selected = 'selected';
                                    }
                                    ?>
                                    <option value="<?php echo $i ?>" <?php echo $selected ?> ><?php echo $i?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div id="total-harga-transaksi" class="chart-display"></div>
                </div>
            </div>
        </div>
        <div class="col-lg-6 col-xl-6">
            <div class="main-card mb-2 card">
                <div class="card-body">
                    <div class="row">
                        <div class="col-lg-6">
                        </div>
                        <div class="col-lg-6">
                            <select class="form-control" id="tahun-total-berat-transaksi">
                                <?php 
                                $year = date('Y');
                                $last_year = $year;
                                $next_year = $year + 10;
                                for ($i= $last_year; $i <= $next_year; $i++) { 
                                    $selected = '';
                                    if($i == $year){
                                        $selected = 'selected';
                                    }
                                    ?>
                                    <option value="<?php echo $i ?>" <?php echo $selected ?> ><?php echo $i?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <div id="total-berat-transaksi" class="chart-display"></div>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<script data-main="<?php echo base_url()?>assets/js/main/main-dashboard-chart" src="<?php echo base_url()?>assets/js/require.js"></script>
