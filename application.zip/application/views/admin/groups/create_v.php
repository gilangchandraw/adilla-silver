<div class="app-page-title">
	<div class="page-title-wrapper">
		<div class="page-title-heading">
			<div class="page-title-icon">
				<i class="fa fa-universal-access icon-gradient bg-plum-plate"></i>
			</div>
			<div>Tambah Departemen Baru</div>
		</div>
	</div>
</div>
<div class="main-card mb-3 card">
    <div class="card-body">
    	<h5 class="card-title"></h5>
        <form id="form" method="post">
            <div class="position-relative form-group">
            	<label for="name" class="">Nama Departemen</label>
            	<input type="text" id="name" name="name" class="form-control" autocomplete="off" required>
            </div>
            <div class="position-relative form-group">
            	<label for="description" class="">Deskripsi</label>
            	<textarea id="description" name="description" class="form-control" autocomplete="off"></textarea>
            </div>
            <button type="submit" class="mt-2 btn btn-primary pull-right"><i class="fa fa-save"> Simpan</i></button>
			<a href="<?php echo base_url();?>group" class="mt-2 mr-2 btn-transition btn btn-outline-danger pull-right"><i class="fa fa-times"> Batal</i></a>
        </form>
    </div>
</div>
<script data-main="<?php echo base_url()?>assets/js/main/main-group" src="<?php echo base_url()?>assets/js/require.js"></script>
