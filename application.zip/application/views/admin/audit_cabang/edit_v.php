<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-binoculars icon-gradient bg-plum-plate"></i>
            </div>
            <div>Edit Data Audit Cabang</div>
        </div>
        <!-- <div class="page-title-actions">
            <div class="page-title-actions">
                <button type="button" data-toggle="tooltip" title="Example Tooltip" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                    <i class="fa fa-star"></i>
                </button>
            </div>
        </div> -->
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <div class="row">

                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="tanggal">Tanggal</label>
                        <input class="form-control" readonly value="<?php echo $audit->tanggal; ?>" type="text" id="tanggal" name="tanggal" autocomplete="off">
                    </div>
                    <div class="form-row">
                        <div class="col-md-6">
                             <div class="position-relative form-group">
                                <label for="tanggal_awal">Tanggal Awal Audit</label>
                                <input class="form-control init-date readonly" type="text" value="<?php echo $audit->tanggal_awal; ?>" id="tanggal_awal" name="tanggal_awal" autocomplete="off">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="tanggal_akhir">Tanggal Akhir Audit</label>
                                <input class="form-control init-date readonly" type="text" value="<?php echo $audit->tanggal_akhir; ?>" id="tanggal_akhir" name="tanggal_akhir" autocomplete="off">
                        </div>
                        </div>                        
                    </div>
                    <div class="position-relative form-group">
                        <label for="cabang_id">Cabang</label>
                        <select class="form-control select2" id="cabang_id" name="cabang_id">
                            <option value="" selected>Pilih Cabang</option>
                            <?php foreach ($cabang as $key => $value) { ?>
                                <option value="<?php echo $value->id ?>" <?php echo $audit->cabang_id == $value->id ? 'selected' : ''; ?>><?php echo $value->nama_cabang; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="position-relative form-group">
                        <label for="krw_uda">KRW UDA</label>
                        <input class="form-control number" type="text" value="<?php echo $audit->krw_uda; ?>" id="krw_uda" name="krw_uda">
                    </div>                    
                    <div class="position-relative form-group">
                        <label for="k_toko">K. Toko</label>
                        <input class="form-control number" type="text" value="<?php echo $audit->k_toko; ?>" id="k_toko" name="k_toko">
                    </div> 
                    <div class="position-relative form-group">
                        <label for="uang_kantor">Uang Kantor</label>
                        <input class="form-control number" type="text" value="<?php echo $audit->uang_kantor; ?>" id="uang_kantor" name="uang_kantor">
                    </div>
                    <div class="position-relative form-group">
                        <label for="uang_mobil">Uang Mobil</label>
                        <input class="form-control number" type="text" value="<?php echo $audit->uang_mobil; ?>" id="uang_mobil" name="uang_mobil">
                    </div>
                </div>
                <input type="hidden" name="id" value="<?php echo $id; ?>">
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="dll">DLL</label>
                        <input class="form-control number" type="text" value="<?php echo $audit->dll; ?>" id="dll" name="dll">
                    </div> 
                    <div class="position-relative form-group">
                        <label for="total">Total</label>
                        <input class="form-control number" type="text" value="<?php echo $audit->total; ?>" id="total" name="total">
                    </div>
                    <div class="position-relative form-group">
                        <label for="uang_potongan">Uang Potongan</label>
                        <input class="form-control number" type="text" value="<?php echo $audit->uang_potongan; ?>" id="uang_potongan" name="uang_potongan">
                    </div> 
                    <div class="position-relative form-group">
                        <label for="uang_kotak_cincin">Uang Kotak Cincin</label>
                        <input class="form-control number" type="text" value="<?php echo $audit->uang_kotak_cincin; ?>" id="uang_kotak_cincin" name="uang_kotak_cincin">
                    </div> 
                    <div class="position-relative form-group">
                        <label for="uang_setor">Uang Setor</label>
                        <input class="form-control number" type="text" value="<?php echo $audit->uang_setor; ?>" id="uang_setor" name="uang_setor">
                    </div> 
                    <div class="position-relative form-group">
                        <label for="uang_bayar_barang">Uang Bayar Barang</label>
                        <input class="form-control number" type="text" value="<?php echo $audit->uang_bayar_barang; ?>" id="uang_bayar_barang" name="uang_bayar_barang">
                    </div> 
                </div>
            </div>
            <div class="box-footer">
                <div class="row">
                    <div class="col-md-6">
                        <span class="reminder" style="color:red"><b>Mohon Periksa Kembali Form, Sebelum Disimpan</b></span>
                    </div>
                </div>
            </div>
            <button type="submit" class="mt-2 btn btn-primary pull-right" id="save-btn"><i class="fa fa-save"> Simpan</i></button>
            <a href="<?php echo base_url(); ?>audit_cabang" class="mt-2 mr-2 btn-transition btn btn-outline-danger pull-right"><i class="fa fa-times"> Batal</i></a>
        </div>
    </div>
</form>

<script data-main="<?php echo base_url() ?>assets/js/main/main-audit-cabang" src="<?php echo base_url() ?>assets/js/require.js"></script>