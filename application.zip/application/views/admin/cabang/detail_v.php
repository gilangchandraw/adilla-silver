<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-database icon-gradient bg-plum-plate"></i>
            </div>
            <div>Detail Data Cabang</div>
        </div>
        <!-- <div class="page-title-actions">
            <div class="page-title-actions">
                <button type="button" data-toggle="tooltip" title="Example Tooltip" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                    <i class="fa fa-star"></i>
                </button>
            </div>
        </div> -->
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="kode_cabang">Kode Cabang</label>
                        <input class="form-control" readonly type="text" id="kode_cabang" name="kode_cabang" value="<?php echo $cabang->kode_cabang; ?>">
                        <input type="hidden" name="id" value="<?php echo $cabang->id; ?>">
                    </div>
                    <div class="position-relative form-group">
                        <label for="users_id">Kepala Cabang</label>
                        <select class="form-control select2" id="users_id" name="users_id" disabled>
                            <option value="" selected>Pilih Kepala Cabang</option>
                            <?php foreach ($kepala_cabang as $key => $value) { ?>
                                <option value="<?php echo $value->id ?>" <?php echo $cabang->users_id == $value->id ? 'selected' : ''; ?>><?php echo $value->first_name; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="position-relative form-group">
                        <label>Tipe Cabang</label>
                        <select class="form-control" disabled id="tipe_cabang" name="tipe_cabang">
                            <option value="" selected>Pilih Tipe Cabang</option>
                            <option value="adilla" <?php echo $cabang->tipe_cabang == 'adilla' ? 'selected' : ''; ?>>Adilla</option>
                            <option value="rafila" <?php echo $cabang->tipe_cabang == 'rafila' ? 'selected' : ''; ?>>Rafila</option>                            
                        </select>
                    </div>
                    <div class="position-relative form-group">
                        <label for="nama_cabang">Nama Cabang</label>
                        <input class="form-control" type="text" readonly id="nama_cabang" name="nama_cabang" value="<?php echo $cabang->nama_cabang; ?>">
                    </div>
                    <div class="position-relative form-group">
                        <label for="alamat">Alamat</label>
                        <textarea class="form-control" readonly type="text" id="alamat" name="alamat"><?php echo $cabang->alamat; ?></textarea>
                    </div>
                    <div class="form-row">
                        <div class="col-md-6">
                             <div class="position-relative form-group">
                                <label for="tanggal_awal_kontrak">Tanggal Awal Kontrak</label>
                                <input class="form-control init-date readonly" readonly value="<?php echo $cabang->tanggal_awal_kontrak; ?>" type="text" id="tanggal_awal_kontrak" name="tanggal_awal_kontrak" autocomplete="off">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="tanggal_akhir_kontrak">Tanggal Akhir Kontrak</label>
                                <input class="form-control init-date readonly" readonly value="<?php echo $cabang->tanggal_akhir_kontrak; ?>" type="text" id="tanggal_akhir_kontrak" name="tanggal_akhir_kontrak" autocomplete="off">
                        </div>
                        </div>                        
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="kas">kas</label>
                        <input class="form-control" readonly type="text" id="kas" name="kas" value="<?php echo $cabang->kas; ?>">
                    </div>
                    <div class="form-row">
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="stok_925">Stok 925</label>
                                <input class="form-control number" readonly type="text" id="stok_925" name="stok_925" value="<?php echo $cabang->stok_925; ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="stok_sp">Stok SP</label>
                                <input class="form-control number" readonly type="text" id="stok_sp" name="stok_sp" value="<?php echo $cabang->stok_sp; ?>">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="position-relative form-group">
                                <label for="kas_sepuhan">Kas Sepuhan</label>
                                <input class="form-control" readonly type="text" id="kas_sepuhan" name="kas_sepuhan" value="<?php echo $cabang->kas_sepuhan; ?>">
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="stok_retur_bk_925">Stok Retur BK 925</label>
                                <input class="form-control number" readonly type="text" id="stok_retur_bk_925" name="stok_retur_bk_925" value="<?php echo $cabang->stok_retur_bk_925; ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="stok_retur_pajang_925">Stok Retur Pajang 925</label>
                                <input class="form-control number" readonly type="text" id="stok_retur_pajang_925" name="stok_retur_pajang_925" value="<?php echo $cabang->stok_retur_pajang_925; ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="stok_retur_bk_sp">Stok Retur BK SP</label>
                                <input class="form-control" readonly type="text" id="stok_retur_bk_sp" name="stok_retur_bk_sp" value="<?php echo $cabang->stok_retur_bk_sp; ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="stok_retur_pajang_sp">Stok Retur Pajang SP</label>
                                <input class="form-control" readonly type="text" id="stok_retur_pajang_sp" name="stok_retur_pajang_sp" value="<?php echo $cabang->stok_retur_pajang_sp; ?>">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="box-footer">
                <div class="row">
                    <div class="col-md-6">
                        <span class="reminder" style="color:red"><b>Mohon Periksa Kembali Form, Sebelum Disimpan</b></span>
                    </div>
                </div>
            </div>
            <a href="<?php echo base_url(); ?>cabang" class="mt-2 mr-2 btn-transition btn btn-success pull-right">Kembali</a>
        </div>
    </div>
</form>

<script data-main="<?php echo base_url() ?>assets/js/main/main-cabang" src="<?php echo base_url() ?>assets/js/require.js"></script>