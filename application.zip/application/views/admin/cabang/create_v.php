<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-database icon-gradient bg-plum-plate"></i>
            </div>
            <div>Tambah Data Cabang</div>
        </div>
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <div class="row">

                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="kode_cabang">Kode Cabang</label>
                        <input class="form-control" type="text" id="kode_cabang" name="kode_cabang">
                    </div>
                    <div class="position-relative form-group">
                        <label for="users_id">Kepala Cabang</label>
                        <select class="form-control select2" id="users_id" name="users_id">
                            <option value="" selected>Pilih Kepala Cabang</option>
                            <?php foreach ($kepala_cabang as $key => $value) { ?>
                                <option value="<?php echo $value->id ?>"><?php echo $value->first_name; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="position-relative form-group">
                        <label>Tipe Cabang</label>
                        <select class="form-control" id="tipe_cabang" name="tipe_cabang">
                            <option value="" selected>Pilih Tipe Cabang</option>
                            <option value="adilla">Adilla</option>
                            <option value="rafila">Rafila</option>                            
                        </select>
                    </div>
                    <div class="position-relative form-group">
                        <label for="nama_cabang">Nama Cabang</label>
                        <input class="form-control" type="text" id="nama_cabang" name="nama_cabang">
                    </div>
                    <div class="position-relative form-group">
                        <label for="alamat">Alamat</label>
                        <textarea class="form-control" type="text" id="alamat" name="alamat"></textarea>
                    </div>
                    <div class="form-row">
                        <div class="col-md-6">
                             <div class="position-relative form-group">
                                <label for="tanggal_awal_kontrak">Tanggal Awal Kontrak</label>
                                <input class="form-control init-date readonly" type="text" id="tanggal_awal_kontrak" name="tanggal_awal_kontrak" autocomplete="off">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="tanggal_akhir_kontrak">Tanggal Akhir Kontrak</label>
                                <input class="form-control init-date readonly" type="text" id="tanggal_akhir_kontrak" name="tanggal_akhir_kontrak" autocomplete="off">
                            </div>
                        </div>                        
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="kas">kas</label>
                        <input class="form-control number" type="text" id="kas" name="kas" value="0">
                    </div>
                    <div class="form-row">
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="stok_925">Stok 925</label>
                                <input class="form-control number" type="text" id="stok_925" name="stok_925" value="0">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="stok_sp">Stok SP</label>
                                <input class="form-control number" type="text" id="stok_sp" name="stok_sp" value="0">
                            </div>
                        </div>
                        <div class="col-md-12">
                            <div class="position-relative form-group">
                                <label for="kas_sepuhan">Kas Sepuhan</label>
                                <input class="form-control number" type="text" id="kas_sepuhan" name="kas_sepuhan" value="0">
                            </div>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="stok_retur_bk_925">Stok Retur BK 925</label>
                                <input class="form-control number" type="text" id="stok_retur_bk_925" name="stok_retur_bk_925" value="0">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="stok_retur_pajang_925">Stok Retur Pajang 925</label>
                                <input class="form-control number" type="text" id="stok_retur_pajang_925" name="stok_retur_pajang_925" value="0">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="stok_retur_bk_sp">Stok Retur BK SP</label>
                                <input class="form-control number" type="text" id="stok_retur_bk_sp" name="stok_retur_bk_sp" value="0">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="stok_retur_pajang_sp">Stok Retur Pajang SP</label>
                                <input class="form-control number" type="text" id="stok_retur_pajang_sp" name="stok_retur_pajang_sp" value="0">
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="box-footer">
                <div class="row">
                    <div class="col-md-6">
                        <span class="reminder" style="color:red"><b>Mohon Periksa Kembali Form, Sebelum Disimpan</b></span>
                    </div>
                </div>
            </div>
            <button type="submit" class="mt-2 btn btn-primary pull-right" id="save-btn"><i class="fa fa-save"> Simpan</i></button>
            <a href="<?php echo base_url(); ?>cabang" class="mt-2 mr-2 btn-transition btn btn-outline-danger pull-right"><i class="fa fa-times"> Batal</i></a>
        </div>
    </div>
</form>

<script data-main="<?php echo base_url() ?>assets/js/main/main-cabang" src="<?php echo base_url() ?>assets/js/require.js"></script>