
<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-clipboard icon-gradient bg-plum-plate"></i>
            </div>
            <div>Laporan Sepuhan</div>
        </div>
        <div class="page-title-actions">
            <a href="#" data-toggle="tooltip" target="_blank" id="print-pdf" title="" data-placement="bottom" class="btn-shadow mr-3 btn btn-danger">
                <i class='fa fa-file-pdf'></i> Export PDF
            </a>
        </div>
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">

        <div class="card-body">
            <div class="row">
                <!-- <div class="col-md-3">
                    <div class="position-relative form-group">
                        <label for="">Pilih Laporan</label>
                        <select class="form-control" type="text" id="laporan" name="laporan" autocomplete="off">
                            <option value="">Pilih Laporan</option>
                            <option value="pembukuan">Laporan Pembukuan</option>
                        <option value="1">Laporan Transaksi Cabang</option>
                        </select>
                    </div>
                </div> -->
                <?php if($this->data['users_groups']->id != 4){ ?>
                <div class="col-md-3">
                    <div class="position-relative form-group">
                        <label for="">Pilih Cabang</label>
                        <select class="form-control select2" id="cabang_id" name="cabang_id">
                            <option value="" selected>Pilih Cabang</option>
                            <?php foreach ($cabang as $key => $value) { ?>
                                <option value="<?php echo $value->id ?>"><?php echo $value->nama_cabang; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <?php } ?>
                <div class="col-md-3">
                    <div class="position-relative form-group">
                        <label for="">Bulan & Tahun</label>
                        <input class="form-control init-year-month readonly" placeholder="<?php echo 'ex '.date('m-Y')?>" type="text" id="tanggal" name="tanggal" autocomplete="off">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="position-relative form-group">
                        <button type="button" class="mt-4 btn btn-success " id="preview-btn"><i class="fa fa-eye"> Preview</i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<!-- <div class="main-card mb-3 card">
                            <div class="card-body">
                                <section class="content">
                                    <div class="box box-default color-palette-box">
                                        <div class="box-body">
                                            <div class="row" id="body_report">
                                                <div class="col-md-12 mb-6" style="page-break-after: always; margin: auto; border: 8px; padding: 10px;">
                                                    <div class="paycheck-container">
                                                        <div class="full-width paycheck-logo">
                                                            <span></span>
                                                            <p class="text-right"></p>
                                                        </div>
                                                        <div class="table-responsive">
                                                        <table class="table table-border" align="center" border="1">
                                                            <tbody>
                                                                <tr>
                                                                    <td rowspan="4"><img style="height: 50px" src="<?php echo base_url(); ?>assets/images/logo.png"></td>
                                                                    <td class="text-center">ADILLA SILVER 925 GROUP</td>
                                                                </tr>
                                                                <tr>
                                                                    <td align="center" class="text-center">Laporan Insentif - Bulan <?php echo $bulan; ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center"> Cabang : <?php echo $cabang; ?></td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center">Karyawan : <?php echo $karyawan; ?> Nota : <?php echo $huruf_nota; ?></td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <table class="table table-border" border="1">
                                                            <thead>
                                                                <tr>
                                                                    <th class="text-center">Tanggal</th>
                                                                    <th class="text-center">Nama Pemasukan</th>
                                                                    <th class="text-center">Harga Pemasukan</th>
                                                                    <th class="text-center">Nama Pengeluaran</th>
                                                                    <th class="text-center">Harga Pengeluaran</th>
                                                                    <th class="text-center">Saldo</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                
                                                            </tbody>
                                                        </table>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                            </div>
                        </div> -->
<div id="hasil-report">
    
</div>
<div id="hasil-laporan-tidak-ada">
    
</div>


<script data-main="<?php echo base_url() ?>assets/js/main/main-laporan-sepuhan" src="<?php echo base_url() ?>assets/js/require.js"></script>