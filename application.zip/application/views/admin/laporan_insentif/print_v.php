<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/fonts/font-awesome/css/font-awesome.min.css">
    <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/fonts/Ionicons/css/ionicons.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/fonts/montserrat/stylesheet.css"> 
  <!-- Theme style -->
  
  <!-- Drop Zone -->
  <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/dropzone/dropzone.min.css">

  <link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/bootstrap-datetimepicker/css/bootstrap-datetimepicker.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/bootstrap-datepicker/bootstrap-datepicker.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/plugins/bootstrap-timepicker/css/bootstrap-timepicker.min.css">
  <!-- <link rel="stylesheet" href="<?php //echo base_url();?>assets/plugins/bootstrap-timepicker/bootstrap-timepicker.css"> -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/select2/select2.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/dropzone/dropzone.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/admin.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/lobilist.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/progressbar.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/skins/skin-main.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 <style type="text/css">
        tfoot {
            display: table-header-group;
        }
 </style>
</head>

    <table class="table table-border" align="center" border="1">
        <tbody>
            <tr>
                <td rowspan="3"><img style="height: 50px" src="<?php echo base_url(); ?>assets/images/logo.png"></td>
                <td class="text-center">ADILLA SILVER 925 GROUP</td>
            </tr>
            <tr>
                <td align="center" class="text-center">Laporan Insentif - Bulan <?php echo $bulan; ?></td>
            </tr>
            <tr>
                <td class="text-center"> Cabang : <?php echo $cabang; ?> Karyawan : <?php echo $karyawan; ?> Nota : <?php echo $huruf_nota; ?></td>
            </tr>
        </tbody>
    </table>
    <table class="table table-border" border="1">
        <thead>
            <tr>
                <th class="text-center">Tanggal</th>
                <th class="text-center">No Nota</th>
                <th class="text-center">Jumlah Nota</th>
                <th class="text-center">No Nota Batal</th>
                <th class="text-center">Jumlah Nota Batal</th>
                <th class="text-center">Berat</th>
                <th class="text-center">Total Berat</th>
                <th class="text-center">Harga</th>
                <th class="text-center">Total Harga</th>
            </tr>
        </thead>
            <?php
                if (!empty($insentif)) {
                    foreach ($insentif as $key => $value) { ?>
                    <tr>
                        <td class="text-center"><?php echo $value->tanggal; ?></td>
                        <td class="text-center"><?php echo $value->no_nota; ?></td>
                        <td class="text-center"><?php echo $value->jumlah_nota; ?></td>
                        <td class="text-center"><?php echo $value->no_nota_batal; ?></td>
                        <td class="text-center"><?php echo $value->jumlah_nota_batal; ?></td>
                        <td class="text-center"><?php echo $value->berat; ?></td>
                        <td class="text-center"><?php echo $value->total_berat; ?></td>
                        <td class="text-center"><?php echo $value->harga; ?></td>
                        <td class="text-center"><?php echo $value->total_harga; ?></td>
                    </tr>
            <?php 
                }
                }
            ?>
    </table>