<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-database icon-gradient bg-plum-plate"></i>
            </div>
            <div>Tambah Data barang</div>
        </div>
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="kode_barang">Kode Barang</label>
                        <input class="form-control" type="text" id="kode_barang" name="kode_barang">
                    </div>
                    <div class="position-relative form-group">
                        <label for="nama_barang">Nama Barang</label>
                        <input class="form-control" type="text" id="nama_barang" name="nama_barang">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="jenis">Jenis Kualitas</label>
                        <select class="form-control" id="jenis" name="jenis">
                            <option value="" selected>Pilih Kualitas</option>
                            <option value="925">925</option>
                            <option value="SP">SP</option>
                        </select>
                    </div>
                    <div class="position-relative form-group">
                        <label for="stok">Stok per/gram</label>
                        <input class="form-control number" type="text" id="stok" name="stok">
                    </div>
                   <!--  <div class="position-relative form-group">
                        <label for="foto" class="">Foto</label>
                        <input type="file" accept="image/*" class="form-control" id="foto" name="foto" required>
                    </div> -->
                </div>
            </div>
            <div class="box-footer">
                <div class="row">
                    <div class="col-md-6">
                        <span class="reminder" style="color:red"><b>Mohon Periksa Kembali Form, Sebelum Disimpan</b></span>
                    </div>
                </div>
            </div>
            <button type="submit" class="mt-2 btn btn-primary pull-right" id="save-btn"><i class="fa fa-save"> Simpan</i></button>
            <a href="<?php echo base_url(); ?>barang" class="mt-2 mr-2 btn-transition btn btn-outline-danger pull-right"><i class="fa fa-times"> Batal</i></a>
        </div>
    </div>
</form>

<script data-main="<?php echo base_url() ?>assets/js/main/main-barang" src="<?php echo base_url() ?>assets/js/require.js"></script>