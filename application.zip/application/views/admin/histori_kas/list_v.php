<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-wallet icon-gradient bg-plum-plate"></i>
            </div>
            <div>Histori Kas Cabang</div>
        </div>
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <?php if (!empty($this->session->flashdata('message'))) { ?>
                <div class="card-header">
                    <div class="alert alert-info fade show text-center w-100" role="alert">
                        <?php print_r($this->session->flashdata('message')); ?>
                    </div>
                </div>
            <?php } ?>

            <?php if (!empty($this->session->flashdata('message_error'))) { ?>
                <div class="card-header">
                    <div class="alert alert-danger fade show text-center w-100" role="alert">
                        <?php print_r($this->session->flashdata('message_error')); ?>
                    </div>
                </div>
            <?php } ?>
            <div class="row">
                <?php if($this->data['is_superadmin']){ ?>
                <div class="col-md-3">
                    <div class="position-relative form-group">
                        <label for="">Pilih Cabang</label>
                        <select class="form-control select2" id="cabang_id" name="cabang_id">
                            <option value="" selected>Pilih Cabang</option>
                            <?php foreach ($cabang as $key => $value) { ?>
                                <option value="<?php echo $value->id ?>"><?php echo $value->nama_cabang; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <?php } ?>
                <div class="col-md-3">
                    <div class="position-relative form-group">
                        <label for="">Bulan & Tahun</label>
                        <input class="form-control init-year-month readonly" placeholder="<?php echo 'ex '.date('m-Y')?>" type="text" id="bulan_tahun" name="bulan_tahun" autocomplete="off">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="position-relative form-group">
                        <button type="button" class="mt-4 btn btn-success " id="preview-btn"><i class="fa fa-eye"> Preview</i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<div id="hasil-report">
    
</div>
<div id="hasil-laporan-tidak-ada">
    
</div>


<script data-main="<?php echo base_url() ?>assets/js/main/main-histori_kas" src="<?php echo base_url() ?>assets/js/require.js"></script>