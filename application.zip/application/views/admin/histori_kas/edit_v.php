<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-wallet icon-gradient bg-plum-plate"></i>
            </div>
            <div>Edit Data Histori Kas cabang Tanggal <?php echo $kas->tanggal; ?></div>
        </div>
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-12">
                    <div class="position-relative form-group">
                        <label`>Tanggal</label>
                        <input class="form-control" type="text" autocomplete="off" readonly name="tanggal" value="<?php echo $kas->tanggal; ?>">
                    </div>
                    <div class="position-relative form-group">
                        <label>Kas Awal</label>
                        <input class="form-control number" type="text" autocomplete="off" id="kas_awal" name="kas_awal" value="<?php echo $kas->kas_awal; ?>">
                    </div>
                    <div class="position-relative form-group">
                        <label>Kas Masuk</label>
                        <input class="form-control number" type="text" autocomplete="off" id="kas_masuk" name="kas_masuk" value="<?php echo $kas->kas_masuk; ?>">
                    </div>
                    <input type="hidden" name="id" value="<?php echo $id; ?>">
                    <input type="hidden" name="cabang_id" value="<?php echo $kas->cabang_id; ?>">
                    <div class="position-relative form-group">
                        <label>Kas Akhir</label>
                        <input class="form-control number" type="text" autocomplete="off" id="kas_akhir" name="kas_akhir" value="<?php echo $kas->kas_akhir; ?>">
                    </div>
                </div>
            </div>
            <div class="box-footer">
                <div class="row">
                    <div class="col-md-6">
                        <span class="reminder" style="color:red"><b>Mohon Periksa Kembali Form, Sebelum Disimpan</b></span>
                    </div>
                </div>
            </div>
            <button type="submit" class="mt-2 btn btn-primary pull-right" id="save-btn"><i class="fa fa-save"> Simpan</i></button>
            <a href="<?php echo base_url(); ?>histori_kas" class="mt-2 mr-2 btn-transition btn btn-outline-danger pull-right"><i class="fa fa-times"> Batal</i></a>
        </div>
    </div>
</form>

<script data-main="<?php echo base_url() ?>assets/js/main/main-histori_kas" src="<?php echo base_url() ?>assets/js/require.js"></script>