<div class="app-page-title">
	<div class="page-title-wrapper">
		<div class="page-title-heading">
			<div class="page-title-icon">
				<i class="fa fa-credit-card icon-gradient bg-plum-plate"></i>
			</div>
			<div>Data Barang Kembali <?php if($this->data['users_groups']->id == 4){ echo $cabang->nama_cabang; } ?>
				<div class="page-title-subheading"></div>
			</div>
		</div>
		<div class="page-title-actions">
			<?php if($this->data['users_groups']->id == 4){ ?>
			<a href="<?php echo base_url() ?>barang_kembali/cek_nota" data-toggle="tooltip" title="" data-placement="bottom" class="btn-shadow mr-3 btn btn-danger">
				<i class='fa fa-exclamation-triangle'></i> Cek No Nota
			</a>
			<?php if ($cek_insert == 0) { ?>
			<a href="<?php echo base_url() ?>barang_kembali/create" data-toggle="tooltip" title="" data-placement="bottom" class="btn-shadow mr-3 btn btn-primary">
				<i class='fa fa-plus'></i> Barang Kembali
			</a>
			<?php 
			}
			}
			?>
		</div>
	</div>
</div>
<div class="row">
	<div class="col-lg-12">
		<div class="main-card mb-2 card">
			<?php if (!empty($this->session->flashdata('message'))) { ?>
				<div class="card-header">
					<div class="alert alert-info fade show text-center w-100" role="alert">
						<?php print_r($this->session->flashdata('message')); ?>
					</div>
				</div>
			<?php } ?>
			<?php if (!empty($this->session->flashdata('message_error'))) { ?>
				<div class="card-header">
					<div class="alert alert-danger fade show text-center w-100" role="alert">
						<?php print_r($this->session->flashdata('message_error')); ?>
					</div>
				</div>
			<?php } ?>
			<div class="card-body">
				<div class="row mb-4">
					<?php if($this->data['users_groups']->id != 4){ ?>
					<div class="col-md-3">
		                <div class="position-relative form-group">
		                    <select class="form-control select2" id="cabang_id">
		                            <option value="" selected>Pilih Cabang</option>
		                        <?php foreach ($data_cabang as $key => $value) { ?>
		                            <option value="<?php echo $value->id ?>"><?php echo $value->nama_cabang; ?></option>
		                        <?php } ?>
		                    </select>
		                </div>
		            </div>
		            <div class="col-md-3">
		                <div class="position-relative form-group">
		                    <select class="form-control" id="status_audit">
		                            <option value="" selected>Pilih Status Audit</option>		                        
		                            <option value="2">Belum</option>
		                            <option value="1">Selesai</option>
		                    </select>
		                </div>
		            </div>
		            <?php } ?>
					<div class="col-md-3">
						<input class="form-control init-date readonly" placeholder="<?php echo date('Y-m-d'); ?>" type="text" id="tanggal" name="tanggal" autocomplete="off">
					</div>
					<div class="col-md-1">
						<button type="button" id="btn-filter" class="btn btn-primary">Filter</button>
					</div>
					<div class="col-md-2">
						<button type="button" id="btn-filter-clear" class="btn btn-danger">Clear Filter</button>
					</div>
				</div>
				<div class="table-responsive">
					<?php if($this->data['users_groups']->id == 4){ ?>
					<table class="table table-striped table-hover table-bordered responsive w-100" id="table">
						<thead>
							<th style="width: 20px">No</th>
							<th class="text-center">Tanggal Transaksi</th>
							<th class="text-center">Jumlah Transaksi</th>
							<th class="text-center">Total Berat/Gram</th>
							<th class="text-center">Total Harga Keseluruhan</th>
							<th class="text-center" style="width: 100px">Aksi</th>
						</thead>
					</table>
					<?php } ?>
					<?php if($this->data['users_groups']->id != 4){ ?>
					<table class="table table-striped table-hover table-bordered responsive w-100" id="table-admin">
						<thead>
							<th style="width: 20px">No</th>
							<th class="text-center">Cabang</th>
							<th class="text-center">Tanggal Transaksi</th>
							<th class="text-center">Jumlah Transaksi</th>
							<th class="text-center">Total Berat/Gram</th>
							<th class="text-center">Total Harga Keseluruhan</th>
							<th class="text-center">Status Audit</th>
							<th class="text-center" style="width: 100px">Aksi</th>
						</thead>
					</table>
					<?php } ?>
				</div>
			</div>
		</div>
	</div>
</div>
<script data-main="<?php echo base_url() ?>assets/js/main/main-barang_kembali" src="<?php echo base_url() ?>assets/js/require.js"></script>