<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-credit-card icon-gradient bg-plum-plate"></i>
            </div>
            <div>Cek No Nota</div>
        </div>
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <div class="form-row">
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="no_nota">No Nota</label>
                        <input class="form-control" type="text" id="no_nota" name="no_nota" autocomplete="off">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="kode_cabang">Cabang</label>
                        <select class="form-control select2" id="kode_cabang" name="kode_cabang">
                            <option value="" selected>Pilih Cabang</option>
                            <?php foreach ($cabang as $key => $value) { ?>
                                <option value="<?php echo $value->kode_cabang; ?>"><?php echo $value->kode_cabang . ' - ' . $value->nama_cabang; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
            </div>
            <button type="button" class="mt-2 btn btn-primary pull-right" id="btn-cek"><i class="fa fa-save"> Cek</i></button>
            <a href="<?php echo base_url(); ?>barang_kembali" class="mt-2 mr-2 btn-transition btn btn-outline-danger pull-right">Selesai</a>
        </div>
        <div class="col-md-12" id="hasil_cek">
            <div class="position-relative form-group">
                <label for="no_nota">Hasil Cek No Nota</label>
                <textarea class="form-control" type="text" style="background-color: #7CFC00;color:white;" id="nota_ada" readonly></textarea>
                <textarea class="form-control" type="text" style="background-color: #FF0000;color:black;" id="nota_tidak_ada" readonly></textarea>
            </div>
        </div>
    </div>
</form>
<script data-main="<?php echo base_url() ?>assets/js/main/main-barang_kembali" src="<?php echo base_url() ?>assets/js/require.js"></script>