<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-credit-card icon-gradient bg-plum-plate"></i>
            </div>
            <div>Edit Data Barang Kembali</div>
        </div>
        <!-- <div class="page-title-actions">
            <div class="page-title-actions">
                <button type="button" data-toggle="tooltip" title="Example Tooltip" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                    <i class="fa fa-star"></i>
                </button>
            </div>
        </div> -->
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <h5>Data Detail Transaksi Barang Kembali</h5>
            <div class="form-row">
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="Kualitas">Kualitas Barang</label>
                        <select class="form-control" id="kualitas" name="kualitas" disabled>
                            <option value="" selected>Pilih Kualitas Barang</option>
                            <option value="1" selected>Utuh</option>
                            <option value="2">Barang Rusak</option>
                            <option value="3">Barang Hilang</option>
                        </select>
                    </div>
                    <div class="position-relative form-group">
                        <label for="potongan">Potongan</label>
                        <select class="form-control" id="potongan" name="potongan">
                            <option value="" selected>Pilih Potongan</option>
                            <option value="5000" <?php echo $bk->potongan == '5000' ? 'selected' : ''; ?>>5000</option>
                            <option value="6000" <?php echo $bk->potongan == '6000' ? 'selected' : ''; ?>>6000</option>
                            <option value="7000" <?php echo $bk->potongan == '7000' ? 'selected' : ''; ?>>7000</option>
                            <option value="8000" <?php echo $bk->potongan == '8000' ? 'selected' : ''; ?>>8000</option>
                        </select>
                    </div>
                    <div class="position-relative form-group">
                        <label for="Karat">Karat Penjualan</label>
                        <input class="form-control number" readonly type="text" name="harga_jenis" id="harga_jenis" value="<?php echo $enum_transaksi->harga; ?>">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="berat">berat Penjualan</label>
                        <input class="form-control number" readonly type="text" name="berat" id="berat" value="<?php echo $penjualan->berat; ?>">
                    </div>
                    <div class="potongan-rusak">
                    <div class="position-relative form-group">
                        <label for="potongan_rusak">Potongan Rusak</label>
                        <input class="form-control number" type="text" id="potongan_rusak" name="potongan_rusak">
                    </div>
                    <div class="position-relative form-group">
                        <label for="berat_barang_rusak">Berat Barang Rusak</label>
                        <input class="form-control number" type="text" id="berat_barang_rusak" name="berat_barang_rusak">
                    </div>                        
                    </div>
                    <div class="position-relative form-group" id="barang-hilang">
                        <label for="berat_barang_hilang">Berat Barang Hilang</label>
                        <input class="form-control number" type="text" id="berat_barang_hilang" name="berat_barang_hilang">
                    </div>
                    <div class="position-relative form-group">
                        <input type="hidden" name="kualitas" id="kualitas" value="1">
                        <input type="hidden" name="barang_kembali_detail_id" id="barang_kembali_detail_id" value="<?php echo $barang_kembali_detail_id; ?>">
                        
                        <!-- <input type="text" name="berat" id="berat" value="<?php echo $penjualan->berat; ?>">                         -->
                        <label for="harga_barang_kembali">Harga Barang Kembali</label>
                        <input class="form-control" readonly type="text" value="<?php echo $bk->harga; ?>" id="harga_barang_kembali" name="harga_barang_kembali">
                    </div>
                </div>
            </div>
            <div class="box-footer">
                <div class="row">
                    <div class="col-md-6">
                        <span class="reminder" style="color:red"><b>Mohon Periksa Kembali Form, Sebelum Disimpan</b></span>
                    </div>
                    <div class="col-md-6">
                        <div class="btn-groups pull-right">
                            <button type="submit" class="mt-2 btn btn-primary pull-right" id="btn-tambah"><i class="fa fa-save"> Simpan </i></button>
                            <a href="<?php echo base_url(); ?>barang_kembali" class="mt-2 mr-2 btn-transition btn btn-outline-danger pull-right"><i class="fa fa-times"> Batal</i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
    <div class="main-card mb-3 card" id="hasil_cek">
        <div class="card-body">
            <div class="col-md-12">
                <div class="position-relative form-group">
                    <label for="no_nota">Hasil Cek No Nota</label>
                    <textarea class="form-control" type="text" style="background-color: #FF0000;color:white;" id="nota_tidak_ada" readonly></textarea>
                </div>
            </div>
        </div>
    </div>

<script data-main="<?php echo base_url() ?>assets/js/main/main-barang_kembali" src="<?php echo base_url() ?>assets/js/require.js"></script>