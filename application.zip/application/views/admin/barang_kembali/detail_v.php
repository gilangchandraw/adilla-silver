<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-credit-card icon-gradient bg-plum-plate"></i>
            </div>
            <div>Detail Data Barang Kembali</div>
        </div>
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
<div class="main-card mb-3 card">
    <?php if (!empty($this->session->flashdata('message'))) { ?>
                <div class="card-header">
                    <div class="alert alert-info fade show text-center w-100" role="alert">
                        <?php print_r($this->session->flashdata('message')); ?>
                    </div>
                </div>
            <?php } ?>

            <?php if (!empty($this->session->flashdata('message_error'))) { ?>
                <div class="card-header">
                    <div class="alert alert-danger fade show text-center w-100" role="alert">
                        <?php print_r($this->session->flashdata('message_error')); ?>
                    </div>
                </div>
            <?php } ?>
    <div class="card-body">
            <div class="form-row">
                <div class="col-md-6">                    
                    <div class="position-relative form-group">    
                        <label for="tanggal">Tanggal Transaksi</label>
                        <input class="form-control init-date readonly" disabled value="<?php echo $barang_kembali->tanggal; ?>"  type="text" id="tanggal" name="tanggal" autocomplete="off">
                    </div>
                </div>
                <div class="col-md-6">                    
                    <div class="position-relative form-group">    
                        <label for="tanggal">Cabang</label>
                        <input class="form-control" disabled value="<?php echo $barang_kembali->kode_cabang.' - '.$barang_kembali->nama_cabang; ?>"  type="text" id="tanggal" name="tanggal" autocomplete="off">
                    </div>
                </div>
          </div>
            <div class="card-body">
                <div class="col-md-12">
                    <h5 class="card-title text-center" style="background-color: #008B8B; color: white">Total Berat SP & 925</h5>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-bordered responsive w-100"> 
                        <thead>
                            <tr>
                                <th class="text-center">Total Berat BK SP</th>
                                <th class="text-center">Total Berat BK 925</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class='text-center'><?php echo $berat_sp; ?></td>
                                <td class='text-center'><?php echo $berat_925; ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="col-md-12">
                    <h5 class="card-title text-center" style="background-color: #008B8B; color: white">Histori Data Barang Kembali</h5>
                </div>
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-bordered responsive w-100" id="table-utuh">
                    <thead>
                        <th class="text-center">No</th>
                        <th class="text-center">Asal Penjualan</th>
                        <th class="text-center">Karyawan</th>
                        <th class="text-center">No Nota</th>
                        <th class="text-center">Karat</th>
                        <th class="text-center">Nama Perhiasan</th>
                        <th class="text-center">Potong</th>
                        <th class="text-center">Potongan</th>
                        <th class="text-center">Berat/Gram</th>
                        <th class="text-center">Harga</th>
                        <th class="text-center">Jenis BK</th>
                        <th class="text-center">Waktu Input</th>
                        <?php if($this->data['users_groups']->id == 4){ ?>
                        <?php if ($cek_insert == 1) { ?>
                        <th class="text-center">Aksi</th>
                        <?php } ?>
                        <?php } ?>
                        <?php if ($this->data['is_superadmin']) { ?>
                            <th class="text-center">Aksi</th>
                        <?php } ?>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        $total_berat = 0;
                        $total_harga = 0;
                        if(!empty($data_barang_kembali_detail)) {
                        foreach ($data_barang_kembali_detail as $key => $value) { 
                            $total_harga += $value->harga;
                            $total_berat += $value->berat;
                            ?>
                            <tr>
                                <td class='text-center'><?php echo $no++; ?></td>
                                <td class='text-center'><?php echo $value->nama_cabang; ?></td>
                                <td class='text-center'><?php echo $value->nama_karyawan; ?></td>
                                <td class='text-center'><?php $no_nota = explode('~', $value->no_nota); echo $no_nota[0]; ?></td>
                                <td class='text-center'><?php echo $value->nama_jenis; ?></td>
                                <td class='text-center'><?php echo $value->nama_barang; ?></td>
                                <td class='text-center'><?php echo $value->potong; ?></td>
                                <td class='text-center'><?php echo number_format($value->potongan); ?></td>
                                <td class='text-center'><?php echo $value->berat; ?></td>
                                <td class='text-center'><?php echo number_format($value->harga); ?></td>
                                <td class='text-center'><?php echo $value->jenis_bk == 0 ? 'BK' : 'Tukar Min'; ?></td>
                                <td class='text-center'><?php $waktu_input = date('H:i', strtotime($value->created_at)); echo $waktu_input; ?></td>
                                <?php if($this->data['users_groups']->id == 4){
                                        if ($cek_insert == 1) {
                                            if ($value->jenis_bk == 0) {
                                 ?>
                                    <td class='text-center'><?php echo "<a href='#' class='btn btn-sm btn-danger delete-data' data-toggle='tooltip' detail_id='" . $value->id . "'' title='Hapus Data' data-placement='bottom'><i class='fa fa-times fa-w-20'></i></a>"; ?></td>
                                <?php 
                                        }else{
                                            echo "<td></td>";
                                        }
                                    } 
                                }  
                                ?>
                                <?php if ($this->data['is_superadmin']) {
                                    if ($value->jenis_bk == 0) {
                                 ?>
                                    <td class='text-center'><?php echo "<a href='#' class='btn btn-sm btn-danger delete-data' data-toggle='tooltip' detail_id='" . $value->id . "'' title='Hapus Data' data-placement='bottom'><i class='fa fa-times fa-w-20'></i></a>"; ?></td>
                                <?php  }else{ ?>
                                    <td></td>
                                <?php  } ?>
                                <?php  } ?>
                            </tr>
                        <?php
                        }
                        }
                        ?>
                            <th class="text-center" style="background-color:#D5F5E3" colspan="8">Total</th>
                            <td class="text-center"><?php echo $total_berat; ?></td>
                            <td class="text-center"><?php echo number_format($total_harga); ?></td>
                    </tbody>
                </table>
                </div>
            </div>
            <?php if(!empty($data_barang_rusak)) { ?>
        <div class="card-body">
            <h5 class="card-title">Histori Data Barang Rusak</h5>
            <div class="table-responsive">
                <table class="table table-striped table-hover table-bordered responsive w-100" id="table-rusak">
                    <thead>
                        <th class="text-center">No</th>
                        <th class="text-center">Asal Penjualan</th>
                        <th class="text-center">Karyawan</th>
                        <th class="text-center">No Nota</th>
                        <th class="text-center">Karat</th>
                        <th class="text-center">Nama Perhiasan</th>
                        <th class="text-center">Potong</th>
                        <th class="text-center">Potongan</th>
                        <th class="text-center">Potongan Rusak</th>
                        <th class="text-center">Berat/Gram</th>
                        <th class="text-center">Harga</th>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        $berat = 0.0;
                        $harga = 0;
                        $potongan_rusak = 0;
                        foreach ($data_barang_rusak as $key => $value) { ?>
                            <tr>
                                <td class='text-center'><?php echo $no++; ?></td>
                                <td class='text-center'><?php echo $value->nama_cabang; ?></td>
                                <td class='text-center'><?php echo $value->nama_karyawan; ?></td>
                                <td class='text-center'><?php $no_nota = explode('~', $value->no_nota); echo $no_nota[0]; ?></td>
                                <td class='text-center'><?php echo $value->nama_jenis; ?></td>
                                <td class='text-center'><?php echo $value->nama_barang; ?></td>
                                <td class='text-center'><?php echo $value->potong; ?></td>
                                <td class='text-center'><?php echo number_format($value->potongan); ?></td>
                                <td class='text-center'><?php $potongan_rusak += $value->potongan_rusak; echo number_format($value->potongan_rusak); ?></td>
                                <td class='text-center'><?php $berat += $value->berat; echo $value->berat; ?></td>
                                <td class='text-center'><?php $harga += $value->harga; echo number_format($value->harga); ?></td>
                            </tr>
                        <?php
                        }
                        ?>
                        <?php if ($cek_insert == 1) { ?>
                            <th class="text-center" style="background-color:#D5F5E3" colspan="8">Total</th>
                        <?php }else{ ?>
                            <th class="text-center" style="background-color:#D5F5E3" colspan="8">Total</th>
                        <?php } ?>
                        <td class="text-center"><?php echo number_format($potongan_rusak); ?></td>
                        <td class="text-center"><?php echo $berat; ?></td>
                        <td class="text-center"><?php echo number_format($harga); ?></td>
                    </tbody>
                </table>
            </div>
        </div>
        <?php } ?>
        <?php if(!empty($data_barang_hilang)) { ?>
        <div class="card-body">
            <h5 class="card-title">Histori Data Barang hilang</h5>
            <div class="table-responsive">
                <table class="table table-striped table-hover table-bordered responsive w-100">
                    <thead>
                        <th class="text-center">No</th>
                        <th class="text-center">Asal Penjualan</th>
                        <th class="text-center">Karyawan</th>
                        <th class="text-center">No Nota</th>
                        <th class="text-center">Karat</th>
                        <th class="text-center">Nama Perhiasan</th>
                        <th class="text-center">Potong</th>
                        <th class="text-center">Potongan</th>
                        <th class="text-center">Potongan Hilang</th>
                        <th class="text-center">Berat/Gram</th>
                        <th class="text-center">Harga</th>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        $berat = 0.0;
                        $harga = 0;
                        $potongan_hilang = 0;
                        foreach ($data_barang_hilang as $key => $value) { ?>
                            <tr>
                                <td class='text-center'><?php echo $no++; ?></td>
                                <td class='text-center'><?php echo $value->nama_cabang; ?></td>
                                <td class='text-center'><?php echo $value->nama_karyawan; ?></td>
                                <td class='text-center'><?php $no_nota = explode('~', $value->no_nota); echo $no_nota[0]; ?></td>
                                <td class='text-center'><?php echo $value->nama_jenis; ?></td>
                                <td class='text-center'><?php echo $value->nama_barang; ?></td>
                                <td class='text-center'><?php echo $value->potong; ?></td>
                                <td class='text-center'><?php echo number_format($value->potongan); ?></td>
                                <td class='text-center'><?php $potongan_hilang += $value->potongan_hilang; echo number_format($value->potongan_hilang); ?></td>
                                <td class='text-center'><?php $berat += $value->berat; echo $value->berat; ?></td>
                                <td class='text-center'><?php $harga += $value->harga; echo number_format($value->harga); ?></td>
                            </tr>
                        <?php
                        }
                        ?>
                        <th class="text-center" style="background-color:#D5F5E3" colspan="8">Total</th>
                        <td class="text-center"><?php echo number_format($potongan_hilang); ?></td>
                        <td class="text-center"><?php echo $berat; ?></td>
                        <td class="text-center"><?php echo number_format($harga); ?></td>
                    </tbody>
                </table>
            </div>
        </div>
        <?php } ?>
    </div>
</div>
</form>    
<script data-main="<?php echo base_url()?>assets/js/main/main-barang_kembali" src="<?php echo base_url()?>assets/js/require.js"></script>