<div class="app-page-title">
	<div class="page-title-wrapper">
		<div class="page-title-heading">
			<div class="page-title-icon">
				<i class="fa fa-database icon-gradient bg-plum-plate"></i>
			</div>
			<div><?php echo ucwords(str_replace("_"," ",$this->uri->segment(1)))?>
				<div class="page-title-subheading"></div>
			</div>
		</div>
		<div class="page-title-actions">
		</div> 
	</div>
</div> 

<div class="row">
	<div class="col-lg-12">
		<div class="main-card mb-2 card">
			<?php if(!empty($this->session->flashdata('message'))){?>
			<div class="card-header">
				<div class="alert alert-info fade show text-center w-100" role="alert">
					<?php print_r($this->session->flashdata('message'));?>
				</div>
			</div>
			<?php }?> 
			
			<?php if(!empty($this->session->flashdata('message_error'))){?>
			<div class="card-header">
				<div class="alert alert-danger fade show text-center w-100" role="alert">
					<?php print_r($this->session->flashdata('message_error'));?>
				</div>
			</div>
			<?php }?>   
			<div class="card-body">
				<div class="row mb-4">
					<div class="col-md-3">
						<select class="form-control" id="huruf_nota" name="huruf_nota">
                            <option value="" selected>Pilih Huruf Nota</option>
                            <option value="A">A</option>
                            <option value="B">B</option>
                            <option value="C">C</option>
                            <option value="D">D</option>
                            <option value="E">E</option>
                            <option value="G">G</option>
                        </select>
					</div>
					<div class="col-md-3">
						<select class="form-control" id="status" name="status">
                            <option value="baru">Nota Baru</option>
                            <option value="1">Nota Sudah Terjual</option>
                            <option value="2">Nota Sudah Kembali</option>
                            <option value="3">Nota Batal</option>
                            <option value="4">Nota Tukar Plus</option>
                            <option value="5">Nota Tukar Min</option>
                            <option value="6">Nota Hilang 2R</option>
                            <option value="7">Nota Hilang 3R</option>
                        </select>
					</div>
					<div class="col-md-1">
						<button type="button" id="btn-filter" class="btn btn-primary">Filter</button>
					</div>
					<div class="col-md-2">
						<button type="button" id="btn-filter-clear" class="btn btn-danger">Clear Filter</button>
					</div>
				</div>
				<input type="hidden" id="pemesanan_nota_cabang_id" value="<?php echo $pemesanan_nota_cabang_id; ?>">
				<div class="table-responsive">
					<table class="table table-striped table-hover table-bordered responsive w-100" id="table-nota">
						<thead>
							<th style="width: 20px">No</th>
							<th class="text-center">No Nota</th>
							<th class="text-center">Status</th>
						</thead>        
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<script data-main="<?php echo base_url()?>assets/js/main/main-nota" src="<?php echo base_url()?>assets/js/require.js"></script>