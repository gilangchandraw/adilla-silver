<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-clipboard icon-gradient bg-plum-plate"></i>
            </div>
            <div>Laporan Barang Hilang</div>
        </div>
        <div class="page-title-actions">
            <a href="#" data-toggle="tooltip" target="_blank" id="print-pdf" title="" data-placement="bottom" class="btn-shadow mr-3 btn btn-danger">
                <i class='fa fa-file-pdf'></i> Export PDF
            </a>
        </div>
        
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">

        <div class="card-body">
            <div class="row">
                <!-- <div class="col-md-3">
                    <div class="position-relative form-group">
                        <label for="">Pilih Laporan</label>
                        <select class="form-control" type="text" id="laporan" name="laporan" autocomplete="off">
                            <option value="">Pilih Laporan</option>
                            <option value="pembukuan">Laporan Pembukuan</option>
                        <option value="1">Laporan Transaksi Cabang</option>
                        </select>
                    </div>
                </div> -->
                <?php if ($this->data['users_groups']->id != 4) { ?>
                    <div class="col-md-3">
                        <div class="position-relative form-group">
                            <label for="">Pilih Cabang</label>
                            <select class="form-control select2" id="cabang_id" name="cabang_id">
                                <option value="" selected>Pilih Cabang</option>
                                <?php foreach ($cabang as $key => $value) { ?>
                                    <option value="<?php echo $value->id ?>"><?php echo $value->nama_cabang; ?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                <?php } ?>
                <div class="col-md-3">
                    <div class="position-relative form-group">
                        <label for="">Bulan & Tahun</label>
                        <input class="form-control init-year-month readonly" placeholder="<?php echo 'ex ' . date('m-Y') ?>" type="text" id="tanggal" name="tanggal" autocomplete="off">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="position-relative form-group">
                        <button type="button" class="mt-4 btn btn-success " id="preview-btn"><i class="fa fa-eye"> Preview</i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>

<div id="hasil-report">

</div>
<div id="hasil-laporan-tidak-ada">

</div>


<script data-main="<?php echo base_url() ?>assets/js/main/main-laporan-barang-hilang" src="<?php echo base_url() ?>assets/js/require.js"></script>