<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-credit-card icon-gradient bg-plum-plate"></i>
            </div>
            <div>Edit Data Pengeluaran</div>
        </div>
        <!-- <div class="page-title-actions">
            <div class="page-title-actions">
                <button type="button" data-toggle="tooltip" title="Example Tooltip" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                    <i class="fa fa-star"></i>
                </button>
            </div>
        </div> -->
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <h5>Data Detail Pengeluaran</h5>
            <div class="form-row">
                <div class="col-md-12">
                    <div class="position-relative form-group">
                        <label for="nama"></label>
                        <select class="form-control select2" id="enum_pengeluaran_id" name="enum_pengeluaran_id">
                            <option value="" selected>Pilih Nama</option>
                            <?php foreach ($enum_pengeluaran as $key => $value) { ?>
                                <option value="<?php echo $value->id ?>" <?php echo $data->enum_pengeluaran_id == $value->id ? 'selected' : ''; ?>><?php echo $value->nama; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <?php if ($data->enum_pengeluaran_id == 10) { ?>
                        <input type="hidden" id="cek" value="1">
                    <?php } ?>
                    <div class="position-relative form-group hide-keterangan">
                        <label for="keterangan">Ketrangan</label>
                        <input class="form-control" type="text" id="keterangan" name="keterangan" autocomplete="off" value="<?php echo $data->keterangan; ?>">
                    </div>
                    <div class="position-relative form-group">
                        <label for="harga">Harga</label>
                        <input class="form-control number" type="text" id="harga" name="harga" autocomplete="off" value="<?php echo $data->harga; ?>">
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                    </div>
                </div>
                <input type="hidden" id="value-btn-tambah" name="value-btn-tambah" value="0">
            </div>
            <div class="box-footer">
                <div class="row">
                    <div class="col-md-6">
                        <span class="reminder" style="color:red"><b>Mohon Periksa Kembali Form, Sebelum Disimpan</b></span>
                    </div>
                </div>
            </div>
            <button type="submit" class="mt-2 btn btn-primary pull-right" id="btn-tambah"><i class="fa fa-save"> Simpan</i></button>
            <!-- <button type="submit" class="mt-2 btn btn-success" id="btn-tambah"><i class="fa fa-plus"> </i></button> -->
            <a href="<?php echo base_url(); ?>pengeluaran" class="mt-2 mr-2 btn-transition btn btn-outline-danger pull-right"><i class="fa fa-times"> Batal</i></a>
        </div>
    </div>
</form>

<script data-main="<?php echo base_url() ?>assets/js/main/main-pengeluaran" src="<?php echo base_url() ?>assets/js/require.js"></script>