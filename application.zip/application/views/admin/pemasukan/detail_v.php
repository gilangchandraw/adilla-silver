<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-random icon-gradient bg-plum-plate"></i>
            </div>
            <div>Detail Data Pemasukan</div>
        </div>
        <!-- <div class="page-title-actions">
            <div class="page-title-actions">
                <button type="button" data-toggle="tooltip" title="Example Tooltip" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                    <i class="fa fa-star"></i>
                </button>
            </div>
        </div> -->
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <div class="form-row">
                <div class="col-md-12">
                    <div class="position-relative form-group">
                        <label for="tanggal">Tanggal</label>
                        <input class="form-control init-date readonly" disabled value="<?php echo $pemasukan->tanggal; ?>" type="text" id="tanggal" name="tanggal" autocomplete="off">
                    </div>
                </div>
            </div>
            <div class="card-body">
                <h5 class="card-title">Histori Data Pemasukan</h5>
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-bordered responsive w-100" id="table-detail">
                        <thead>
                            <th class="text-center">No</th>
                            <th class="text-center">Nama Pemasukan</th>
                            <th class="text-center">Keterangan</th>
                            <th class="text-center">Harga</th>
                            <th class="text-center">Aksi</th>

                        </thead>

                        <tbody>
                            <?php
                            $no = 1;
                            $total = 0;
                            if(!empty($data_pemasukan_detail)){
                            foreach ($data_pemasukan_detail as $key => $value) {
                            $total += $value->harga; ?>
                                <tr>
                                    <td class='text-center'><?php echo $no++; ?></td>
                                    <!-- <?php if($value->enum_kantor_id == 12){ ?>
                                        <td class='text-center'><?php echo $value->nama_enum_kantor.' - '.$value->keterangan; ?></td>
                                    <?php }else{ ?>
                                        <td class='text-center'><?php echo $value->nama_enum_kantor; ?></td>
                                    <?php } ?> -->
                                    <td class='text-center'><?php echo $value->nama_enum_kantor; ?></td>
                                    <td class='text-center'><?php echo $value->keterangan; ?></td>
                                    <td class='text-center'><?php echo number_format($value->harga); ?></td>
                                    <td class='text-center'><?php echo "<a href='#' class='btn btn-sm btn-danger delete-data' data-toggle='tooltip' detail_id='" . $value->id . "'' title='Hapus Data' data-placement='bottom'><i class='fa fa-times fa-w-20'></i></a>"; ?></td>
                                </tr>
                            <?php
                            }
                        }
                            ?>
                            <tr>
                                <td class='text-center' colspan="3"><b>Total</b></td>
                                <td class='text-center'><b><?php echo number_format($total); ?></b></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</form>

<script data-main="<?php echo base_url() ?>assets/js/main/main-pemasukan" src="<?php echo base_url() ?>assets/js/require.js"></script>