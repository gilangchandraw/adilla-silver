<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-clipboard icon-gradient bg-plum-plate"></i>
            </div>
            <div>Laporan Bulanan</div>
        </div>
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-3">
                    <div class="position-relative form-group">
                        <label for="">Pilih Cabang</label>
                        <select class="form-control select2" id="cabang_id" name="cabang_id">
                            <option value="" selected>Pilih Cabang</option>
                            <?php foreach ($cabang as $key => $value) { ?>
                                <option value="<?php echo $value->id ?>"><?php echo $value->nama_cabang; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="position-relative form-group">
                        <label for="">Bulan & Tahun</label>
                        <input class="form-control init-year-month readonly" placeholder="<?php echo 'ex '.date('m-Y')?>" type="text" id="tanggal" name="tanggal" autocomplete="off">
                    </div>
                </div>
                <div class="col-md-2">
                    <div class="position-relative form-group">
                        <button type="button" class="mt-4 btn btn-success " id="preview-btn"><i class="fa fa-eye"> Preview</i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>
<div id="hasil-report">
    
</div>
<div id="hasil-laporan-tidak-ada">
    
</div>
<div class="main-card mb-3 card">
    <div class="card-body">
        <section class="content">
            <div class="box box-default color-palette-box">
                <div class="box-body">
                    <div class="row" id="body_report">
                        <div class="col-md-6 mb-15" style="page-break-after: always; margin: auto; width: 50%; border: 3px; padding: 10px;">
                            <div class="paycheck-container" style="padding: 15px; border:1px solid #ebebeb;">
                                <div class="full-width paycheck-logo">
                                    <span></span>
                                    <p class="text-right"></p>
                                </div>
                                <table class="table-paycheck table table-border" align="center">
                                    <tbody>
                                        <tr>
                                            <td rowspan="4"><img style="height: 50px" src="<?php echo base_url(); ?>assets/images/logo.png"></td>
                                            <td class="text-center">ADILLA SILVER 925 GROUP</td>
                                        </tr>
                                        <tr>
                                            <td align="center" class="text-center">Laporan Bulanan</td>
                                        </tr>
                                        <tr>
                                            <td class="text-center">1</td>
                                        </tr>
                                        <tr>
                                            <td class="text-center">1>
                                        </tr>

                                    </tbody>
                                </table>
                                <table class="table-paycheck table table-border" border="1">
                                    <tbody>
                                        <tr>
                                            <td colspan="4" class="text-center">BULAN :</td>
                                        </tr>
                                        <tr align="center">
                                            <td class="text-center" style="background-color:#87CEEB;"> <strong>
                                                    TRANSAKSI</strong></td>
                                            <td class="text-center" style="background-color:#87CEEB;">
                                                <strong>KARAT</strong>
                                            </td>
                                            <td class="text-center" style="background-color:#87CEEB;">
                                                <strong>GRAM</strong></td>
                                            <td class="text-center" style="background-color:#87CEEB;">
                                                <strong>Rp</strong></td>
                                        </tr>
                                        <tr>
                                            <td align="center" class="text-center" rowspan="3"> <strong>PENJUALAN</strong> </td>
                                            <td class="text-center">[25]</td>
                                            <td class="text-center">1</td>
                                            <td class="text-center">1</td>
                                        </tr>
                                        <tr>
                                            <td class="text-center">[30]</td>
                                            <td class="text-center">1</td>
                                            <td class="text-center">1</td>
                                        </tr>
                                        <tr>
                                            <td class="text-center">[35]</td>
                                            <td class="text-center">1</td>
                                            <td class="text-center">1</td>
                                        </tr>
                                        <!-- tukarplus -->
                                        <tr>
                                            <td align="center" class="text-center" rowspan="3"> <strong> TUKAR [+]</strong></td>
                                            <td class="text-center">[25]</td>
                                            <td class="text-center">1</td>
                                            <td class="text-center">1</td>
                                        </tr>
                                        <tr>
                                            <td class="text-center">[30]</td>
                                            <td class="text-center">1>
                                            <td class="text-center">1>
                                        </tr>
                                        <tr>
                                            <td class="text-center">[35]</td>
                                            <td class="text-center">1</td>
                                            <td class="text-center">1</td>
                                        </tr>
                                        <tr style="background-color:#98FB98;">
                                            <td align="center" colspan="2" class="text-center"> <strong>TOTAL PENJUALAN
                                                </strong> </td>
                                            <td class="text-center">1</td>
                                            <td class="text-center">1</td>
                                        </tr>
                                        <!-- BK -->
                                        <tr>
                                            <td class="text-center" rowspan="7"> <strong> BARANG KEMBALI</strong></td>
                                            <td class="text-center">[20]</td>
                                            <td class="text-center">1</td>
                                            <td class="text-center">1</td>
                                        </tr>
                                        <tr>
                                            <td class="text-center">[22]</td>
                                            <td class="text-center">1>
                                            <td class="text-center">1>
                                        </tr>
                                        <tr>
                                            <td class="text-center">[23]</td>
                                            <td class="text-center">1</td>
                                            <td class="text-center">1</td>
                                        </tr>
                                        <tr>
                                            <td class="text-center">[25]</td>
                                            <td class="text-center">1</td>
                                            <td class="text-center">1</td>
                                        </tr>
                                        <tr>
                                            <td class="text-center">[27]</td>
                                            <td class="text-center">1</td>
                                            <td class="text-center">1</td>
                                        </tr>
                                        <tr>
                                            <td class="text-center">[28]</td>
                                            <td class="text-center">1</td>
                                            <td class="text-center">1</td>
                                        </tr>
                                        <tr>
                                            <td class="text-center">[30]</td>
                                            <td class="text-center">1</td>
                                            <td class="text-center">1</td>
                                        </tr>
                                        <tr style="background-color:#98FB98;">
                                            <td align="center" colspan="2" class="text-center"> <strong>TOTAL BARANG KEMBALI
                                                </strong> </td>
                                            <td class="text-center">1</td>
                                            <td class="text-center">1 </td>
                                        </tr>
                                        <!-- Pengeluaran -->
                                        <tr>
                                            <td align="center" class="text-center" rowspan="7"> <strong> PENGELUARAN</strong>
                                            </td>
                                            <td align="center" class="text-center">
                                                <strong>
                                                    Nama</strong></td>
                                            <td align="center" colspan="3" class="text-center"> <strong> Rp</strong></td>
                                        </tr>
                                        <tr>
                                            <td class="text-center">KONTRAK TOKO</td>
                                            <td align="center" colspan="3" class="text-center"> <strong> </strong></td>
                                        </tr>
                                        <tr>
                                            <td class="text-center">GAJI/BONUS</td>
                                            <td align="center" colspan="3" class="text-center"> <strong> </strong></td>
                                        </tr>
                                        <tr>
                                            <td class="text-center">LISTRIK</td>
                                            <td align="center" colspan="3" class="text-center"> <strong> </strong></td>
                                        </tr>
                                        <tr>
                                            <td class="text-center">PDAM</td>
                                            <td align="center" colspan="3" class="text-center"> <strong> </strong></td>
                                        </tr>
                                        <tr>
                                            <td class="text-center">MOBIL</td>
                                            <td align="center" colspan="3" class="text-center"> <strong> </strong></td>
                                        </tr>
                                        <tr>
                                            <td class="text-center">DLL</td>
                                            <td align="center" colspan="3" class="text-center"> <strong> </strong></td>
                                        </tr>
                                        <tr style="background-color:#98FB98;">
                                            <td align="center" colspan="2" class="text-center"> <strong>TOTAL PENGELUARAN
                                                </strong>
                                            </td>
                                            <td align="center" colspan="3" class="text-center"> <strong> </strong></td>
                                        </tr>
                                        <tr style="background-color:#98FB98;">
                                            <td align="center" colspan="2" class="text-center"> <strong>KAS </strong>
                                            </td>
                                            <td align="center" colspan="3" class="text-center"> <strong> </strong></td>
                                        </tr>
                                        <tr>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>

<script data-main="<?php echo base_url() ?>assets/js/main/main-laporan_bulanan" src="<?php echo base_url() ?>assets/js/require.js"></script>