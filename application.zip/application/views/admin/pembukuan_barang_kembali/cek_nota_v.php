<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-book-open icon-gradient bg-plum-plate"></i>
            </div>
            <div>Cek No Nota</div>
        </div>
        <!-- <div class="page-title-actions">
            <div class="page-title-actions">
                <button type="button" data-toggle="tooltip" title="Example Tooltip" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                    <i class="fa fa-star"></i>
                </button>
            </div>
        </div> -->
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <!-- <h5>Data Transaksi</h5> -->
            <div class="form-row">
                <div class="col-md-12">
                    <div class="position-relative form-group">
                        <label for="no_nota">No Nota</label>
                        <input class="form-control" type="text" id="no_nota" name="no_nota" autocomplete="off">
                    </div>
                </div>
            </div>
            <button type="button" class="mt-2 btn btn-primary pull-right" id="btn-cek"><i class="fa fa-save"> Cek</i></button>
            <a href="<?php echo base_url(); ?>barang_kembali" class="mt-2 mr-2 btn-transition btn btn-outline-danger pull-right">Selesai</a>
        </div>
        <div class="col-md-12" id="hasil_cek">
            <div class="position-relative form-group">
                <label for="no_nota">Hasil Cek No Nota</label>
                <input class="form-control" type="text" style="background-color: #FF0000;color:white;" id="nota_ada" readonly>
                <input class="form-control" type="text" style="background-color: #7CFC00;color:black;" id="nota_tidak_ada" readonly>
            </div>
        </div>
    </div>
</form>

<script data-main="<?php echo base_url() ?>assets/js/main/main-barang_kembali" src="<?php echo base_url() ?>assets/js/require.js"></script>