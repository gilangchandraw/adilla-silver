<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-credit-card icon-gradient bg-plum-plate"></i>
            </div>
            <div>Tambah Data Barang Kembali</div>
        </div>
        <!-- <div class="page-title-actions">
            <div class="page-title-actions">
                <button type="button" data-toggle="tooltip" title="Example Tooltip" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                    <i class="fa fa-star"></i>
                </button>
            </div>
        </div> -->
    </div>
</div>
<div class="main-card mb-3 card">
    <div class="card-body">
        <div class="form-row">
            <div class="col-md-6">
                <div class="position-relative form-group">
                    <label for="no_nota_tambah">No Nota</label>
                    <input class="form-control" type="text" id="no_nota_tambah" name="no_nota_tambah" autocomplete="off">
                </div>
            </div>
            <div class="col-md-6">
                <div class="position-relative form-group">
                    <label for="kode_cabang">Cabang</label>
                    <select class="form-control select2" id="kode_cabang" name="kode_cabang">
                        <option value="" selected>Pilih Cabang</option>
                        <?php foreach ($cabang as $key => $value) { ?>
                            <option value="<?php echo $value->kode_cabang; ?>"><?php echo $value->kode_cabang . ' - ' . $value->nama_cabang; ?></option>
                        <?php } ?>
                    </select>
                </div>
            </div>
        </div>
        <button type="button" class="mt-2 btn btn-primary pull-right" id="btn_cek_tambah"><i class="fa fa-save"> Get Data</i></button>
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <!-- <h5>Data Transaksi</h5> -->
        <div class="card-body" id="nota_tambah_ada">
            <h5>Data Detail Transaksi Penjualan</h5>
            <div class="table-responsive">
                <table class="table table-striped table-hover table-bordered responsive w-100">
                    <thead>
                        <th class="text-center">Cabang</th>
                        <th class="text-center">Tanggal Penjualan</th>
                        <th class="text-center">Karyawan</th>
                        <th class="text-center">No Nota</th>
                        <th class="text-center">Karat</th>
                        <th class="text-center">Nama Perhiasan</th>
                        <th class="text-center">Potong</th>
                        <th class="text-center">Berat/Gram</th>
                        <th class="text-center">Harga</th>
                    </thead>
                    <tr>
                        <td class="text-center" id="cabang"></td>
                        <td class="text-center" id="tanggal_penjualan"></td>
                        <td class="text-center" id="nama_karyawan"></td>
                        <td class="text-center" id="no_nota_html"></td>
                        <td class="text-center" id="nama_jenis"></td>
                        <td class="text-center" id="nama_barang"></td>
                        <td class="text-center" id="potong"></td>
                        <td class="text-center" id="berat_html"></td>
                        <td class="text-center" id="harga"></td>
                    </tr>
                    <tbody>
                    </tbody>
                </table>
            </div>
            <div class="form-row">
                <input class="form-control" type="hidden" id="no_nota" name="no_nota" autocomplete="off">
                <input type="hidden" readonly id="berat" name="berat" autocomplete="off">
                <input class="form-control" readonly type="hidden" id="harga_jenis" name="harga_jenis">
                <input class="form-control" readonly type="hidden" id="penjualan_id" name="penjualan_id">
                <input class="form-control" readonly type="hidden" id="harga_jenis_barang_kembali" name="harga_jenis_barang_kembali">
                <input class="form-control" readonly type="hidden" id="hasil_before_pengurangan" name="hasil_before_pengurangan">
                <input class="form-control" readonly type="hidden" id="potongan_hilang" name="potongan_hilang">
                <input type="hidden" id="value-btn-tambah" name="value-btn-tambah" value="0">
            </div>
            <br>
            <h5>Data Detail Transaksi Barang Kembali</h5>
            <div class="form-row">
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="tanggal">Tanggal Transaksi</label>
                        <input class="form-control init-date readonly" type="text" id="tanggal" name="tanggal" autocomplete="off">
                    </div>
                    <div class="position-relative form-group">
                        <label for="cabang_id">Cabang</label>
                        <select class="form-control select2" id="cabang_id" name="cabang_id">
                            <option value="" selected>Pilih Cabang</option>
                            <?php foreach ($cabang as $key => $value) { ?>
                                <option value="<?php echo $value->id ?>"><?php echo $value->kode_cabang . ' - ' . $value->nama_cabang; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="position-relative form-group">
                        <label for="Kualitas">Kualitas Barang</label>
                        <select class="form-control" id="kualitas" name="kualitas">
                            <option value="" selected>Pilih Kualitas Barang</option>
                            <option value="1">Utuh</option>
                            <option value="2">Barang Rusak</option>
                            <option value="3">Barang Hilang</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="potongan">Potongan</label>
                        <select class="form-control" id="potongan" name="potongan">
                            <option value="" selected>Pilih Potongan</option>
                            <option value="5000">5000</option>
                            <option value="7000">7000</option>
                            <option value="8000">8000</option>
                        </select>
                    </div>
                    <div class="position-relative form-group" id="potongan-rusak">
                        <label for="potongan_rusak">Potongan Rusak</label>
                        <input class="form-control number" type="text" id="potongan_rusak" name="potongan_rusak">
                    </div>
                    <div class="position-relative form-group" id="barang-hilang">
                        <label for="berat_barang_hilang">Berat Barang Hilang</label>
                        <input class="form-control number" type="text" id="berat_barang_hilang" name="berat_barang_hilang">
                    </div>
                    <div class="position-relative form-group">
                        <label for="harga_barang_kembali">Harga Barang Kembali</label>
                        <input class="form-control" readonly type="text" id="harga_barang_kembali" name="harga_barang_kembali">
                    </div>
                </div>
            </div>
            <div class="box-footer">
                <div class="row">
                    <div class="col-md-6">
                        <span class="reminder" style="color:red"><b>Mohon Periksa Kembali Form, Sebelum Disimpan</b></span>
                    </div>
                </div>
            </div>
            <button type="submit" class="mt-2 btn btn-primary pull-right" id="btn-tambah"><i class="fa fa-save"> Simpan & Tambah Penjualan</i></button>
            <a href="<?php echo base_url(); ?>barang_kembali" class="mt-2 mr-2 btn-transition btn btn-outline-danger pull-right"><i class="fa fa-times"> Batal</i></a>

        </div>
        <div class="col-md-12" id="hasil_cek">
            <div class="position-relative form-group">
                <label for="no_nota">Hasil Cek No Nota</label>
                <!-- <textarea class="form-control" style="background-color: #FF0000;color:white;" id="nota_ada" readonly></textarea> -->
                <input class="form-control" type="text" style="background-color: #FF0000;color:white;" id="nota_tidak_ada" readonly>
            </div>
        </div>
    </div>
</form>

<script data-main="<?php echo base_url() ?>assets/js/main/main-barang_kembali" src="<?php echo base_url() ?>assets/js/require.js"></script>