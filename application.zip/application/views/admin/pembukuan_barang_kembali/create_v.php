<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-book-open icon-gradient bg-plum-plate"></i>
            </div>
            <div>Tambah Data Barang Kembali</div>
        </div>
        <!-- <div class="page-title-actions">
            <div class="page-title-actions">
                <button type="button" data-toggle="tooltip" title="Example Tooltip" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                    <i class="fa fa-star"></i>
                </button>
            </div>
        </div> -->
    </div>
</div>
<div class="main-card mb-3 card">
    <div class="card-body">
        <div class="form-row">
            <div class="col-md-12">
                <div class="position-relative form-group">
                    <label for="cabang_id">Cabang</label>
                    <select class="form-control select2" id="cabang_id" name="cabang_id">
                        <option value="" selected>Pilih Cabang</option>
                        <?php foreach ($cabang as $key => $value) { ?>
                            <option value="<?php echo $value->id; ?>"><?php echo $value->kode_cabang . ' - ' . $value->nama_cabang; ?></option>
                        <?php } ?>
                    </select>
                </div>
            </div>
        </div>
        <button type="button" class="mt-2 btn btn-primary pull-right" id="btn_cek_tambah"><i class="fa fa-save"> Get Data</i></button>
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <!-- <h5>Data Transaksi</h5> -->
        <div class="card-body" id="nota_tambah_ada">
            <div class="form-row">
                <input type="hidden" id="value-btn-tambah" name="value-btn-tambah" value="0">
            </div>
            <br>
            <h5>Data Detail Transaksi Barang Kembali</h5>
            <div class="form-row">
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="tanggal">Tanggal Transaksi</label>
                        <input class="form-control init-date readonly" type="text" id="tanggal" name="tanggal" autocomplete="off">
                        <input type="hidden" name="cabang_id_bk" id="cabang_id_bk">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="no_nota_id">No Nota</label>
                        <select class="form-control select2" id="no_nota_id" name="no_nota_id">
                            <option value="" selected>Pilih No Nota</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="box-footer">
                <div class="row">
                    <div class="col-md-6">
                        <span class="reminder" style="color:red"><b>Mohon Periksa Kembali Form, Sebelum Disimpan</b></span>
                    </div>
                </div>
            </div>
            <button type="submit" class="mt-2 btn btn-primary pull-right" id="btn-tambah"><i class="fa fa-save"> Simpan & Tambah Penjualan</i></button>
            <a href="<?php echo base_url(); ?>pembukuan_barang_kembali" class="mt-2 mr-2 btn-transition btn btn-outline-danger pull-right"><i class="fa fa-times"> Batal</i></a>

        </div>
        <div class="card-body" id="nota_tambah_tidak_ada">
            <div class="form-row">
                <h5>No Nota pembukuan Belum Diinputkan</h5>
            </div>
        </div>
    </div>
</form>

<script data-main="<?php echo base_url() ?>assets/js/main/main-pembukuan-barang-kembali" src="<?php echo base_url() ?>assets/js/require.js"></script>