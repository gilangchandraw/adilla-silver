<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-book-open icon-gradient bg-plum-plate"></i>
            </div>
            <div>Detail Data Barang Kembali</div>
        </div>
        <!-- <div class="page-title-actions">
            <div class="page-title-actions">
                <button type="button" data-toggle="tooltip" title="Example Tooltip" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                    <i class="fa fa-star"></i>
                </button>
            </div>
        </div> -->
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <?php if (!empty($this->session->flashdata('message'))) { ?>
                <div class="card-header">
                    <div class="alert alert-info fade show text-center w-100" role="alert">
                        <?php print_r($this->session->flashdata('message')); ?>
                    </div>
                </div>
            <?php } ?>

            <?php if (!empty($this->session->flashdata('message_error'))) { ?>
                <div class="card-header">
                    <div class="alert alert-danger fade show text-center w-100" role="alert">
                        <?php print_r($this->session->flashdata('message_error')); ?>
                    </div>
                </div>
            <?php } ?>
            <div class="form-row">
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="tanggal">Tanggal Transaksi</label>
                        <input class="form-control init-date readonly" disabled value="<?php echo $barang_kembali->tanggal; ?>" type="text" id="tanggal" name="tanggal" autocomplete="off">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="tanggal">Cabang</label>
                        <input class="form-control" disabled value="<?php echo $barang_kembali->kode_cabang . ' - ' . $barang_kembali->nama_cabang; ?>" type="text" id="tanggal" name="tanggal" autocomplete="off">
                    </div>
                </div>
            </div>
            <div class="card-body">
                <h5 class="card-title">Histori Data Barang Kembali</h5>
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-bordered responsive w-100" id="table">
                        <thead>
                            <th class="text-center">No</th>
                            <th class="text-center">No Nota</th>
                            <th class="text-center">Aksi</th>
                        </thead>

                        <tbody>
                            <?php
                            $no = 1;
                            if ($data_barang_kembali_detail) {
                                foreach ($data_barang_kembali_detail as $key => $value) { ?>
                                    <tr>
                                        <td class='text-center'><?php echo $no++; ?></td>
                                        <td class='text-center'><?php echo $value->no_nota; ?></td>
                                        <td class='text-center'><?php echo "<a href='#' class='btn btn-sm btn-danger delete-data' data-toggle='tooltip' detail_id='" . $value->id . "'' title='Hapus Data' data-placement='bottom'><i class='fa fa-times fa-w-20'></i></a>"; ?></td>
                                    </tr>
                            <?php
                                }
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</form>

<script data-main="<?php echo base_url() ?>assets/js/main/main-pembukuan-barang-kembali" src="<?php echo base_url() ?>assets/js/require.js"></script>