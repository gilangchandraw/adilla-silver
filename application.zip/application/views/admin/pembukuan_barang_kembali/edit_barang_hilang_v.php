<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-book-open icon-gradient bg-plum-plate"></i>
            </div>
            <div>Edit Data Barang Hilang</div>
        </div>
        <!-- <div class="page-title-actions">
            <div class="page-title-actions">
                <button type="button" data-toggle="tooltip" title="Example Tooltip" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                    <i class="fa fa-star"></i>
                </button>
            </div>
        </div> -->
    </div>
</div>

<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <h5 class="card-title">Histori Data Barang Kembali</h5>
            <div class="table-responsive">
                <table class="table table-striped table-hover table-bordered responsive w-100">
                    <thead>
                        <th class="text-center">Karyawan</th>
                        <th class="text-center">No Nota</th>
                        <th class="text-center">Karat</th>
                        <th class="text-center">Nama Perhiasan</th>
                        <th class="text-center">Potong</th>
                        <th class="text-center">Potongan</th>
                        <th class="text-center">Berat/Gram</th>
                        <th class="text-center">Harga</th>
                    </thead>

                    <tbody>
                        <tr>
                            <td class='text-center'><?php echo $bk->nama_karyawan; ?></td>
                            <td class='text-center'><?php echo $bk->no_nota; ?></td>
                            <td class='text-center'><?php echo $bk->nama_jenis; ?></td>
                            <td class='text-center'><?php echo $bk->nama_barang; ?></td>
                            <td class='text-center'><?php echo $bk->potong; ?></td>
                            <td class='text-center'><?php echo number_format($bk->potongan); ?></td>
                            <td class='text-center'><?php echo $bk->berat; ?></td>
                            <td class='text-center'><?php echo number_format($bk->harga); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
        <!-- <h5>Data Transaksi</h5> -->
        <div class="card-body">
            <div class="form-row">
                <input class="form-control" value="<?php echo $barang_hilang_id; ?>" type="hidden" id="barang_hilang_id" name="barang_hilang_id" autocomplete="off">
                <input class="form-control" value="<?php echo $bk->berat; ?>" type="hidden" id="berat" name="berat" autocomplete="off">
                <input type="hidden" id="value-btn-tambah" name="value-btn-tambah" value="0">
            </div>
            <h5 class="card-title">Edit Data Barang Hilang</h5>
            <div class="form-row">
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="no_nota">Karyawan</label>
                        <input class="form-control" readonly type="text" value="<?php echo $data->nama_karyawan; ?>" autocomplete="off">
                    </div>
                    <div class="position-relative form-group">
                        <label for="no_nota">No Nota</label>
                        <input class="form-control" readonly type="text" value="<?php echo $data->no_nota; ?>" id="no_nota" name="no_nota" autocomplete="off">
                    </div>
                    <div class="position-relative form-group">
                        <label for="no_nota">Karat</label>
                        <input class="form-control" readonly type="text" value="<?php echo $data->nama_jenis; ?>" id="karat" name="karat" autocomplete="off">
                    </div>
                    <div class="position-relative form-group">
                        <label for="no_nota">Barang</label>
                        <input class="form-control" readonly type="text" value="<?php echo $data->nama_barang; ?>" id="karat" name="karat" autocomplete="off">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="potongan">Potongan</label>
                        <input class="form-control" readonly type="text" value="<?php echo $data->potongan; ?>" id="potongan" name="potongan" autocomplete="off">
                    </div>
                    <div class="position-relative form-group">
                        <label for="berat">berat Hilang</label>
                        <input class="form-control" type="text" value="<?php echo $data->berat; ?>" id="berat_barang_hilang" name="berat_barang_hilang" autocomplete="off">
                    </div>

                    <input class="form-control number" type="hidden" id="potongan_hilang" name="potongan_hilang">
                    <div class="position-relative form-group">
                        <label for="harga_barang_kembali">Harga Barang Kembali</label>
                        <input class="form-control" readonly type="text" value="<?php echo $data->harga; ?>" id="harga_barang_kembali" name="harga_barang_kembali">
                    </div>
                </div>
            </div>
            <button type="submit" class="mt-2 btn btn-primary pull-right" id="btn-tambah"><i class="fa fa-save"> Simpan & Tambah Penjualan</i></button>
            <a href="<?php echo base_url(); ?>pembukuan_barang_kembali" class="mt-2 mr-2 btn-transition btn btn-outline-danger pull-right"><i class="fa fa-times"> Batal</i></a>
        </div>

    </div>
</form>

<script data-main="<?php echo base_url() ?>assets/js/main/main-barang_kembali" src="<?php echo base_url() ?>assets/js/require.js"></script>