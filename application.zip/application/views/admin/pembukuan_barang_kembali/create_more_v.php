<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-book-open icon-gradient bg-plum-plate"></i>
            </div>
            <div>Tambah Data Barang Kembali</div>
        </div>
        <!-- <div class="page-title-actions">
            <div class="page-title-actions">
                <button type="button" data-toggle="tooltip" title="Example Tooltip" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                    <i class="fa fa-star"></i>
                </button>
            </div>
        </div> -->
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <!-- <h5>Data Transaksi</h5> -->
        <div class="card-body">
            <div class="form-row">
                <input type="hidden" id="value-btn-tambah" name="value-btn-tambah" value="0">
            </div>
            <br>
            <h5>Data Detail Transaksi Barang Kembali</h5>
            <?php if (!empty($this->session->flashdata('message'))) { ?>
                <div class="card-header">
                    <div class="alert alert-info fade show text-center w-100" role="alert">
                        <?php print_r($this->session->flashdata('message')); ?>
                    </div>
                </div>
            <?php } ?>

            <?php if (!empty($this->session->flashdata('message_error'))) { ?>
                <div class="card-header">
                    <div class="alert alert-danger fade show text-center w-100" role="alert">
                        <?php print_r($this->session->flashdata('message_error')); ?>
                    </div>
                </div>
            <?php } ?>
            <div class="form-row">
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="tanggal">Tanggal Transaksi</label>
                        <input class="form-control" readonly type="text" autocomplete="off" value="<?php echo $barang_kembali->tanggal; ?>">
                        <input type="hidden" name="cabang_id_tukar" id="cabang_id_tukar">
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="tanggal">Cabang</label>
                        <input class="form-control" readonly type="text" id="tanggal" name="tanggal" autocomplete="off" value="<?php echo $barang_kembali->nama_cabang; ?>">
                    </div>
                </div>
                <div class="col-md-12">
                    <div class="position-relative form-group">
                        <label for="no_nota_id">No Nota</label>
                        <select class="form-control select2" id="no_nota_id" name="no_nota_id">
                            <option value="" selected>Pilih No Nota</option>
                            <?php
                            foreach ($nota_pembukuan as $key => $value) { ?>
                                <option value="<?php echo $value->id; ?>"><?php echo $value->no_nota; ?></option>
                            <?php }
                            ?>
                        </select>
                        <input type="hidden" name="cabang_id_bk" id="cabang_id_bk">
                        <input type="hidden" name="barang_kembali_id" id="barang_kembali_id" value="<?php echo $id; ?>">
                    </div>
                </div>
            </div>
            <div class="box-footer">
                <div class="row">
                    <div class="col-md-6">
                        <span class="reminder" style="color:red"><b>Mohon Periksa Kembali Form, Sebelum Disimpan</b></span>
                    </div>
                </div>
            </div>
            <button type="submit" class="mt-2 btn btn-primary pull-right" id="btn-tambah"><i class="fa fa-save"> Simpan & Tambah Penjualan</i></button>
            <a href="<?php echo base_url(); ?>pembukuan_barang_kembali" class="mt-2 mr-2 btn-transition btn btn-outline-danger pull-right"><i class="fa fa-times"> Batal</i></a>

        </div>
    </div>
</form>
<div class="main-card mb-3 card">
    <div class="card-body">
        <h5 class="card-title">Histori Data Barang Kembali</h5>
        <div class="table-responsive">
            <table class="table table-striped table-hover table-bordered responsive w-100">
                <thead>
                    <th class="text-center">No</th>
                    <th class="text-center">No Nota</th>
                </thead>

                <tbody>
                    <?php
                    $no = 1;
                    if ($data_barang_kembali_detail) {
                        foreach ($data_barang_kembali_detail as $key => $value) { ?>
                            <tr>
                                <td class='text-center'><?php echo $no++; ?></td>
                                <td class='text-center'><?php echo $value->no_nota; ?></td>
                            </tr>
                    <?php
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script data-main="<?php echo base_url() ?>assets/js/main/main-pembukuan-barang-kembali" src="<?php echo base_url() ?>assets/js/require.js"></script>