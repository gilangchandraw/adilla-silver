<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-database icon-gradient bg-plum-plate"></i>
            </div>
            <div>Edit Data Barang Keluar</div>
        </div>
        <!-- <div class="page-title-actions">
            <div class="page-title-actions">
                <button type="button" data-toggle="tooltip" title="Example Tooltip" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                    <i class="fa fa-star"></i>
                </button>
            </div>
        </div> -->
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="tanggal">Tanggal</label>
                        <input class="form-control" type="text" id="tanggal" value="<?php echo $barang_keluar->tanggal; ?>" name="tanggal">
                    </div>
                    <div class="position-relative form-group">
                        <label for="kode_barang">Kode barang</label>
                        <input class="form-control" type="text" id="kode_barang" value="<?php echo $barang_keluar->kode_barang; ?>" name="kode_barang">
                    </div>
                </div>
                <input type="hidden" name="id" value="<?php echo $barang_keluar->id; ?>">
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="nama_barang">Nama barang</label>
                        <input class="form-control" type="text" id="nama_barang" value="<?php echo $barang_keluar->nama_barang; ?>" name="nama_barang_keluar">
                    </div>
                    <div class="position-relative form-group">
                        <label for="stok">Jumlah Barang Keluar</label>
                        <input class="form-control number" type="text" id="stok" value="<?php echo $barang_keluar->stok; ?>" name="stok">
                    </div>
                </div>
            </div>
            <div class="box-footer">
                <div class="row">
                    <div class="col-md-6">
                        <span class="reminder" style="color:red"><b>Mohon Periksa Kembali Form, Sebelum Disimpan</b></span>
                    </div>
                </div>
            </div>
            <button type="submit" class="mt-2 btn btn-primary pull-right" id="save-btn"><i class="fa fa-save"> Simpan</i></button>
            <a href="<?php echo base_url(); ?>barang_keluar" class="mt-2 mr-2 btn-transition btn btn-outline-danger pull-right"><i class="fa fa-times"> Batal</i></a>
        </div>
    </div>
</form>

<script data-main="<?php echo base_url() ?>assets/js/main/main-barang_keluar" src="<?php echo base_url() ?>assets/js/require.js"></script>