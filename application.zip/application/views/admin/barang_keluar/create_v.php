<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-truck icon-gradient bg-plum-plate"></i>
            </div>
            <div>Tambah Data Barang Keluar</div>
        </div>
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="tanggal">Tanggal</label>
                        <input class="form-control init-date " type="text" id="tanggal" name="tanggal" autocomplete="off">
                        <!-- <input class="form-control" readonly value="<?php echo date('Y-m-d'); ?>"  type="text" id="tanggal" name="tanggal" autocomplete="off"> -->
                    </div>
                    <div class="position-relative form-group">
                        <label for="nama_cabang">Nama Cabang</label>
                        <select class="form-control select2" id="nama_cabang" name="nama_cabang">
                            <option value="" selected>Pilih Cabang</option>
                            <?php foreach ($cabang as $key => $value) { ?>
                                <option value="<?php echo $value->id ?>"><?php echo $value->kode_cabang . ' - ' . $value->nama_cabang; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="position-relative form-group">
                        <div class="position-relative form-check custom-control-inline">
                            <label class="form-check-label">
                                <input name="status_sk" type="radio" class="form-check-input" id="status_sk" value="1">
                                Barang Perhiasan
                            </label>
                        </div>

                        <div class="position-relative form-check custom-control-inline">
                            <label class="form-check-label">
                                <input name="status_sk" type="radio" class="form-check-input" id="status_sk" value="2">
                                Barang Sepuhan
                            </label>
                        </div>
                        <div class="position-relative form-check custom-control-inline">
                            <label class="form-check-label">
                                <input name="status_sk" type="radio" class="form-check-input" id="status_sk" value="3">
                                Barang Kotak Cincin
                            </label>
                        </div>
                    </div>
                    <div class="position-relative form-group" id="barang_view">
                        <label>Perhiasan</label>
                        <select class="form-control select2" id="barang_id" name="barang_id" value="1">
                            <option value="" selected>Nama Perhiasan</option>
                            <?php foreach ($barang as $key => $value) { ?>
                                <option value="<?php echo $value->id ?>"><?php echo $value->kode_barang . ' - ' . $value->nama_barang; ?></option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="position-relative form-group" id="barang_sepuhan_view">
                        <label>Barang Sepuhan</label>
                        <select class="form-control select2" id="barang_sepuhan_id" name="barang_sepuhan_id" value="2">
                            <option value="" selected>Nama Sepuhan</option>
                            <?php foreach ($barang_sepuhan as $key => $value) { ?>
                                <option value="<?php echo $value->id ?>"><?php echo $value->kode_sepuhan . ' - ' . $value->nama_barang; ?></option>
                            <?php } ?>
                        </select>
                    </div>

                    <div class="position-relative form-group" id="barang_kotak_cincin_view">
                        <label>Barang Kotak Cincin</label>
                        <select class="form-control select2" id="barang_kotak_cincin_id" name="barang_kotak_cincin_id" value="3">
                            <option value="" selected>Nama Kotak Cincin</option>
                            <?php foreach ($barang_kotak_cincin as $key => $value) { ?>
                                <option value="<?php echo $value->id ?>"><?php echo $value->kode_kotak_cincin . ' - ' . $value->nama_barang; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="jumlah_barang">Jumlah Barang Keluar</label>
                        <input class="form-control number" type="text" id="jumlah_barang" name="jumlah_barang">
                    </div>
                    <div class="position-relative form-group">
                        <label for="total_harga">Total Harga</label>
                        <input class="form-control number" type="text" id="total_harga" name="total_harga" autocomplete="off">
                    </div>
                </div>
            </div>
            <div class="box-footer">
                <div class="row">
                    <div class="col-md-6">
                        <span class="reminder" style="color:red"><b>Mohon Periksa Kembali Form, Sebelum Disimpan</b></span>
                    </div>
                </div>
            </div>
            <button type="submit" class="mt-2 btn btn-primary pull-right" id="save-btn"><i class="fa fa-save"> Simpan</i></button>
            <a href="<?php echo base_url(); ?>barang_keluar" class="mt-2 mr-2 btn-transition btn btn-outline-danger pull-right"><i class="fa fa-times"> Batal</i></a>
        </div>
    </div>
</form>

<script data-main="<?php echo base_url() ?>assets/js/main/main-barang_keluar" src="<?php echo base_url() ?>assets/js/require.js"></script>