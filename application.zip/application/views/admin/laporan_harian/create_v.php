<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-clipboard icon-gradient bg-plum-plate"></i>
            </div>
            <div>Laporan Harian</div>
        </div>
        <!-- <div class="page-title-actions">
            <a href="#" data-toggle="tooltip" target="_blank" id="print-pdf" title="" data-placement="bottom" class="btn-shadow mr-3 btn btn-danger">
                <i class='fa fa-file-pdf'></i> Export PDF
            </a>
        </div> -->
    </div>
</div>
<div class="main-card mb-3 card">
    <div class="card-body">
        <div class="row">
            <?php if($this->data['users_groups']->id != 4){ ?>
            <!-- <div class="col-md-3">
                <div class="position-relative form-group">
                    <label for="">Jenis Laporan</label>
                    <select class="form-control" type="text" id="laporan" autocomplete="off">
                        <option value="">Pilih Laporan</option>
                        <option value="pembukuan">Laporan Pembukuan</option>
                        <option value="1">Laporan Transaksi Cabang</option>
                    </select>
                </div>
            </div> -->
            <div class="col-md-3">
                <div class="position-relative form-group">
                    <label for="">Cabang</label>
                    <select class="form-control select2" id="cabang_id">
                            <option value="" selected>Pilih Cabang</option>
                        <?php foreach ($cabang as $key => $value) { ?>
                            <option value="<?php echo $value->id ?>"><?php echo $value->nama_cabang; ?></option>
                        <?php } ?>
                    </select>
                </div>
            </div>
            <?php } ?>
            <div class="col-md-3">
                <div class="position-relative form-group">
                    <label for="">Tanggal Transaksi</label>
                    <input class="form-control init-date readonly" placeholder="<?php echo 'ex '.date('Y-m-d')?>" type="text" id="tanggal" autocomplete="off">
                </div>
            </div>


            <div class="col-md-2">
                <div class="position-relative form-group">
                    <button type="button" class="mt-4 btn btn-success " id="preview-btn"><i class="fa fa-eye"> Preview</i></button>
                </div>
            </div>
        </div>
    </div>
</div>
<?php if (!empty($this->session->flashdata('message_error'))) { ?>
                <div class="card-header">
                    <div class="alert alert-danger fade show text-center w-100" role="alert">
                        <?php print_r($this->session->flashdata('message_error')); ?>
                    </div>
                </div>
            <?php } ?>
<div id="hasil-report">
    
</div>
<div id="hasil-laporan-tidak-ada">
    
</div>
<!-- <div class="main-card mb-3 card" id="hasil-laporan">
    <div class="card-body">
        <div class="row">
            <table border="1" align="center" cellspacing="0" cellpadding="5">

                <td colspan="5">
                    <img src="<?php echo base_url(); ?>assets/images/logo.png" alt="Logo" class="center" width="90" height="50">
                    <strong>
                        ADILLA SILVER 925 GROUP
                    </strong>
                    <p align="right" id="tanggal_laporan"></p>
                    <p align="right" id="cabang"></p>
                </td>

                <tr align="center">
                    <td colspan="5">
                        <strong>
                            LAPORAN AKTIVITAS
                        </strong></td>
                </tr>
                <tr align="center">
                    <td colspan="4">
                        <strong>GRAM</strong></td>
                    <td colspan="2" width="120"><strong>Rp</strong></td>
                </tr>
                <tr>
                    <td colspan="2" width="200"> <strong>PENJUALAN</strong> <p class="pull-right">[25]</p></td>
                    <td colspan="2" width="120" class="text-center" id="berat_penjualan_25"></td>
                    <td class="text-center" id="harga_penjualan_25"></td>
                </tr>
                <tr>
                    <td colspan="2" width="200"><p class="pull-right">[30]</p></td>
                    <td colspan="2" class="text-center" width="120" id="berat_penjualan_30"></td>
                    <td id="harga_penjualan_30" class="text-center"></td>
                </tr>
                <tr>
                    <td colspan="2" width="200"><p class="pull-right">[35]</p></td>
                    <td colspan="2" width="120" id="berat_penjualan_35" class="text-center"></td>
                    <td id="harga_penjualan_35" class="text-center"></td>
                </tr>
                <tr>
                    <td colspan="2" width="200"> <strong>TUKAR [+]</strong> <p class="pull-right">[25]</p></td>
                    <td colspan="2" width="120" class="text-center" id="berat_tukar_25"></td>
                    <td class="text-center" id="harga_tukar_25"></td>
                </tr>
                <tr>
                    <td colspan="2" width="200"><p class="pull-right">[30]</p></td>
                    <td colspan="2" class="text-center" width="120" id="berat_tukar_30"></td>
                    <td id="harga_tukar_30" class="text-center"></td>
                </tr>
                <tr>
                    <td colspan="2" width="200"><p class="pull-right">[35]</p></td>
                    <td colspan="2" width="120" class="text-center" id="berat_tukar_35"></td>
                    <td id="harga_tukar_35" class="text-center"></td>
                </tr>
                <tr>
                    <td colspan="2" width="200"> <strong>TOTAL PENJUALAN</strong> <p class="pull-right"></p></td>
                    <td colspan="2" width="120" class="text-center" id="total_berat"></td>
                    <td class="text-center" id="total_harga"></td>
                </tr>
                <tr>
                    <td colspan="2" width="200"><strong>BARANG KEMBALI</strong><p class="pull-right">[20]</p></td>
                    <td colspan="2" width="120" class="text-center" id="berat_bk_20"></td>
                    <td class="text-center" id="harga_bk_20"></td>
                </tr>
                <tr>
                    <td colspan="2" width="200"><p class="pull-right">[22]</p></td>
                    <td colspan="2" width="120" class="text-center" id="berat_bk_22"></td>
                    <td class="text-center" id="harga_bk_22"></td>
                </tr>
                <tr>
                    <td colspan="2" width="200"><p class="pull-right">[23]</p></td>
                    <td colspan="2" width="120" class="text-center" id="berat_bk_23"></td>
                    <td class="text-center" id="harga_bk_23"></td>
                </tr>
                <tr>
                    <td colspan="2" width="200"><p class="pull-right">[25]</p></td>
                    <td colspan="2" width="120" class="text-center" id="berat_bk_25"></td>
                    <td class="text-center" id="harga_bk_25"></td>
                </tr>
                <tr>
                    <td colspan="2" width="200"><p class="pull-right">[27]</p></td>
                    <td colspan="2" width="120" class="text-center" id="berat_bk_27"></td>
                    <td class="text-center" id="harga_bk_27"></td>
                </tr>
                <tr>
                    <td colspan="2" width="200"><p class="pull-right">[28]</p></td>
                    <td colspan="2" width="120" class="text-center" id="berat_bk_28"></td>
                    <td class="text-center" id="harga_bk_28"></td>
                </tr>
                <tr>
                    <td colspan="2" width="200"><p class="pull-right">[30]</p></td>
                    <td colspan="2" width="120" class="text-center" id="berat_bk_30"></td>
                    <td class="text-center" id="harga_bk_30"></td>
                </tr>
                <tr align="center">
                    <td colspan="4"><strong>TOTAL BARANG KEMBALI</strong></td>
                    <td class="text-center" id="total_harga_bk"><strong></strong></td>
                </tr>
                <tr>
                    <td colspan="2" width="200"><strong>PENGELUARAN</strong></td>
                    <td colspan="2" width="120">Karyawan</td>
                    <td>Rp</td>
                </tr>
                <tr>
                    <td colspan="2" width="200"></td>
                    <td colspan="2" width="120"> K.Toko</td>
                    <td>Rp</td>
                </tr>
                <tr>
                    <td colspan="2" width="200"></td>
                    <td colspan="2" width="120">Mobil</td>
                    <td>Rp</td>
                </tr>
                <tr>
                    <td colspan="2" width="200"></td>
                    <td colspan="2" width="120">Dll</td>
                    <td>Rp</td>
                </tr>
                <tr align="center">
                    <td colspan="4"><strong>TOTAL PENGELUARAN</strong></td>
                    <td><strong>Rp</strong></td>
                </tr>
                <tr align="center">
                    <td colspan="4"><strong>KAS</strong></td>
                    <td><strong>Rp</strong></td>
                </tr> -->
                <!--  <tr>
            <td colspan="5" width="500" align="center">
                <strong>
                    UANG DIANGGAP ADA
                </strong></td> 
        </tr> 
        <tr>
            <td colspan="4"><strong>KETERANGAN</strong></td>
            <td>Rp</td>
        </tr>
        <tr>
            <td colspan="4" align="center">Barang Kembali Cimindi</td>
            <td>Rp</td>
        </tr>
        <tr align="center">
            <td colspan="4" width="500"><strong>TOTAL</strong></td>
            <td><strong>Rp</strong></td>
        </tr>
        <tr>
            <td colspan="5" width="500" align="center">
                <strong>
                    BARANG RUSAK
                </strong></td>
        </tr>
        <tr align="center">
            <td colspan="2"><strong>NAMA BARANG</strong></td>
            <td><strong>GRAM</strong></td>
            <td><strong>POT</strong></td>
            <td><strong>Rp</strong></td>
        </tr>
        <tr>
            <td align="center" colspan="2">Kalung Sp</td>
            <td>4,2</td>
            <td>1</td>
            <td>Rp</td>
        </tr>
        <tr>
            <td align="center" colspan="2"><strong>TOTAL</strong></td>
            <td><strong>-</strong></td>
            <td><strong>-</strong></td>
            <td align="center"><strong>Rp</strong></td>
        </tr>
        <tr>
            <td colspan="5" width="500" align="center">
                <strong>
                    BARANG HILANG
                </strong></td>
        </tr>
        <tr align="center">
            <td><strong>NAMA BARANG</strong></td>
            <td><strong>GRAM AWAL</strong></td>
            <td><strong>SELISIH</strong></td>
            <td><strong>GRAM AKHIR</strong></td>
            <td><strong>Rp</strong></td>
        </tr>
        <tr>
            <td>-</td>
            <td>-
            </td>
            <td>
                -
            </td>
            <td>
                -
            </td>
            <td>
                -
            </td>
        </tr>
        <tr align="center">
            <td><strong>TOTAL</strong></td>
            <td><strong>-</strong></td>
            <td><strong>-</strong></td>
            <td><strong>-</strong></td>
            <td><strong>-</strong></td>
        </tr>
        <tr>
            <td colspan="5" width="500" align="center">
                <strong>
                    SEPUHAN
                </strong></td>
        </tr>
        <tr align="center">
            <td><strong>PEMASUKAN</strong></td>
            <td><strong>Rp</strong></td>
            <td><strong>PENGELUARAN</strong></td>
            <td><strong>Rp</strong></td>
            <td><strong>SISA SALDO</strong></td>
        </tr>
        <tr>
            <td>-</td>
            <td>-
            </td>
            <td>
                -
            </td>
            <td>
                -
            </td>
            <td>
                -
            </td>
        </tr>
        <tr align="center">
            <td><strong>TOTAL</strong></td>
            <td><strong>-</strong></td>
            <td><strong>-</strong></td>
            <td><strong>-</strong></td>
            <td><strong>-</strong></td>
        </tr> -->
            <!-- </table>

        </div>
    </div>
</div> -->

<script data-main="<?php echo base_url() ?>assets/js/main/main-laporan_harian" src="<?php echo base_url() ?>assets/js/require.js"></script>