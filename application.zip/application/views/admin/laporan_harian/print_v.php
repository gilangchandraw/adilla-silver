<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/fonts/font-awesome/css/font-awesome.min.css">
    <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/fonts/Ionicons/css/ionicons.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/fonts/montserrat/stylesheet.css"> 
  <!-- Theme style -->
  
  <!-- Drop Zone -->
  <link rel="stylesheet" href="<?php echo base_url()?>assets/plugins/dropzone/dropzone.min.css">

  <link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/datatables.net-bs/css/dataTables.bootstrap.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/bootstrap-datetimepicker/css/bootstrap-datetimepicker.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/bootstrap-datepicker/bootstrap-datepicker.css">
  <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/plugins/bootstrap-timepicker/css/bootstrap-timepicker.min.css">
  <!-- <link rel="stylesheet" href="<?php //echo base_url();?>assets/plugins/bootstrap-timepicker/bootstrap-timepicker.css"> -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/select2/select2.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/dropzone/dropzone.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/admin.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/lobilist.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/progressbar.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/css/skins/skin-main.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,600,700,300italic,400italic,600italic">
  <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
 <style type="text/css">
        tfoot {
            display: table-header-group;
        }
 </style>
</head>
        <div class="full-width paycheck-logo">
                                <span></span>
                                <p class="text-right"></p>
                            </div>
                            <table class="table-paycheck table table-border">
                                <tbody>
                                    <tr>
                                        <td rowspan="4"><img style="height: 50px" src="<?php echo base_url()?>assets/images/logo.png"></td>
                                        <td class="text-center">ADILLA SILVER 925 GROUP</td>
                                    </tr>
                                    <tr>
                                        <td class="text-center">Laporan Harian</td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><?php echo $cabang; ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-center"><?php echo $tanggal;?></td>
                                    </tr>
                                    
                                </tbody>
                            </table>
                            <table class="table-paycheck table table-border" border="1">
                                <tbody>
                                    <tr>
                                        <td colspan="5" class="text-center">LAPORAN AKTIVITAS</td>
                                    </tr>
                                    <tr>
                                        <td class="text-center" style="background-color:#87CEEB;">Transaksi</td>
                                        <td class="text-center" style="background-color:#87CEEB;">Karat</td>
                                        <td class="text-center" style="background-color:#87CEEB;">Gram</td>
                                        <td class="text-center" style="background-color:#87CEEB;" colspan="2">Rp</td>
                                    </tr>
                                    <tr>
                                        <td style="background-color:#87CEEB;" class="text-center" rowspan="3">Penjualan</td>
                                        <td class="text-center">[25]</td>
                                        <td class="text-center"><?php echo $berat_penjualan_25; ?></td>
                                        <td colspan="2" class="text-center"><?php echo $harga_penjualan_25; ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-center">[30]</td>
                                        <td class="text-center"><?php echo $berat_penjualan_30; ?></td>
                                        <td colspan="2" class="text-center"><?php echo $harga_penjualan_30; ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-center">[35]</td>
                                        <td class="text-center"><?php echo $berat_penjualan_35; ?></td>
                                        <td colspan="2" class="text-center"><?php echo $harga_penjualan_35; ?></td>
                                    </tr>
                                    <!-- tukarplus -->
                                    <tr>
                                        <td style="background-color:#87CEEB;" class="text-center" rowspan="3">Tukar [+]</td>
                                        <td class="text-center">[25]</td>
                                        <td class="text-center"><?php echo $berat_tukar_25; ?></td>
                                        <td colspan="2" class="text-center"><?php echo $harga_tukar_25; ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-center">[30]</td>
                                        <td class="text-center"><?php echo $berat_tukar_30;?></td>
                                        <td colspan="2" class="text-center"><?php echo $harga_tukar_30;?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-center">[35]</td>
                                        <td class="text-center"><?php echo $berat_tukar_35; ?></td>
                                        <td colspan="2" class="text-center"><?php echo $harga_tukar_35; ?></td>
                                    </tr>
                                    <tr>
                                        <td colspan="2" style="background-color:#98FB98;" class="text-center">Total Penjualan</td>
                                        <td style="background-color:#98FB98;" class="text-center"><?php echo $total_berat_penjualan; ?></td>
                                        <td colspan="2" style="background-color:#98FB98;" class="text-center"><?php echo $total_harga_penjualan; ?></td>
                                    </tr>
                                    <!-- BK -->
                                    <tr>
                                        <td style="background-color:#87CEEB;" class="text-center" rowspan="7">Barang Kembali</td>
                                        <td class="text-center">[20]</td>
                                        <td class="text-center"><?php echo $berat_bk_20; ?></td>
                                        <td colspan="2" class="text-center"><?php echo $harga_bk_20; ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-center">[22]</td>
                                        <td class="text-center"><?php echo $berat_bk_22;?></td>
                                        <td colspan="2" class="text-center"><?php echo $harga_bk_22;?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-center">[23]</td>
                                        <td class="text-center"><?php echo $berat_bk_23; ?></td>
                                        <td colspan="2" class="text-center"><?php echo $harga_bk_23; ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-center">[25]</td>
                                        <td class="text-center"><?php echo $berat_bk_25; ?></td>
                                        <td colspan="2" class="text-center"><?php echo $harga_bk_25; ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-center">[27]</td>
                                        <td class="text-center"><?php echo $berat_bk_27; ?></td>
                                        <td colspan="2" class="text-center"><?php echo $harga_bk_27; ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-center">[28]</td>
                                        <td class="text-center"><?php echo $berat_bk_28; ?></td>
                                        <td colspan="2" class="text-center"><?php echo $harga_bk_28; ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-center">[30]</td>
                                        <td class="text-center"><?php echo $berat_bk_30; ?></td>
                                        <td colspan="2" class="text-center"><?php echo $harga_bk_30; ?></td>
                                    </tr>
                                    <tr>
                                        <td colspan="2" style="background-color:#98FB98;" class="text-center">Total Barang Kembali</td>
                                        <td style="background-color:#98FB98;" class="text-center"><?php echo $total_berat_bk; ?></td>
                                        <td colspan="2" style="background-color:#98FB98;" class="text-center"><?php echo $total_harga_bk; ?></td>
                                    </tr>
                                    <?php
                                        $rowspan_pengeluaran = 1;
                                        if (!empty($pengeluaran)) {
                                            $rowspan_pengeluaran = count($pengeluaran);
                                            $rowspan_pengeluaran = $rowspan_pengeluaran + 1;
                                        }
                                    ?>
                                    <tr>
                                        <td style="background-color:#87CEEB;" class="text-center" rowspan="<?php echo $rowspan_pengeluaran; ?>" colspan="2">Pengeluaran</td>
                                        <td style="background-color:#87CEEB;" class="text-center">Nama</td>
                                        <td style="background-color:#87CEEB;" colspan="2" class="text-center">Rp</td>
                                    </tr>
                                    <?php
                                        if (!empty($pengeluaran)) {
                                            $total_pengeluaran = 0;
                                            foreach ($pengeluaran as $key => $value) { ?>
                                                <tr>
                                                    <?php if($value->enum_pengeluaran_id == 11) {?>
                                                        <td class='text-center'><?php echo $value->keterangan; ?></td>
                                                    <?php }else{ ?>
                                                        <td class='text-center'><?php echo $value->nama_pengeluaran; ?></td>
                                                    <?php } ?>
                                                    <td colspan="2" class="text-center"><?php $total_pengeluaran += $value->harga; echo number_format($value->harga); ?></td>
                                                </tr>
                                    <?php }
                                        }
                                    ?>
                                    <tr>
                                        <td colspan="3" style="background-color:#98FB98;" class="text-center">Total Pengeluaran</td>
                                        <td colspan="2" style="background-color:#98FB98;" class="text-center"><?php echo number_format($total_pengeluaran); ?></td>
                                    </tr>
                                    <tr>
                                        <td colspan="3" style="background-color:#98FB98;" class="text-center">Kas</td>
                                        <td colspan="2" style="background-color:#98FB98;" class="text-center"><?php echo number_format($kas); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-center" colspan="5" style="background-color:#87CEEB;">Uang Dianggap Ada</td>
                                    </tr>
                                    <tr>
                                        <td class="text-center" colspan="2">Keterangan</td>
                                        <td class="text-center" colspan="3">Rp</td>
                                    </tr>
                                    <?php
                                        $total_uda = 0;
                                        if (!empty($uda)) {
                                            foreach ($uda as $key => $value) { ?>
                                                <tr>
                                                    <td colspan="2" class="text-center"><?php echo $value->cabang; ?></td>
                                                    <td colspan="3" class="text-center"><?php $total_uda += $value->harga; echo number_format($value->harga); ?></td>
                                                </tr>
                                    <?php }
                                        }
                                    ?>
                                    <tr>
                                        <td colspan="2" style="background-color:#98FB98;" class="text-center">Total</td>
                                        <td colspan="3" style="background-color:#98FB98;" class="text-center"><?php echo number_format($total_uda); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-center" colspan="5" style="background-color:#87CEEB;">Barang Rusak</td>
                                    </tr>
                                    <tr>
                                        <td class="text-center">Nama Barang</td>
                                        <td class="text-center">Gram</td>
                                        <td class="text-center">POT</td>
                                        <td colspan="2" class="text-center">Rp</td>
                                    </tr>
                                    <?php
                                        if (!empty($barang_rusak)) {
                                            foreach ($barang_rusak as $key => $value) { ?>
                                                <tr>
                                                    <td class="text-center"><?php echo $value->nama_barang; ?></td>
                                                    <td class="text-center"><?php echo $value->berat; ?></td>
                                                    <td class="text-center"><?php echo $value->potong; ?></td>
                                                    <td colspan="2" class="text-center"><?php echo number_format($value->harga); ?></td>
                                                </tr>
                                    <?php }
                                        }
                                    ?>
                                    <tr>
                                        <td style="background-color:#98FB98;" class="text-center">Total</td>
                                        <td style="background-color:#98FB98;" class="text-center"><?php echo $total_gram_br; ?></td>
                                        <td style="background-color:#98FB98;" class="text-center"><?php echo $total_potong_br; ?></td>
                                        <td style="background-color:#98FB98;" colspan="2" class="text-center"><?php echo $total_harga_br; ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-center" colspan="5" style="background-color:#87CEEB;">Barang Hilang</td>
                                    </tr>
                                    <tr>
                                        <td class="text-center">Nama Barang</td>
                                        <td class="text-center">Gram Awal</td>
                                        <td class="text-center">Selisih</td>
                                        <td class="text-center">Gram Akhir</td>
                                        <td class="text-center">Rp</td>
                                    </tr>
                                    <?php
                                        $total_barang_rusak = 0;
                                        if (!empty($barang_hilang)) {
                                            foreach ($barang_hilang as $key => $value) { ?>
                                                <tr>
                                                    <td class="text-center"><?php echo $value->nama_barang; ?></td>
                                                    <td class="text-center"><?php echo $value->gram_awal; ?></td>
                                                    <td class="text-center"><?php echo $value->berat; ?></td>
                                                    <td class="text-center"><?php echo $value->berat; ?></td>
                                                    <td class="text-center"><?php echo number_format($value->harga); ?></td>
                                                </tr>
                                    <?php }
                                        }
                                    ?>
                                    <tr>
                                        <td style="background-color:#98FB98;" class="text-center">Total</td>
                                        <td style="background-color:#98FB98;" class="text-center"><?php echo $total_gram_awal_bh; ?></td>
                                        <td style="background-color:#98FB98;" class="text-center"><?php echo $total_selisih_bh; ?></td>
                                        <td style="background-color:#98FB98;" class="text-center"><?php echo $total_gram_akhir_bh; ?></td>
                                        <td style="background-color:#98FB98;" class="text-center"><?php echo $total_harga_bh; ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-center" colspan="5" style="background-color:#87CEEB;">Sepuhan</td>
                                    </tr>
                                    <tr>
                                        <td class="text-center">Pemasukan</td>
                                        <td class="text-center">Rp</td>
                                        <td class="text-center">Pengeluaran</td>
                                        <td class="text-center">Harga</td>
                                        <td class="text-center">Sisa Kas Sepuhan</td>
                                    </tr>
                                    <?php
                                        $total_harga_pemasukan = 0;
                                        $total_harga_pengeluaran = 0;
                                        $total_kas_sepuhan = 0;
                                        if (!empty($sepuhan)) {
                                            foreach ($sepuhan as $key => $value) { 
                                                $total_harga_pemasukan += $value->harga_pemasukan;
                                                $total_harga_pengeluaran += $value->harga_pengeluaran;
                                                $total_kas_sepuhan += $value->kas_sepuhan_akhir;
                                        ?>
                                                <tr>
                                                    <td class="text-center"><?php echo $value->nama_pemasukan; ?></td>
                                                    <td class="text-center"><?php echo number_format($value->harga_pemasukan); ?></td>
                                                    <td class="text-center"><?php echo $value->nama_pengeluaran; ?></td>
                                                    <td class="text-center"><?php echo number_format($value->harga_pengeluaran); ?></td>
                                                    <td class="text-center"><?php echo number_format($value->kas_sepuhan_akhir); ?></td>
                                                </tr>
                                    <?php }
                                        }
                                    ?>
                                    <tr>
                                        <td style="background-color:#98FB98;" class="text-center">Total</td>
                                        <td style="background-color:#98FB98;" class="text-center"><?php echo number_format($total_harga_pemasukan); ?></td>
                                        <td style="background-color:#98FB98;" class="text-center">Total</td>
                                        <td style="background-color:#98FB98;" class="text-center"><?php echo number_format($total_harga_pengeluaran); ?></td>
                                        <td style="background-color:#98FB98;" class="text-center"><?php echo number_format($total_kas_sepuhan); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-center" colspan="5" style="background-color:#87CEEB;">Kotak Cincin</td>
                                    </tr>
                                    <tr>
                                        <td colspan="2" class="text-center">Nama Barang</td>
                                        <td class="text-center">Qty</td>
                                        <td colspan="2" class="text-center">Harga</td>
                                    </tr>
                                    <?php
                                        $total_qty_kc = 0;
                                        $total_harga_kc = 0;
                                        if (!empty($kc)) {
                                            foreach ($kc as $key => $value) { 
                                                $total_qty_kc += $value->qty;
                                                $total_harga_kc += $value->harga;
                                        ?>
                                                <tr>
                                                    <td colspan="2" class="text-center"><?php echo $value->nama_kotak_cincin; ?></td>
                                                    <td class="text-center"><?php echo $value->qty; ?></td>
                                                    <td colspan="2" class="text-center"><?php echo number_format($value->harga); ?></td>
                                                </tr>
                                    <?php }
                                        }
                                    ?>
                                    <tr>
                                        <td style="background-color:#98FB98;" colspan="2" class="text-center">Total</td>
                                        <td style="background-color:#98FB98;" class="text-center"><?php echo $total_qty_kc; ?></td>
                                        <td style="background-color:#98FB98;" colspan="2" class="text-center"><?php echo number_format($total_harga_kc); ?></td>
                                    </tr>
                                    <tr>
                                        <td colspan="3" style="background-color:#87CEEB;" class="text-center">Uang Laci</td>
                                        <td colspan="2" style="background-color:#87CEEB;" class="text-center">Uang Brangkas</td>
                                    </tr>
                                    <tr>
                                        <td class="text-center">Rp. 100,000</td>
                                        <td colspan="2" class="text-center"><?php echo $rp_100000; ?></td>
                                        <td colspan="2" class="text-center"><?php echo $uang_brangkas; ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-center">Rp. 50,000</td>
                                        <td colspan="2" class="text-center"><?php echo $rp_50000; ?></td>
                                        <td colspan="2" style="background-color:#87CEEB;" class="text-center">Uang Jelek</td>
                                    </tr>
                                    <tr>
                                        <td class="text-center">Rp. 20,000</td>
                                        <td colspan="2" class="text-center"><?php echo $rp_20000; ?></td>
                                        <td colspan="2" class="text-center"><?php echo $uang_jelek; ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-center">Rp. 10,000</td>
                                        <td colspan="2" class="text-center"><?php echo $rp_10000; ?></td>
                                        <td colspan="2" style="background-color:#87CEEB;" class="text-center">U.D.A</td>
                                    </tr>
                                    <tr>
                                        <td class="text-center">Rp. 5,000</td>
                                        <td colspan="2" class="text-center"><?php echo $rp_5000; ?></td>
                                        <td colspan="2" class="text-center"><?php echo number_format($total_uda); ?></td>
                                    </tr>
                                    <tr>
                                        <td class="text-center">Rp. 2,000</td>
                                        <td colspan="2" class="text-center"><?php echo $rp_2000; ?></td>
                                        <td colspan="2" style="background-color:#87CEEB;" class="text-center">Uang Setor</td>
                                    </tr>
                                    <tr>
                                        <td class="text-center">Rp. 1,000</td>
                                        <td colspan="2" class="text-center"><?php echo $rp_1000; ?></td>
                                        <td colspan="2" class="text-center"><?php echo $uang_setor; ?></td>
                                    </tr>
                                    <tr>
                                        <td rowspan="2" class="text-center">Rp. 500</td>
                                        <td rowspan="2" colspan="2" class="text-center"><?php echo $rp_500; ?></td>
                                        <td colspan="2" style="background-color:#87CEEB;" class="text-center">U. Kas Pagi</td>
                                    </tr>
                                    <tr>
                                        <td colspan="2" class="text-center"><?php echo $uang_kas_pagi; ?></td>
                                    </tr>
                                </tbody>
                            </table>