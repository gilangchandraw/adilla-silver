<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.7 -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/plugins/bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/fonts/font-awesome/css/font-awesome.min.css">
    <!-- Ionicons -->
  <link rel="stylesheet" href="<?php echo base_url();?>assets/fonts/Ionicons/css/ionicons.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>assets/fonts/montserrat/stylesheet.css"> 
<style type="text/css">
        tfoot {
            display: table-header-group;
        }
 </style>
</head>
<section class="content">
    <div class="box box-default color-palette-box">
        <div class="box-body">
            <div class="row" id="body_report">
                <div class="col-md-6 mb-15" style="page-break-after: always;">
                        <div class="paycheck-container" style="padding: 15px; border:1px solid #ebebeb;">
                        <div class="full-width paycheck-logo">
                            <img style="height: 40px" src="<?php echo base_url()?>assets/images/logo.png">
                            <span>
                                <strong>
                                    <center>
                                        ADILLA SILVER 925 GROUP<br>
                                        Laporan Harian<br>
                                        <?php echo $cabang; ?>
                                        <br><?php echo $tanggal;?>
                                    </center>
                                </strong>
                            </span>
                        </div>
                            <table border="1" cellspacing="0" cellpadding="5" class="table-paycheck table table-border">

                <!-- <td colspan="5">
                    <img src="<?php echo base_url(); ?>assets/images/logo.png" alt="Logo" class="center" width="90" height="50">
                    <strong>
                        ADILLA SILVER 925 GROUP
                    </strong>
                    <p align="right" id="tanggal_laporan"></p>
                    <p align="right" id="cabang"></p>
                </td> -->

                <tr align="center">
                    <td colspan="5">
                        <strong>
                            LAPORAN AKTIVITAS
                        </strong></td>
                </tr>
                <tr align="center">
                    <td colspan="4">
                        <strong>GRAM</strong></td>
                    <td colspan="2" width="120"><strong>Rp</strong></td>
                </tr>
                <tr align="center">
                    <td colspan="2"> <strong>PENJUALAN</strong> <p class="pull-right">[25]</p></td>
                    <td colspan="2" width="120" class="text-center"><?php echo $berat_penjualan_25; ?></td>
                    <td class="text-center"><?php echo $harga_penjualan_25; ?></td>
                </tr>
                <tr align="center">
                    <td colspan="2"><p class="pull-right">[30]</p></td>
                    <td colspan="2" class="text-center" width="120"><?php echo $berat_penjualan_30; ?></td>
                    <td class="text-center"><?php echo $harga_penjualan_30; ?></td>
                </tr>
                <tr align="center">
                    <td colspan="2"><p class="pull-right">[35]</p></td>
                    <td colspan="2" width="120" class="text-center"><?php echo $berat_penjualan_35; ?></td>
                    <td class="text-center"><?php echo $harga_penjualan_35; ?></td>
                </tr>
                <tr align="center">
                    <td colspan="2"> <strong>TUKAR [+]</strong> <p class="pull-right">[25]</p></td>
                    <td colspan="2" width="120" class="text-center"><?php echo $berat_tukar_25; ?></td>
                    <td class="text-center"><?php echo $harga_tukar_25; ?></td>
                </tr>
                <tr align="center">
                    <td colspan="2"><p class="pull-right">[30]</p></td>
                    <td colspan="2" class="text-center" width="120"><?php echo $berat_tukar_30;?></td>
                    <td class="text-center"><?php echo $harga_tukar_30;?></td>
                </tr>
                <tr align="center">
                    <td colspan="2"><p class="pull-right">[35]</p></td>
                    <td colspan="2" width="120" class="text-center"><?php echo $berat_tukar_35; ?></td>
                    <td class="text-center"><?php echo $harga_tukar_35; ?></td>
                </tr>
                <tr align="center">
                    <td colspan="2"> <strong>TOTAL PENJUALAN</strong> <p class="pull-right"></p></td>
                    <td colspan="2" width="120" class="text-center"><?php echo $total_berat_penjualan; ?></td>
                    <td class="text-center"><?php echo $total_harga_penjualan; ?></td>
                </tr>
                <tr align="center">
                    <td colspan="2"><strong>BARANG KEMBALI</strong><p class="pull-right">[20]</p></td>
                    <td colspan="2" width="120" class="text-center"><?php echo $berat_bk_20; ?></td>
                    <td class="text-center"><?php echo $harga_bk_20; ?></td>
                </tr>
                <tr align="center">
                    <td colspan="2"><p class="pull-right">[22]</p></td>
                    <td colspan="2" width="120" class="text-center"><?php echo $berat_bk_22; ?></td>
                    <td class="text-center"><?php echo $harga_bk_22; ?></td>
                </tr>
                <tr align="center">
                    <td colspan="2"><p class="pull-right">[23]</p></td>
                    <td colspan="2" width="120" class="text-center"><?php echo $berat_bk_23; ?></td>
                    <td class="text-center"><?php echo $harga_bk_23; ?></td>
                </tr>
                <tr align="center">
                    <td colspan="2"><p class="pull-right">[25]</p></td>
                    <td colspan="2" width="120" class="text-center"><?php echo $berat_bk_25; ?></td>
                    <td class="text-center"><?php echo $harga_bk_25; ?></td>
                </tr>
                <tr align="center">
                    <td colspan="2"><p class="pull-right">[27]</p></td>
                    <td colspan="2" width="120" class="text-center"><?php echo $berat_bk_27; ?></td>
                    <td class="text-center"><?php echo $harga_bk_27; ?></td>
                </tr>
                <tr align="center">
                    <td colspan="2"><p class="pull-right">[28]</p></td>
                    <td colspan="2" width="120" class="text-center"><?php echo $berat_bk_28; ?></td>
                    <td class="text-center"><?php echo $harga_bk_28; ?></td>
                </tr>
                <tr align="center">
                    <td colspan="2"><p class="pull-right">[30]</p></td>
                    <td colspan="2" width="120" class="text-center"><?php echo $berat_bk_30; ?></td>
                    <td class="text-center"><?php echo $harga_bk_30; ?></td>
                </tr>
                <tr align="center">
                    <td colspan="4"><strong>TOTAL BARANG KEMBALI</strong></td>
                    <td class="text-center"><strong></strong><?php echo $total_harga_bk; ?></td>
                </tr>
                <tr align="center">
                    <td colspan="2"><strong>PENGELUARAN</strong></td>
                    <td colspan="2" width="120"><strong>Nama</strong></td>
                    <td><strong>Rp</strong></td>
                </tr>
                <?php
                    if (!empty($pengeluaran)) {
                        $total_pengeluaran = 0;
                        foreach ($pengeluaran as $key => $value) { ?>
                            <tr>
                                <td colspan="2"></td>
                                <td colspan="2" width="120"><?php echo $value->nama_pengeluaran; ?></td>
                                <td><?php $total_pengeluaran += $value->harga; echo number_format($value->harga); ?></td>
                            </tr>
                <?php }
                    }
                ?>
                <tr>
                    <td colspan="4"><strong>TOTAL PENGELUARAN</strong></td>
                    <td><strong><?php echo number_format($total_pengeluaran); ?></strong></td>
                </tr>
                <tr>
                    <td colspan="4"><strong>KAS</strong></td>
                    <td><strong>Rp</strong></td>
                </tr>
                <!--  <tr>
            <td colspan="5" width="500">
                <strong>
                    UANG DIANGGAP ADA
                </strong></td> 
        </tr> 
        <tr>
            <td colspan="4"><strong>KETERANGAN</strong></td>
            <td>Rp</td>
        </tr>
        <tr>
            <td colspan="4">Barang Kembali Cimindi</td>
            <td>Rp</td>
        </tr>
        <tr>
            <td colspan="4" width="500"><strong>TOTAL</strong></td>
            <td><strong>Rp</strong></td>
        </tr>
        <tr>
            <td colspan="5" width="500">
                <strong>
                    BARANG RUSAK
                </strong></td>
        </tr>
        <tr>
            <td colspan="2"><strong>NAMA BARANG</strong></td>
            <td><strong>GRAM</strong></td>
            <td><strong>POT</strong></td>
            <td><strong>Rp</strong></td>
        </tr>
        <tr>
            <td colspan="2">Kalung Sp</td>
            <td>4,2</td>
            <td>1</td>
            <td>Rp</td>
        </tr>
        <tr>
            <td colspan="2"><strong>TOTAL</strong></td>
            <td><strong>-</strong></td>
            <td><strong>-</strong></td>
            <td><strong>Rp</strong></td>
        </tr>
        <tr>
            <td colspan="5" width="500">
                <strong>
                    BARANG HILANG
                </strong></td>
        </tr>
        <tr>
            <td><strong>NAMA BARANG</strong></td>
            <td><strong>GRAM AWAL</strong></td>
            <td><strong>SELISIH</strong></td>
            <td><strong>GRAM AKHIR</strong></td>
            <td><strong>Rp</strong></td>
        </tr>
        <tr>
            <td>-</td>
            <td>-
            </td>
            <td>
                -
            </td>
            <td>
                -
            </td>
            <td>
                -
            </td>
        </tr>
        <tr>
            <td><strong>TOTAL</strong></td>
            <td><strong>-</strong></td>
            <td><strong>-</strong></td>
            <td><strong>-</strong></td>
            <td><strong>-</strong></td>
        </tr>
        <tr>
            <td colspan="5" width="500">
                <strong>
                    SEPUHAN
                </strong></td>
        </tr>
        <tr>
            <td><strong>PEMASUKAN</strong></td>
            <td><strong>Rp</strong></td>
            <td><strong>PENGELUARAN</strong></td>
            <td><strong>Rp</strong></td>
            <td><strong>SISA SALDO</strong></td>
        </tr>
        <tr>
            <td>-</td>
            <td>-
            </td>
            <td>
                -
            </td>
            <td>
                -
            </td>
            <td>
                -
            </td>
        </tr>
        <tr>
            <td><strong>TOTAL</strong></td>
            <td><strong>-</strong></td>
            <td><strong>-</strong></td>
            <td><strong>-</strong></td>
            <td><strong>-</strong></td>
        </tr> -->
            </table>
                        </div>
                </div>
            </div>
        </div>
    </div>
</section>
