<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-edit icon-gradient bg-plum-plate"></i>
            </div>
            <div>Detail Data Penjualan</div>
        </div>
        <!-- <div class="page-title-actions">
            <div class="page-title-actions">
                <button type="button" data-toggle="tooltip" title="Example Tooltip" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                    <i class="fa fa-star"></i>
                </button>
            </div>
        </div> -->
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <div class="form-row">
                <div class="col-md-12">
                    <div class="position-relative form-group">
                        <label for="tanggal">Tanggal Transaksi</label>
                        <input class="form-control init-date readonly" disabled value="<?php echo $insentif->tanggal; ?>" type="text" id="tanggal" name="tanggal" autocomplete="off">
                        <input type="hidden" name="penjualan_id" value="<?php echo $insentif->id; ?>">
                    </div>
                </div>
                <!-- <div class="col-md-6">
                    <div class="form-row">
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label>Stok 925/gram</label>
                                <input class="form-control number" type="text" readonly>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label>Stok SP/gram</label>
                                <input class="form-control number" type="text" readonly id="angka_akhir" name="angka_akhir">
                            </div>
                        </div>
                    </div>
                </div> -->
            </div>
            <div class="card-body">
                <?php if (!empty($this->session->flashdata('message'))) { ?>
                    <div class="card-header">
                        <div class="alert alert-info fade show text-center w-100" role="alert">
                            <?php print_r($this->session->flashdata('message')); ?>
                        </div>
                    </div>
                <?php } ?>

                <?php if (!empty($this->session->flashdata('message_error'))) { ?>
                    <div class="card-header">
                        <div class="alert alert-danger fade show text-center w-100" role="alert">
                            <?php print_r($this->session->flashdata('message_error')); ?>
                        </div>
                    </div>
                <?php } ?>
                <h5 class="card-title">Histori Data Penjualan</h5>
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-bordered responsive w-100">
                        <thead>
                            <th class="text-center">No</th>
                            <th class="text-center">Karyawan</th>
                            <th class="text-center">Huruf Nota</th>
                            <th class="text-center">No Nota Masing"</th>
                            <th class="text-center">No Nota J (Cadangan)</th>
                            <th class="text-center">Jumlah Nota</th>
                            <th class="text-center">No Nota Batal</th>
                            <th class="text-center">Jumlah Nota Batal</th>
                            <th class="text-center">Berat</th>
                            <!-- <th class="text-center">Total Berat</th> -->
                            <th class="text-center">Harga</th>
                            <!-- <th class="text-center">Total Harga</th> -->

                            <?php if ($this->data['users_groups']->id == 4) {
                                if ($cek_insert == 1) { ?>
                                    <th class="text-center">Aksi</th>
                            <?php }
                            } ?>
                            <?php if ($this->data['is_superadmin']) { ?>
                                <th class="text-center">Aksi</th>
                            <?php } ?>
                        </thead>

                        <tbody>
                            <?php
                            $no = 1;
                            $berat = 0.0;
                            $harga = 0;
                            foreach ($data_insentif_detail as $key => $value) { ?>
                                <tr>
                                    <td class='text-center'><?php echo $no++; ?></td>
                                    <td class='text-center'><?php echo $value->nama_karyawan; ?></td>
                                    <td class='text-center'><?php echo $value->huruf_nota; ?></td>
                                    <td class='text-center'><?php echo $value->no_nota_awal; ?></td>
                                    <td class='text-center'><?php echo $value->no_nota_akhir; ?></td>
                                    <td class='text-center'><?php echo $value->jumlah_nota; ?></td>
                                    <td class='text-center'><?php echo $value->no_nota_batal; ?></td>
                                    <td class='text-center'><?php echo $value->jumlah_nota_batal; ?></td>
                                    <td class='text-center'><?php echo $value->berat; ?></td>
                                    <!-- <td class='text-center'><?php echo $value->total_berat; ?></td> -->
                                    <td class='text-center'><?php echo number_format($value->harga); ?></td>
                                    <!-- <td class='text-center'><?php echo number_format($value->total_harga); ?></td> -->
                                    <?php if ($this->data['users_groups']->id == 4) {
                                        if ($cek_insert == 1) { ?>
                                            <td class='text-center'><?php echo "<a href='" . base_url() . "insentif/edit/" . $value->id . "' class='btn btn-sm btn-warning' data-toggle='tooltip' title='Edit Data' data-placement='bottom'><i class='fa fa-edit fa-w-20'></i></a>"; ?></td>
                                    <?php }
                                    } ?>
                                    <?php if ($this->data['is_superadmin']) { ?>
                                        <td class='text-center'><?php echo "<a href='" . base_url() . "insentif/edit/" . $value->id . "' class='btn btn-sm btn-warning' data-toggle='tooltip' title='Edit Data' data-placement='bottom'><i class='fa fa-edit fa-w-20'></i></a>"; ?></td>
                                    <?php } ?>
                                </tr>
                            <?php
                            }
                            ?>

                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</form>

<script data-main="<?php echo base_url() ?>assets/js/main/main-penjualan" src="<?php echo base_url() ?>assets/js/require.js"></script>