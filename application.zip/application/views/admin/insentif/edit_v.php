<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-edit icon-gradient bg-plum-plate"></i>
            </div>
            <div>Edit Data Insentif</div>
        </div>
        <!-- <div class="page-title-actions">
            <div class="page-title-actions">
                <button type="button" data-toggle="tooltip" title="Example Tooltip" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                    <i class="fa fa-star"></i>
                </button>
            </div>
        </div> -->
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <!-- <h5>Data Transaksi</h5> -->
            <div class="form-row">
                <div class="col-md-12">
                    <div class="position-relative form-group">
                        <label for="tanggal">Tanggal Transaksi</label>
                        <input class="form-control" readonly value="<?php echo $insentif->tanggal; ?>" type="text" id="tanggal" name="tanggal" autocomplete="off">
                    </div>
                </div>
            </div>
            <div class="form-row">
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="karyawan_id">Karyawan</label>
                        <select class="form-control select2" id="karyawan_id" name="karyawan_id">
                            <option value="" selected>Pilih Karyawan</option>
                            <?php foreach ($karyawan as $key => $value) { ?>
                                <option value="<?php echo $value->id ?>" <?php echo $detail->karyawan_id == $value->id ? 'selected' : '';?>><?php echo $value->nama_karyawan; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="position-relative form-group">
                        <label for="huruf_nota">Huruf Nota</label>
                        <input type="hidden" name="huruf_nota" value="<?php echo $detail->huruf_nota; ?>">
                        <select class="form-control" id="huruf_nota" name="huruf_nota">
                            <option value="" selected>Pilih Huruf Nota</option>
                            <option value="A" <?php echo $detail->huruf_nota == 'A' ? 'selected' : ''; ?>>A</option>
                            <option value="B" <?php echo $detail->huruf_nota == 'B' ? 'selected' : ''; ?>>B</option>
                            <option value="C" <?php echo $detail->huruf_nota == 'C' ? 'selected' : ''; ?>>C</option>
                            <option value="D" <?php echo $detail->huruf_nota == 'D' ? 'selected' : ''; ?>>D</option>
                            <option value="E" <?php echo $detail->huruf_nota == 'E' ? 'selected' : ''; ?>>E</option>
                            <option value="G" <?php echo $detail->huruf_nota == 'G' ? 'selected' : ''; ?>>G</option>
                        </select>
                    </div>
                    <input type="hidden" name="insentif_detail_id" value="<?php echo $insentif_detail_id; ?>">
                    <div class="position-relative form-group">
                        <label for="no_nota_awal">No Nota Masing"</label>
                        <input class="form-control" type="text" id="no_nota_awal" name="no_nota_awal" value="<?php echo $detail->no_nota_awal; ?>">
                    </div>
                    <div class="position-relative form-group">
                        <label for="no_nota_akhir">No Nota J (Cadangan)</label>
                        <input class="form-control" type="text" id="no_nota_akhir" name="no_nota_akhir" value="<?php echo $detail->no_nota_akhir; ?>">
                    </div>
                    <div class="position-relative form-group">
                        <label for="jumlah_nota">Jumlah Nota</label>
                        <input class="form-control number" type="text" id="jumlah_nota" name="jumlah_nota" autocomplete="off" value="<?php echo $detail->jumlah_nota; ?>">
                    </div>
                </div>
                <div class="col-md-6 nota-batal">
                    <div class="position-relative form-group">
                        <label for="no_nota_batal">No Nota Batal</label>
                        <textarea class="form-control" id="no_nota_batal" name="no_nota_batal" autocomplete="off"><?php echo $detail->no_nota_batal; ?></textarea>
                    </div>
                    <div class="position-relative form-group">
                        <label for="jumlah_nota_batal">Jumlah Nota Batal</label>
                        <input class="form-control number" type="text" id="jumlah_nota_batal" name="jumlah_nota_batal" autocomplete="off" value="<?php echo $detail->jumlah_nota_batal; ?>">
                    </div>
                    <div class="position-relative form-group">
                        <label for="berat">Berat (gr)</label>
                        <input class="form-control number" type="text" id="berat" name="berat" autocomplete="off" value="<?php echo $detail->berat; ?>">
                    </div>
                    <div class="position-relative form-group">
                        <label for="harga">Harga (rp)</label>
                        <input class="form-control number" type="text" id="harga" name="harga" autocomplete="off" value="<?php echo $detail->harga; ?>">
                    </div>
                </div>
                <input type="hidden" id="value-btn-tambah" name="value-btn-tambah" value="0">
            </div>
            <div class="box-footer">
                <div class="row">
                    <div class="col-md-6">
                        <span class="reminder" style="color:red"><b>Mohon Periksa Kembali Form, Sebelum Disimpan</b></span>
                    </div>
                    <div class="col-md-6">
                        <div class="btn-groups pull-right">
                            <button type="submit" class="mt-2 btn btn-primary pull-right" id="btn-tambah"><i class="fa fa-save"> Simpan</i></button>
                            <a href="<?php echo base_url(); ?>insentif" class="mt-2 mr-2 btn-transition btn btn-outline-danger pull-right"><i class="fa fa-times"> Batal</i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</form>

<script data-main="<?php echo base_url() ?>assets/js/main/main-insentif" src="<?php echo base_url() ?>assets/js/require.js"></script>