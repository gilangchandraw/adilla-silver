<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-edit icon-gradient bg-plum-plate"></i>
            </div>
            <div>Tambah Data Insentif Baru</div>
        </div>
        <!-- <div class="page-title-actions">
            <div class="page-title-actions">
                <button type="button" data-toggle="tooltip" title="Example Tooltip" data-placement="bottom" class="btn-shadow mr-3 btn btn-dark">
                    <i class="fa fa-star"></i>
                </button>
            </div>
        </div> -->
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <!-- <h5>Data Transaksi</h5> -->
            <div class="form-row">
                <div class="col-md-12">
                    <div class="position-relative form-group">
                        <label for="tanggal">Tanggal Transaksi</label>
                        <!-- <input class="form-control init-date readonly"  type="text" id="tanggal" name="tanggal" autocomplete="off"> -->
                        <input class="form-control" readonly value="<?php echo $insentif->tanggal; ?>" type="text" id="tanggal" name="tanggal" autocomplete="off">
                    </div>
                </div>
            </div>
            <div class="form-row">
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="karyawan_id">Karyawan</label>
                        <select class="form-control select2" id="karyawan_id" name="karyawan_id">
                            <option value="" selected>Pilih Karyawan</option>
                            <?php foreach ($karyawan as $key => $value) { ?>
                                <option value="<?php echo $value->id ?>"><?php echo $value->nama_karyawan; ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="position-relative form-group">
                        <label for="huruf_nota">Huruf Nota</label>
                        <select class="form-control" id="huruf_nota" name="huruf_nota">
                            <option value="" selected>Pilih Huruf Nota</option>
                            <option value="A">A</option>
                            <option value="B">B</option>
                            <option value="C">C</option>
                            <option value="D">D</option>
                            <option value="E">E</option>
                            <option value="G">G</option>
                            <option value="J">J</option>
                        </select>
                    </div>
                    <div class="position-relative form-group">
                        <label for="no_nota_awal">No Nota Masing"</label>
                        <input class="form-control" type="text" id="no_nota_awal" name="no_nota_awal">
                    </div>
                    <div class="position-relative form-group">
                        <label for="no_nota_akhir">No Nota J (Cadangan) </label>
                        <input class="form-control" type="text" id="no_nota_akhir" name="no_nota_akhir">
                    </div>
                    <div class="position-relative form-group">
                        <label for="jumlah_nota">Jumlah Nota</label>
                        <input class="form-control number" type="text" id="jumlah_nota" name="jumlah_nota" autocomplete="off">
                    </div>
                </div>
                <div class="col-md-6 nota-batal">
                    <div class="position-relative form-group">
                        <label for="no_nota_batal">No Nota Batal</label>
                        <textarea class="form-control" id="no_nota_batal" name="no_nota_batal" autocomplete="off"></textarea>
                    </div>
                    <div class="position-relative form-group">
                        <label for="jumlah_nota_batal">Jumlah Nota Batal</label>
                        <input class="form-control number" type="text" id="jumlah_nota_batal" name="jumlah_nota_batal" autocomplete="off">
                    </div>
                    <div class="position-relative form-group">
                        <label for="berat">Berat (gr)</label>
                        <input class="form-control number" type="text" id="berat" name="berat" autocomplete="off">
                        <input type="hidden" id="insentif_id" name="insentif_id" value="<?php echo $id; ?>">
                    </div>
                    <div class="position-relative form-group">
                        <label for="harga">Harga (rp)</label>
                        <input class="form-control number" type="text" id="harga" name="harga" autocomplete="off">
                    </div>
                </div>
                <input type="hidden" id="value-btn-tambah" name="value-btn-tambah" value="0">
            </div>
            <div class="box-footer">
                <div class="row">
                    <div class="col-md-6">
                        <span class="reminder" style="color:red"><b>Mohon Periksa Kembali Form, Sebelum Disimpan</b></span>
                    </div>
                    <div class="col-md-6">
                        <div class="btn-groups pull-right">
                            <button type="submit" class="mt-2 btn btn-primary pull-right" id="btn-tambah"><i class="fa fa-save"> Simpan & Tambah Insentif</i></button>
                            <a href="<?php echo base_url(); ?>insentif" class="mt-2 mr-2 btn-transition btn btn-success pull-right"><i class="fa fa-check"> Selesai</i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <h5 class="card-title">Histori Data Insentif</h5>
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-bordered responsive w-100">
                        <thead>
                            <th class="text-center">No</th>
                            <th class="text-center">Karyawan</th>
                            <th class="text-center">Huruf Nota</th>
                            <th class="text-center">No Nota Masing"</th>
                            <th class="text-center">No Nota J (Cadangan)</th>
                            <th class="text-center">Jumlah Nota</th>
                            <th class="text-center">No Nota Batal</th>
                            <th class="text-center">Jumlah Nota Batal</th>
                            <th class="text-center">Berat</th>
                            <!-- <th class="text-center">Total Berat</th> -->
                            <th class="text-center">Harga</th>
                            <!-- <th class="text-center">Total Harga</th> -->
                        </thead>

                        <tbody>
                            <?php
                            $no = 1;
                            foreach ($data_insentif_detail as $key => $value) { ?>
                                <tr>
                                    <td class='text-center'><?php echo $no++; ?></td>
                                    <td class='text-center'><?php echo $value->nama_karyawan; ?></td>
                                    <td class='text-center'><?php echo $value->huruf_nota; ?></td>
                                    <td class='text-center'><?php echo $value->no_nota_awal; ?></td>
                                    <td class='text-center'><?php echo $value->no_nota_akhir; ?></td>
                                    <td class='text-center'><?php echo $value->jumlah_nota; ?></td>
                                    <td class='text-center'><?php echo $value->no_nota_batal; ?></td>
                                    <td class='text-center'><?php echo $value->jumlah_nota_batal; ?></td>
                                    <td class='text-center'><?php echo $value->berat; ?></td>
                                    <!-- <td class='text-center'><?php echo $value->total_berat; ?></td> -->
                                    <td class='text-center'><?php echo number_format($value->harga); ?></td>
                                    <!-- <td class='text-center'><?php echo number_format($value->total_harga); ?></td> -->
                                </tr>
                            <?php
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</form>

<script data-main="<?php echo base_url() ?>assets/js/main/main-insentif" src="<?php echo base_url() ?>assets/js/require.js"></script>