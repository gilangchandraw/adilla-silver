<div class="app-page-title">
	<div class="page-title-wrapper">
		<div class="page-title-heading">
			<div class="page-title-icon">
				<i class="fa fa-user icon-gradient bg-plum-plate"></i>
			</div>
			<div><?php echo ucwords(str_replace("_", " ", $this->uri->segment(1))) ?>
				<div class="page-title-subheading"></div>
			</div>
		</div>
		<div class="page-title-actions">
			<a href="<?php echo base_url() ?>data_karyawan/create" data-toggle="tooltip" title="" data-placement="bottom" class="btn-shadow mr-3 btn btn-primary">
				<i class='fa fa-plus'></i> Data Karyawan
			</a>
		</div>
	</div>
</div>

<div class="row">
	<div class="col-lg-12">
		<div class="main-card mb-2 card">
			<?php if (!empty($this->session->flashdata('message'))) { ?>
				<div class="card-header">
					<div class="alert alert-info fade show text-center w-100" role="alert">
						<?php print_r($this->session->flashdata('message')); ?>
					</div>
				</div>
			<?php } ?>

			<?php if (!empty($this->session->flashdata('message_error'))) { ?>
				<div class="card-header">
					<div class="alert alert-danger fade show text-center w-100" role="alert">
						<?php print_r($this->session->flashdata('message_error')); ?>
					</div>
				</div>
			<?php } ?>
			<div class="card-body">
				<div class="table-responsive">
					<table class="table table-striped table-hover table-bordered responsive w-100" id="table">
						<thead>
							<th style="width: 20px">No</th>
							<th class="text-center">Nama Cabang</th>
							<th class="text-center">Nama karyawan</th>
							<th class="text-center">Alamat</th>
							<th class="text-center">No Telepon</th>
							<th class="text-center" style="width: 100px">Aksi</th>
						</thead>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<script data-main="<?php echo base_url() ?>assets/js/main/main-data_karyawan" src="<?php echo base_url() ?>assets/js/require.js"></script>