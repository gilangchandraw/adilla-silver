<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-user icon-gradient bg-plum-plate"></i>
            </div>
            <div>Tambah Data Karyawan</div>
        </div>
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="nama_karyawan">Nama Karyawan</label>
                        <input class="form-control" type="text" id="nama_karyawan" name="nama_karyawan">
                    </div>
                    <div class="position-relative form-group">
                        <label for="alamat">Alamat</label>
                        <textarea class="form-control" type="text" id="alamat" name="alamat"></textarea>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="no_telepon">No Telepon</label>
                        <input class="form-control number" type="text" id="no_telepon" name="no_telepon">
                    </div>
                </div>
            </div>
            <div class="box-footer">
                <div class="row">
                    <div class="col-md-6">
                        <span class="reminder" style="color:red"><b>Mohon Periksa Kembali Form, Sebelum Disimpan</b></span>
                    </div>
                </div>
            </div>
            <button type="submit" class="mt-2 btn btn-primary pull-right" id="save-btn"><i class="fa fa-save"> Simpan</i></button>
            <a href="<?php echo base_url(); ?>data_karyawan" class="mt-2 mr-2 btn-transition btn btn-outline-danger pull-right"><i class="fa fa-times"> Batal</i></a>
        </div>
    </div>
</form>

<script data-main="<?php echo base_url() ?>assets/js/main/main-data_karyawan" src="<?php echo base_url() ?>assets/js/require.js"></script>