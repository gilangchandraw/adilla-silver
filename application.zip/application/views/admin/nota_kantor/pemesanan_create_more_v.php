<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-database icon-gradient bg-plum-plate"></i>
            </div>
            <div>Tambah Data Stok Nota</div>
        </div>
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="tanggal">Tanggal Stok</label>
                        <input class="form-control" value="<?php echo $pemesanan->tanggal; ?>" readonly type="text" id="tanggal" name="tanggal" autocomplete="off">
                    </div>
                    <div class="position-relative form-group">
                        <label for="huruf_nota">Huruf Nota</label>
                        <select class="form-control select2" id="huruf_nota" name="huruf_nota">
                            <option value="" selected>Pilih Huruf Nota</option>
                            <option value="A">A (Nota Penjualan)</option>
                            <option value="B">B (Nota Penjualan)</option>
                            <option value="C">C (Nota Penjualan)</option>
                            <option value="D">D (Nota Penjualan)</option>
                            <option value="E">E (Nota Penjualan)</option>
                            <option value="F">F (Nota Penjualan)</option>
                            <option value="G">G (Nota Tukar)</option>
                            <option value="J">J (Nota Cadangan Penjualan)</option>
                            <option value="T">T (Nota Cadangan Tukar)</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="jenis_nota">Jenis Nota</label>
                        <select class="form-control select2" id="jenis_nota" name="jenis_nota">
                            <option value="" selected>Pilih Jenis Nota</option>
                            <option value="0">Pembukuan</option>
                            <option value="1">Transaksi Cabang</option>
                        </select>
                    </div>
                    <div class="form-row">
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="angka_awal">Angka Awal</label>
                                <input class="form-control number" type="text" id="angka_awal" name="angka_awal">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="angka_akhir">Angka Akhir</label>
                                <input class="form-control number" type="text" id="angka_akhir" name="angka_akhir">
                                <input class="form-control" type="hidden" id="pemesanan_nota_id" name="pemesanan_nota_id" value="<?php echo $pemesanan_nota_id; ?>">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="box-footer">
                <div class="row">
                    <div class="col-md-6">
                        <span class="reminder" style="color:red"><b>Mohon Periksa Kembali Form, Sebelum Disimpan</b></span>
                    </div>
                </div>
            </div>
            <button type="submit" class="mt-2 btn btn-primary pull-right" id="save-btn"><i class="fa fa-save"> Simpan & Tambah</i></button>
            <a href="<?php echo base_url(); ?>nota_kantor/pemesanan/<?php echo $pemesanan->cabang_id; ?>" class="mt-2 mr-2 btn-transition btn btn-success pull-right"><i class="fa fa-check"> Selesai</i></a>
            <div class="card-body">
                <h5 class="card-title">Histori Data Pemesanan Nota</h5>
                <div class="table-responsive">
                    <table class="table table-striped table-hover table-bordered responsive w-100" id="table-detail">
                        <thead>
                            <th class="text-center">No</th>
                            <th class="text-center">Huruf Nota</th>
                            <th class="text-center">jenis Nota</th>
                            <th class="text-center">Angka Awal</th>
                            <th class="text-center">Angka Akhir</th>
                            <th class="text-center">Aksi</th>
                        </thead>

                        <tbody>
                            <?php
                            $no = 1;
                            if(!empty($pemesanan_detail)) {
                            foreach ($pemesanan_detail as $key => $value) { ?>
                                <tr>
                                    <td class='text-center'><?php echo $no++; ?></td>
                                    <td class='text-center'><?php echo $value->huruf_nota; ?></td>
                                    <td class='text-center'><?php echo $value->jenis_nota == 0 ? 'Pembukuan' : 'Transaksi Cabang'; ?></td>
                                    <td class='text-center'><?php echo $value->angka_awal; ?></td>
                                    <td class='text-center'><?php echo $value->angka_akhir; ?></td>
                                    <td class='text-center'><?php echo "<a href='" . base_url() . "nota_kantor/pemesanan_edit/" . $value->id . "' class='btn btn-sm btn-warning' data-toggle='tooltip' title='Edit Data' data-placement='bottom'><i class='fa fa-edit fa-w-20'></i></a>"; ?>  <?php echo "<a href='#' class='btn btn-sm btn-danger delete-data' data-toggle='tooltip' detail_id='".$value->id."'' title='Hapus Data' data-placement='bottom'><i class='fa fa-times fa-w-20'></i></a>"; ?></td>
                                </tr>
                            <?php
                            }
                        }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</form>

<script data-main="<?php echo base_url() ?>assets/js/main/main-nota-kantor" src="<?php echo base_url() ?>assets/js/require.js"></script>