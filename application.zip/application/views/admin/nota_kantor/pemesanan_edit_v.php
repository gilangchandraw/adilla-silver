<div class="app-page-title">
    <div class="page-title-wrapper">
        <div class="page-title-heading">
            <div class="page-title-icon">
                <i class="fa fa-database icon-gradient bg-plum-plate"></i>
            </div>
            <div>Tambah Data Stok Nota</div>
        </div>
    </div>
</div>
<form id="form" method="POST" action="" enctype="multipart/form-data">
    <div class="main-card mb-3 card">
        <div class="card-body">
            <div class="row">
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="tanggal">Tanggal Stok</label>
                        <input class="form-control init-date readonly" value="<?php echo $data->tanggal; ?>" readonly type="text" id="tanggal" name="tanggal" autocomplete="off">
                    </div>
                    <div class="position-relative form-group">
                        <label for="huruf_nota">Huruf Nota</label>
                        <select class="form-control select2" id="huruf_nota" name="huruf_nota">
                            <option value="" selected>Pilih Huruf Nota</option>
                            <option value="A" <?php echo $detail->huruf_nota == 'A' ? 'selected' : ''; ?>>A</option>
                            <option value="B" <?php echo $detail->huruf_nota == 'B' ? 'selected' : ''; ?>>B</option>
                            <option value="C" <?php echo $detail->huruf_nota == 'C' ? 'selected' : ''; ?>>C</option>
                            <option value="D" <?php echo $detail->huruf_nota == 'D' ? 'selected' : ''; ?>>D</option>
                            <option value="E" <?php echo $detail->huruf_nota == 'E' ? 'selected' : ''; ?>>E</option>
                            <option value="G" <?php echo $detail->huruf_nota == 'G' ? 'selected' : ''; ?>>G</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="position-relative form-group">
                        <label for="jenis_nota">Jenis Nota</label>
                        <select class="form-control select2" id="jenis_nota" name="jenis_nota">
                            <option value="" selected>Pilih Jenis Nota</option>
                            <option value="0" <?php echo $detail->jenis_nota == 0 ? 'selected' : ''; ?>>Pembukuan</option>
                            <option value="1" <?php echo $detail->jenis_nota == 1 ? 'selected' : ''; ?>>Transaksi Cabang</option>
                        </select>
                    </div>
                    <div class="form-row">
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="angka_awal">Angka Awal</label>
                                <input class="form-control number" type="text" id="angka_awal" name="angka_awal" value="<?php echo $detail->angka_awal; ?>">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="position-relative form-group">
                                <label for="angka_akhir">Angka Akhir</label>
                                <input class="form-control number" type="text" id="angka_akhir" name="angka_akhir" value="<?php echo $detail->angka_akhir; ?>">
                            </div>
                        </div>
                        <input type="hidden" name="id" value="<?php echo $id; ?>">
                    </div>
                </div>
            </div>
            <div class="box-footer">
                <div class="row">
                    <div class="col-md-6">
                        <span class="reminder" style="color:red"><b>Mohon Periksa Kembali Form, Sebelum Disimpan</b></span>
                    </div>
                </div>
            </div>
            <button type="submit" class="mt-2 btn btn-primary pull-right" id="save-btn"><i class="fa fa-save"> Simpan</i></button>
            <a href="<?php echo base_url(); ?>nota_kantor" class="mt-2 mr-2 btn-transition btn btn-success pull-right"><i class="fa fa-check"> Selesai</i></a>

        </div>
    </div>
</form>

<script data-main="<?php echo base_url() ?>assets/js/main/main-nota-kantor" src="<?php echo base_url() ?>assets/js/require.js"></script>