<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Data_karyawan extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('data_karyawan_model');
		$this->load->model('cabang_model');
	}

	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$this->data['content'] = 'admin/data_karyawan/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function create()
	{
		$this->form_validation->set_rules('nama_karyawan', "nama_karyawan Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$data = array(

				'nama_karyawan' => $this->input->post('nama_karyawan'),
				'alamat' => $this->input->post('alamat'),
				'users_id' => $this->data['users']->id,
				'no_telepon' => $this->input->post('no_telepon'),
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			$insert = $this->data_karyawan_model->insert($data);

			if ($insert) {
				$this->session->set_flashdata('message', "Data Data Karyawan Baru Berhasil Disimpan");
				redirect("data_karyawan");
			} else {
				$this->session->set_flashdata('message_error', "Data Data Karyawan Baru Gagal Disimpan");
				redirect("data_karyawan");
			}
		} else {
			if ($this->data['is_can_create']) {
				$this->data['content'] = 'admin/data_karyawan/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function edit()
	{
		$this->form_validation->set_rules('nama_karyawan', "nama_karyawan Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$id = $this->input->post('id');
			$data = array(

				'nama_karyawan' => $this->input->post('nama_karyawan'),
				'alamat' => $this->input->post('alamat'),
				'no_telepon' => $this->input->post('no_telepon'),
				'updated_by' => $this->data['users']->id
			);
			$update = $this->data_karyawan_model->update($data, array("id" => $this->input->post('id')));
			if ($update) {
				$this->session->set_flashdata('message', "Data Data Karyawan Berhasil Diedit");
				redirect("data_karyawan");
			} else {
				$this->session->set_flashdata('message_error', "Data Data Karyawan Gagal Diedit");
				redirect("data_karyawan");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("data_karyawan/edit/" . $id);
			} else {
				if ($this->data['is_can_edit']) {
					$this->data['id'] = $this->uri->segment(3);
					$this->data['data_karyawan'] = $this->data_karyawan_model->getOneBy(array("data_karyawan.id" => $this->data['id']));
					$this->data['content'] = 'admin/data_karyawan/edit_v';
				} else {
					$this->data['content']  = 'errors/html/restrict';
				}
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function detail()
	{
		$this->data['id'] = $this->uri->segment(3);
		$this->data['data_karyawan'] = $this->data_karyawan_model->getOneBy(array("data_karyawan.id" => $this->data['id']));

		$this->data['content'] = 'admin/data_karyawan/detail_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function dataList()
	{
		$columns = array(
			0 => 'data_karyawan.id',
			1 => 'data_karyawan.nama_karyawan',
			2 => 'data_karyawan.alamat',
			3 => 'data_karyawan.no_telepon',
			4 => 'action'
		);

		$where = array();
		if (!$this->data['is_superadmin']) {
			$where['data_karyawan.users_id'] = $this->data['users']->id;
		}

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->data_karyawan_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);

		if (!empty($this->input->post('search')['value'])) {
			$search_value = $this->input->post('search')['value'];
			$search = array(

				"data_karyawan.nama_karyawan" => $search_value,
				"data_karyawan.alamat" => $search_value,
				"data_karyawan.no_telepon" => $search_value,
			);
			$totalFiltered = $this->data_karyawan_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->data_karyawan_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$edit_url = "";
				$delete_url = "";
				if ($this->data['is_can_edit'] && $data->is_deleted == 0) {
					$edit_url = "<a href='" . base_url() . "data_karyawan/edit/" . $data->id . "' class='btn btn-sm btn-warning' data-toggle='tooltip' title='Edit Data' data-placement='bottom'><i class='fa fa-edit fa-w-20'></i></a>";
				}
				if ($this->data['is_can_edit']) {
					if ($data->is_deleted == 0) {
						$delete_url = "<a href='#' 
	        				url='" . base_url() . "data_karyawan/destroy/" . $data->id . "/" . $data->is_deleted . "' class='btn btn-sm btn-danger delete' data-toggle='tooltip' title='Non Aktifkan Data' data-placement='bottom'><i class='fa fa-times fa-w-20'></i></a>";
					} else {
						$delete_url = "<a href='#' 
	        				url='" . base_url() . "data_karyawan/destroy/" . $data->id . "/" . $data->is_deleted . "' class='btn btn-sm btn-success delete' data-toggle='tooltip' title='Aktifkan Data' data-placement='bottom'><i class='fa fa-check fa-w-20'></i></a>";
					}
				}

				$nestedData['id'] = $start + $key + 1;
				$nestedData['cabang'] = $data->kode_cabang . ' - ' . $data->nama_cabang;
				$nestedData['nama_karyawan'] = $data->nama_karyawan;
				$nestedData['alamat'] = $data->alamat;
				$nestedData['no_telepon'] = $data->no_telepon;
				$nestedData['action'] = $edit_url . " " . $delete_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function destroy()
	{
		$response_data = array();
		$response_data['status'] = false;
		$response_data['msg'] = "";
		$response_data['data'] = array();

		$id = $this->uri->segment(3);
		$is_deleted = $this->uri->segment(4);
		if (!empty($id)) {
			$data = array(
				'is_deleted' => ($is_deleted == 1) ? 0 : 1
			);
			$update = $this->data_karyawan_model->update($data, array("id" => $id));

			$response_data['data'] = $data;
			$response_data['status'] = true;
		} else {
			$response_data['msg'] = "ID Harus Diisi";
		}

		echo json_encode($response_data);
	}

	public function get_data()
	{
		$cabang_id = $this->input->get('cabang_id');
		$data_cabang = $this->cabang_model->getOneBy(['cabang.id' => $cabang_id]);

		$where['data_karyawan.users_id'] = $data_cabang->users_id;
		$where['data_karyawan.is_deleted'] = 0;
		$data_karyawan = $this->data_karyawan_model->getAllById($where);

		$data = array();
		if ($data_karyawan) {
			$data['status'] = true;
			$data['data'] = $data_karyawan;
			$data['message'] = "Berhasil Ambil data karyawan";
		} else {
			$data['status'] = false;
			$data['data'] = [];
			$data['message'] = "Gagal Ambil data karyawan";
		}
		echo json_encode($data);
	}
}
