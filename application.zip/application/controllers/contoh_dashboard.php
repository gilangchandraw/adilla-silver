<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH.'core/Admin_Controller.php';
class Dashboard_air_minum extends Admin_Controller {
 	public function __construct()
	{
		parent::__construct();
		$this->load->model('unit_model');
		$this->load->model('data_teknis_model');
		$this->load->model('data_umum_model');
		$this->load->model('data_pelayanan_model');
		$this->load->model('master_data_kelembagaan_model');
		$this->load->model('unit_model');
		$this->load->model('kelola_jaringan_kota_model');
		$this->load->model('kelola_jaringan_desa_model');
		$this->load->model('jumlah_penduduk_model');
		$this->load->model('kelola_bjp_model');
		$this->load->model('pembinaan_air_minum_model');
		$this->load->model('wilayah_model');
		$this->load->model('profil_daerah_model');
		 
	}
	public function index()
	{
		$this->load->helper('url');

		if($this->data['is_can_read']){

			$where = array();
	        $this->data['teknis_kota'] = $this->data_teknis_model->getCountAll($where);
	        $this->data['umum_kota'] = $this->data_umum_model->getCountAll($where);
	        $pelayanan_kota = $this->data_pelayanan_model->getCountAll($where);
	        if ($pelayanan_kota != NULL) {
	        	$this->data['pelayanan_kota'] = $pelayanan_kota->jumlah_sr;
	        }else{
	        	$this->data['pelayanan_kota'] = 0;
	        }

	        $this->data['desa'] = $this->kelola_jaringan_desa_model->getCountAll($where);
	        // echo $this->db->last_query();
	        // var_dump($this->data['umum']);
	        // die();
	        
			$this->data['content'] = 'admin/dashboard/air_minum';   
		}else{
			$this->data['content'] = 'errors/html/restrict'; 
		}
		
		$this->load->view('admin/layouts/page',$this->data);  
		
		// $this->data['content'] = 'admin/dashboard/air_minum';   

		// $this->load->view('admin/layouts/page',$this->data); 
	}

	public function pengelola_air_bersih()
	{
		

		$lembaga 	= $this->master_data_kelembagaan_model->getAllById();
		$unit 		= $this->unit_model->getSumUnit();
		
		$arrUnit = [];
		foreach ($unit as $key => $value)
		{
			$arrUnit[$value->pengelola] = $value->totalPengelola;
		}

		$dataFix = [];
		foreach ($lembaga as $key => $value)
		{
			$dataFix[] = [
				'name' 		=> $value->nama_pengelola,
				'y' 		=> isset($arrUnit[$value->id]) ? (int) $arrUnit[$value->id] / 100 : 0,
				'z' 		=> isset($arrUnit[$value->id]) ? (int) $arrUnit[$value->id] : 0,
				// 'drilldown' => $value->nama_pengelola,
			];
		}

		$json_data = array(
                    "series"            => $dataFix   
                    );
		echo json_encode($json_data);
	}

	public function air_bersih_sebaran()
	{
		//PDAM
		$jumlahPenduduk 	= $this->jumlah_penduduk_model->countKabBandung(['tahun'=>date('Y')]);
		$jumlahSr			= $this->data_pelayanan_model->getCountAll();
		$hasilPerhitunganPdam 			= ($jumlahSr->jumlah_sr * 4 / $jumlahPenduduk->totalPenduduk) * 100;
		$hasilPDAM = number_format($hasilPerhitunganPdam,3);


		// NON PDAM
		$jumlahSrDesa			= $this->kelola_jaringan_desa_model->getCountAll();
		$hasilPerhitunganNonPDAM 		= ($jumlahSrDesa->sambunganRumah * 4 / $jumlahPenduduk->totalPenduduk) * 100;
		$hasilNonPDAM = number_format($hasilPerhitunganNonPDAM,3);

		//LAIN LAIN
		$jumlahSrBjp			= $this->kelola_bjp_model->getCountAll();
		$hasilPerhitunganLain 		= ($jumlahSrBjp->sambungan_rumah * 4 / $jumlahPenduduk->totalPenduduk) * 100;
		$hasil_lain = number_format($hasilPerhitunganLain,3);
		

		//BELUM TERJANGKAU
		// $b 		= ($hasilPDAM + $hasilNonPDAM + $hasil_lain) * 4;
		$jumlahSemua 		= ($jumlahSr->jumlah_sr + $jumlahSrDesa->sambunganRumah + $jumlahSrBjp->sambungan_rumah);
		$hasilPerhitunganBT 		= $jumlahPenduduk->totalPenduduk - $jumlahSemua;
		$BelumTerjangkau = number_format($hasilPerhitunganBT,3);
		$hasilBagi = $hasilPerhitunganBT / 100;
		$hasilBelumTerjangkau = number_format($hasilBagi,3);
		
			for ($i=0; $i < 4; $i++) { 
				if ($i == 0) {
					$data['name'] = 'PDAM';
					$data['y'] = floatval($hasilPDAM);
					$data['z'] = floatval($hasilPDAM * 10);
				} elseif($i == 1) {
					$data['name'] = 'Non PDAM';
					$data['y'] = floatval($hasilNonPDAM);
					$data['z'] = floatval($hasilNonPDAM * 10);
				}elseif($i == 2){
					$data['name'] = 'Lain-Lain';
					$data['y'] = floatval($hasil_lain);
					$data['z'] = floatval($hasil_lain * 10);
				}else{
					$data['name'] = 'Belum Terjangkau';
					$data['y'] = floatval($hasilBelumTerjangkau);
					$data['z'] = floatval($hasilPerhitunganBT);
				}
				$new_data[] = $data;
			}
		$json_data = array(
                    "series"            => $new_data   
                    );
		echo json_encode($json_data);
	}

	public function pembinaan_air_bersih_cakupan()
	{
		$nilai = $this->pembinaan_air_minum_model->getAllById();
		$nilaiBT = $this->kelola_jaringan_desa_model->getAllByIdData(['status'=>0]);
		// var_dump($nilaiBT);
		// die();
		$totalNilaiKurang = 0;
		$totalNilaiCukup = 0;
		$totalNilaiBaik = 0;
		$totalNilaiBelumTerjangkau = 0;
	//count nilai belum terjangkau lur
		if ($nilaiBT != FALSE) {
			foreach ($nilaiBT as $key => $value) {
				if ($value->status==0) {
					$totalNilaiBelumTerjangkau++;
				}
			}
		}
			
	//nilai akhir
		if ($nilai != FALSE) {
			foreach ($nilai as $key => $value) {
		    	if ($value->nilai_akhir < 4) {
            		$totalNilaiKurang++;
            	} elseif($value->nilai_akhir > 4 && $value->nilai_akhir < 7) {
            		$totalNilaiCukup++;
            	}else{
            		$totalNilaiBaik++;
            	}
			}
		}
		
	//series data
		for ($i=0; $i < 4; $i++) { 
			if ($i == 0) {
				$data['name'] 	= 'Kurang';
				$data['y'] 		= $totalNilaiKurang/100;
				$data['z'] 		= $totalNilaiKurang;
			}elseif($i == 1){
				$data['name'] 	= 'Cukup';
				$data['y'] 		= $totalNilaiCukup/100;
				$data['z'] 		= $totalNilaiCukup;
			}elseif($i == 2){
				$data['name'] 	= 'Baik';
				$data['y'] 		= $totalNilaiBaik/100;
				$data['z'] 		= $totalNilaiBaik;
			}else{
				$data['name'] 	= 'Belum Terjangkau';
				$data['y'] 		= $totalNilaiBelumTerjangkau/100;
				$data['z'] 		= $totalNilaiBelumTerjangkau;
			}
			$dataFix[] = $data; 
		}
		$json_data = array(
                    "series"            => $dataFix   
                    );
		echo json_encode($json_data);
	}

	public function pembinaan_air_bersih_kecamatan_perkotaan()
	{

		$where = array();
        $order = array();
  		$search = array();
  		$limit = 0;
  		$start = 0;


		$kecamatan = $this->kelola_jaringan_kota_model->getAllByKecamatan($limit,$start,$search,NULL,NULL,$where);
		$kurang = [];
		$baik = [];
		$cukup = [];
		$belum = [];


		// $dataDummy = [
		// 	['id_kec' => 3204011, 'kurang' => '10', 'baik' => 20, 'cukup' => '100', 'belum' => '200' ],
		// ];
		$dataNilaiByKec = $this->pembinaan_air_minum_model->getNilaiByKecamatan();

		$dataNilai = [];
		foreach ($dataNilaiByKec as $key => $value)
		{
			$dataNilai[$value['id_kec'].'_kurang'] = (int) $value['kurang'];
			$dataNilai[$value['id_kec'].'_baik'] = (int) $value['baik'];
			$dataNilai[$value['id_kec'].'_cukup'] = (int) $value['cukup'];
			$dataNilai[$value['id_kec'].'_belum'] = (int) $value['belum'];
		}
		
		foreach ($kecamatan as $key => $value)
		{
			$kurang[] = isset($dataNilai[$value->id . '_kurang']) ? $dataNilai[$value->id . '_kurang'] : 0;
			$baik[] = isset($dataNilai[$value->id . '_baik']) ? $dataNilai[$value->id . '_baik'] : 0;
			$cukup[] = isset($dataNilai[$value->id . '_cukup']) ? $dataNilai[$value->id . '_cukup'] : 0;
			$belum[] = isset($dataNilai[$value->id . '_belum']) ? $dataNilai[$value->id . '_belum'] : 0;
			$data 		= $value->name;
			$new_data[] 				= $data;
		}

		$dataFix = [
			['name' => 'Kurang', 'data' => $kurang],
			['name' => 'Baik', 'data' => $baik],
			['name' => 'Cukup', 'data' => $cukup],
			['name' => 'Belum', 'data' => $belum],
		];

		$json_data = array(
                    "wilayah"            => $new_data,
                    "dataPembinaan"            => $dataFix
                    );
		echo json_encode($json_data);
	}

	public function pembinaan_air_bersih_kecamatan_perkotaan_detail($kecamatan)
	{
		$getKecId = $this->wilayah_model->getKecamatan(['name'=>$kecamatan]);
		$kecId = $getKecId[0]->id;
		
		$desa =  $this->wilayah_model->getDesa(['district_id'=>$kecId]);
		$kurang = [];
		$baik = [];
		$cukup = [];
		$belum = [];


		// $dataDummy = [
		// 	['id_desa' => 3204011, 'kurang' => '10', 'baik' => 20, 'cukup' => '100', 'belum' => '200' ],
		// ];

		$dataNilaiByDesa = $this->pembinaan_air_minum_model->getNilaiByDesa();


		$dataNilai = [];
		foreach ($dataNilaiByDesa as $key => $value)
		{
			$dataNilai[$value['id_desa'].'_kurang'] = (int) $value['kurang'];
			$dataNilai[$value['id_desa'].'_baik'] = (int) $value['baik'];
			$dataNilai[$value['id_desa'].'_cukup'] = (int) $value['cukup'];
			$dataNilai[$value['id_desa'].'_belum'] = (int) $value['belum'];
		}


		
		foreach ($desa as $key => $value)
		{
			$kurang[] = isset($dataNilai[$value->id . '_kurang']) ? $dataNilai[$value->id . '_kurang'] : 0;
			$baik[] = isset($dataNilai[$value->id . '_baik']) ? $dataNilai[$value->id . '_baik'] : 0;
			$cukup[] = isset($dataNilai[$value->id . '_cukup']) ? $dataNilai[$value->id . '_cukup'] : 0;
			$belum[] = isset($dataNilai[$value->id . '_belum']) ? $dataNilai[$value->id . '_belum'] : 0;
			$data 		= $value->name;
			$new_data[] 				= $data;
		}

		$dataFix = [
			['name' => 'Kurang', 'data' => $kurang],
			['name' => 'Baik', 'data' => $baik],
			['name' => 'Cukup', 'data' => $cukup],
			['name' => 'Belum', 'data' => $belum],
		];

		$json_data = array(
                    "desa"            => $new_data,
                    "dataPembinaan"            => $dataFix
                    );
		echo json_encode($json_data);
	}

	public function pengelola_air_bersih_kecamatan()
	{
	//data pengelola
		$lembaga 	= $this->master_data_kelembagaan_model->getAllById();
	//get unit berdasarkan kecamatan
		$unitKec 		= $this->data_umum_model->getUnitByKec();
		$arrUnitKec = [];
		$data = [];
		foreach ($unitKec as $key => $value) {
			$arrUnitKec[] = [
				'kecamatan_id'	=> $value->kecamatan_id,
				'unit_id'		=> $value->id_unit
			];
			$data[] = ['kecamatan_id' => $value->kecamatan_id,'unit_id'=>$value->id_unit];
		}
		// print_r($data);
		// die();
		$hitung = count($data);
		
	//get unit berdasarkan pengelola
		$unitPengelola 		= $this->unit_model->getUnitPengelola();
		
		foreach ($unitPengelola as $key => $value) {
			for ($i=0; $i < $hitung; $i++) { 
				if ($value->id == $data[$i]['unit_id']) {
					$data[$key]['pengelola'] = $value->pengelola;
					$data[$key]['total'] = $value->totalPengelola;
				}
			}			
		}
		// print_r($data);
		// die();
		$arrCek = [];
		foreach ($data as $key => $value) {
			$index = $value['kecamatan_id'] . '_' . $value['pengelola'];
			$arrCek[$index] = $value['total'];
			
		}

		$dataNilai = [];
		foreach ($data as $key => $value)
		{
			$dataNilai[$value['kecamatan_id'].'_kec'] = (int) $value['kecamatan_id'];
			$dataNilai[$value['pengelola'].'_pengelola'] = (int) $value['pengelola'];
			$dataNilai[$value['total'].'_total'] = (int) $value['total'];
		}

		

		$where = array();
        $order = array();
  		$search = array();
  		$limit = 0;
  		$start = 0;


		$kecamatan = $this->kelola_jaringan_kota_model->getAllByKecamatan($limit,$start,$search,NULL,NULL,$where);

		$hasilAkhir=[];
		$listKecamatan=[];
		foreach ($kecamatan as $key => $value)
		{
			$hasilAkhir[] 		= isset($dataNilai[$value->id . '_kec']) ? $dataNilai[$value->id . '_kec'] : 0;
			$data 				= $value->name;
			$listKecamatan[] 	= $data;
		}

		$arrLembaga =[];
		foreach ($lembaga as $key => $value) {
			$arrLembaga[] = [
				'id' =>$value->id,
				'nama' =>$value->nama_pengelola
			];
		}

		$dataFix = [];
		foreach ($lembaga as $key1 => $lem)
		{
			$dataKec = [];
			foreach ($kecamatan as $key => $kec)
			{
				$index = $kec->id .'_'. $lem->id;
				$dataKec[] = isset($arrCek[$index]) ? (int)$arrCek[$index] : 0;
			}

			$dataFix[] = [
				'name' => $lem->nama_pengelola,
				'data' => $dataKec,
			];
		}

		$json_data = array(
                    "listKecamatan"            			=> $listKecamatan,
                    "dataPengelolaAirBersih"          => $dataFix
                    );
		echo json_encode($json_data);
	}

	public function pengelola_air_bersih_kecamatan_detail($kecamatan)
	{
		$getKecId = $this->wilayah_model->getKecamatan(['name'=>$kecamatan]);
		$kecId = $getKecId[0]->id;
		
	// desa berdasarkan kecamatan
		$desa =  $this->wilayah_model->getDesa(['district_id'=>$kecId]);
	//data pengelola
		$lembaga 	= $this->master_data_kelembagaan_model->getAllById();
	//get unit berdasarkan kecamatan

		$unitKec 		= $this->kelola_jaringan_desa_model->getPengelolaByDesa(['id_kec'=>$kecId]);
		$data = [];
		foreach ($unitKec as $key => $value) {
			$data[] = ['desa_id' => $value->id_desa,'pengelola' => $value->pengelola, 'total'=> $value->totalPengelola];
		}
		
		$arrCek = [];
		foreach ($data as $key => $value) {
			$index = $value['desa_id'] . '_' . $value['pengelola'];
			$arrCek[$index] = $value['total'];
			
		}

		$dataNilai = [];
		foreach ($data as $key => $value)
		{
			$dataNilai[$value['desa_id'].'_desa'] = (int) $value['desa_id'];
			$dataNilai[$value['pengelola'].'_pengelola'] = (int) $value['pengelola'];
			$dataNilai[$value['total'].'_total'] = (int) $value['total'];
		}

		$hasilAkhir=[];
		$listDesa=[];
		foreach ($desa as $key => $value)
		{
			$hasilAkhir[] 		= isset($dataNilai[$value->id . '_desa']) ? $dataNilai[$value->id . '_desa'] : 0;
			$data 				= $value->name;
			$listDesa[] 	= $data;
		}

		$arrLembaga =[];
		foreach ($lembaga as $key => $value) {
			$arrLembaga[] = [
				'id' =>$value->id,
				'nama' =>$value->nama_pengelola
			];
		}

		$dataFix = [];
		foreach ($lembaga as $key1 => $lem)
		{
			$dataDesa = [];
			foreach ($desa as $key => $des)
			{
				$index = $des->id .'_'. $lem->id;
				$dataDesa[] = isset($arrCek[$index]) ? (int)$arrCek[$index] : 0;
			}

			$dataFix[] = [
				'name' => $lem->nama_pengelola,
				'data' => $dataDesa,
			];
		}

		// echo '<pre>';
		// var_dump($dataFix);
		// echo '</pre>';
		// die();
		$json_data = array(
                    "listDesa"            			=> $listDesa,
                    "dataPengelolaAirBersihDetail"          => $dataFix
                    );
		echo json_encode($json_data);
	}

	public function cakupan_air_bersih_kecamatan()
	{

		$where = array();
        $order = array();
  		$search = array();
  		$limit = 0;
  		$start = 0;


		$kecamatan = $this->kelola_jaringan_kota_model->getAllByKecamatan($limit,$start,$search,NULL,NULL,$where);

		
		
		
		$belumTerjangkau = [];
		$dataAirBersihBersihKecamatan = $this->data_umum_model->getCountByKec();
		
	// get penduduk kecamatan
		$totalPendudukKec = $this->profil_daerah_model->sumTotalJumlahPendudukbyKecamatanAll();

	//dataPDAM
		$pdam = [];
		$wherePdam['kecamatan_id !='] =NULL;
		$jumlahSrPdam			= $this->data_pelayanan_model->getCountByKec($wherePdam);

		$data = [];
			if ($jumlahSrPdam != FALSE) {
				foreach ($jumlahSrPdam as $key => $value) {
					$hasilPdam = $value->jumlah_sr * 4;
					$pdam[] =['kecamatan_id'=>$value->kecamatan_id,'pdam'=> $hasilPdam];
					$data[$value->kecamatan_id] = [ "id_kec" => $value->kecamatan_id, 'pdam' => $hasilPdam, 'belum' => $hasilPdam];
				}
			}
			
	// data Non PDAM 
		$nonPdam = [];
		$whereNonPdam['id_kec !='] =NULL;
		$jumlahSrNonPdam			= $this->kelola_jaringan_desa_model->countSrByKec($whereNonPdam);
		
		
			if ($jumlahSrNonPdam != FALSE) {
				foreach ($jumlahSrNonPdam as $key => $value) {
					$hasilNonPdam = $value->sambunganRumah * 4;
					$nonPdam[] =['kecamatan_id'=>$value->id_kec,'nonPdam'=> $hasilNonPdam];
					$data[$value->id_kec]['belum'] = $data[$value->id_kec]['belum'] +  $hasilNonPdam;
					$data[$value->id_kec]['nonPdam'] = $hasilNonPdam;
				}
			}
				
		
		
	// // data lain lain
		$whereBjp['id_kec !='] = NULL;
		$whereBjp['sambungan_rumah !='] = NULL;
		$lainLain = [];
		$jumlahSrBjp			= $this->kelola_bjp_model->countSrByKec($whereBjp);
		if ($jumlahSrBjp != FALSE) {
			foreach ($jumlahSrBjp as $key => $value) {
				$hasilLain = $value->sambungan_rumah * 4;
				$lainLain[] =['kecamatan_id'=>$value->id_kec,'lain'=> $hasilLain];
				$data[$value->id_kec]['belum'] = $data[$value->id_kec]['belum'] +  $hasilLain;
				$data[$value->id_kec]['lain'] = $hasilLain;
			}
		}
			
	// // //belum terjangkau
			foreach ($totalPendudukKec as $key => $value) {
				if (in_array($value->kecamatan_id, array_keys($data))) {
					$data[$value->kecamatan_id]['belum'] = $value->jumlah_penduduk - $data[$value->kecamatan_id]['belum'];
				}
			}
		
		$dataNilai = [];
		foreach ($data as $key => $value)
		{
			$dataNilai[$value['id_kec'].'_pdam'] = (int) $value['pdam'];
			if (!empty($value['nonPdam'])) {
				$dataNilai[$value['id_kec'].'_nonPdam'] = (int) $value['nonPdam'];
			}
			if (!empty($value['lain'])) {
				$dataNilai[$value['id_kec'].'_lain'] = (int) $value['lain'];	
			}			
			$dataNilai[$value['id_kec'].'_belum'] = (int) $value['belum'];
		}
		$hasilPdamAkhir=[];
		$hasilNonPdamAkhir=[];
		$hasilLainAkhir=[];
		$hasilbelumAkhir=[];
		
		foreach ($kecamatan as $key => $value)
		{
			$hasilPdamAkhir[] = isset($dataNilai[$value->id . '_pdam']) ? $dataNilai[$value->id . '_pdam'] : 0;
			$hasilNonPdamAkhir[] = isset($dataNilai[$value->id . '_nonPdam']) ? $dataNilai[$value->id . '_nonPdam'] : 0;
			$hasilLainAkhir[] = isset($dataNilai[$value->id . '_lain']) ? $dataNilai[$value->id . '_lain'] : 0;
			$hasilbelumAkhir[] = isset($dataNilai[$value->id . '_belum']) ? $dataNilai[$value->id . '_belum'] : 0;
			$data 		= $value->name;
			$new_data[] 				= $data;
		}

		$dataFix = [
			['name' => 'Pdam', 'data' => $hasilPdamAkhir],
			['name' => 'Non Pdam', 'data' => $hasilNonPdamAkhir],
			['name' => 'lain - Lain', 'data' => $hasilLainAkhir],
			['name' => 'Belum Terjangkau', 'data' => $hasilbelumAkhir],
		];

		$json_data = array(
                    "kecamatan"            			=> $new_data,
                    "dataCakupanAirBersih"          => $dataFix
                    );
		echo json_encode($json_data);
	}

	public function cakupan_air_bersih_kecamatan_detail($kecamatan)
	{
		$getKecId = $this->wilayah_model->getKecamatan(['name'=>$kecamatan]);
		$kecId = $getKecId[0]->id;
	// desa berdasarkan kecamatan
		$desa =  $this->wilayah_model->getDesa(['district_id'=>$kecId]);

	// get data penduduk kecamatan
		$getPendudukDesa = $this->profil_daerah_model->getAllByIdDesa();
	//dataPDAM
		$pdam = [];
		$wherePdam['desa_id_dp !='] =NULL;
		$wherePdam['jumlah_sr !='] =NULL;
		$wherePdam['kecamatan_id'] =$kecId;
		$jumlahSrPdam			= $this->data_pelayanan_model->getCountByDesa($wherePdam);
		$data = [];
		if($jumlahSrPdam != FALSE){
			foreach ($jumlahSrPdam as $key => $value) {
				$hasilPdam = $value->jumlah_sr * 4;
				$pdam[] =['desa_id'=>$value->desa_id_dp,'pdam'=> $hasilPdam];
				$data[$value->desa_id_dp] = [ "desa_id" => $value->desa_id_dp, 'pdam' => $hasilPdam, 'belum' => $hasilPdam];
			}
		}
	// data Non PDAM 
		$nonPdam = [];
		$whereNonPdam['id_kec'] = $kecId;
		$jumlahSrNonPdam			= $this->kelola_jaringan_desa_model->countSrByDesa($whereNonPdam);
		
		if ($jumlahSrNonPdam != FALSE) {
			foreach ($jumlahSrNonPdam as $key => $value) {
				$hasilNonPdam = $value->sambunganRumah * 4;
				$nonPdam[] =['desa_id'=>$value->id_desa,'nonPdam'=> $hasilNonPdam];
				$data[$value->id_desa]['belum'] = $data[$value->id_desa]['belum'] +  $hasilNonPdam;
				$data[$value->id_desa]['nonPdam'] = $hasilNonPdam;
			}
		}
	// data lain lain
		$whereBjp['id_kec'] = $kecId;
		$whereBjp['sambungan_rumah !='] = NULL;
		$whereBjp['id_desa !='] = NULL;
		$lainLain = [];
		$jumlahSrBjp			= $this->kelola_bjp_model->countSrByDesa($whereBjp);
		if ($jumlahSrBjp != FALSE) {
			foreach ($jumlahSrBjp as $key => $value) {
				$hasilLain = $value->sambungan_rumah * 4;
				$lainLain[] =['desa_id'=>$value->id_desa,'lain'=> $hasilLain];
				$data[$value->id_desa]['belum'] = $data[$value->id_desa]['belum'] +  $hasilLain;
				$data[$value->id_desa]['lain'] = $hasilLain;
			}
		}
			foreach ($getPendudukDesa as $key => $value) {
				if (in_array($value->desa_id, array_keys($data))) {
					$data[$value->desa_id]['belum'] = $value->jumlah_penduduk - $data[$value->desa_id]['belum'];
				}
			}
		
		// $dataDummy = [
		// 	['id_desa' => 3204011, 'kurang' => '10', 'baik' => 20, 'cukup' => '100', 'belum' => '200' ],
		// ];

		$dataNilai = [];
		foreach ($data as $key => $value)
		{
			$dataNilai[$value['desa_id'].'_pdam'] = (int) $value['pdam'];
			if (!empty($value['nonPdam'])) {
				$dataNilai[$value['desa_id'].'_nonPdam'] = (int) $value['nonPdam'];
			}
			if (!empty($value['lain'])) {
				$dataNilai[$value['desa_id'].'_lain'] = (int) $value['lain'];
			}
			$dataNilai[$value['desa_id'].'_belum'] = (int) $value['belum'];
		}
		// create array hasil akhir
		$hasilPdamAkhir=[];
		$hasilNonPdamAkhir=[];
		$hasilLainAkhir=[];
		$hasilbelumAkhir=[];
		
		foreach ($desa as $key => $value)
		{
			$hasilPdamAkhir[] = isset($dataNilai[$value->id . '_pdam']) ? $dataNilai[$value->id . '_pdam'] : 0;
			$hasilNonPdamAkhir[] = isset($dataNilai[$value->id . '_nonPdam']) ? $dataNilai[$value->id . '_nonPdam'] : 0;
			$hasilLainAkhir[] = isset($dataNilai[$value->id . '_lain']) ? $dataNilai[$value->id . '_lain'] : 0;
			$hasilbelumAkhir[] = isset($dataNilai[$value->id . '_belum']) ? $dataNilai[$value->id . '_belum'] : 0;
			$data 		= $value->name;
			$new_data[] 				= $data;
		}

		$dataFix = [
			['name' => 'Pdam', 'data' => $hasilPdamAkhir],
			['name' => 'Non Pdam', 'data' => $hasilNonPdamAkhir],
			['name' => 'lain - Lain', 'data' => $hasilLainAkhir],
			['name' => 'Belum Terjangkau', 'data' => $hasilbelumAkhir],
		];

		$json_data = array(
                    "desa"            				=> $new_data,
                    "dataCakupanAirBersihDetail"    => $dataFix
                    );
		echo json_encode($json_data);
	}
}
