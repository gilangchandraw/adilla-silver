<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Stok_barang extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('histori_stok_barang_model');
		$this->load->model('cabang_model');
	}

	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$this->data['data_cabang'] = $this->cabang_model->getAllById();
			if ($this->data['users_groups']->id == 4) {
				$where['cabang.users_id'] = $this->data['users']->id;
				$this->data['cabang'] = $this->cabang_model->getOneBy($where);
			}
			$this->data['content'] = 'admin/stok_barang/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
		);

		$where = array();
		if ($this->data['users_groups']->id == 4) {
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
			$where['cabang_id'] = $cabang->id;
		}

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->histori_stok_barang_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		$searchColumn = $this->input->post('columns');
		$isSearchColumn = false;

		if (!empty($searchColumn[0]['search']['value'])) {
			$value = $searchColumn[0]['search']['value'];
			$isSearchColumn = true;
			$where['histori_stok_barang.tanggal'] = $value;
		}
		if (!empty($searchColumn[1]['search']['value'])) {
			$value = $searchColumn[1]['search']['value'];
			$isSearchColumn = true;
			$where['histori_stok_barang.cabang_id'] = $value;
		}

		if ($isSearchColumn) {
			$totalFiltered = $this->histori_stok_barang_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
			$totalData = $totalFiltered;
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->histori_stok_barang_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$nestedData['id'] = $start + $key + 1;

				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['cabang'] = $data->cabang_id;
				// 925
				$nestedData['stok_925_awal'] = $data->stok_925_awal;
				$nestedData['stok_925_penjualan'] = $data->stok_925_penjualan;
				$nestedData['stok_925_kembali'] = $data->stok_925_kembali;
				$nestedData['total_stok_925'] = $data->total_stok_925;
				$nestedData['stok_925_akhir'] = $data->stok_925_akhir;
				// sp
				$nestedData['stok_sp_awal'] = $data->stok_sp_awal;
				$nestedData['stok_sp_penjualan'] = $data->stok_sp_penjualan;
				$nestedData['stok_sp_kembali'] = $data->stok_sp_kembali;
				$nestedData['total_stok_sp'] = $data->total_stok_sp;
				$nestedData['stok_sp_akhir'] = $data->stok_sp_akhir;
				//retur dan reparasi
				$nestedData['stok_925_reparasi'] = $data->stok_925_reparasi;
				$nestedData['stok_925_retur'] = $data->stok_925_retur;
				$nestedData['stok_sp_reparasi'] = $data->stok_sp_reparasi;
				$nestedData['stok_sp_retur'] = $data->stok_sp_retur;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}
}
