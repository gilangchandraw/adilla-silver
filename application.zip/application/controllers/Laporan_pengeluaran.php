<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Laporan_pengeluaran extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('cabang_model');
		$this->load->model('pengeluaran_model');
		$this->load->model('pengeluaran_detail_model');
		
	}

	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$this->data['cabang'] = $this->cabang_model->getAllById();
			$this->data['content'] = 'admin/laporan_pengeluaran/create_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function get_data()
	{
		// / get data cabang untuk kasir
		$cabang_id = $this->input->get('cabang_id');
		$tanggal = $this->input->get('tanggal');
		
		$data_cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
		if ($this->data['users_groups']->id == 4) {
			$cabang_id = $data_cabang->id;
		}
		if ($this->data['users_groups']->id != 4) {
			$data_cabang = $this->cabang_model->getOneBy(['cabang.id' => $cabang_id]);
		}
		$tanggal = explode('-', $tanggal);
		$bulan = $tanggal[0];
		$tahun = $tanggal[1];

		$no_bulan = $bulan;
		if ($bulan < 10) {
			$no_bulan = explode(0, $bulan);
			$no_bulan = $no_bulan[1];
		}
		// inisialisasi nama bulan
		if ($no_bulan == 1) {
			$nama_no_bulan = 'Januari';
		}elseif ($no_bulan == 2) {
			$nama_bulan = 'Februari';
		}elseif ($no_bulan == 3) {
			$nama_bulan = 'Maret';
		}elseif ($no_bulan == 4) {
			$nama_bulan = 'April';
		}elseif ($no_bulan == 5) {
			$nama_bulan = 'Mei';
		}elseif ($no_bulan == 6) {
			$nama_bulan = 'Juni';
		}elseif ($no_bulan == 7) {
			$nama_bulan = 'Juli';
		}elseif ($no_bulan == 8) {
			$nama_bulan = 'Agustus';
		}elseif ($no_bulan == 9) {
			$nama_bulan = 'September';
		}elseif ($no_bulan == 10) {
			$nama_bulan = 'Oktober';
		}elseif ($no_bulan == 11) {
			$nama_bulan = 'November';
		}elseif ($no_bulan == 12) {
			$nama_bulan = 'Desember';
		}

		$where['MONTH(pengeluaran.tanggal)'] = $bulan;
		$where['YEAR(pengeluaran.tanggal)'] = $tahun;
		$where['pengeluaran.cabang_id'] = $cabang_id;
		// untuk cabang
		if ($this->data['users_groups']->id == 4) {
			$where['pengeluaran.cabang_id'] = $cabang_id;
		}
		$where['pengeluaran.is_deleted'] = 0;
		$pengeluaran = $this->pengeluaran_model->getAllById($where);
		$data_pengeluaran_detail = [];
		if (!empty($pengeluaran)) {
			foreach ($pengeluaran as $key => $value) {
				$where_detail['pengeluaran_detail.pengeluaran_id'] = $value->id;
					$pengeluaran_detail = $this->pengeluaran_detail_model->getAllById($where_detail);
					if (!empty($pengeluaran_detail)) {
						$jumlah_pengeluaran_1 = 0;
						$jumlah_pengeluaran_2 = 0;
						$jumlah_pengeluaran_5 = 0;
						$jumlah_pengeluaran_4 = 0;
						$jumlah_pengeluaran_7 = 0;
						$jumlah_pengeluaran_11 = 0;
						$jumlah_pengeluaran_12 = 0;
						$jumlah_pengeluaran_10 = 0;
						foreach ($pengeluaran_detail as $key_detail => $value_detail) {
							if ($value_detail->enum_pengeluaran_id == 1) {
								$jumlah_pengeluaran_1 += $value_detail->harga;
							}elseif ($value_detail->enum_pengeluaran_id == 2) {
								$jumlah_pengeluaran_2 += $value_detail->harga;
							}elseif ($value_detail->enum_pengeluaran_id == 3) {
								$jumlah_pengeluaran_10 += $value_detail->harga;
							}elseif ($value_detail->enum_pengeluaran_id == 5) {
								$jumlah_pengeluaran_5 += $value_detail->harga;
							}elseif ($value_detail->enum_pengeluaran_id == 7) {
								$jumlah_pengeluaran_7 += $value_detail->harga;
							}elseif ($value_detail->enum_pengeluaran_id == 4) {
								$jumlah_pengeluaran_4 += $value_detail->harga;
							}elseif ($value_detail->enum_pengeluaran_id == 11) {
								$jumlah_pengeluaran_11 += $value_detail->harga;
							}elseif ($value_detail->enum_pengeluaran_id == 12) {
								$jumlah_pengeluaran_12 += $value_detail->harga;
							}elseif ($value_detail->enum_pengeluaran_id == 10) {
								$jumlah_pengeluaran_10 += $value_detail->harga;
							}elseif ($value_detail->enum_pengeluaran_id == 6) {
								$jumlah_pengeluaran_10 += $value_detail->harga;
							}elseif ($value_detail->enum_pengeluaran_id == 8) {
								$jumlah_pengeluaran_10 += $value_detail->harga;
							}elseif ($value_detail->enum_pengeluaran_id == 9) {
								$jumlah_pengeluaran_10 += $value_detail->harga;
							}							
						}
						$obj =  new stdClass();
		                $obj->tanggal = $value->tanggal;
		                $obj->jumlah_pengeluaran_1 = $jumlah_pengeluaran_1;
						$obj->jumlah_pengeluaran_2 = $jumlah_pengeluaran_2;
						$obj->jumlah_pengeluaran_5 = $jumlah_pengeluaran_5;
						$obj->jumlah_pengeluaran_7 = $jumlah_pengeluaran_7;
						$obj->jumlah_pengeluaran_4 = $jumlah_pengeluaran_4;
						$obj->jumlah_pengeluaran_11 = $jumlah_pengeluaran_11;
						$obj->jumlah_pengeluaran_12 = $jumlah_pengeluaran_12;
						$obj->jumlah_pengeluaran_10 = $jumlah_pengeluaran_10;
		    			array_push($data_pengeluaran_detail, $obj);
					}
			}

			$days_in_month = cal_days_in_month(CAL_GREGORIAN,$no_bulan,$tahun);
			$result = [];

			for ($i=1; $i <= $days_in_month; $i++) {
				if ($i <10) {
	                $i = '0'.$i;
	            }
	            $date = $tahun.'-'.$bulan.'-'.$i;
	            $object_data =  new stdClass();
                $object_data->tanggal = $date;
                $object_data->jumlah_pengeluaran_1 = '';
				$object_data->jumlah_pengeluaran_2 = '';
				$object_data->jumlah_pengeluaran_5 = '';
				$object_data->jumlah_pengeluaran_7 = '';
				$object_data->jumlah_pengeluaran_4 = '';
				$object_data->jumlah_pengeluaran_11 = '';
				$object_data->jumlah_pengeluaran_12 = '';
				$object_data->jumlah_pengeluaran_10 = '';
                
                if (!empty($data_pengeluaran_detail)) {
	            	foreach ($data_pengeluaran_detail as $key => $value) {
	            		if ($value->tanggal == $date) {
	            			$object_data->tanggal = $value->tanggal;
			                $object_data->jumlah_pengeluaran_1 = number_format($value->jumlah_pengeluaran_1);
							$object_data->jumlah_pengeluaran_2 = number_format($value->jumlah_pengeluaran_2);
							$object_data->jumlah_pengeluaran_5 = number_format($value->jumlah_pengeluaran_5);
							$object_data->jumlah_pengeluaran_7 = number_format($value->jumlah_pengeluaran_7);
							$object_data->jumlah_pengeluaran_4 = number_format($value->jumlah_pengeluaran_4);
							$object_data->jumlah_pengeluaran_11 = number_format($value->jumlah_pengeluaran_11);
							$object_data->jumlah_pengeluaran_12 = number_format($value->jumlah_pengeluaran_12);
							$object_data->jumlah_pengeluaran_10 = number_format($value->jumlah_pengeluaran_10);
	            		}
	            		
	            	}
                		array_push($result, $object_data);
	            }
			}
			
			$data['status'] = true;
			$data['cabang'] = $data_cabang->nama_cabang;
			$data['bulan'] = $nama_bulan;

			//pengeluaran
			$data['pengeluaran'] = $result;
		} else {
			$data['status'] = false;
		}
		
		echo json_encode($data);
	}

	public function print_pdf()
	{
		// / get data cabang untuk kasir
		$cabang_id = $this->input->get('cabang_id');
		$tanggal = $this->input->get('tanggal');
		
		$data_cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
		if ($this->data['users_groups']->id == 4) {
			$cabang_id = $data_cabang->id;
		}
		if ($this->data['users_groups']->id != 4) {
			$data_cabang = $this->cabang_model->getOneBy(['cabang.id' => $cabang_id]);
		}
		$tanggal = explode('-', $tanggal);
		$bulan = $tanggal[0];
		$tahun = $tanggal[1];
		$no_bulan = $bulan;
		if ($bulan < 10) {
			$no_bulan = explode(0, $bulan);
			$no_bulan = $no_bulan[1];
		}
		// inisialisasi nama bulan
		if ($no_bulan == 1) {
			$nama_no_bulan = 'Januari';
		}elseif ($no_bulan == 2) {
			$nama_bulan = 'Februari';
		}elseif ($no_bulan == 3) {
			$nama_bulan = 'Maret';
		}elseif ($no_bulan == 4) {
			$nama_bulan = 'April';
		}elseif ($no_bulan == 5) {
			$nama_bulan = 'Mei';
		}elseif ($no_bulan == 6) {
			$nama_bulan = 'Juni';
		}elseif ($no_bulan == 7) {
			$nama_bulan = 'Juli';
		}elseif ($no_bulan == 8) {
			$nama_bulan = 'Agustus';
		}elseif ($no_bulan == 9) {
			$nama_bulan = 'September';
		}elseif ($no_bulan == 10) {
			$nama_bulan = 'Oktober';
		}elseif ($no_bulan == 11) {
			$nama_bulan = 'November';
		}elseif ($no_bulan == 12) {
			$nama_bulan = 'Desember';
		}

		$where['MONTH(pengeluaran.tanggal)'] = $bulan;
		$where['YEAR(pengeluaran.tanggal)'] = $tahun;
		$where['pengeluaran.cabang_id'] = $cabang_id;
		// untuk cabang
		if ($this->data['users_groups']->id == 4) {
			$where['pengeluaran.cabang_id'] = $cabang_id;
		}
		$where['pengeluaran.is_deleted'] = 0;
		$pengeluaran = $this->pengeluaran_model->getAllById($where);
		$data_pengeluaran_detail = [];
		if (!empty($pengeluaran)) {
			foreach ($pengeluaran as $key => $value) {
				$where_detail['pengeluaran_detail.pengeluaran_id'] = $value->id;
					$pengeluaran_detail = $this->pengeluaran_detail_model->getAllById($where_detail);
					if (!empty($pengeluaran_detail)) {
						$jumlah_pengeluaran_1 = 0;
						$jumlah_pengeluaran_2 = 0;
						$jumlah_pengeluaran_5 = 0;
						$jumlah_pengeluaran_7 = 0;
						$jumlah_pengeluaran_4 = 0;
						$jumlah_pengeluaran_11 = 0;
						$jumlah_pengeluaran_12 = 0;
						$jumlah_pengeluaran_10 = 0;
						foreach ($pengeluaran_detail as $key_detail => $value_detail) {
							if ($value_detail->enum_pengeluaran_id == 1) {
								$jumlah_pengeluaran_1 += $value_detail->harga;
							}elseif ($value_detail->enum_pengeluaran_id == 2) {
								$jumlah_pengeluaran_2 += $value_detail->harga;
							}elseif ($value_detail->enum_pengeluaran_id == 3) {
								$jumlah_pengeluaran_10 += $value_detail->harga;
							}elseif ($value_detail->enum_pengeluaran_id == 5) {
								$jumlah_pengeluaran_5 += $value_detail->harga;
							}elseif ($value_detail->enum_pengeluaran_id == 7) {
								$jumlah_pengeluaran_7 += $value_detail->harga;
							}elseif ($value_detail->enum_pengeluaran_id == 4) {
								$jumlah_pengeluaran_4 += $value_detail->harga;
							}elseif ($value_detail->enum_pengeluaran_id == 11) {
								$jumlah_pengeluaran_11 += $value_detail->harga;
							}elseif ($value_detail->enum_pengeluaran_id == 12) {
								$jumlah_pengeluaran_12 += $value_detail->harga;
							}elseif ($value_detail->enum_pengeluaran_id == 10) {
								$jumlah_pengeluaran_10 += $value_detail->harga;
							}elseif ($value_detail->enum_pengeluaran_id == 6) {
								$jumlah_pengeluaran_10 += $value_detail->harga;
							}elseif ($value_detail->enum_pengeluaran_id == 8) {
								$jumlah_pengeluaran_10 += $value_detail->harga;
							}elseif ($value_detail->enum_pengeluaran_id == 9) {
								$jumlah_pengeluaran_10 += $value_detail->harga;
							}							
						}
						$obj =  new stdClass();
		                $obj->tanggal = $value->tanggal;
		                $obj->jumlah_pengeluaran_1 = $jumlah_pengeluaran_1;
						$obj->jumlah_pengeluaran_2 = $jumlah_pengeluaran_2;
						$obj->jumlah_pengeluaran_5 = $jumlah_pengeluaran_5;
						$obj->jumlah_pengeluaran_7 = $jumlah_pengeluaran_7;
						$obj->jumlah_pengeluaran_4 = $jumlah_pengeluaran_4;
						$obj->jumlah_pengeluaran_11 = $jumlah_pengeluaran_11;
						$obj->jumlah_pengeluaran_12 = $jumlah_pengeluaran_12;
						$obj->jumlah_pengeluaran_10 = $jumlah_pengeluaran_10;
		    			array_push($data_pengeluaran_detail, $obj);
					}
			}

			$days_in_month = cal_days_in_month(CAL_GREGORIAN,$no_bulan,$tahun);
			$result = [];

			for ($i=1; $i <= $days_in_month; $i++) {
				if ($i <10) {
	                $i = '0'.$i;
	            }
	            $date = $tahun.'-'.$bulan.'-'.$i;
	            $object_data =  new stdClass();
                $object_data->tanggal = $date;
                $object_data->jumlah_pengeluaran_1 = '';
				$object_data->jumlah_pengeluaran_2 = '';
				$object_data->jumlah_pengeluaran_5 = '';
				$object_data->jumlah_pengeluaran_7 = '';
				$object_data->jumlah_pengeluaran_4 = '';
				$object_data->jumlah_pengeluaran_11 = '';
				$object_data->jumlah_pengeluaran_12 = '';
				$object_data->jumlah_pengeluaran_10 = '';
                
                if (!empty($data_pengeluaran_detail)) {
	            	foreach ($data_pengeluaran_detail as $key => $value) {
	            		if ($value->tanggal == $date) {
	            			$object_data->tanggal = $value->tanggal;
			                $object_data->jumlah_pengeluaran_1 = number_format($value->jumlah_pengeluaran_1);
							$object_data->jumlah_pengeluaran_2 = number_format($value->jumlah_pengeluaran_2);
							$object_data->jumlah_pengeluaran_5 = number_format($value->jumlah_pengeluaran_5);
							$object_data->jumlah_pengeluaran_7 = number_format($value->jumlah_pengeluaran_7);
							$object_data->jumlah_pengeluaran_4 = number_format($value->jumlah_pengeluaran_4);
							$object_data->jumlah_pengeluaran_11 = number_format($value->jumlah_pengeluaran_11);
							$object_data->jumlah_pengeluaran_12 = number_format($value->jumlah_pengeluaran_12);
							$object_data->jumlah_pengeluaran_10 = number_format($value->jumlah_pengeluaran_10);
	            		}
	            		
	            	}
                		array_push($result, $object_data);
	            }
			}
			
			$data['status'] = true;
			$data['cabang'] = $data_cabang->nama_cabang;
			$data['bulan'] = $nama_bulan;

			//pengeluaran
			$data['pengeluaran'] = $result;

			require_once BASEPATH. 'vendor/autoload.php';
	        // $mpdf = new \Mpdf\Mpdf(['mode' => 'utf-8', 'format' => [216, 350]]);
	        $mpdf = new \Mpdf\Mpdf(['orientation' => 'L']);
	        $html = $this->load->view('admin/laporan_pengeluaran/print_v',$data,TRUE);
	        // print_r($html);
	        // die();
	        $mpdf->WriteHTML($html);
	        $mpdf->Output("laporan-pengeluaran-".$nama_bulan.'-'.time().".pdf","I");
		} else {
			$data['status'] = false;
		}
		
		echo json_encode($data);
	}

	
}
