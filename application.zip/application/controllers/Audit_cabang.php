<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Audit_cabang extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('audit_cabang_model');
		$this->load->model('cabang_model');
	}

	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$this->data['cabang'] = $this->cabang_model->getAllById(['cabang.is_deleted' => 0]);
			$this->data['content'] = 'admin/audit_cabang/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function create()
	{
		$this->form_validation->set_rules('tanggal_awal', "tanggal_awal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$uang_setor = $this->input->post('uang_setor');
			$uang_potongan = $this->input->post('uang_potongan');
			$total = $this->input->post('total');
			$dll = $this->input->post('dll');
			$uang_kantor = $this->input->post('uang_kantor');
			$k_toko = $this->input->post('k_toko');
			$krw_uda = $this->input->post('krw_uda');
			$cabang_id = $this->input->post('cabang_id');
			$tanggal_akhir = $this->input->post('tanggal_akhir');
			$tanggal_awal = $this->input->post('tanggal_awal');
			$tanggal = $this->input->post('tanggal');
			$uang_bayar_barang = $this->input->post('uang_bayar_barang');
			$uang_kotak_cincin = $this->input->post('uang_kotak_cincin');
			$uang_mobil = $this->input->post('uang_mobil');

			$data = array(
				'users_id' => $this->data['users']->id,
				'tanggal' => $tanggal,
				'tanggal_awal' => $tanggal_awal,
				'tanggal_akhir' => $tanggal_akhir,
				'cabang_id' => $cabang_id,
				'krw_uda' => $krw_uda,
				'k_toko' => $k_toko,
				'uang_kantor' => $uang_kantor,
				'dll' => $dll,
				'total' => $total,
				'uang_potongan' => $uang_potongan,
				'uang_setor' => $uang_setor,
				'uang_mobil' => $uang_mobil,
				'uang_kotak_cincin' => $uang_kotak_cincin,
				'uang_bayar_barang' => $uang_bayar_barang,
				'uang_setor' => $uang_setor,
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			$insert = $this->audit_cabang_model->insert($data);
			
			if ($insert) {
				$this->session->set_flashdata('message', "Data Audit cabang Baru Berhasil Disimpan");
				redirect("audit_cabang");
			} else {
				$this->session->set_flashdata('message_error', "Data Audit cabang Baru Gagal Disimpan");
				redirect("audit_cabang");
			}
		} else {
			if ($this->data['is_can_create']) {
				$this->data['cabang'] = $this->cabang_model->getAllById(['cabang.is_deleted' => 0]);
				$this->data['content'] = 'admin/audit_cabang/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function edit()
	{
		$this->form_validation->set_rules('tanggal_awal', "tanggal_awal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$id = $this->input->post('id');
			$uang_setor = $this->input->post('uang_setor');
			$uang_potongan = $this->input->post('uang_potongan');
			$total = $this->input->post('total');
			$dll = $this->input->post('dll');
			$uang_kantor = $this->input->post('uang_kantor');
			$k_toko = $this->input->post('k_toko');
			$krw_uda = $this->input->post('krw_uda');
			$cabang_id = $this->input->post('cabang_id');
			$tanggal_akhir = $this->input->post('tanggal_akhir');
			$tanggal_awal = $this->input->post('tanggal_awal');
			$tanggal = $this->input->post('tanggal');
			$uang_bayar_barang = $this->input->post('uang_bayar_barang');
			$uang_kotak_cincin = $this->input->post('uang_kotak_cincin');
			$uang_mobil = $this->input->post('uang_mobil');

			$data = array(
				'tanggal_awal' => $tanggal_awal,
				'tanggal_akhir' => $tanggal_akhir,
				'cabang_id' => $cabang_id,
				'krw_uda' => $krw_uda,
				'k_toko' => $k_toko,
				'uang_kantor' => $uang_kantor,
				'dll' => $dll,
				'total' => $total,
				'uang_potongan' => $uang_potongan,
				'uang_setor' => $uang_setor,
				'uang_mobil' => $uang_mobil,
				'uang_kotak_cincin' => $uang_kotak_cincin,
				'uang_bayar_barang' => $uang_bayar_barang,
				'updated_by' => $this->data['users']->id
			);
			$update = $this->audit_cabang_model->update($data, array("id" => $id));
			if ($update) {
				$this->session->set_flashdata('message', "Data audit cabang Berhasil Diedit");
				redirect("audit_cabang");
			} else {
				$this->session->set_flashdata('message_error', "Data audit cabang Gagal Diedit");
				redirect("audit_cabang");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("audit_cabang/edit/" . $id);
			} else {
				if ($this->data['is_can_edit']) {
					$this->data['id'] = $this->uri->segment(3);
					$this->data['cabang'] = $this->cabang_model->getAllById(['cabang.is_deleted' => 0]);
					$this->data['audit'] = $this->audit_cabang_model->getOneBy(array("audit_cabang.id" => $this->data['id']));
					$this->data['content'] = 'admin/audit_cabang/edit_v';
				} else {
					$this->data['content']  = 'errors/html/restrict';
				}
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}
	public function detail()
	{

		$this->data['id'] = $this->uri->segment(3);
		$this->data['cabang'] = $this->cabang_model->getAllById(['cabang.is_deleted' => 0]);
		$this->data['audit'] = $this->audit_cabang_model->getOneBy(['audit_cabang.id' => $this->data['id']]);
		$this->data['content'] = 'admin/audit_cabang/detail_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
			1 => 'audit_cabang.kode_audit_cabang',
			2 => 'audit_cabang.nama_audit_cabang',
			3 => 'audit_cabang.alamat',
			4 => 'action'
		);

		$where = array();
		// if(!$this->data['is_superadmin']){
		// 	$where['audit_cabang.office_id'] = $this->data['users']->office_id;
		// }

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->audit_cabang_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		$searchColumn = $this->input->post('columns');
        $isSearchColumn = false;

        if(!empty($searchColumn[0]['search']['value'])){
            $value = $searchColumn[0]['search']['value'];
            $isSearchColumn = true;
            $where['audit_cabang.tanggal'] = $value;
        }
        if(!empty($searchColumn[1]['search']['value'])){
            $value = $searchColumn[1]['search']['value'];
            $isSearchColumn = true;
            $where['audit_cabang.cabang_id'] = $value;
        }
        if($isSearchColumn){
			$totalFiltered = $this->audit_cabang_model->getCountAllBy($limit,$start,$search,$order,$dir,$where); 
			$totalData = $totalFiltered;
        }else{
        	$totalFiltered = $totalData;
        }

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->audit_cabang_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$detail_url = "";
				$edit_url = "";
				// $print_url = "";
				if ($data->is_deleted == 0) {
					// $edit_url = "<a href='".base_url()."audit_cabang/edit/".$data->id."' class='btn btn-sm btn-info'>Ubah</a>";
						$edit_url = "<a href='" . base_url() . "audit_cabang/edit/" . $data->id . "' class='btn btn-sm btn-warning' data-toggle='tooltip' title='Edit Data' data-placement='bottom'><i class='fa fa-edit fa-w-20'></i></a>";
					$detail_url = "<a href='" . base_url() . "audit_cabang/detail/" . $data->id . "' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";
				}
				$nestedData['id'] = $start + $key + 1;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['tanggal_awal'] = $data->tanggal_awal;
				$nestedData['tanggal_akhir'] = $data->tanggal_akhir;
				$nestedData['cabang'] = $data->nama_cabang;
				// $nestedData['action'] = $detail_url . " " . $print_url.' '.$edit_url;
				$nestedData['action'] = $detail_url . " ".$edit_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function destroy()
	{
		$response_data = array();
		$response_data['status'] = false;
		$response_data['msg'] = "";
		$response_data['data'] = array();

		$id = $this->uri->segment(3);
		$is_deleted = $this->uri->segment(4);
		if (!empty($id)) {
			$this->load->model("audit_cabang_model");
			$data = array(
				'is_deleted' => ($is_deleted == 1) ? 0 : 1
			);
			$update = $this->audit_cabang_model->update($data, array("id" => $id));

			$response_data['data'] = $data;
			$response_data['status'] = true;
		} else {
			$response_data['msg'] = "ID Harus Diisi";
		}

		echo json_encode($response_data);
	}

	public function get_data_audit_cabang()
	{

		$audit_cabang_id = $this->input->get('audit_cabang_id');
		$where['audit_cabang.id'] = $audit_cabang_id;
		$audit_cabang = $this->audit_cabang_model->getOneBy($where);
		if ($audit_cabang) {
			$data['status'] = true;
			$data['stok_retur_bk_925'] = $audit_cabang->stok_retur_bk_925;
			$data['stok_retur_pajang_925'] = $audit_cabang->stok_retur_pajang_925;
			$data['stok_retur_bk_sp'] = $audit_cabang->stok_retur_bk_sp;
			$data['stok_retur_pajang_sp'] = $audit_cabang->stok_retur_pajang_sp;
		} else {
			$data['status'] = false;
		}
		echo json_encode($data);
	}
}
