<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH.'core/Admin_Controller.php';
class Insentif extends Admin_Controller {
 	public function __construct()
	{
		parent::__construct(); 
	 	$this->load->model('insentif_model');
	 	$this->load->model('insentif_detail_model');
	 	$this->load->model('cabang_model');
	 	$this->load->model('data_karyawan_model');
	 	$this->load->model('barang_model');
	 	$this->load->model('enum_transaksi_barang_model');
	 	$this->load->model('nota_model');
	 	$this->load->model('histori_kas_model');
	 	$this->load->model('histori_stok_barang_model');
	}

	public function index()
	{
		$this->load->helper('url');
		if($this->data['is_can_read']){
			$cek_insert = true;
			$this->data['data_cabang'] = $this->cabang_model->getAllById(); 	
			if($this->data['users_groups']->id == 4){
				$where['cabang.users_id'] = $this->data['users']->id;
				$this->data['cabang'] = $this->cabang_model->getOneBy($where); 	
				$where_cek['insentif.tanggal'] = date('Y-m-d');
				$where_cek['insentif.cabang_id'] = $this->data['cabang']->id;
				$cek_insert = $this->insentif_model->getOneBy($where_cek);
			}

			$this->data['cek_insert'] = $cek_insert ? 1 : 0;
			
			$this->data['content'] = 'admin/insentif/list_v'; 	
		}else{
			$this->data['content'] = 'errors/html/restrict'; 
		}
		
		$this->load->view('admin/layouts/page',$this->data);  
	}

	public function create()
	{ 
		$this->form_validation->set_rules('tanggal',"tanggal Is Required", 'trim|required');
		 
		if ($this->form_validation->run() === TRUE)
		{ 
			$tanggal = $this->input->post('tanggal');
			$karyawan_id = $this->input->post('karyawan_id');
			$huruf_nota = $this->input->post('huruf_nota');
			$no_nota_awal = $this->input->post('no_nota_awal');
			$no_nota_akhir = $this->input->post('no_nota_akhir');
			$jumlah_nota = $this->input->post('jumlah_nota');
			$no_nota_batal = $this->input->post('no_nota_batal');
			$jumlah_nota_batal = $this->input->post('jumlah_nota_batal');
			$berat = $this->input->post('berat');
			$harga = $this->input->post('harga');
			// $harga = $harga * 4000;
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
			//master insentif
			$data_insentif = array(
				'users_id' => $this->data['users']->id,
				'cabang_id' => $cabang->id,
				'tanggal' => $tanggal,
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			); 
			$insert_insentif = $this->insentif_model->insert($data_insentif);
			// get data kemarin
			$tanggal_kemarin = date('Y-m-d', strtotime('-1 days'));

			// $where_kemarin['tanggal'] = $tanggal_kemarin;
			// $where_kemarin['karyawan_id'] = $karyawan_id;
			// $where_kemarin['huruf_nota'] = $huruf_nota;
			// $data_kemarin = $this->insentif_detail_model->getOneBy($where_kemarin);
			// if ($data_kemarin != false) {
			// 	$total_berat = $data_kemarin->total_berat + $berat;
			// 	$total_harga = $data_kemarin->total_harga + $harga;
			// 	// $total_harga = $data_kemarin->total_harga + ($harga * 0.004);
			// } else {
			// 	$total_berat = $berat;
			// 	// $total_harga = $harga * 0.004;
			// 	$total_harga = $harga;
			// }
			//detail insentif
			$data_insentif = array(
				'insentif_id' => $insert_insentif,
				'tanggal' => $tanggal,
				'karyawan_id' => $karyawan_id,
				'huruf_nota' => $huruf_nota,
				'no_nota_awal' => $no_nota_awal,
				'no_nota_akhir' => $no_nota_akhir,
				'jumlah_nota' => $jumlah_nota,
				'no_nota_batal' => $no_nota_batal,
				'jumlah_nota_batal' => $jumlah_nota_batal,
				'berat' => $berat,
				// 'total_berat' => $total_berat,
				'harga' => $harga,
				// 'total_harga' => $total_harga,
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			); 
			$insert_insentif_detail = $this->insentif_detail_model->insert($data_insentif);
			if ($insert_insentif_detail)
			{ 
				$this->session->set_flashdata('message', "Data insentif Baru Berhasil Disimpan");
				redirect("insentif/create_more/".$insert_insentif);
			}
			else
			{
				$this->session->set_flashdata('message_error',"Data insentif Baru Gagal Disimpan");
				redirect("insentif");
			}
		}else{  
			if($this->data['is_can_create']){  
				$where['data_karyawan.is_deleted'] = 0;
				$where['data_karyawan.users_id'] = $this->data['users']->id;
				$this->data['karyawan'] = $this->data_karyawan_model->getAllById($where); 
				$this->data['content'] = 'admin/insentif/create_v'; 
	        }else{
	            $this->data['content']  = 'errors/html/restrict'; 
	        } 
	        $this->load->view('admin/layouts/page',$this->data);
		}
	} 

	public function create_more($id)
	{ 
		$this->form_validation->set_rules('insentif_id', "insentif_id Is Required", 'trim|required'); 
		   
		if ($this->form_validation->run() === TRUE)
		{
		 	$insentif_id = $this->input->post('insentif_id');
		 	$tanggal = $this->input->post('tanggal');
			$karyawan_id = $this->input->post('karyawan_id');
			$huruf_nota = $this->input->post('huruf_nota');
			$no_nota_awal = $this->input->post('no_nota_awal');
			$no_nota_akhir = $this->input->post('no_nota_akhir');
			$jumlah_nota = $this->input->post('jumlah_nota');
			$no_nota_batal = $this->input->post('no_nota_batal');
			$jumlah_nota_batal = $this->input->post('jumlah_nota_batal');
			$berat = $this->input->post('berat');
			$harga = $this->input->post('harga');
			// $harga = $harga * 4000;
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
			
			// // get data kemarin
			// $tanggal_kemarin = date('Y-m-d', strtotime('-1 days'));
			// $where_kemarin['tanggal'] = $tanggal_kemarin;
			// $where_kemarin['karyawan_id'] = $karyawan_id;
			// $where_kemarin['huruf_nota'] = $huruf_nota;
			// $data_kemarin = $this->insentif_detail_model->getOneBy($where_kemarin);
			// if ($data_kemarin != false) {
			// 	$total_berat = $data_kemarin->total_berat + $berat;
			// 	// $total_harga = $data_kemarin->total_harga + ($harga * 0.004);
			// 	$total_harga = $data_kemarin->total_harga + $harga;
			// } else {
			// 	$total_berat = $berat;
			// 	// $total_harga = $harga * 0.004;
			// 	$total_harga = $harga;
			// }
			//detail insentif
			$data_insentif = array(
				'insentif_id' => $insentif_id,
				'tanggal' => $tanggal,
				'karyawan_id' => $karyawan_id,
				'huruf_nota' => $huruf_nota,
				'no_nota_awal' => $no_nota_awal,
				'no_nota_akhir' => $no_nota_akhir,
				'jumlah_nota' => $jumlah_nota,
				'no_nota_batal' => $no_nota_batal,
				'jumlah_nota_batal' => $jumlah_nota_batal,
				'berat' => $berat,
				// 'total_berat' => $total_berat,
				'harga' => $harga,
				// 'total_harga' => $total_harga,
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			); 
			$insert_insentif_detail = $this->insentif_detail_model->insert($data_insentif);
			if ($insert_insentif_detail)
			{ 
				$this->session->set_flashdata('message', "Data insentif Baru Berhasil Disimpan");
				redirect("insentif/create_more/".$insentif_id);
			}
			else
			{
				$this->session->set_flashdata('message_error',"Data insentif Baru Gagal Disimpan");
				redirect("insentif");
			}
				
		} 
		else
		{
			if(!empty($_POST)){ 
				$this->session->set_flashdata('message_error',validation_errors());
				return redirect("insentif/create_more/".$id);	
			}else{
				$this->data['id']= $id;
				$this->data['insentif'] = $this->insentif_model->getOneBy(array("insentif.id"=>$this->data['id']));
				$this->data['data_insentif_detail'] = $this->insentif_detail_model->getAllById(['insentif_id' => $id, 'insentif_detail.is_deleted' => 0]);
				$where['data_karyawan.is_deleted'] = 0;
				$where['data_karyawan.users_id'] = $this->data['users']->id;
				$this->data['karyawan'] = $this->data_karyawan_model->getAllById($where); 
				$this->data['content'] = 'admin/insentif/create_more_v';
				$this->load->view('admin/layouts/page',$this->data);
				
			}  
		}    
		
	}

	public function detail()
	{ 
		$this->data['id']= $this->uri->segment(3);
		$this->data['insentif'] = $this->insentif_model->getOneBy(array("insentif.id"=>$this->data['id']));
		$this->data['data_insentif_detail'] = $this->insentif_detail_model->getAllById(['insentif_id' => $this->data['id'], 'insentif_detail.is_deleted' => 0]);
		$this->data['cek_insert'] = $this->data['insentif']->tanggal == date('Y-m-d') ? 1 : 0;
		$this->data['content'] = 'admin/insentif/detail_v'; 
		$this->load->view('admin/layouts/page',$this->data); 		
	} 

	public function dataList()
	{
		$columns = array( 
            0 =>'id',
        );
		if(!$this->data['is_superadmin']){
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
			$where['insentif.cabang_id'] = $cabang->id;
		}
		$where['insentif.is_deleted'] = 0;
		
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
  		$search = array();
  		$limit = 0;
  		$start = 0;
        $totalData = $this->insentif_model->getCountAllBy($limit,$start,$search,$order,$dir,$where); 
        


        $searchColumn = $this->input->post('columns');
        $isSearchColumn = false;

        if(!empty($searchColumn[0]['search']['value'])){
            $value = $searchColumn[0]['search']['value'];
            $isSearchColumn = true;
            $where['insentif.tanggal'] = $value;
        }
        

        if($isSearchColumn){
			$totalFiltered = $this->insentif_model->getCountAllBy($limit,$start,$search,$order,$dir,$where); 
			$totalData = $totalFiltered;
        }else{
        	$totalFiltered = $totalData;
        }
       
        $limit = $this->input->post('length');
        $start = $this->input->post('start');
     	$datas = $this->insentif_model->getAllBy($limit,$start,$search,$order,$dir,$where);
     	
        $new_data = array();
        if(!empty($datas))
        { 
            foreach ($datas as $key => $data)
            {  

            	$detail_url = "";
            	$add_url = "";
     			
            	$detail_url = "<a href='".base_url()."insentif/detail/".$data->id."' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";
            	// if ($data->tanggal == date('Y-m-d')) {
	            	$add_url = "<a href='".base_url()."insentif/create_more/".$data->id."' class='btn btn-sm btn-success' data-toggle='tooltip' title='Tambah Data' data-placement='bottom'><i class='fa fa-plus fa-w-20'></i></a>";            		
            	// }

                $nestedData['id'] = $start+$key+1;
                $nestedData['tanggal'] = $data->tanggal;
                $nestedData['action'] = $detail_url.' '.$add_url;   
                $new_data[] = $nestedData; 
            }
        }
          
        $json_data = array(
                    "draw"            => intval($this->input->post('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $new_data   
                    );
            
        echo json_encode($json_data); 
	}

	public function dataListAdmin()
	{
		$columns = array( 
            0 =>'id',
        );
		if($this->data['users_groups']->id == 4){
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
			$where['insentif.cabang_id'] = $cabang->id;
		}
		$where['insentif.is_deleted'] = 0;
		
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
  		$search = array();
  		$limit = 0;
  		$start = 0;
        $totalData = $this->insentif_model->getCountAllBy($limit,$start,$search,$order,$dir,$where); 
        


        $searchColumn = $this->input->post('columns');
        $isSearchColumn = false;

        if(!empty($searchColumn[0]['search']['value'])){
            $value = $searchColumn[0]['search']['value'];
            $isSearchColumn = true;
            $where['insentif.tanggal'] = $value;
        }
        if(!empty($searchColumn[1]['search']['value'])){
            $value = $searchColumn[1]['search']['value'];
            $isSearchColumn = true;
            $where['insentif.cabang_id'] = $value;
        }
        if(!empty($searchColumn[2]['search']['value'])){
            $value = $searchColumn[2]['search']['value'];
            $isSearchColumn = true;
            if ($value == 2) {
            	$value = 0;
            }
            $where['insentif.status_audit'] = $value;
        }

        if($isSearchColumn){
			$totalFiltered = $this->insentif_model->getCountAllBy($limit,$start,$search,$order,$dir,$where); 
			$totalData = $totalFiltered;
        }else{
        	$totalFiltered = $totalData;
        }
       
        $limit = $this->input->post('length');
        $start = $this->input->post('start');
     	$datas = $this->insentif_model->getAllBy($limit,$start,$search,$order,$dir,$where);
     	
        $new_data = array();
        if(!empty($datas))
        { 
            foreach ($datas as $key => $data)
            {  

            	$detail_url = "";
            	$add_url = "";
            	$audit_url = "";
     			
            	$detail_url = "<a href='".base_url()."insentif/detail/".$data->id."' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";
            	// $add_url = "<a href='".base_url()."insentif/create_more/".$data->id."' class='btn btn-sm btn-success' data-toggle='tooltip' title='Tambah Data' data-placement='bottom'><i class='fa fa-plus fa-w-20'></i></a>";
            	$edit_url = "<a href='" . base_url() . "insentif/edit/" . $data->id . "' class='btn btn-sm btn-warning' data-toggle='tooltip' title='Edit Data' data-placement='bottom'><i class='fa fa-edit fa-w-20'></i></a>";

            	if ($data->status_audit == 0 && $this->data['users_groups']->id == 3) {
            		$audit_url = "<a href='#' 
	        				url='" . base_url() . "insentif/destroy/" . $data->id . "/" . $data->status_audit . "' class='btn btn-sm btn-danger delete' data-toggle='tooltip' title='Data telah Diaudit' data-placement='bottom'><i class='fa fa-check-circle fa-w-20'></i></a>";
            	}

                $nestedData['id'] = $start+$key+1;
                $nestedData['cabang'] = $data->nama_cabang;
                $nestedData['tanggal'] = $data->tanggal;
                $nestedData['status_audit'] = $data->status_audit == 0 ? '<b style="color:red;">Belum</b>' : '<b style="color:green;">Selesai</b>';
                $nestedData['action'] = $detail_url.' '.$add_url.' '.$audit_url;   
                $new_data[] = $nestedData; 
            }
        }
          
        $json_data = array(
                    "draw"            => intval($this->input->post('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $new_data   
                    );
            
        echo json_encode($json_data); 
	}

	public function destroy(){
		$response_data = array();
        $response_data['status'] = false;
        $response_data['msg'] = "";
        $response_data['data'] = array();   

		$id =$this->uri->segment(3);
		$status_audit = $this->uri->segment(4);
 		if(!empty($id)){
 			$this->load->model("insentif_model");
			$data = array(
				'status_audit' => ($status_audit == 1)?0:1
			); 
			$update = $this->insentif_model->update($data,array("id"=>$id));

        	$response_data['data'] = $data; 
         	$response_data['status'] = true;
 		}else{
 		 	$response_data['msg'] = "ID Harus Diisi";
 		}
		
        echo json_encode($response_data); 
	}

	public function get_data_nota(){
		$no_nota_tambah = $this->input->get('no_nota_tambah');
		$kode_cabang = $this->input->get('kode_cabang');
		$no_nota_tambah = $no_nota_tambah.'~'.$kode_cabang;
		$where['no_nota LIKE'] = '%'.$no_nota_tambah.'%';
		$where['barang_id !='] = 0;
		$where['insentif_detail.is_deleted'] = 0;
		$get = $this->insentif_detail_model->getOneBy($where);
		if($get){
			$insentif = $this->insentif_model->getOneBy(['insentif.id' => $get->insentif_id]);
			$data['status'] = true;
			$data['cabang'] = $insentif->kode_cabang.' - '.$insentif->nama_cabang;
			$data['tanggal'] = $insentif->tanggal;
			$data['insentif_id'] = $get->insentif_id;
			$data['nama_karyawan'] = $get->nama_karyawan;
			if(!$this->data['is_superadmin']){
				$no_nota = explode('~', $get->no_nota);
				$data['no_nota_tukar'] = $no_nota[0];
				$data['no_nota'] = $get->no_nota;	
			}else{
				$data['no_nota'] = $get->no_nota;	
			}
			
			$data['nama_jenis'] = $get->nama_jenis;
			$data['harga_jenis'] = $get->harga_jenis;
			$data['nama_barang'] = $get->nama_barang;
			$data['jenis_transaksi_id'] = $get->jenis_transaksi_id;
			$data['potong'] = $get->potong;
			$data['berat'] = $get->berat;
			$data['harga'] = $get->harga;
		}else{
			$data['status'] = false;
		}
		echo json_encode($data);
	}

	// public function edit_stok_opname_925_and_sp(){
	// 	//stok opname dulu daks
	// 			// get insentif_id
	// 		$insentif_detail = $this->insentif_detail_model->getOneBy(['insentif_detail.id' => $insentif_detail_id]);
	// 		$insentif = $this->insentif_model->getOneBy(['insentif.id' => $insentif_detail->insentif_id]);
	// 		$cabang_id = $insentif->cabang_id;

	// 		$data_stok = $this->histori_stok_barang_model->getAllById(['cabang_id' => $cabang_id]);
			
			
	// 		/*
	// 			kembaliin dulu data sebelumnya
	// 		*/
	// 		// perhitungan stok opname
	// 			$berat_baru = $this->input->post('berat');
	// 			$cek_jenis_barang = $this->barang_model->getOneBy(['id' => $insentif_detail->barang_id]);
	// 			// get histori barang
	// 			$cek_histori = $this->histori_stok_barang_model->getOneBy(['cabang_id' => $cabang_id, 'tanggal' => $insentif->tanggal]);
	// 			// die();
	// 			if (strpos($cek_jenis_barang->nama_barang, '925') != false) {
	// 			    //histori stok kembaliin data sebelumnya
	// 				$stok_925_insentif = $cek_histori->stok_925_insentif - $insentif_detail->berat;
	// 				$total_stok_925 = $cek_histori->total_stok_925 - $insentif_detail->berat;
	// 			    $data_histori = array(
	// 			    	'stok_925_insentif' => $stok_925_insentif,
	// 			    	'total_stok_925' => $total_stok_925,
	// 			    );
	// 			    //berat baru
	// 			    $stok_925_insentif_edit = $stok_925_insentif + $berat_baru;
	// 			    $total_stok_925_edit = $total_stok_925 + $berat_baru;
	// 			    $data_histori_edit = array(
	// 			    	'stok_925_insentif' => $stok_925_insentif_edit,
	// 			    	'total_stok_925' => $total_stok_925_edit,
	// 			    );
	// 			    $total_stok_925  = array();
	// 				$stok_925_awal 	= 0;
	// 				$stok_925_akhir 	= 0;
	// 				$tgl_awal 	= '';
	// 				$tgl_akhir 	= '';
	// 				foreach ($data_stok as $key => $value) {
	// 					$total_stok_925[$value->tanggal] = $value->id;
	// 					$total_stok_925[$value->tanggal] = $value->total_stok_925;
	// 					if($stok_925_awal == 0){
	// 						$stok_925_awal = $value->stok_925_awal;
	// 						$tgl_awal = $value->tanggal;
	// 					}
	// 					$tgl_akhir = $value->tanggal;
	// 				}
			
	// 				$tgl_akhir = date('Y-m-d', strtotime('+1 days', strtotime($tgl_akhir)));//agar melebihi 1 hari
	// 				// data yg salah
	// 				//masukkan format tanggal dan jumlah kas yg masuk 
	// 				$tanggal  = $insentif->tanggal;
	// 				$total_stok_925_baru 		= $total_stok_925_edit;

	// 				for($i=$tgl_awal; $i!=$tgl_akhir; $i=date('Y-m-d', strtotime('+1 days', strtotime($i)))){
						
	// 					$data_update_stok_barang = array(
	// 						'stok_925_awal' => $stok_925_awal,
	// 						'total_stok_925' => ($i == $tanggal ? $total_stok_925_baru : $total_stok_925[$i]),
	// 						'stok_925_akhir' => ($i == $tanggal ? $stok_925_awal - $total_stok_925_baru : $stok_925_awal - $total_stok_925[$i]),
	// 						'updated_by' => $this->data['users']->id
	// 					);
	// 					$where_update_stok_925['cabang_id'] = $cabang_id;
	// 					$where_update_stok_925['tanggal'] = $i;
	// 					$update = $this->histori_stok_barang_model->update($data_update_stok_barang, $where_update_stok_925);
	// 					// edit kas di cabang
	// 					$data_stok_cabang = array('stok_925' => ($i == $tanggal ? $stok_925_awal - $total_stok_925_baru : $stok_925_awal - $total_stok_925[$i]));
	// 					$update = $this->cabang_model->update($data_stok_cabang, array("cabang.id" => $cabang_id));
						
	// 					$stok_925_awal -= ($i == $tanggal ? $total_stok_925_baru : $total_stok_925[$i]);
	// 				}
	// 			}else{
	// 				//histori stok kembaliin data sebelumnya
	// 				$stok_sp_insentif = $cek_histori->stok_sp_insentif - $insentif_detail->berat;
	// 				$total_stok_sp = $cek_histori->total_stok_sp - $insentif_detail->berat;
	// 			    $data_histori = array(
	// 			    	'stok_sp_insentif' => $stok_sp_insentif,
	// 			    	'total_stok_sp' => $total_stok_sp,
	// 			    );
	// 			    //berat baru
	// 			    $stok_sp_insentif_edit = $stok_sp_insentif + $berat_baru;
	// 			    $total_stok_sp_edit = $total_stok_sp + $berat_baru;
	// 			    $data_histori_edit = array(
	// 			    	'stok_sp_insentif' => $stok_sp_insentif_edit,
	// 			    	'total_stok_sp' => $total_stok_sp_edit,
	// 			    );
	// 			    $total_stok_sp  = array();
	// 				$stok_sp_awal 	= 0;
	// 				$stok_sp_akhir 	= 0;
	// 				$tgl_awal 	= '';
	// 				$tgl_akhir 	= '';
	// 				foreach ($data_stok as $key => $value) {
	// 					$total_stok_sp[$value->tanggal] = $value->id;
	// 					$total_stok_sp[$value->tanggal] = $value->total_stok_sp;
	// 					if($stok_sp_awal == 0){
	// 						$stok_sp_awal = $value->stok_sp_awal;
	// 						$tgl_awal = $value->tanggal;
	// 					}
	// 					$tgl_akhir = $value->tanggal;
	// 				}
			
	// 				$tgl_akhir = date('Y-m-d', strtotime('+1 days', strtotime($tgl_akhir)));//agar melebihi 1 hari
	// 				// data yg salah
	// 				//masukkan format tanggal dan jumlah kas yg masuk 
	// 				$tanggal  = $insentif->tanggal;
	// 				$total_stok_sp_baru 		= $total_stok_sp_edit;

	// 				for($i=$tgl_awal; $i!=$tgl_akhir; $i=date('Y-m-d', strtotime('+1 days', strtotime($i)))){
						
	// 					$data_update_stok_barang = array(
	// 						'stok_sp_awal' => $stok_sp_awal,
	// 						'total_stok_sp' => ($i == $tanggal ? $total_stok_sp_baru : $total_stok_sp[$i]),
	// 						'stok_sp_akhir' => ($i == $tanggal ? $stok_sp_awal - $total_stok_sp_baru : $stok_sp_awal - $total_stok_sp[$i]),
	// 						'updated_by' => $this->data['users']->id
	// 					);
	// 					$where_update_stok_sp['cabang_id'] = $cabang_id;
	// 					$where_update_stok_sp['tanggal'] = $i;
	// 					$update = $this->histori_stok_barang_model->update($data_update_stok_barang, $where_update_stok_sp);
	// 					// edit kas di cabang
	// 					$data_stok_cabang = array('stok_sp' => ($i == $tanggal ? $stok_sp_awal - $total_stok_sp_baru : $stok_sp_awal - $total_stok_sp[$i]));
	// 					$update = $this->cabang_model->update($data_stok_cabang, array("cabang.id" => $cabang_id));
						
	// 					$stok_sp_awal -= ($i == $tanggal ? $total_stok_sp_baru : $total_stok_sp[$i]);
	// 				}
	// 			}
	// 			$where_update_stok['cabang_id'] = $cabang_id;
	// 			$where_update_stok['tanggal'] = $insentif->tanggal;
	// 			$update_stok_histori = $this->histori_stok_barang_model->update($data_histori, $where_update_stok);
	// 			$update_stok_histori_edit = $this->histori_stok_barang_model->update($data_histori_edit, $where_update_stok);
	// }

	public function edit($insentif_detail_id)
	{
		$this->form_validation->set_rules('insentif_detail_id', "insentif_detail_id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$insentif_detail_id = $this->input->post('insentif_detail_id');

			$karyawan_id = $this->input->post('karyawan_id');
			$no_nota_awal = $this->input->post('no_nota_awal');
			$huruf_nota = $this->input->post('huruf_nota');
			$no_nota_akhir = $this->input->post('no_nota_akhir');
			$jumlah_nota = $this->input->post('jumlah_nota');
			$no_nota_batal = $this->input->post('no_nota_batal');
			$jumlah_nota_batal = $this->input->post('jumlah_nota_batal');
			$berat = $this->input->post('berat');
			$harga = $this->input->post('harga');
			$karyawan_id = $this->input->post('karyawan_id');
			$huruf_nota = $this->input->post('huruf_nota');


			$data_edit_detail = array(
				'no_nota_awal' => $no_nota_awal,
				'no_nota_akhir' => $no_nota_akhir,
				'jumlah_nota' => $jumlah_nota,
				'no_nota_batal' => $no_nota_batal,
				'jumlah_nota_batal' => $jumlah_nota_batal,
				'berat' => $berat,
				'huruf_nota' => $huruf_nota,
				'karyawan_id' => $karyawan_id,
				'harga' => $harga,
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			// // cek apakah berat yg di ubah atau harga
			$cek = $this->insentif_detail_model->getOneBy(['insentif_detail.id' => $insentif_detail_id]);
			
			$data_edit_insentif_detail = $this->insentif_detail_model->update($data_edit_detail, array("id" => $insentif_detail_id));
			
			if ($data_edit_insentif_detail)
			{ 
				$this->session->set_flashdata('message', "Data insentif Berhasil Diedit");
				redirect("insentif/detail/".$cek->insentif_id);
			}
			else
			{
				$this->session->set_flashdata('message_error',"Data insentif Gagal Diedit");
				redirect("insentif");
			}
			

		} else {
			if ($this->data['is_can_edit']) {
				$this->data['insentif_detail_id'] = $insentif_detail_id;
				$this->data['detail'] = $this->insentif_detail_model->getOneBy(array("insentif_detail.id" => $insentif_detail_id));
				$this->data['insentif'] = $this->insentif_model->getOneBy(array("insentif.id" => $this->data['detail']->insentif_id));
				$where['data_karyawan.is_deleted'] = 0;
				$where['data_karyawan.users_id'] = $this->data['users']->id;
				if($this->data['is_superadmin']){
					$where['data_karyawan.users_id'] = $this->data['insentif']->users_id;
				}
				$this->data['karyawan'] = $this->data_karyawan_model->getAllById($where); 

				$this->data['content'] = 'admin/insentif/edit_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

}
