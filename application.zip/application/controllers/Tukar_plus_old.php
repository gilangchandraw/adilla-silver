<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Tukar_plus extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('tukar_plus_model');
		$this->load->model('tukar_plus_detail_model');
		$this->load->model('cabang_model');
		$this->load->model('data_karyawan_model');
		$this->load->model('barang_model');
		$this->load->model('enum_transaksi_barang_model');
		$this->load->model('barang_kembali_detail_model');
		$this->load->model('penjualan_model');
		$this->load->model('penjualan_detail_model');
		$this->load->model('nota_model');
		$this->load->model('barang_kembali_model');
		$this->load->model('histori_kas_model');
		$this->load->model('histori_stok_barang_model');

	}

	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$cek_insert = true;
			$this->data['data_cabang'] = $this->cabang_model->getAllById();
			if($this->data['users_groups']->id == 4){
				$where['cabang.users_id'] = $this->data['users']->id;
				$this->data['cabang'] = $this->cabang_model->getOneBy($where); 	
				$where_cek['tukar_plus.tanggal'] = date('Y-m-d');
				$where_cek['tukar_plus.enum'] = 1;
				$where_cek['tukar_plus.cabang_id'] = $this->data['cabang']->id;
				$cek_insert = $this->tukar_plus_model->getOneBy($where_cek);
			}
			$this->data['cek_insert'] = $cek_insert ? 1 : 0;

			$this->data['content'] = 'admin/tukar_plus/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function cek_nota()
	{
		$this->data['content'] = 'admin/tukar_plus/cek_nota_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function create()
	{
		$this->form_validation->set_rules('tanggal', "tanggal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$tanggal = $this->input->post('tanggal');
			
			$value_tambah = $this->input->post('value-btn-tambah');
			$jenis_tukar = $this->input->post('jenis_tukar');
			$harga = $this->input->post('harga_konsumen');
			
			
			$no_nota = $this->input->post('no_nota');
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
			// get nota penjualan
			$no_nota_penjualan = $this->input->post('no_nota_penjualan');
			$where_penjualan['penjualan_detail.no_nota LIKE'] = '%'.$no_nota_penjualan.'%';
			$where_penjualan['penjualan_detail.enum'] = 1;
			$penjualan_detail = $this->penjualan_detail_model->getOneBy($where_penjualan);
			$no_nota_penjualan = $penjualan_detail->no_nota;
			// get nota G
			$where_nota_g['nota.no_nota LIKE'] = '%'.$no_nota.'%';
			// $where_nota_g['nota.jenis_nota'] = 1;
			$where_nota_g['nota.status_stok_nota'] = 1;
			$nota_g = $this->nota_model->getOneBy($where_nota_g);
			$no_nota = $nota_g->no_nota;

			
			if ($jenis_tukar == 1) {
				$harga = $this->input->post('harga_konsumen');
				$harga = $harga + $this->input->post('harga_penjualan') - 5000;
				$harga_plus = $this->input->post('harga_konsumen') - 5000;
				$data_tukar_plus = array(
					'users_id' => $this->data['users']->id,
					'tanggal' => $this->input->post('tanggal'),
					'total_berat' => $this->input->post('berat_tp'),
					'jumlah_transaksi' => 1,
					'enum' => 1,
					'cabang_id' => $cabang->id,
					'total_harga_keseluruhan' => $harga_plus,
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$insert_tukar_plus = $this->tukar_plus_model->insert($data_tukar_plus);
			} else {
				$data_tukar_plus = array(
					'users_id' => $this->data['users']->id,
					'tanggal' => $this->input->post('tanggal'),
					'total_berat' => $this->input->post('berat_tp'),
					'jumlah_transaksi' => 1,
					'enum' => 1,
					'cabang_id' => $cabang->id,
					'total_harga_keseluruhan' => $this->input->post('harga_tp'),
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$insert_tukar_plus = $this->tukar_plus_model->insert($data_tukar_plus);
			}
			
			// foto
			$foto         = $this->input->post('foto');
			$location_path = './uploads/foto-barang-tukar/';
			$name = $no_nota;
			$name = str_replace(' ', '-', $name);
			$uploaded      = uploadFile("foto".$foto, $location_path,$name);
		    if($uploaded['status']==1){
		    	$data_foto['foto'] = str_replace(' ', '_', $uploaded['message']);
		    }

			if ($jenis_tukar == 1) {

				$harga = $this->input->post('harga_konsumen');
				$harga = $harga + $this->input->post('harga_penjualan') - 5000;
				$harga_plus = $this->input->post('harga_konsumen') - 5000;
				$data_tukar_plus_detail = array(
					'berat_plus' => $this->input->post('berat_tp'),
					'harga_plus' => $harga_plus,
					'enum' => 1,
					'tukar_plus_id' => $insert_tukar_plus,
					'karyawan_id' => $this->input->post('karyawan_id'),
					'no_nota' => $no_nota,
					'foto' => $data_foto['foto'],
					'barang_id' => $this->input->post('barang_id'),
					'jenis_transaksi_id' => $this->input->post('jenis_transaksi_id'),
					'berat' => $this->input->post('berat_tp')+$this->input->post('berat'),
					'potong' => $this->input->post('potong'),
					'no_nota_penjualan' => $no_nota_penjualan,
					'potongan_rusak' => $this->input->post('potongan_rusak'),
					'potongan' => $this->input->post('potongan'),
					'harga' => $harga,
					'status' => 'Tukar Plus',
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$insert_tukar_plus_detail = $this->tukar_plus_detail_model->insert($data_tukar_plus_detail);
				//update status nota
				$data_update_nota = array(
						'status' => 4
				);

				//update status nota di tabel nota
				$where_update_nota_penjualan['nota.no_nota'] = $no_nota_penjualan;
				$where_update_nota_penjualan['nota.jenis_nota'] = 1;
				$where_update_nota_penjualan['nota.status_stok_nota'] = 1;
				$this->nota_model->update($data_update_nota, $where_update_nota_penjualan);
				$data_update_nota = array(
						'status' => 4
				);
				//update status nota di tabel nota
				$where_update_nota['nota.no_nota'] = $no_nota;
				$where_update_nota['nota.jenis_nota'] = 1;
				$where_update_nota['nota.status_stok_nota'] = 1;
				$this->nota_model->update($data_update_nota, $where_update_nota);
				//hapus nota di penjualan
				$data_update = array('penjualan_detail.is_deleted' => 1);
				$this->penjualan_detail_model->update($data_update,array("penjualan_detail.no_nota" => $no_nota_penjualan));
				
				$cek_detail = $this->penjualan_detail_model->getAllById(['penjualan_detail.penjualan_id' => $penjualan_detail->penjualan_id]);
				if (empty($cek_detail)) {
					$data_update = array('penjualan.is_deleted' => 1);
					$this->penjualan_model->update($data_update,array('penjualan.id' => $penjualan_detail->penjualan_id));		
				}
				if (!empty($cek_detail)) {
					$total_berat = 0.0;
					$total_harga_keseluruhan = 0;
					$jumlah_transaksi = count($cek_detail);
					foreach ($cek_detail as $key => $value) {
						$total_berat += $value->berat;
						$total_harga_keseluruhan += $value->harga;
					}
					$data_update_penjualan = array(
						'jumlah_transaksi' 					=> $jumlah_transaksi,
						'total_berat' 					=> $total_berat,
						'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
						'updated_by' => $this->data['users']->id

					); 
					$update_master_penjualan = $this->penjualan_model->update($data_update_penjualan,array("penjualan.id" => $penjualan_detail->penjualan_id));
				}
				// // UPDATE DATA KAS
				// $where_kas['histori_kas.tanggal'] = $tanggal;
				// $where_kas['histori_kas.users_id'] = $this->data['users']->id;
				// $where_kas['histori_kas.cabang_id'] = $cabang->id;
				// $kas = $cabang->kas + $this->input->post('harga_tp');
				// //update kas di cabang
				// $data_update_kas = array(
				// 		'kas' => $kas
				// );
				// $update_kas = $this->cabang_model->update($data_update_kas,['cabang.id' => $cabang->id]);
				// //update kas di histori kas
				// $update_kas = $this->histori_kas_model->update($data_update_kas,$where_kas);

				// perhitungan stock opname
				/*
					cek jenis stok apakah sama antara penjualan dengan tukar_plus
				*/
				// penjualan
				$cek_jenis_penjualan = $this->barang_model->getOneBy(['id' => $penjualan_detail->barang_id]);
				$jenis_penjualan = $cek_jenis_penjualan->jenis;
				// tukar_plus
				$barang_id_tp = $this->input->post('barang_id');
				$cek_jenis_tp = $this->barang_model->getOneBy(['id' => $barang_id_tp]);
				$jenis_tukar = $cek_jenis_tp->jenis;
				//get data histori stok barang
				$cek_histori = $this->histori_stok_barang_model->getOneBy(['cabang_id' => $cabang->id, 'tanggal' => date('Y-m-d')]);
				if ($jenis_penjualan == $jenis_tukar) {
					/* 
						tukar barang ke yg sama
					*/
					$barang_id = $this->input->post('barang_id');
					$berat_tp = $this->input->post('berat_tp');
					$cek_jenis_barang = $this->barang_model->getOneBy(['id' => $barang_id]);
					if($cek_jenis_barang->jenis == '925'){
						//untuk di cabang
					    $stok_akhir = $cabang->stok_925 - $berat_tp;
					    $data_stok_opname = array('stok_925' => $stok_akhir);
					    // untuk di histori stok barang
					    $stok_925_penjualan = $cek_histori->stok_925_penjualan + $berat_tp;
					    $total_stok_925 = $cek_histori->total_stok_925 + $berat_tp;
					    $stok_925_akhir = $cek_histori->stok_925_akhir - $berat_tp;
					    $data_histori = array(
					    	'stok_925_penjualan' => $stok_925_penjualan,
					    	'total_stok_925' => $total_stok_925,
					    	'stok_925_akhir' => $stok_925_akhir,
					    );
					}else{
						//untuk di cabang
						$stok_akhir = $cabang->stok_sp - $berat_tp;
					    $data_stok_opname = array('stok_sp' => $stok_akhir);
					    // untuk di histori stok barang
					    $stok_sp_penjualan = $cek_histori->stok_sp_penjualan + $berat_tp;
					    $total_stok_sp = $cek_histori->total_stok_sp + $berat_tp;
					    $stok_sp_akhir = $cek_histori->stok_sp_akhir - $berat_tp;
					    $data_histori = array(
					    	'stok_sp_penjualan' => $stok_sp_penjualan,
					    	'total_stok_sp' => $total_stok_sp,
					    	'stok_sp_akhir' => $stok_sp_akhir,
					    );
					}
					// edit di histori
					$where_update_stok['cabang_id'] = $cabang->id;
					$where_update_stok['tanggal'] = date('Y-m-d');
					$update_stok_histori = $this->histori_stok_barang_model->update($data_histori, $where_update_stok);
					//edit di cabang
					$update_stok_opname = $this->cabang_model->update($data_stok_opname, ['id' => $cabang->id]);
				} else {
					/* 
						tukar barang ke yg beda
					*/
					$barang_id = $this->input->post('barang_id');
					$berat_tp = $this->input->post('berat_tp');
					$berat_tp = $this->input->post('berat_tp') + $penjualan_detail->berat;
					$cek_jenis_barang = $this->barang_model->getOneBy(['id' => $barang_id]);
					if($cek_jenis_barang->jenis == '925'){
					// kembaliin dulu yg penjualan
						//untuk di cabang
						$stok_akhir = $cabang->stok_sp + $penjualan_detail->berat;
					    $data_stok_opname_kembali = array('stok_sp' => $stok_akhir);
					    // untuk di histori stok barang
					    $stok_sp_kembali = $cek_histori->stok_sp_kembali + $penjualan_detail->berat;
					    $total_stok_sp = $cek_histori->total_stok_sp - $penjualan_detail->berat;
					    $stok_sp_akhir = $cek_histori->stok_sp_akhir + $penjualan_detail->berat;
					    $data_histori_kembali = array(
					    	'stok_sp_kembali' => $stok_sp_kembali,
					    	'total_stok_sp' => $total_stok_sp,
					    	'stok_sp_akhir' => $stok_sp_akhir,
					    );
					//transaksi tukar plus
					    //untuk di cabang
					    $stok_akhir = $cabang->stok_925 - $berat_tp;
					    $data_stok_opname_tukar = array('stok_925' => $stok_akhir);
					    // untuk di histori stok barang
					    $stok_925_penjualan = $cek_histori->stok_925_penjualan + $berat_tp;
					    $total_stok_925 = $cek_histori->total_stok_925 + $berat_tp;
					    $stok_925_akhir = $cek_histori->stok_925_akhir - $berat_tp;
					    $data_histori_tukar = array(
					    	'stok_925_penjualan' => $stok_925_penjualan,
					    	'total_stok_925' => $total_stok_925,
					    	'stok_925_akhir' => $stok_925_akhir,
					    );
					}else{
					// kembaliin dulu yg penjualan
						$stok_akhir = $cabang->stok_925 + $penjualan_detail->berat;
					    $data_stok_opname_kembali = array('stok_925' => $stok_akhir);
					    // untuk di histori stok barang
					    $stok_925_kembali = $cek_histori->stok_925_kembali + $penjualan_detail->berat;
					    $total_stok_925 = $cek_histori->total_stok_925 - $penjualan_detail->berat;
					    $stok_925_akhir = $cek_histori->stok_925_akhir + $penjualan_detail->berat;
					    $data_histori_kembali = array(
					    	'stok_925_kembali' => $stok_925_kembali,
					    	'total_stok_925' => $total_stok_925,
					    	'stok_925_akhir' => $stok_925_akhir,
					    );
					//transaksi tukar plus
					    //untuk di cabang
						$stok_akhir = $cabang->stok_sp - $berat_tp;
					    $data_stok_opname_tukar = array('stok_sp' => $stok_akhir);
					    // untuk di histori stok barang
					    $stok_sp_penjualan = $cek_histori->stok_sp_penjualan + $berat_tp;
					    $total_stok_sp = $cek_histori->total_stok_sp + $berat_tp;
					    $stok_sp_akhir = $cek_histori->stok_sp_akhir - $berat_tp;
					    $data_histori_tukar = array(
					    	'stok_sp_penjualan' => $stok_sp_penjualan,
					    	'total_stok_sp' => $total_stok_sp,
					    	'stok_sp_akhir' => $stok_sp_akhir,
					    );
					}
				// kembaliin dulu yg penjualan
					// edit di histori
					$where_update_stok['cabang_id'] = $cabang->id;
					$where_update_stok['tanggal'] = date('Y-m-d');
					$update_stok_histori_kembali = $this->histori_stok_barang_model->update($data_histori_kembali, $where_update_stok);
					//edit di cabang
					$update_stok_opname_kembali = $this->cabang_model->update($data_stok_opname_kembali, ['id' => $cabang->id]);
				//transaksi tukar plus
					// edit di histori
					$update_stok_histori_tukar = $this->histori_stok_barang_model->update($data_histori_tukar, $where_update_stok);
					//edit di cabang
					$update_stok_opname_tukar = $this->cabang_model->update($data_stok_opname_tukar, ['id' => $cabang->id]);
				}
			}else{
				/*
					tukar min
				*/
				// get enum jenis
				$harga_jenis = $this->input->post('harga_jenis');
				$where_enum['enum_transaksi_barang.jenis_transaksi'] = 'tukar_barang';
				$where_enum['enum_transaksi_barang.harga'] = $harga_jenis;
				$enum_transaksi_tm = $this->enum_transaksi_barang_model->getOneBy($where_enum);
				$data_tukar_plus_detail = array(
					'enum' => 1,
					'tukar_plus_id' => $insert_tukar_plus,
					'karyawan_id' => $this->input->post('karyawan_id'),
					'no_nota' => $no_nota,
					'foto' => $data_foto['foto'],
					'jenis_transaksi_id' => $enum_transaksi_tm->id,
					'barang_id' => $this->input->post('barang_id'),
					'berat' => $this->input->post('berat_tp'),
					'potong' => $this->input->post('potong'),
					'berat_min' => $this->input->post('selisih_berat'),
					'no_nota_penjualan' => $no_nota_penjualan,
					'harga' => $this->input->post('harga_tp'),
					'potongan_rusak' => $this->input->post('potongan_rusak'),
					'potongan' => $this->input->post('potongan'),
					'status' => 'Tukar Min',
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$insert_tukar_plus_detail = $this->tukar_plus_detail_model->insert($data_tukar_plus_detail);
				$harga_jenis_barang_kembali = $this->input->post('harga_jenis_barang_kembali');
				$where_enum['enum_transaksi_barang.jenis_transaksi'] = 'barang_kembali';
				$where_enum['enum_transaksi_barang.harga'] = $harga_jenis_barang_kembali;
				$enum_transaksi = $this->enum_transaksi_barang_model->getOneBy($where_enum);
				//update status nota
				$data_update_nota = array(
						'status' => 2
				);
				//update status nota di tabel nota
				$where_update_nota_penjualan['nota.no_nota'] = $no_nota_penjualan;
				$where_update_nota_penjualan['nota.jenis_nota'] = 1;
				$where_update_nota_penjualan['nota.status_stok_nota'] = 1;
				$this->nota_model->update($data_update_nota, $where_update_nota_penjualan);
				$data_update_nota = array(
						'status' => 5
				);
				//update status nota di tabel nota
				$where_update_nota['nota.no_nota'] = $no_nota;
				$where_update_nota['nota.jenis_nota'] = 1;
				$where_update_nota['nota.status_stok_nota'] = 1;
				$this->nota_model->update($data_update_nota, $where_update_nota);
				//cek data barang kembali
				$data_bk = $this->barang_kembali_model->getOneBy(['barang_kembali.tanggal' => $tanggal, 'barang_kembali.enum' => 1]);

				$penjualan_detail = $this->penjualan_detail_model->getOneBy(['penjualan_detail.no_nota' => $no_nota_penjualan]);
				$penjualan_master = $this->penjualan_model->getOneBy(['penjualan.id' => $penjualan_detail->penjualan_id]);
				
				if ($data_bk) {
					// insert ke BK
					$data_barang_kembali_detail = array(
						'cabang_id_asal' => $penjualan_master->cabang_id,
						'barang_kembali_id' => $data_bk->id,
						'karyawan_id' => $this->input->post('karyawan_id'),
						'no_nota' => $penjualan_detail->no_nota,
						'jenis_transaksi_id' => $enum_transaksi->id,
						'barang_id' => $this->input->post('barang_id'),
						'berat' => $this->input->post('selisih_berat'),
						'potong' => $this->input->post('potong'),
						'harga' => $this->input->post('harga_konsumen'),
						'potongan' => $this->input->post('potongan'),
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
				} else {
					$data_barang_kembali = array(
						'users_id' => $this->data['users']->id,
						'tanggal' => $tanggal,
						'cabang_id' => $cabang->id,
						'total_berat' => $this->input->post('selisih_berat'),
						'jumlah_transaksi' => 1,
						'enum' => 1,
						'total_harga_keseluruhan' => $this->input->post('harga_konsumen'),
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
					$insert_barang_kembali = $this->barang_kembali_model->insert($data_barang_kembali);

					$data_barang_kembali_detail = array(
						'cabang_id_asal' => $penjualan_master->cabang_id,
						'barang_kembali_id' => $insert_barang_kembali,
						'karyawan_id' => $this->input->post('karyawan_id'),
						'no_nota' => $penjualan_detail->no_nota,
						'jenis_transaksi_id' => $enum_transaksi->id,
						'barang_id' => $this->input->post('barang_id'),
						'berat' => $this->input->post('selisih_berat'),
						'potong' => $this->input->post('potong'),
						'harga' => $this->input->post('harga_konsumen'),
						'potongan' => $this->input->post('potongan'),
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
				}
				
				// echo '<pre>';
				// print_r($data_barang_kembali_detail);
				// echo '</pre>';
				// die();
				$insert_barang_kembali_detail = $this->barang_kembali_detail_model->insert($data_barang_kembali_detail);

				$data_update = array('penjualan_detail.is_deleted' => 1);
				$this->penjualan_detail_model->update($data_update,array("penjualan_detail.no_nota" => $no_nota_penjualan));
				$cek_detail = $this->penjualan_detail_model->getAllById(['penjualan_detail.penjualan_id' => $penjualan_detail->penjualan_id]);
				if (empty($cek_detail)) {
					$data_update = array('penjualan.is_deleted' => 1);
					$this->penjualan_model->update($data_update,array('penjualan.id' => $penjualan_detail->penjualan_id));		
				}
				if (!empty($cek_detail)) {
					$total_berat = 0.0;
					$total_harga_keseluruhan = 0;
					$jumlah_transaksi = count($cek_detail);
					foreach ($cek_detail as $key => $value) {
						$total_berat += $value->berat;
						$total_harga_keseluruhan += $value->harga;
					}
					$data_update_penjualan = array(
						'jumlah_transaksi' 					=> $jumlah_transaksi,
						'total_berat' 					=> $total_berat,
						'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
						'updated_by' => $this->data['users']->id

					); 
					$update_master_penjualan = $this->penjualan_model->update($data_update_penjualan,array("penjualan.id" => $penjualan_detail->penjualan_id));
				}

				$data_bk_detail = $this->barang_kembali_detail_model->getAllById(['barang_kembali_detail.barang_kembali_id' => $data_bk->id, 'barang_kembali_detail.is_deleted' => 0]);
				if (!empty($data_bk_detail)) {
					$total_berat = 0.0;
					$total_harga_keseluruhan = 0;
					$jumlah_transaksi = count($data_bk_detail);
					foreach ($data_bk_detail as $key => $value) {
						$total_berat += $value->berat;
						$total_harga_keseluruhan += $value->harga;
					}
					$data_update_bk = array(
						'jumlah_transaksi' 					=> $jumlah_transaksi,
						'total_berat' 					=> $total_berat,
						'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
						'updated_by' => $this->data['users']->id

					); 
					$update_master_bk = $this->barang_kembali_model->update($data_update_bk,array("barang_kembali.id" => $data_bk->id));
				}
			// perhitungan stock opname
				/*
					cek jenis stok apakah sama antara penjualan dengan tukar_plus
				*/
				// penjualan
				$cek_jenis_penjualan = $this->barang_model->getOneBy(['id' => $penjualan_detail->barang_id]);
				$jenis_penjualan = $cek_jenis_penjualan->jenis;
				// tukar_plus
				$barang_id_tp = $this->input->post('barang_id');
				$cek_jenis_tp = $this->barang_model->getOneBy(['id' => $barang_id_tp]);
				$jenis_tukar = $cek_jenis_tp->jenis;
				//get data histori stok barang
				$cek_histori = $this->histori_stok_barang_model->getOneBy(['cabang_id' => $cabang->id, 'tanggal' => date('Y-m-d')]);
				if ($jenis_penjualan == $jenis_tukar) {
					/* 
						tukar barang ke yg sama
					*/
					$barang_id = $this->input->post('barang_id');
					$berat_tm = $this->input->post('selisih_berat');
					$cek_jenis_barang = $this->barang_model->getOneBy(['id' => $barang_id]);
					if($cek_jenis_barang->jenis == '925'){
						//untuk di cabang
					    $stok_akhir = $cabang->stok_925 + $berat_tm;
					    $data_stok_opname = array('stok_925' => $stok_akhir);
					    // untuk di histori stok barang
					    $stok_925_kembali = $cek_histori->stok_925_kembali + $berat_tm;
					    $total_stok_925 = $cek_histori->total_stok_925 - $berat_tm;
					    $stok_925_akhir = $cek_histori->stok_925_akhir + $berat_tm;
					    $data_histori = array(
					    	'stok_925_kembali' => $stok_925_kembali,
					    	'total_stok_925' => $total_stok_925,
					    	'stok_925_akhir' => $stok_925_akhir,
					    );
					}else{
						//untuk di cabang
						$stok_akhir = $cabang->stok_sp - $berat_tm;
					    $data_stok_opname = array('stok_sp' => $stok_akhir);
					    // untuk di histori stok barang
					    $stok_sp_kembali = $cek_histori->stok_sp_kembali + $berat_tm;
					    $total_stok_sp = $cek_histori->total_stok_sp - $berat_tm;
					    $stok_sp_akhir = $cek_histori->stok_sp_akhir + $berat_tm;
					    $data_histori = array(
					    	'stok_sp_kembali' => $stok_sp_kembali,
					    	'total_stok_sp' => $total_stok_sp,
					    	'stok_sp_akhir' => $stok_sp_akhir,
					    );
					}
					// edit di histori
					$where_update_stok['cabang_id'] = $cabang->id;
					$where_update_stok['tanggal'] = date('Y-m-d');
					$update_stok_histori = $this->histori_stok_barang_model->update($data_histori, $where_update_stok);
					//edit di cabang
					$update_stok_opname = $this->cabang_model->update($data_stok_opname, ['id' => $cabang->id]);
				}else{
					/* 
						tukar barang ke yg beda
					*/
					$barang_id = $this->input->post('barang_id');
					$berat_tp = $this->input->post('berat_tp');
					$cek_jenis_barang = $this->barang_model->getOneBy(['id' => $barang_id]);
					if($cek_jenis_barang->jenis == '925'){
					// kembaliin dulu yg penjualan
						//untuk di cabang
						$stok_akhir = $cabang->stok_sp + $penjualan_detail->berat;
					    $data_stok_opname_kembali = array('stok_sp' => $stok_akhir);
					    // untuk di histori stok barang
					    $stok_sp_kembali = $cek_histori->stok_sp_kembali + $penjualan_detail->berat;
					    $total_stok_sp = $cek_histori->total_stok_sp - $penjualan_detail->berat;
					    $stok_sp_akhir = $cek_histori->stok_sp_akhir + $penjualan_detail->berat;
					    $data_histori_kembali = array(
					    	'stok_sp_kembali' => $stok_sp_kembali,
					    	'total_stok_sp' => $total_stok_sp,
					    	'stok_sp_akhir' => $stok_sp_akhir,
					    );
					//transaksi tukar plus
					    //untuk di cabang
					    $stok_akhir = $cabang->stok_925 - $berat_tp;
					    $data_stok_opname_tukar = array('stok_925' => $stok_akhir);
					    // untuk di histori stok barang
					    $stok_925_penjualan = $cek_histori->stok_925_penjualan + $berat_tp;
					    $total_stok_925 = $cek_histori->total_stok_925 + $berat_tp;
					    $stok_925_akhir = $cek_histori->stok_925_akhir - $berat_tp;
					    $data_histori_tukar = array(
					    	'stok_925_penjualan' => $stok_925_penjualan,
					    	'total_stok_925' => $total_stok_925,
					    	'stok_925_akhir' => $stok_925_akhir,
					    );
					}else{
					// kembaliin dulu yg penjualan
						$stok_akhir = $cabang->stok_925 + $penjualan_detail->berat;
					    $data_stok_opname_kembali = array('stok_925' => $stok_akhir);
					    // untuk di histori stok barang
					    $stok_925_kembali = $cek_histori->stok_925_kembali + $penjualan_detail->berat;
					    $total_stok_925 = $cek_histori->total_stok_925 - $penjualan_detail->berat;
					    $stok_925_akhir = $cek_histori->stok_925_akhir + $penjualan_detail->berat;
					    $data_histori_kembali = array(
					    	'stok_925_kembali' => $stok_925_kembali,
					    	'total_stok_925' => $total_stok_925,
					    	'stok_925_akhir' => $stok_925_akhir,
					    );
					//transaksi tukar plus
					    //untuk di cabang
						$stok_akhir = $cabang->stok_sp - $berat_tp;
					    $data_stok_opname_tukar = array('stok_sp' => $stok_akhir);
					    // untuk di histori stok barang
					    $stok_sp_penjualan = $cek_histori->stok_sp_penjualan + $berat_tp;
					    $total_stok_sp = $cek_histori->total_stok_sp + $berat_tp;
					    $stok_sp_akhir = $cek_histori->stok_sp_akhir - $berat_tp;
					    $data_histori_tukar = array(
					    	'stok_sp_penjualan' => $stok_sp_penjualan,
					    	'total_stok_sp' => $total_stok_sp,
					    	'stok_sp_akhir' => $stok_sp_akhir,
					    );
					}
				// kembaliin dulu yg penjualan
					// edit di histori
					$where_update_stok['cabang_id'] = $cabang->id;
					$where_update_stok['tanggal'] = date('Y-m-d');
					$update_stok_histori_kembali = $this->histori_stok_barang_model->update($data_histori_kembali, $where_update_stok);
					//edit di cabang
					$update_stok_opname_kembali = $this->cabang_model->update($data_stok_opname_kembali, ['id' => $cabang->id]);
				//transaksi tukar plus
					// edit di histori
					$update_stok_histori_tukar = $this->histori_stok_barang_model->update($data_histori_tukar, $where_update_stok);
					//edit di cabang
					$update_stok_opname_tukar = $this->cabang_model->update($data_stok_opname_tukar, ['id' => $cabang->id]);
				}

			}

			$cek_detail = $this->penjualan_detail_model->getAllById(['penjualan_detail.penjualan_id' => $penjualan_detail->penjualan_id]);
			if (!empty($cek_detail)) {
				$total_berat = 0.0;
				$total_harga_keseluruhan = 0;
				$jumlah_transaksi = count($cek_detail);
				foreach ($cek_detail as $key => $value) {
					$total_berat += $value->berat;
					$total_harga_keseluruhan += $value->harga;
				}
				$data_update_penjualan = array(
					'jumlah_transaksi' 					=> $jumlah_transaksi,
					'total_berat' 					=> $total_berat,
					'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
					'updated_by' => $this->data['users']->id

				); 
				$update_master_penjualan = $this->penjualan_model->update($data_update_penjualan,array("penjualan.id" => $penjualan_detail->penjualan_id));
			}
			// // UPDATE DATA KAS
			// 	$where_kas['histori_kas.tanggal'] = $tanggal;
			// 	$where_kas['histori_kas.users_id'] = $this->data['users']->id;
			// 	$where_kas['histori_kas.cabang_id'] = $cabang->id;
			// 	$kas = $cabang->kas - $this->input->post('selisih_harga');
			// 	//update kas di cabang
			// 	$data_update_kas = array(
			// 			'kas' => $kas
			// 	);
			// 	$update_kas = $this->cabang_model->update($data_update_kas,['cabang.id' => $cabang->id]);
			// 	//update kas di histori kas
			// 	$update_kas = $this->histori_kas_model->update($data_update_kas,$where_kas);

			if ($insert_tukar_plus_detail) {
				$this->session->set_flashdata('message', "Data transaksi Tukar Barang Baru Berhasil Disimpan");
				redirect("tukar_plus/create_more/" . $insert_tukar_plus);
			} else {
				$this->session->set_flashdata('message_error', "Data transaksi Tukar Barang Baru Gagal Disimpan");
				redirect("tukar_plus");
			}
		} else {
			if ($this->data['is_can_create']) {
				$where['data_karyawan.is_deleted'] = 0;
				$where['data_karyawan.users_id'] = $this->data['users']->id;
				$this->data['karyawan'] = $this->data_karyawan_model->getAllById($where);
				$this->data['enum_transaksi'] = $this->enum_transaksi_barang_model->getAllById(['jenis_transaksi' => 'tukar_plus']);
				$this->data['barang'] = $this->barang_model->getAllById();
				//get nota
				$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
				$where_nota['nota.cabang_id'] = $cabang->id;
				$where_nota['nota.jenis_nota'] = 1;
				$where_nota['nota.huruf_nota'] = 'G';
				$where_nota['nota.status'] = 0;
				$where_update_nota['nota.status_stok_nota'] = 1;
				$nota = $this->nota_model->getOneBy($where_nota);
				if ($nota) {
					$no_nota = explode('~', $nota->no_nota);
					$this->data['no_nota_view'] = $no_nota[0];
					$this->data['no_nota'] = $nota->no_nota;
				}else{
					$this->session->set_flashdata('message_error', "Nota G Tidak Ada, Silahkan Hubungi Admin Kantor Adilla 925");
					redirect("tukar_plus");
				}
				
				$this->data['cabang'] = $this->cabang_model->getAllById();
				$this->data['content'] = 'admin/tukar_plus/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function create_more($id)
	{
		$this->form_validation->set_rules('tukar_plus_id', "tukar_plus_id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$tukar_plus_id = $this->input->post('tukar_plus_id');
			
			$value_tambah = $this->input->post('value-btn-tambah');
			$harga = $this->input->post('harga_konsumen');
			$jenis_tukar = $this->input->post('jenis_tukar');
			$no_nota = $this->input->post('no_nota');
			$tanggal = $this->input->post('tanggal');
			// get nota penjualan
			$no_nota_penjualan = $this->input->post('no_nota_penjualan');
			$where_penjualan['penjualan_detail.no_nota LIKE'] = '%'.$no_nota_penjualan.'%';
			$where_penjualan['penjualan_detail.enum'] = 1;
			$penjualan_detail = $this->penjualan_detail_model->getOneBy($where_penjualan);
			$no_nota_penjualan = $penjualan_detail->no_nota;
			// get nota G
			$where_nota_g['nota.no_nota LIKE'] = '%'.$no_nota.'%';
			$where_nota_g['nota.jenis_nota'] = 1;
			$where_nota_g['nota.status_stok_nota'] = 1;
			$nota_g = $this->nota_model->getOneBy($where_nota_g);
			$no_nota = $nota_g->no_nota;
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);

			// foto
			$foto         = $this->input->post('foto');
			$location_path = './uploads/foto-barang-tukar/';
			$name = $no_nota;
			$name = str_replace(' ', '-', $name);
			$uploaded      = uploadFile("foto".$foto, $location_path,$name);
		    if($uploaded['status']==1){
		    	$data_foto['foto'] = str_replace(' ', '_', $uploaded['message']);
		    }
			if ($jenis_tukar == 1) {
				// $harga = $this->input->post('harga_tp');
				$harga = $harga + $this->input->post('harga_penjualan') - 5000;
				$harga_plus = $this->input->post('harga_konsumen') - 5000;
				
				$data_tukar_plus_detail = array(
					'berat_plus' => $this->input->post('berat_tp'),
					'harga_plus' => $harga_plus,
					'enum' => 1,
					'tukar_plus_id' => $tukar_plus_id,
					'karyawan_id' => $this->input->post('karyawan_id'),
					'no_nota' => $no_nota,
					'foto' => $data_foto['foto'],
					'jenis_transaksi_id' => $this->input->post('jenis_transaksi_id'),
					'barang_id' => $this->input->post('barang_id'),
					'berat' => $this->input->post('berat_tp')+$this->input->post('berat'),
					'potong' => $this->input->post('potong'),
					'no_nota_penjualan' => $no_nota_penjualan,
					'potongan_rusak' => $this->input->post('potongan_rusak'),
					'potongan' => $this->input->post('potongan'),
					'harga' => $harga,
					'status' => 'Tukar Plus',
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$insert_tukar_plus_detail = $this->tukar_plus_detail_model->insert($data_tukar_plus_detail);

				//update status nota
				$data_update_nota = array(
						'status' => 4
				);

				//update status nota di tabel nota
				$where_update_nota_penjualan['nota.no_nota'] = $no_nota_penjualan;
				$where_update_nota_penjualan['nota.jenis_nota'] = 1;
				$where_update_nota_penjualan['nota.status_stok_nota'] = 1;
				$this->nota_model->update($data_update_nota, $where_update_nota_penjualan);
				
				//update status nota
				$data_update_nota = array(
						'status' => 4
				);
				//update status nota di tabel nota
				$where_update_nota['nota.no_nota'] = $no_nota;
				$where_update_nota['nota.jenis_nota'] = 1;
				$where_update_nota['nota.status_stok_nota'] = 1;
				$this->nota_model->update($data_update_nota, $where_update_nota);

				//hapus nota di penjualan
				$data_update = array('penjualan_detail.is_deleted' => 1);
				$this->penjualan_detail_model->update($data_update,array("penjualan_detail.no_nota" => $no_nota_penjualan));

				$penjualan_detail = $this->penjualan_detail_model->getOneBy(['penjualan_detail.no_nota' => $no_nota_penjualan]);
				$cek_detail = $this->penjualan_detail_model->getAllById(['penjualan_detail.penjualan_id' => $penjualan_detail->penjualan_id]);
				if (empty($cek_detail)) {
					$data_update = array('penjualan.is_deleted' => 1);
					$this->penjualan_model->update($data_update,array('penjualan.id' => $penjualan_detail->penjualan_id));		
				}
				// // UPDATE DATA KAS
				// $where_kas['histori_kas.tanggal'] = $tanggal;
				// $where_kas['histori_kas.users_id'] = $this->data['users']->id;
				// $where_kas['histori_kas.cabang_id'] = $cabang->id;
				// $kas = $cabang->kas + $this->input->post('harga_tp');
				// //update kas di cabang
				// $data_update_kas = array(
				// 		'kas' => $kas
				// );
				// $update_kas = $this->cabang_model->update($data_update_kas,['cabang.id' => $cabang->id]);
				// //update kas di histori kas
				// $update_kas = $this->histori_kas_model->update($data_update_kas,$where_kas);
				// perhitungan stock opname
				/*
					cek jenis stok apakah sama antara penjualan dengan tukar_plus
				*/
				// penjualan
				$cek_jenis_penjualan = $this->barang_model->getOneBy(['id' => $penjualan_detail->barang_id]);
				$jenis_penjualan = $cek_jenis_penjualan->jenis;
				// tukar_plus
				$barang_id_tp = $this->input->post('barang_id');
				$cek_jenis_tp = $this->barang_model->getOneBy(['id' => $barang_id_tp]);
				$jenis_tukar = $cek_jenis_tp->jenis;
				//get data histori stok barang
				$cek_histori = $this->histori_stok_barang_model->getOneBy(['cabang_id' => $cabang->id, 'tanggal' => date('Y-m-d')]);
				if ($jenis_penjualan == $jenis_tukar) {
					/* 
						tukar barang ke yg sama
					*/
					$barang_id = $this->input->post('barang_id');
					$berat_tp = $this->input->post('berat_tp');
					$cek_jenis_barang = $this->barang_model->getOneBy(['id' => $barang_id]);
					if($cek_jenis_barang->jenis == '925'){
						//untuk di cabang
					    $stok_akhir = $cabang->stok_925 - $berat_tp;
					    $data_stok_opname = array('stok_925' => $stok_akhir);
					    // untuk di histori stok barang
					    $stok_925_penjualan = $cek_histori->stok_925_penjualan + $berat_tp;
					    $total_stok_925 = $cek_histori->total_stok_925 + $berat_tp;
					    $stok_925_akhir = $cek_histori->stok_925_akhir - $berat_tp;
					    $data_histori = array(
					    	'stok_925_penjualan' => $stok_925_penjualan,
					    	'total_stok_925' => $total_stok_925,
					    	'stok_925_akhir' => $stok_925_akhir,
					    );
					}else{
						//untuk di cabang
						$stok_akhir = $cabang->stok_sp - $berat_tp;
					    $data_stok_opname = array('stok_sp' => $stok_akhir);
					    // untuk di histori stok barang
					    $stok_sp_penjualan = $cek_histori->stok_sp_penjualan + $berat_tp;
					    $total_stok_sp = $cek_histori->total_stok_sp + $berat_tp;
					    $stok_sp_akhir = $cek_histori->stok_sp_akhir - $berat_tp;
					    $data_histori = array(
					    	'stok_sp_penjualan' => $stok_sp_penjualan,
					    	'total_stok_sp' => $total_stok_sp,
					    	'stok_sp_akhir' => $stok_sp_akhir,
					    );
					}
					// edit di histori
					$where_update_stok['cabang_id'] = $cabang->id;
					$where_update_stok['tanggal'] = date('Y-m-d');
					$update_stok_histori = $this->histori_stok_barang_model->update($data_histori, $where_update_stok);
					//edit di cabang
					$update_stok_opname = $this->cabang_model->update($data_stok_opname, ['id' => $cabang->id]);
				} else {
					/* 
						tukar barang ke yg beda
					*/
					$barang_id = $this->input->post('barang_id');
					$berat_tp = $this->input->post('berat_tp');
					$berat_tp = $this->input->post('berat_tp') + $penjualan_detail->berat;
					$cek_jenis_barang = $this->barang_model->getOneBy(['id' => $barang_id]);
					if($cek_jenis_barang->jenis == '925'){
					// kembaliin dulu yg penjualan
						//untuk di cabang
						$stok_akhir = $cabang->stok_sp + $penjualan_detail->berat;
					    $data_stok_opname_kembali = array('stok_sp' => $stok_akhir);
					    // untuk di histori stok barang
					    $stok_sp_kembali = $cek_histori->stok_sp_kembali + $penjualan_detail->berat;
					    $total_stok_sp = $cek_histori->total_stok_sp - $penjualan_detail->berat;
					    $stok_sp_akhir = $cek_histori->stok_sp_akhir + $penjualan_detail->berat;
					    $data_histori_kembali = array(
					    	'stok_sp_kembali' => $stok_sp_kembali,
					    	'total_stok_sp' => $total_stok_sp,
					    	'stok_sp_akhir' => $stok_sp_akhir,
					    );
					//transaksi tukar plus
					    //untuk di cabang
					    $stok_akhir = $cabang->stok_925 - $berat_tp;
					    $data_stok_opname_tukar = array('stok_925' => $stok_akhir);
					    // untuk di histori stok barang
					    $stok_925_penjualan = $cek_histori->stok_925_penjualan + $berat_tp;
					    $total_stok_925 = $cek_histori->total_stok_925 + $berat_tp;
					    $stok_925_akhir = $cek_histori->stok_925_akhir - $berat_tp;
					    $data_histori_tukar = array(
					    	'stok_925_penjualan' => $stok_925_penjualan,
					    	'total_stok_925' => $total_stok_925,
					    	'stok_925_akhir' => $stok_925_akhir,
					    );
					}else{
					// kembaliin dulu yg penjualan
						$stok_akhir = $cabang->stok_925 + $penjualan_detail->berat;
					    $data_stok_opname_kembali = array('stok_925' => $stok_akhir);
					    // untuk di histori stok barang
					    $stok_925_kembali = $cek_histori->stok_925_kembali + $penjualan_detail->berat;
					    $total_stok_925 = $cek_histori->total_stok_925 - $penjualan_detail->berat;
					    $stok_925_akhir = $cek_histori->stok_925_akhir + $penjualan_detail->berat;
					    $data_histori_kembali = array(
					    	'stok_925_kembali' => $stok_925_kembali,
					    	'total_stok_925' => $total_stok_925,
					    	'stok_925_akhir' => $stok_925_akhir,
					    );
					//transaksi tukar plus
					    //untuk di cabang
						$stok_akhir = $cabang->stok_sp - $berat_tp;
					    $data_stok_opname_tukar = array('stok_sp' => $stok_akhir);
					    // untuk di histori stok barang
					    $stok_sp_penjualan = $cek_histori->stok_sp_penjualan + $berat_tp;
					    $total_stok_sp = $cek_histori->total_stok_sp + $berat_tp;
					    $stok_sp_akhir = $cek_histori->stok_sp_akhir - $berat_tp;
					    $data_histori_tukar = array(
					    	'stok_sp_penjualan' => $stok_sp_penjualan,
					    	'total_stok_sp' => $total_stok_sp,
					    	'stok_sp_akhir' => $stok_sp_akhir,
					    );
					}
				// kembaliin dulu yg penjualan
					// edit di histori
					$where_update_stok['cabang_id'] = $cabang->id;
					$where_update_stok['tanggal'] = date('Y-m-d');
					$update_stok_histori_kembali = $this->histori_stok_barang_model->update($data_histori_kembali, $where_update_stok);
					//edit di cabang
					$update_stok_opname_kembali = $this->cabang_model->update($data_stok_opname_kembali, ['id' => $cabang->id]);
				//transaksi tukar plus
					// edit di histori
					$update_stok_histori_tukar = $this->histori_stok_barang_model->update($data_histori_tukar, $where_update_stok);
					//edit di cabang
					$update_stok_opname_tukar = $this->cabang_model->update($data_stok_opname_tukar, ['id' => $cabang->id]);
				}
			}else{
				// get enum jenis
				$harga_jenis = $this->input->post('harga_jenis');
				$where_enum['enum_transaksi_barang.jenis_transaksi'] = 'tukar_barang';
				$where_enum['enum_transaksi_barang.harga'] = $harga_jenis;
				$enum_transaksi_tm = $this->enum_transaksi_barang_model->getOneBy($where_enum);
				

				$data_tukar_plus_detail = array(
					'enum' => 1,
					'tukar_plus_id' => $tukar_plus_id,
					'karyawan_id' => $this->input->post('karyawan_id'),
					'no_nota' => $no_nota,
					'foto' => $data_foto['foto'],
					'jenis_transaksi_id' => $enum_transaksi_tm->id,
					'barang_id' => $this->input->post('barang_id'),
					'berat' => $this->input->post('berat_tp'),
					'potong' => $this->input->post('potong'),
					'berat_min' => $this->input->post('selisih_berat'),
					'no_nota_penjualan' => $no_nota_penjualan,
					'harga' => $this->input->post('harga_tp'),
					'potongan_rusak' => $this->input->post('potongan_rusak'),
					'potongan' => $this->input->post('potongan'),
					'status' => 'Tukar Min',
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$insert_tukar_plus_detail = $this->tukar_plus_detail_model->insert($data_tukar_plus_detail);
				$harga_jenis_barang_kembali = $this->input->post('harga_jenis_barang_kembali');
				$where_enum['enum_transaksi_barang.jenis_transaksi'] = 'barang_kembali';
				$where_enum['enum_transaksi_barang.harga'] = $harga_jenis_barang_kembali;
				$enum_transaksi = $this->enum_transaksi_barang_model->getOneBy($where_enum);
				//update status nota
				$data_update_nota = array(
						'status' => 2
				);
				//update status nota di tabel nota
				$where_update_nota_penjualan['nota.no_nota'] = $no_nota_penjualan;
				$where_update_nota_penjualan['nota.jenis_nota'] = 1;
				$where_update_nota_penjualan['nota.status_stok_nota'] = 1;
				$this->nota_model->update($data_update_nota, $where_update_nota_penjualan);
				
				$data_update_nota = array(
						'status' => 5
				);
				//update status nota di tabel nota
				$where_update_nota['nota.no_nota'] = $no_nota;
				$where_update_nota['nota.jenis_nota'] = 1;
				$where_update_nota['nota.status_stok_nota'] = 1;
				$this->nota_model->update($data_update_nota, $where_update_nota);
				//cek data barang kembali
				$data_bk = $this->barang_kembali_model->getOneBy(['barang_kembali.tanggal' => $tanggal, 'barang_kembali.enum' => 1]);

				$penjualan_detail = $this->penjualan_detail_model->getOneBy(['penjualan_detail.no_nota' => $no_nota_penjualan]);
				$penjualan_master = $this->penjualan_model->getOneBy(['penjualan.id' => $penjualan_detail->penjualan_id]);

				// insert ke BK
				$data_barang_kembali_detail = array(
					'barang_kembali_id' => $data_bk->id,
					'cabang_id_asal' => $penjualan_master->cabang_id,
					'karyawan_id' => $this->input->post('karyawan_id'),
					'no_nota' => $penjualan_detail->no_nota,
					'jenis_transaksi_id' => $enum_transaksi->id,
					'barang_id' => $this->input->post('barang_id'),
					'berat' => $this->input->post('selisih_berat'),
					'potong' => $this->input->post('potong'),
					'harga' => $this->input->post('harga_konsumen'),
					'potongan' => $this->input->post('potongan'),
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$insert_barang_kembali_detail = $this->barang_kembali_detail_model->insert($data_barang_kembali_detail);

				$data_update = array('penjualan_detail.is_deleted' => 1);
				$this->penjualan_detail_model->update($data_update,array("penjualan_detail.no_nota" => $no_nota_penjualan));
				$cek_detail = $this->penjualan_detail_model->getAllById(['penjualan_detail.penjualan_id' => $penjualan_detail->penjualan_id]);
				if (empty($cek_detail)) {
					$data_update = array('penjualan.is_deleted' => 1);
					$this->penjualan_model->update($data_update,array('penjualan.id' => $penjualan_detail->penjualan_id));		
				}
				$data_bk_detail = $this->barang_kembali_detail_model->getAllById(['barang_kembali_detail.barang_kembali_id' => $data_bk->id, 'barang_kembali_detail.is_deleted' => 0]);
				if (!empty($data_bk_detail)) {
					$total_berat = 0.0;
					$total_harga_keseluruhan = 0;
					$jumlah_transaksi = count($data_bk_detail);
					foreach ($data_bk_detail as $key => $value) {
						$total_berat += $value->berat;
						$total_harga_keseluruhan += $value->harga;
					}
					$data_update_bk = array(
						'jumlah_transaksi' 					=> $jumlah_transaksi,
						'total_berat' 					=> $total_berat,
						'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
						'updated_by' => $this->data['users']->id

					); 
					$update_master_bk = $this->barang_kembali_model->update($data_update_bk,array("barang_kembali.id" => $data_bk->id));
				}
				// // UPDATE DATA KAS
				// $where_kas['histori_kas.tanggal'] = $tanggal;
				// $where_kas['histori_kas.users_id'] = $this->data['users']->id;
				// $where_kas['histori_kas.cabang_id'] = $cabang->id;
				// $kas = $cabang->kas - $this->input->post('selisih_harga');
				// //update kas di cabang
				// $data_update_kas = array(
				// 		'kas' => $kas
				// );
				// $update_kas = $this->cabang_model->update($data_update_kas,['cabang.id' => $cabang->id]);
				// //update kas di histori kas
				// $update_kas = $this->histori_kas_model->update($data_update_kas,$where_kas);
			// perhitungan stock opname
				/*
					cek jenis stok apakah sama antara penjualan dengan tukar_plus
				*/
				// penjualan
				$cek_jenis_penjualan = $this->barang_model->getOneBy(['id' => $penjualan_detail->barang_id]);
				$jenis_penjualan = $cek_jenis_penjualan->jenis;
				// tukar_plus
				$barang_id_tp = $this->input->post('barang_id');
				$cek_jenis_tp = $this->barang_model->getOneBy(['id' => $barang_id_tp]);
				$jenis_tukar = $cek_jenis_tp->jenis;
				//get data histori stok barang
				$cek_histori = $this->histori_stok_barang_model->getOneBy(['cabang_id' => $cabang->id, 'tanggal' => date('Y-m-d')]);
				if ($jenis_penjualan == $jenis_tukar) {
					/* 
						tukar barang ke yg sama
					*/
					$barang_id = $this->input->post('barang_id');
					$berat_tm = $this->input->post('selisih_berat');
					$cek_jenis_barang = $this->barang_model->getOneBy(['id' => $barang_id]);
					if($cek_jenis_barang->jenis == '925'){
						//untuk di cabang
					    $stok_akhir = $cabang->stok_925 + $berat_tm;
					    $data_stok_opname = array('stok_925' => $stok_akhir);
					    // untuk di histori stok barang
					    $stok_925_kembali = $cek_histori->stok_925_kembali + $berat_tm;
					    $total_stok_925 = $cek_histori->total_stok_925 - $berat_tm;
					    $stok_925_akhir = $cek_histori->stok_925_akhir + $berat_tm;
					    $data_histori = array(
					    	'stok_925_kembali' => $stok_925_kembali,
					    	'total_stok_925' => $total_stok_925,
					    	'stok_925_akhir' => $stok_925_akhir,
					    );
					}else{
						//untuk di cabang
						$stok_akhir = $cabang->stok_sp - $berat_tm;
					    $data_stok_opname = array('stok_sp' => $stok_akhir);
					    // untuk di histori stok barang
					    $stok_sp_kembali = $cek_histori->stok_sp_kembali + $berat_tm;
					    $total_stok_sp = $cek_histori->total_stok_sp - $berat_tm;
					    $stok_sp_akhir = $cek_histori->stok_sp_akhir + $berat_tm;
					    $data_histori = array(
					    	'stok_sp_kembali' => $stok_sp_kembali,
					    	'total_stok_sp' => $total_stok_sp,
					    	'stok_sp_akhir' => $stok_sp_akhir,
					    );
					}
					// edit di histori
					$where_update_stok['cabang_id'] = $cabang->id;
					$where_update_stok['tanggal'] = date('Y-m-d');
					$update_stok_histori = $this->histori_stok_barang_model->update($data_histori, $where_update_stok);
					//edit di cabang
					$update_stok_opname = $this->cabang_model->update($data_stok_opname, ['id' => $cabang->id]);
				}else{
					/* 
						tukar barang ke yg beda
					*/
					$barang_id = $this->input->post('barang_id');
					$berat_tp = $this->input->post('berat_tp');
					$cek_jenis_barang = $this->barang_model->getOneBy(['id' => $barang_id]);
					if($cek_jenis_barang->jenis == '925'){
					// kembaliin dulu yg penjualan
						//untuk di cabang
						$stok_akhir = $cabang->stok_sp + $penjualan_detail->berat;
					    $data_stok_opname_kembali = array('stok_sp' => $stok_akhir);
					    // untuk di histori stok barang
					    $stok_sp_kembali = $cek_histori->stok_sp_kembali + $penjualan_detail->berat;
					    $total_stok_sp = $cek_histori->total_stok_sp - $penjualan_detail->berat;
					    $stok_sp_akhir = $cek_histori->stok_sp_akhir + $penjualan_detail->berat;
					    $data_histori_kembali = array(
					    	'stok_sp_kembali' => $stok_sp_kembali,
					    	'total_stok_sp' => $total_stok_sp,
					    	'stok_sp_akhir' => $stok_sp_akhir,
					    );
					//transaksi tukar plus
					    //untuk di cabang
					    $stok_akhir = $cabang->stok_925 - $berat_tp;
					    $data_stok_opname_tukar = array('stok_925' => $stok_akhir);
					    // untuk di histori stok barang
					    $stok_925_penjualan = $cek_histori->stok_925_penjualan + $berat_tp;
					    $total_stok_925 = $cek_histori->total_stok_925 + $berat_tp;
					    $stok_925_akhir = $cek_histori->stok_925_akhir - $berat_tp;
					    $data_histori_tukar = array(
					    	'stok_925_penjualan' => $stok_925_penjualan,
					    	'total_stok_925' => $total_stok_925,
					    	'stok_925_akhir' => $stok_925_akhir,
					    );
					}else{
					// kembaliin dulu yg penjualan
						$stok_akhir = $cabang->stok_925 + $penjualan_detail->berat;
					    $data_stok_opname_kembali = array('stok_925' => $stok_akhir);
					    // untuk di histori stok barang
					    $stok_925_kembali = $cek_histori->stok_925_kembali + $penjualan_detail->berat;
					    $total_stok_925 = $cek_histori->total_stok_925 - $penjualan_detail->berat;
					    $stok_925_akhir = $cek_histori->stok_925_akhir + $penjualan_detail->berat;
					    $data_histori_kembali = array(
					    	'stok_925_kembali' => $stok_925_kembali,
					    	'total_stok_925' => $total_stok_925,
					    	'stok_925_akhir' => $stok_925_akhir,
					    );
					//transaksi tukar plus
					    //untuk di cabang
						$stok_akhir = $cabang->stok_sp - $berat_tp;
					    $data_stok_opname_tukar = array('stok_sp' => $stok_akhir);
					    // untuk di histori stok barang
					    $stok_sp_penjualan = $cek_histori->stok_sp_penjualan + $berat_tp;
					    $total_stok_sp = $cek_histori->total_stok_sp + $berat_tp;
					    $stok_sp_akhir = $cek_histori->stok_sp_akhir - $berat_tp;
					    $data_histori_tukar = array(
					    	'stok_sp_penjualan' => $stok_sp_penjualan,
					    	'total_stok_sp' => $total_stok_sp,
					    	'stok_sp_akhir' => $stok_sp_akhir,
					    );
					}
				// kembaliin dulu yg penjualan
					// edit di histori
					$where_update_stok['cabang_id'] = $cabang->id;
					$where_update_stok['tanggal'] = date('Y-m-d');
					$update_stok_histori_kembali = $this->histori_stok_barang_model->update($data_histori_kembali, $where_update_stok);
					//edit di cabang
					$update_stok_opname_kembali = $this->cabang_model->update($data_stok_opname_kembali, ['id' => $cabang->id]);
				//transaksi tukar plus
					// edit di histori
					$update_stok_histori_tukar = $this->histori_stok_barang_model->update($data_histori_tukar, $where_update_stok);
					//edit di cabang
					$update_stok_opname_tukar = $this->cabang_model->update($data_stok_opname_tukar, ['id' => $cabang->id]);
				}
			}
			// ubah master tukar_plus
			$data_tukar_plus = $this->tukar_plus_model->getOneBy(['tukar_plus.id' => $tukar_plus_id]);
			//update harga
			if ($jenis_tukar == 1) {
				$update_berat = $data_tukar_plus->total_berat + $this->input->post('berat_tp');
				$harga = $this->input->post('harga_konsumen') - 5000;
				$update_harga = $harga + $data_tukar_plus->total_harga_keseluruhan;
			} else {
				$update_berat = $data_tukar_plus->total_berat + $this->input->post('berat_tp');
				$update_harga = $harga + $data_tukar_plus->total_harga_keseluruhan;
			}
			
			// update jumlah_transaksi
			$update_jumlah = $data_tukar_plus->jumlah_transaksi + 1;
			// update berat
			$data_update_tukar_plus = array(
				'jumlah_transaksi' 					=> $update_jumlah,
				'total_harga_keseluruhan'			=> $update_harga,
				'total_berat' 					=> $update_berat,
				'updated_by' => $this->data['users']->id

			);
			$update_master_tukar_plus = $this->tukar_plus_model->update($data_update_tukar_plus, array("tukar_plus.id" => $tukar_plus_id));
			//update master
			$cek_detail = $this->penjualan_detail_model->getAllById(['penjualan_detail.penjualan_id' => $penjualan_detail->penjualan_id]);
			if (!empty($cek_detail)) {
				$total_berat = 0.0;
				$total_harga_keseluruhan = 0;
				$jumlah_transaksi = count($cek_detail);
				foreach ($cek_detail as $key => $value) {
					$total_berat += $value->berat;
					$total_harga_keseluruhan += $value->harga;
				}
				$data_update_penjualan = array(
					'jumlah_transaksi' 					=> $jumlah_transaksi,
					'total_berat' 					=> $total_berat,
					'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
					'updated_by' => $this->data['users']->id

				); 
				$update_master_penjualan = $this->penjualan_model->update($data_update_penjualan,array("penjualan.id" => $penjualan_detail->penjualan_id));
			}
			
			if ($update_master_tukar_plus) {
				$this->session->set_flashdata('message', "Data transaksi Tukar Barang Baru Berhasil Disimpan");
				redirect("tukar_plus/create_more/" . $tukar_plus_id);
			} else {
				$this->session->set_flashdata('message_error', "Data transaksi Tukar Barang Baru Gagal Disimpan");
				redirect("tukar_plus");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("tukar_plus/edit/" . $id);
			} else {
				$this->data['id'] = $id;
				$this->data['tukar_plus'] = $this->tukar_plus_model->getOneBy(array("tukar_plus.id" => $this->data['id'], 'tukar_plus.is_deleted' => 0));
				//nota
				$where_nota['nota.`cabang_id'] = $this->data['tukar_plus']->cabang_id;
				$where_nota['nota.jenis_nota'] = 1;
				$where_nota['nota.huruf_nota'] = 'G';
				$where_nota['nota.status'] = 0;
				$where_nota['nota.status_stok_nota'] = 1;
				$nota = $this->nota_model->getOneBy($where_nota);
				$no_nota = explode('~', $nota->no_nota);
				$this->data['no_nota_view'] = $no_nota[0];
				$this->data['no_nota'] = $nota->no_nota;
				$this->data['data_tukar_plus_detail'] = $this->tukar_plus_detail_model->getAllById(['tukar_plus_id' => $id, 'tukar_plus_detail.is_deleted' => 0]);
				$this->data['data_tukar_plus_detail_min'] = $this->tukar_plus_detail_model->getAllByIdBKMin(['tukar_plus_id' => $id, 'tukar_plus_detail.is_deleted' => 0]);
				$where['data_karyawan.is_deleted'] = 0;
				$where['data_karyawan.users_id'] = $this->data['users']->id;
				$this->data['karyawan'] = $this->data_karyawan_model->getAllById($where);
				$this->data['enum_transaksi'] = $this->enum_transaksi_barang_model->getAllById(['jenis_transaksi' => 'tukar_plus']);
				$this->data['barang'] = $this->barang_model->getAllById();
				$this->data['cabang'] = $this->cabang_model->getAllById();

				$this->data['content'] = 'admin/tukar_plus/create_more_v';
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function detail()
	{
		$this->data['id'] = $this->uri->segment(3);
		$this->data['tukar_plus'] = $this->tukar_plus_model->getOneBy(array("tukar_plus.id" => $this->data['id']));
		$this->data['data_tukar_plus_detail'] = $this->tukar_plus_detail_model->getAllById(['tukar_plus_detail.tukar_plus_id' => $this->data['id'], 'tukar_plus_detail.is_deleted' => 0]);
		$this->data['data_tukar_plus_detail_min'] = $this->tukar_plus_detail_model->getAllByIdBKMin(['tukar_plus_detail.tukar_plus_id' => $this->data['id'], 'tukar_plus_detail.is_deleted' => 0]);

		$this->data['cek_insert'] = $this->data['tukar_plus']->tanggal == date('Y-m-d') ? 1 : 0;
		$this->data['content'] = 'admin/tukar_plus/detail_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
		);
		if($this->data['users_groups']->id == 4){
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
			$where['tukar_plus.cabang_id'] = $cabang->id;
		}
		$where['tukar_plus.enum'] = 1;
		$where['tukar_plus.is_deleted'] = 0;

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->tukar_plus_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		$searchColumn = $this->input->post('columns');
        $isSearchColumn = false;

        if(!empty($searchColumn[0]['search']['value'])){
            $value = $searchColumn[0]['search']['value'];
            $isSearchColumn = true;
            $where['tukar_plus.tanggal'] = $value;
        }

        if($isSearchColumn){
			$totalFiltered = $this->tukar_plus_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
			$totalData = $totalFiltered;
        }else{
        	$totalFiltered = $totalData;
        }

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->tukar_plus_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$detail_url = "";
				$add_url = "";

				$detail_url = "<a href='" . base_url() . "tukar_plus/detail/" . $data->id . "' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";
				if($this->data['users_groups']->id == 4){
					if ($data->tanggal == date('Y-m-d')) {
						$add_url = "<a href='".base_url()."tukar_plus/create_more/".$data->id."' class='btn btn-sm btn-success' data-toggle='tooltip' title='Tambah Data' data-placement='bottom'><i class='fa fa-plus fa-w-20'></i></a>";
					}
				}

				$nestedData['id'] = $start + $key + 1;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['jumlah_transaksi'] = $data->jumlah_transaksi;
				$nestedData['total_berat'] = $data->total_berat;
				$nestedData['total_harga_keseluruhan'] = 'Rp. ' . number_format($data->total_harga_keseluruhan);
				$nestedData['action'] = $detail_url.' '.$add_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function dataListAdmin()
	{
		$columns = array(
			0 => 'id',
		);
		$where['tukar_plus.enum'] = 1;
		$where['tukar_plus.is_deleted'] = 0;

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->tukar_plus_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		$searchColumn = $this->input->post('columns');
        $isSearchColumn = false;

        if(!empty($searchColumn[0]['search']['value'])){
            $value = $searchColumn[0]['search']['value'];
            $isSearchColumn = true;
            $where['tukar_plus.tanggal'] = $value;
        }
        if(!empty($searchColumn[1]['search']['value'])){
            $value = $searchColumn[1]['search']['value'];
            $isSearchColumn = true;
            $where['tukar_plus.cabang_id'] = $value;
        }
        if(!empty($searchColumn[2]['search']['value'])){
            $value = $searchColumn[2]['search']['value'];
            $isSearchColumn = true;
            if ($value == 2) {
            	$value = 0;
            }
            $where['tukar_plus.status_audit'] = $value;
        }

        if($isSearchColumn){
			$totalFiltered = $this->tukar_plus_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
			$totalData = $totalFiltered;
        }else{
        	$totalFiltered = $totalData;
        }

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->tukar_plus_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$detail_url = "";
				$add_url = "";
				$audit_url = "";

				$detail_url = "<a href='" . base_url() . "tukar_plus/detail/" . $data->id . "' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";
				if($this->data['is_superadmin']){
					$add_url = "<a href='".base_url()."tukar_plus/create_more/".$data->id."' class='btn btn-sm btn-success' data-toggle='tooltip' title='Tambah Data' data-placement='bottom'><i class='fa fa-plus fa-w-20'></i></a>";
				}
				if ($data->status_audit == 0 && $this->data['users_groups']->id == 3) {
            		$audit_url = "<a href='#' 
	        				url='" . base_url() . "tukar_plus/destroy/" . $data->id . "/" . $data->status_audit . "' class='btn btn-sm btn-danger delete' data-toggle='tooltip' title='Data telah Diaudit' data-placement='bottom'><i class='fa fa-check-circle fa-w-20'></i></a>";
            	}
				$nestedData['id'] = $start + $key + 1;
				$nestedData['cabang'] = $data->nama_cabang;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['jumlah_transaksi'] = $data->jumlah_transaksi;
				$nestedData['total_berat'] = $data->total_berat;
				$nestedData['total_harga_keseluruhan'] = 'Rp. ' . number_format($data->total_harga_keseluruhan);
				$nestedData['status_audit'] = $data->status_audit == 0 ? '<b style="color:red;">Belum</b>' : '<b style="color:green;">Selesai</b>';
           		$nestedData['action'] = $detail_url.' '.$add_url.' '.$audit_url;   
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function destroy()
	{
		$response_data = array();
		$response_data['status'] = false;
		$response_data['msg'] = "";
		$response_data['data'] = array();

		$id = $this->uri->segment(3);
		$status_audit = $this->uri->segment(4);
		if (!empty($id)) {
			$this->load->model("tukar_plus_model");
			$data = array(
				'status_audit' => ($status_audit == 1) ? 0 : 1
			);
			$update = $this->tukar_plus_model->update($data, array("id" => $id));

			$response_data['data'] = $data;
			$response_data['status'] = true;
		} else {
			$response_data['msg'] = "ID Harus Diisi";
		}

		echo json_encode($response_data);
	}

	public function hasil_nota()
	{
		$no_nota = $this->input->get('no_nota');
		$where['no_nota'] = $no_nota;
		$cek = $this->tukar_plus_detail_model->getOneBy($where);

		if ($cek) {
			$data['status'] = true;
			// $data['harga'] = $jenis->harga;
		} else {
			$data['status'] = false;
			// $data['harga'] = '';
		}
		echo json_encode($data);
	}

	public function edit($tukar_plus_detail_id)
	{
		$this->form_validation->set_rules('tukar_plus_detail_id', "tukar_plus_detail_id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$tukar_plus_detail_id = $this->input->post('tukar_plus_detail_id');
			$jenis_tukar = $this->input->post('jenis_tukar');
			//stok opname dulu daks
			// get tukar plus id
			$tukar_plus_detail = $this->tukar_plus_detail_model->getOneBy(['tukar_plus_detail.id' => $tukar_plus_detail_id]);
			$tukar_plus = $this->tukar_plus_model->getOneBy(['tukar_plus.id' => $tukar_plus_detail->tukar_plus_id]);
			$cabang_id = $tukar_plus->cabang_id;
			$penjualan_detail = $this->penjualan_detail_model->getOneBy(array("penjualan_detail.no_nota" => $tukar_plus_detail->no_nota_penjualan));

			$data_stok = $this->histori_stok_barang_model->getAllById(['cabang_id' => $cabang_id]);
			// edit di tukar plus
			if ($jenis_tukar == 1) {
				/*
					kembaliin dulu data sebelumnya
				*/
				// perhitungan stok opname
				$berat_baru = $this->input->post('berat_tp');
				$cek_jenis_barang = $this->barang_model->getOneBy(['id' => $tukar_plus_detail->barang_id]);
				// get histori barang
				$cek_histori = $this->histori_stok_barang_model->getOneBy(['cabang_id' => $cabang_id, 'tanggal' => $tukar_plus->tanggal]);
				
				if($cek_jenis_barang->jenis == '925'){
				    //histori stok kembaliin data sebelumnya
					$stok_925_penjualan = $cek_histori->stok_925_penjualan - $tukar_plus_detail->berat;
					$total_stok_925 = $cek_histori->total_stok_925 - $tukar_plus_detail->berat;
				    $data_histori = array(
				    	'stok_925_penjualan' => $stok_925_penjualan,
				    	'total_stok_925' => $total_stok_925,
				    );
				    //berat baru
				    $stok_925_penjualan_edit = $stok_925_penjualan + $berat_baru;
				    $total_stok_925_edit = $total_stok_925 + $berat_baru;
				    $data_histori_edit = array(
				    	'stok_925_penjualan' => $stok_925_penjualan_edit,
				    	'total_stok_925' => $total_stok_925_edit,
				    );
				    $total_stok_925  = array();
					$stok_925_awal 	= 0;
					$stok_925_akhir 	= 0;
					$tgl_awal 	= '';
					$tgl_akhir 	= '';
					foreach ($data_stok as $key => $value) {
						$total_stok_925[$value->tanggal] = $value->id;
						$total_stok_925[$value->tanggal] = $value->total_stok_925;
						if($stok_925_awal == 0){
							$stok_925_awal = $value->stok_925_awal;
							$tgl_awal = $value->tanggal;
						}
						$tgl_akhir = $value->tanggal;
					}
			
					$tgl_akhir = date('Y-m-d', strtotime('+1 days', strtotime($tgl_akhir)));//agar melebihi 1 hari
					// data yg salah
					//masukkan format tanggal dan jumlah kas yg masuk 
					$tanggal  = $tukar_plus->tanggal;
					$total_stok_925_baru 		= $total_stok_925_edit;

					for($i=$tgl_awal; $i!=$tgl_akhir; $i=date('Y-m-d', strtotime('+1 days', strtotime($i)))){
						
						$data_update_stok_barang = array(
							'stok_925_awal' => $stok_925_awal,
							'total_stok_925' => ($i == $tanggal ? $total_stok_925_baru : $total_stok_925[$i]),
							'stok_925_akhir' => ($i == $tanggal ? $stok_925_awal - $total_stok_925_baru : $stok_925_awal - $total_stok_925[$i]),
							'updated_by' => $this->data['users']->id
						);
						$where_update_stok_925['cabang_id'] = $cabang_id;
						$where_update_stok_925['tanggal'] = $i;
						$update = $this->histori_stok_barang_model->update($data_update_stok_barang, $where_update_stok_925);
						// edit kas di cabang
						$data_stok_cabang = array('stok_925' => ($i == $tanggal ? $stok_925_awal - $total_stok_925_baru : $stok_925_awal - $total_stok_925[$i]));
						$update = $this->cabang_model->update($data_stok_cabang, array("cabang.id" => $cabang_id));
						
						$stok_925_awal -= ($i == $tanggal ? $total_stok_925_baru : $total_stok_925[$i]);
					}
				}else{
					//histori stok kembaliin data sebelumnya
					$stok_sp_penjualan = $cek_histori->stok_sp_penjualan - $tukar_plus_detail->berat;
					$total_stok_sp = $cek_histori->total_stok_sp - $tukar_plus_detail->berat;
				    $data_histori = array(
				    	'stok_sp_penjualan' => $stok_sp_penjualan,
				    	'total_stok_sp' => $total_stok_sp,
				    );
				    //berat baru
				    $stok_sp_penjualan_edit = $stok_sp_penjualan + $berat_baru;
				    $total_stok_sp_edit = $total_stok_sp + $berat_baru;
				    $data_histori_edit = array(
				    	'stok_sp_penjualan' => $stok_sp_penjualan_edit,
				    	'total_stok_sp' => $total_stok_sp_edit,
				    );
				    $total_stok_sp  = array();
					$stok_sp_awal 	= 0;
					$stok_sp_akhir 	= 0;
					$tgl_awal 	= '';
					$tgl_akhir 	= '';
					foreach ($data_stok as $key => $value) {
						$total_stok_sp[$value->tanggal] = $value->id;
						$total_stok_sp[$value->tanggal] = $value->total_stok_sp;
						if($stok_sp_awal == 0){
							$stok_sp_awal = $value->stok_sp_awal;
							$tgl_awal = $value->tanggal;
						}
						$tgl_akhir = $value->tanggal;
					}
			
					$tgl_akhir = date('Y-m-d', strtotime('+1 days', strtotime($tgl_akhir)));//agar melebihi 1 hari
					// data yg salah
					//masukkan format tanggal dan jumlah kas yg masuk 
					$tanggal  = $tukar_plus->tanggal;
					$total_stok_sp_baru 		= $total_stok_sp_edit;

					for($i=$tgl_awal; $i!=$tgl_akhir; $i=date('Y-m-d', strtotime('+1 days', strtotime($i)))){
						
						$data_update_stok_barang = array(
							'stok_sp_awal' => $stok_sp_awal,
							'total_stok_sp' => ($i == $tanggal ? $total_stok_sp_baru : $total_stok_sp[$i]),
							'stok_sp_akhir' => ($i == $tanggal ? $stok_sp_awal - $total_stok_sp_baru : $stok_sp_awal - $total_stok_sp[$i]),
							'updated_by' => $this->data['users']->id
						);
						$where_update_stok_sp['cabang_id'] = $cabang_id;
						$where_update_stok_sp['tanggal'] = $i;
						$update = $this->histori_stok_barang_model->update($data_update_stok_barang, $where_update_stok_sp);
						// edit kas di cabang
						$data_stok_cabang = array('stok_sp' => ($i == $tanggal ? $stok_sp_awal - $total_stok_sp_baru : $stok_sp_awal - $total_stok_sp[$i]));
						$update = $this->cabang_model->update($data_stok_cabang, array("cabang.id" => $cabang_id));
						
						$stok_sp_awal -= ($i == $tanggal ? $total_stok_sp_baru : $total_stok_sp[$i]);
					}
				}
				$where_update_stok['cabang_id'] = $cabang_id;
				$where_update_stok['tanggal'] = $tukar_plus->tanggal;
				$update_stok_histori = $this->histori_stok_barang_model->update($data_histori, $where_update_stok);
				$update_stok_histori_edit = $this->histori_stok_barang_model->update($data_histori_edit, $where_update_stok);
			} else {
				/*
					kembaliin dulu data sebelumnya
				*/
				// perhitungan stok opname
				$berat_lama = $penjualan_detail->berat - $tukar_plus_detail->berat;
				$berat_baru = $this->input->post('berat_tp_min');
				$berat_baru = $penjualan_detail->berat - $berat_baru;

				$cek_jenis_barang = $this->barang_model->getOneBy(['id' => $tukar_plus_detail->barang_id]);
				// get histori barang
				$cek_histori = $this->histori_stok_barang_model->getOneBy(['cabang_id' => $cabang_id, 'tanggal' => $tukar_plus->tanggal]);
				
				if($cek_jenis_barang->jenis == '925'){
				    //histori stok kembaliin data sebelumnya
					$stok_925_kembali = $cek_histori->stok_925_kembali - $berat_lama;
					$total_stok_925 = $cek_histori->total_stok_925 + $berat_lama;
				    $data_histori = array(
				    	'stok_925_kembali' => $stok_925_kembali,
				    	'total_stok_925' => $total_stok_925,
				    );
				    //berat baru
				    $stok_925_kembali_edit = $stok_925_kembali + $berat_baru;
				    $total_stok_925_edit = $total_stok_925 - $berat_baru;
				    $data_histori_edit = array(
				    	'stok_925_kembali' => $stok_925_kembali_edit,
				    	'total_stok_925' => $total_stok_925_edit,
				    );
					$total_stok_925  = array();
					$stok_925_awal 	= 0;
					$stok_925_akhir 	= 0;
					$tgl_awal 	= '';
					$tgl_akhir 	= '';
					// // echo $total_stok_925_edit;
					// echo '<table border="1">
					// 				<th>tanggal</th>
					// 				<th>stok 925 awal</th>
					// 				<th>total_stok_925</th>
					// 				<th>stok_925_akhir</th>';
					foreach ($data_stok as $key => $value) {
						$total_stok_925[$value->tanggal] = $value->id;
						$total_stok_925[$value->tanggal] = $value->total_stok_925;
						if($stok_925_awal == 0){
							$stok_925_awal = $value->stok_925_awal;
							$tgl_awal = $value->tanggal;
						}
						// echo '<tr>
						// 				<td>'.$value->tanggal.'</td>
						// 				<td>'.$value->stok_925_awal.'</td>
						// 				<td>'.$value->total_stok_925.'</td>
						// 				<td>'.$value->stok_925_akhir.'</td>
						// 			</tr>';
						$tgl_akhir = $value->tanggal;
					}
					// echo '</table>';
					$tgl_akhir = date('Y-m-d', strtotime('+1 days', strtotime($tgl_akhir)));//agar melebihi 1 hari
					// data yg salah
					//masukkan format tanggal dan jumlah kas yg masuk 
					$tanggal  = $tukar_plus->tanggal;
					$total_stok_925_baru 		= $total_stok_925_edit;
					// echo "tabel hasil";
					// echo '<table border="1">
					// 				<th>tanggal</th>
					// 				<th>stok 925 awal</th>
					// 				<th>total_stok_925</th>
					// 				<th>stok_925_akhir</th>';
					for($i=$tgl_awal; $i!=$tgl_akhir; $i=date('Y-m-d', strtotime('+1 days', strtotime($i)))){
						
						$data_update_stok_barang = array(
							'stok_925_awal' => $stok_925_awal,
							'total_stok_925' => ($i == $tanggal ? $total_stok_925_baru : $total_stok_925[$i]),
							'stok_925_akhir' => ($i == $tanggal ? $stok_925_awal - $total_stok_925_baru : $stok_925_awal - $total_stok_925[$i]),
							'updated_by' => $this->data['users']->id
						);
						$where_update_stok_925['cabang_id'] = $cabang_id;
						$where_update_stok_925['tanggal'] = $i;
						$update = $this->histori_stok_barang_model->update($data_update_stok_barang, $where_update_stok_925);
						// edit kas di cabang
						$data_stok_cabang = array('stok_925' => ($i == $tanggal ? $stok_925_awal - $total_stok_925_baru : $stok_925_awal - $total_stok_925[$i]));
						$update = $this->cabang_model->update($data_stok_cabang, array("cabang.id" => $cabang_id));
						// echo '<tr>
						// 				<td>'.$i.'</td>
						// 				<td>'.$stok_925_awal.'</td>
						// 				<td>'.($i == $tanggal ? $total_stok_925_baru : $total_stok_925[$i]).'</td>
						// 				<td>'.($i == $tanggal ? $stok_925_awal - $total_stok_925_baru : $stok_925_awal - $total_stok_925[$i]).'</td>
						// 			</tr>';
						
						$stok_925_awal -= ($i == $tanggal ? $total_stok_925_baru : $total_stok_925[$i]);
					}
				}else{
					//histori stok kembaliin data sebelumnya
					$stok_sp_kembali = $cek_histori->stok_sp_kembali - $berat_lama;
					$total_stok_sp = $cek_histori->total_stok_sp + $berat_lama;
				    $data_histori = array(
				    	'stok_sp_kembali' => $stok_sp_kembali,
				    	'total_stok_sp' => $total_stok_sp,
				    );
				    //berat baru
				    $stok_sp_kembali_edit = $stok_sp_kembali + $berat_baru;
				    $total_stok_sp_edit = $total_stok_sp - $berat_baru;
				    $data_histori_edit = array(
				    	'stok_sp_kembali' => $stok_sp_kembali_edit,
				    	'total_stok_sp' => $total_stok_sp_edit,
				    );
					$total_stok_sp  = array();
					$stok_sp_awal 	= 0;
					$stok_sp_akhir 	= 0;
					$tgl_awal 	= '';
					$tgl_akhir 	= '';
					// // echo $total_stok_sp_edit;
					// echo '<table border="1">
					// 				<th>tanggal</th>
					// 				<th>stok sp awal</th>
					// 				<th>total_stok_sp</th>
					// 				<th>stok_sp_akhir</th>';
					foreach ($data_stok as $key => $value) {
						$total_stok_sp[$value->tanggal] = $value->id;
						$total_stok_sp[$value->tanggal] = $value->total_stok_sp;
						if($stok_sp_awal == 0){
							$stok_sp_awal = $value->stok_sp_awal;
							$tgl_awal = $value->tanggal;
						}
						// echo '<tr>
						// 				<td>'.$value->tanggal.'</td>
						// 				<td>'.$value->stok_sp_awal.'</td>
						// 				<td>'.$value->total_stok_sp.'</td>
						// 				<td>'.$value->stok_sp_akhir.'</td>
						// 			</tr>';
						$tgl_akhir = $value->tanggal;
					}
					// echo '</table>';
					$tgl_akhir = date('Y-m-d', strtotime('+1 days', strtotime($tgl_akhir)));//agar melebihi 1 hari
					// data yg salah
					//masukkan format tanggal dan jumlah kas yg masuk 
					$tanggal  = $tukar_plus->tanggal;
					$total_stok_sp_baru 		= $total_stok_sp_edit;
					// echo "tabel hasil";
					// echo '<table border="1">
					// 				<th>tanggal</th>
					// 				<th>stok sp awal</th>
					// 				<th>total_stok_sp</th>
					// 				<th>stok_sp_akhir</th>';
					for($i=$tgl_awal; $i!=$tgl_akhir; $i=date('Y-m-d', strtotime('+1 days', strtotime($i)))){
						
						$data_update_stok_barang = array(
							'stok_sp_awal' => $stok_sp_awal,
							'total_stok_sp' => ($i == $tanggal ? $total_stok_sp_baru : $total_stok_sp[$i]),
							'stok_sp_akhir' => ($i == $tanggal ? $stok_sp_awal - $total_stok_sp_baru : $stok_sp_awal - $total_stok_sp[$i]),
							'updated_by' => $this->data['users']->id
						);
						$where_update_stok_sp['cabang_id'] = $cabang_id;
						$where_update_stok_sp['tanggal'] = $i;
						$update = $this->histori_stok_barang_model->update($data_update_stok_barang, $where_update_stok_sp);
						// edit kas di cabang
						$data_stok_cabang = array('stok_sp' => ($i == $tanggal ? $stok_sp_awal - $total_stok_sp_baru : $stok_sp_awal - $total_stok_sp[$i]));
						$update = $this->cabang_model->update($data_stok_cabang, array("cabang.id" => $cabang_id));
						// echo '<tr>
						// 				<td>'.$i.'</td>
						// 				<td>'.$stok_sp_awal.'</td>
						// 				<td>'.($i == $tanggal ? $total_stok_sp_baru : $total_stok_sp[$i]).'</td>
						// 				<td>'.($i == $tanggal ? $stok_sp_awal - $total_stok_sp_baru : $stok_sp_awal - $total_stok_sp[$i]).'</td>
						// 			</tr>';
						
						$stok_sp_awal -= ($i == $tanggal ? $total_stok_sp_baru : $total_stok_sp[$i]);
					}
				}
				$where_update_stok['cabang_id'] = $cabang_id;
				$where_update_stok['tanggal'] = $tukar_plus->tanggal;
				$update_stok_histori = $this->histori_stok_barang_model->update($data_histori, $where_update_stok);
				$update_stok_histori_edit = $this->histori_stok_barang_model->update($data_histori_edit, $where_update_stok);
			}
			
			$get_id = $this->tukar_plus_detail_model->getOneBy(['tukar_plus_detail.id' => $tukar_plus_detail_id]);
			if ($jenis_tukar == 1) {
				$data_tp = array(
					'potong' => $this->input->post('potong'),
					'potongan_rusak' => $this->input->post('potongan_rusak'),
					'berat_plus' => $this->input->post('berat_tp'),
					'harga_plus' => $this->input->post('harga_konsumen')-5000,
					'berat' => $this->input->post('berat_tp') + $penjualan_detail->berat,
					'harga' => $this->input->post('harga_konsumen')-5000+$penjualan_detail->harga,
					'updated_by' => $this->data['users']->id
				);
			} else {
				$data_tp = array(
					'potong' => $this->input->post('potong'),
					'potongan_rusak' => $this->input->post('potongan_rusak'),
					'berat_min' => $this->input->post('berat_tp_min'),
					'berat' => $this->input->post('selisih_berat'),
					'harga' => $this->input->post('selisih_harga'),
					'updated_by' => $this->data['users']->id
				);
			}
			
			
			$update = $this->tukar_plus_detail_model->update($data_tp, array("id" => $tukar_plus_detail_id));
			if ($jenis_tukar == 2) {
				$data_update_bk = array(
					'berat' => $this->input->post('berat_tp_min'),
					'harga' => $this->input->post('harga_tp'),
					 );
				$update = $this->barang_kembali_detail_model->update($data_update_bk, array("barang_kembali_detail.no_nota" => $get_id->no_nota_penjualan));
			}

			$cek_detail = $this->tukar_plus_detail_model->getAllById(['tukar_plus_detail.tukar_plus_id' => $get_id->tukar_plus_id, 'tukar_plus_detail.enum' => 1]);
			if (!empty($cek_detail)) {
				$total_berat = 0.0;
				$total_harga_keseluruhan = 0;
				$jumlah_transaksi = count($cek_detail);
				foreach ($cek_detail as $key => $value) {
					$total_berat += $value->berat;
					$total_harga_keseluruhan += $value->harga;
				}
				$data_update = array(
					'jumlah_transaksi' 					=> $jumlah_transaksi,
					'total_berat' 					=> $total_berat,
					'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
					'updated_by' => $this->data['users']->id

				); 
				$update = $this->tukar_plus_model->update($data_update,array("tukar_plus.id" => $get_id->tukar_plus_id));
			}
			
			if ($update) {
				$this->session->set_flashdata('message', "Data Barang Tukar Plus Berhasil Diedit");
				redirect("tukar_plus/detail/".$get_id->tukar_plus_id);
			} else {
				$this->session->set_flashdata('message_error', "Data Barang Tukar Plus Gagal Diedit");
				redirect("tukar_plus/detail/".$get_id->tukar_plus_id);
			}
		} else {
			if ($this->data['is_can_edit']) {
				$this->data['tukar_plus_detail_id'] = $tukar_plus_detail_id;
				$this->data['tp'] = $this->tukar_plus_detail_model->getOneBy(array("tukar_plus_detail.id" => $tukar_plus_detail_id));
				if ($this->data['tp']->status == 'Tukar Min') {
					$this->data['tp'] = $this->tukar_plus_detail_model->getOneByMin(array("tukar_plus_detail.id" => $tukar_plus_detail_id));					
				}
				
				
				//
				$where['data_karyawan.is_deleted'] = 0;
				$this->data['karyawan'] = $this->data_karyawan_model->getAllById($where);
				$this->data['enum_transaksi'] = $this->enum_transaksi_barang_model->getOneBy(['id' => $this->data['tp']->jenis_transaksi_id]);
				$this->data['barang'] = $this->barang_model->getAllById();
				// penjualan
				$this->data['penjualan'] = $this->penjualan_detail_model->getOneBy(array("penjualan_detail.no_nota" => $this->data['tp']->no_nota_penjualan));
				
				$this->data['content'] = 'admin/tukar_plus/edit_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function print_nota($tukar_plus_detail_id)
	{
		$tukar_plus_detail = $this->tukar_plus_detail_model->getOneBy(['tukar_plus_detail.id' => $tukar_plus_detail_id]);
		if ($tukar_plus_detail->status_print == 0) {
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
			if ($tukar_plus_detail && $cabang) {
				// ubah status print
		        $data = array('status_print' => 1);
				$update = $this->tukar_plus_detail_model->update($data, ['tukar_plus_detail.id' => $tukar_plus_detail_id]);
				// kedataan tukar_plus
				$number = '0123456789';
				$barcode = substr(str_shuffle($number), 0, 1);
				$tukar_plus = $this->tukar_plus_model->getOneBy(['tukar_plus.id' => $tukar_plus_detail->tukar_plus_id]);
				$data['tukar_plus'] = $tukar_plus;
				$data['barcode'] = $barcode;
				$data['tukar_plus_detail'] = $tukar_plus_detail;
				$data['cabang'] = $cabang;
				$this->load->view('admin/tukar_plus/print_v',$data);
			} else {
				$this->session->set_flashdata('message_error', "Gagal Nota Silahkan Coba Kembali, Apabila Masih Gagal silahkan hubungin Admin Adilla 925");
				redirect("tukar_plus/detail/".$tukar_plus->tukar_plus_id);
			}
		} else {
			// anu matih ieu bisa aya penambahan uang coy
			echo "<script>alert('Nota Telah Diprint, Anda Terdeteksi oleh sistem melakukan print nota Ganda!!!'); history.go(-1);</script>";
		}	
	}

	public function nota_batal($tukar_plus_detail_id)
	{
		
		$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
		//data penjualan
		$data_tukar = $this->tukar_plus_detail_model->getOneBy(['tukar_plus_detail.id' => $tukar_plus_detail_id]);
		
		// ambil data stok barang
		$where['cabang_id'] = $cabang->id;
		$where['tanggal'] = date('Y-m-d');
		$data_stok = $this->histori_stok_barang_model->getOneBy($where);
		// ambil data barang
		$cek_jenis_barang = $this->barang_model->getOneBy(['barang.id' => $data_tukar->barang_id]);
		
		if ($cabang && $data_tukar && $data_stok && $cek_jenis_barang) {
			// ubah status penjualan menjadi terjual
			$data_update = array('penjualan_detail.is_deleted' => 0);
			$this->penjualan_detail_model->update($data_update,array("penjualan_detail.no_nota" => $data_tukar->no_nota_penjualan));
			if ($data_tukar->status == 'Tukar Plus') {
				if ($cek_jenis_barang->jenis == '925') {
					// kantor
				    $stok_akhir = $cabang->stok_925 + $data_tukar->berat_plus;
				    $data_stok_opname_cabang = array('stok_925' => $stok_akhir);
				    // buat cabang
				    $stok_925_penjualan = $data_stok->stok_925_penjualan - $data_tukar->berat_plus;
				    $total_stok_925 = $data_stok->total_stok_925 - $data_tukar->berat_plus;
				    $stok_925_akhir = $data_stok->stok_925_akhir + $data_tukar->berat_plus;
				    //histori stok
				    $data_histori = array(
				    	'stok_925_penjualan' => $stok_925_penjualan,
				    	'total_stok_925' => $total_stok_925,
				    	'stok_925_akhir' => $stok_925_akhir,
				    );
				}else{
					// kantor
				    $stok_akhir = $cabang->stok_sp + $data_tukar->berat_plus;
				    $data_stok_opname_cabang = array('stok_sp' => $stok_akhir);
				    // buat cabang
				    $stok_sp_penjualan = $data_stok->stok_sp_penjualan - $data_tukar->berat_plus;
				    $total_stok_sp = $data_stok->total_stok_sp - $data_tukar->berat_plus;
				    $stok_sp_akhir = $data_stok->stok_sp_akhir + $data_tukar->berat_plus;
				    //histori stok
				    $data_histori = array(
				    	'stok_sp_penjualan' => $stok_sp_penjualan,
				    	'total_stok_sp' => $total_stok_sp,
				    	'stok_sp_akhir' => $stok_sp_akhir,
				    );
				}
			} else {
				// get data barang kembali guys
				$data_bk = $this->barang_kembali_detail_model->getOneBy(['barang_kembali_detail.no_nota' => $data_tukar->no_nota_penjualan]);
				$cek_jenis_barang = $this->barang_model->getOneBy(['barang.id' => $data_bk->barang_id]);
				// nota batal tukar min
				if ($cek_jenis_barang->jenis == '925') {
					// kantor
				    $stok_akhir = $cabang->stok_925 - $data_bk->berat;
				    $data_stok_opname_cabang = array('stok_925' => $stok_akhir);
				    //data histori
				    $stok_925_kembali = $data_stok->stok_925_kembali - $berat_tm;
				    $total_stok_925 = $data_stok->total_stok_925 + $berat_tm;
				    $stok_925_akhir = $data_stok->stok_925_akhir - $berat_tm;
				    $data_histori = array(
				    	'stok_925_kembali' => $stok_925_kembali,
				    	'total_stok_925' => $total_stok_925,
				    	'stok_925_akhir' => $stok_925_akhir,
				    );
				}else{
					// kantor
				    $stok_akhir = $cabang->stok_sp - $data_bk->berat;
				    $data_stok_opname_cabang = array('stok_sp' => $stok_akhir);
				    //data histori
				    $stok_sp_kembali = $data_stok->stok_sp_kembali - $berat_tm;
				    $total_stok_sp = $data_stok->total_stok_sp + $berat_tm;
				    $stok_sp_akhir = $data_stok->stok_sp_akhir - $berat_tm;
				    $data_histori = array(
				    	'stok_sp_kembali' => $stok_sp_kembali,
				    	'total_stok_sp' => $total_stok_sp,
				    	'stok_sp_akhir' => $stok_sp_akhir,
				    );
				}
			}
			// die();
			// update stok kantor
			$where_update_kantor['cabang.id'] = $cabang->id;
			$kantor = $this->cabang_model->update($data_stok_opname_cabang, $where_update_kantor);
			// update histori stok barang
			$where_update_cabang['histori_stok_barang.id'] = $data_stok->id;
			$histori_stok_cabang = $this->histori_stok_barang_model->update($data_histori, $where_update_cabang);
			//update data penjualan  menjadi batal
			$data_tukar_plus_detail = array(
				'berat_plus' => 0,
				'harga_plus' => 0,
				'enum' => 1,
				'tukar_plus_id' => $data_tukar->tukar_plus_id,
				'karyawan_id' => $data_tukar->karyawan_id,
				'no_nota' => $data_tukar->no_nota,
				'barang_id' => 0,
				'jenis_transaksi_id' => 0,
				'berat' => 0,
				'potong' => 0,
				'potongan_rusak' => 0,
				'harga' => 0,
				'status' => 'Nota Batal',
				'status_print' => 2,
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			$data_update_nota = array(
					'status' => 3
			);
			// update status nota di tabel nota
			$where_update_nota['nota.no_nota'] = $data_tukar->no_nota;
			$where_update_nota['nota.jenis_nota'] = 1;
			$where_update_nota['nota.status_stok_nota'] = 1;
			$nota_update = $this->nota_model->update($data_update_nota, $where_update_nota);
			// tukar_plus_detail
			$penjualan_detail_update = $this->tukar_plus_detail_model->update($data_tukar_plus_detail, ['tukar_plus_detail.id' => $data_tukar->id]);
			$no_nota = explode('~', $data_tukar->no_nota);

			// update total penjualan
			$where_cek_detail['tukar_plus_detail.tukar_plus_id'] = $data_tukar->tukar_plus_id;
			$where_cek_detail['tukar_plus_detail.is_deleted'] = 0;
			$where_cek_detail['tukar_plus_detail.barang_id !='] = 0;
			$cek_detail = $this->tukar_plus_detail_model->getAllById($where_cek_detail);
			if (!empty($cek_detail)) {
				$total_berat = 0.0;
				$total_harga_keseluruhan = 0;
				$jumlah_transaksi = count($cek_detail);
				foreach ($cek_detail as $key => $value) {
					if ($value->status == 'Tukar Plus') {
						$total_berat += $value->berat_plus;
					} else {
						$total_berat += $value->berat_min;
					}
					
					$total_harga_keseluruhan += $value->harga_plus;
				}
				$data_update_tukar = array(
					'jumlah_transaksi' 					=> $jumlah_transaksi,
					'total_berat' 					=> $total_berat,
					'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
					'updated_by' => $this->data['users']->id

				); 
				$update_master_tukar = $this->tukar_plus_model->update($data_update_tukar,array("tukar_plus.id" => $data_tukar->tukar_plus_id));
			}
			if ($update_master_tukar)
			{ 
				$this->session->set_flashdata('message', "Data Penjualan Nota ".$no_nota[0]." menjadi Nota Batal");
				redirect("tukar_plus/detail/".$data_tukar->tukar_plus_id);
			}
			else
			{
				$this->session->set_flashdata('message_error',"Data transaksi Baru Gagal Disimpan");
				redirect("tukar_plus");
			}
			
		} else {
			$this->session->set_flashdata('message_error',"Ubah nota Batal terjadi error, silahkan coba lagi");
			redirect("tukar_plus");
		}
	}

	public function print_nota_perhari()
	{	
		// get cabang
		$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
		$data['cabang'] = $cabang->nama_cabang;
		$this->data['id'] = $this->uri->segment(3);
		$data['tukar_plus'] = $this->tukar_plus_model->getOneBy(array("tukar_plus.id" => $this->data['id']));
		$data['data_tukar_plus_detail'] = $this->tukar_plus_detail_model->getAllById(['tukar_plus_detail.tukar_plus_id' => $this->data['id'], 'tukar_plus_detail.is_deleted' => 0]);
		if (!empty($data['data_tukar_plus_detail'])) {
			require_once BASEPATH. 'vendor/autoload.php';
	        $mpdf = new \Mpdf\Mpdf(['orientation' => 'L']);
	        $html = $this->load->view('admin/tukar_plus/print_nota_perhari_v',$data,TRUE);
	        // print_r($html);
	        // die();
	        $mpdf->WriteHTML($html);
	        // $mpdf->Output("laporan-nota-terjual~".$tanggal.'-'.time().".pdf","I");
	        $mpdf->Output("laporan-nota-terjual-".time().".pdf","I");
		} else {
			# code...
		}


		// $this->data['cek_insert'] = $this->data['tukar_plus']->tanggal == date('Y-m-d') ? 1 : 0;
		// $this->data['content'] = 'admin/tukar_plus/detail_v';
		// $this->load->view('admin/layouts/page', $this->data);
	}
}
