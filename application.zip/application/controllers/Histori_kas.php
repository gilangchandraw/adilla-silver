<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class histori_kas extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('cabang_model');
		$this->load->model('histori_kas_model');
	}


	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$this->data['cabang'] = $this->cabang_model->getAllById();
			$this->data['content'] = 'admin/histori_kas/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function get_data()
	{
		$cabang_id = $this->input->get('cabang_id');
		$bulan_tahun = $this->input->get('bulan_tahun');

		$bulan_tahun = explode('-', $bulan_tahun);
		$bulan = $bulan_tahun[0];
		$tahun = $bulan_tahun[1];
		$no_bulan = $bulan;
		if ($bulan < 10) {
			$no_bulan = explode(0, $bulan);
			$no_bulan = $no_bulan[1];
		}
		// inisialisasi nama bulan
		if ($no_bulan == 1) {
			$nama_no_bulan = 'Januari';
		}elseif ($no_bulan == 2) {
			$nama_bulan = 'Februari';
		}elseif ($no_bulan == 3) {
			$nama_bulan = 'Maret';
		}elseif ($no_bulan == 4) {
			$nama_bulan = 'April';
		}elseif ($no_bulan == 5) {
			$nama_bulan = 'Mei';
		}elseif ($no_bulan == 6) {
			$nama_bulan = 'Juni';
		}elseif ($no_bulan == 7) {
			$nama_bulan = 'Juli';
		}elseif ($no_bulan == 8) {
			$nama_bulan = 'Agustus';
		}elseif ($no_bulan == 9) {
			$nama_bulan = 'September';
		}elseif ($no_bulan == 10) {
			$nama_bulan = 'Oktober';
		}elseif ($no_bulan == 11) {
			$nama_bulan = 'November';
		}elseif ($no_bulan == 12) {
			$nama_bulan = 'Desember';
		}

		$where = [];

		if ($cabang_id) {
			$where['histori_kas.cabang_id'] = $cabang_id;
			$cabang = $this->cabang_model->getOneBy(['cabang.id' => $cabang_id]);
		}

		if ($bulan_tahun) {
			$where['MONTH(histori_kas.tanggal)'] = $no_bulan;
			$where['YEAR(histori_kas.tanggal)'] = $tahun;
		}

		$data_kas = $this->histori_kas_model->getAllById($where);
		$html = '';
		if (!empty($data_kas)) {
			$html .='<div class="main-card mb-3 card">
                            <div class="card-body">
                                <section class="content">
                                    <div class="box box-default color-palette-box">
                                        <div class="box-body">
                                            <div class="row" id="body_report">
                                                <div class="col-md-12 mb-15" style="page-break-after: always; margin: auto; border: 8px; padding: 10px;">
                                                    <div class="paycheck-container">
                                                        <div class="full-width paycheck-logo">
                                                            <span></span>
                                                            <p class="text-right"></p>
                                                        </div>
                                                        <div class="table-responsive">
                                                        <table class="table-paycheck table table-border" align="center">
                                                            <tbody>
                                                                <tr>
                                                                    <td rowspan="3"><img style="height: 50px" src="'.base_url().'assets/images/logo.png"></td>
                                                                    <td class="text-center">ADILLA SILVER 925 GROUP</td>
                                                                </tr>
                                                                <tr>
                                                                    <td align="center" class="text-center">History Kas Cabang '. $cabang->nama_cabang.'</td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="text-center"> Bulan  '.$nama_bulan.' Tahun '.$tahun.'</td>
                                                                </tr>
                                                            </tbody>
                                                        </table>
                                                        <table class="table-paycheck table table-border" border="1">
                                                            <thead>
                                                                    <th class="text-center">Tanggal</th>
                                                                    <th class="text-center">Kas Awal</th>
                                                                    <th class="text-center">Kas Masuk</th>
                                                                    <th class="text-center">Kas Akhir</th>
                                                                    <th class="text-center">Aksi</th>
                                                            </thead>
                                                            <tbody>';
                                                            foreach ($data_kas as $key => $value) {
                                                            	$html .= '<tr>';
                                                                    $html .= '<td class="text-center">'.$value->tanggal.'</td>';
                                                                    $html .= '<td class="text-center">'.number_format($value->kas_awal).'</td>';
                                                                    $html .= '<td class="text-center">'.number_format($value->kas_masuk).'</td>';
                                                                    $html .= '<td class="text-center">'.number_format($value->kas_akhir).'</td>';
                                                                    $html .= '<td class="text-center"><a href="'.base_url().'histori_kas/edit/'.$value->id.'" class="btn btn-sm btn-warning" data-toggle="tooltip" title="Edit Data" data-placement="bottom"><i class="fa fa-edit fa-w-20"></i></a></td>';
                                                                $html .= '</tr>';
                                                            }
                                                                
                                                            $html .='</tbody>
                                                        </table>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </section>
                            </div>
                        </div>';
            $fix_data['status'] = true;
            $fix_data['html'] = $html;
		}else{
			$html .= 
            '<div class="main-card mb-3 card">
                <div class="card-body"> <h2>Tidak ada Data Kas</h2>';
                
            $html .= '</div>
            </div>';
            $fix_data['html'] = $html;
			$fix_data['status'] = false;
		}
		echo json_encode($fix_data);
	}

	public function edit()
	{
		$this->form_validation->set_rules('id', "id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$id = $this->input->post('id');
			$cabang_id = $this->input->post('cabang_id');
			$tanggal = $this->input->post('tanggal');
			$kas_masuk_data = $this->input->post('kas_masuk');
			$kas_awal = $this->input->post('kas_awal');
			$kas_akhir = $this->input->post('kas_akhir');

			$kas_akhir_baru = $kas_awal + $kas_masuk_data;
			$data_kas_detail = array(
				'kas_awal' => $this->input->post('kas_awal'),
				'kas_masuk' => $this->input->post('kas_masuk'),
				'kas_akhir' => $kas_akhir_baru,
				'updated_by' => $this->data['users']->id
			);
			$update_kas_detail = $this->histori_kas_model->update($data_kas_detail, array("id" => $id));

			$data_kas_baru = $this->histori_kas_model->getOneBy(['histori_kas.id' => $id]);

			$data_kas = $this->histori_kas_model->getAllById(['cabang_id' => $cabang_id]);
			$kas_masuk  = array();
			$kas_awal 	= 0;
			$kas_akhir 	= 0;
			$tgl_awal 	= '';
			$tgl_akhir 	= '';

			foreach ($data_kas as $key => $value) {
				$kas_masuk[$value->tanggal] = $value->id;
				$kas_masuk[$value->tanggal] = $value->kas_masuk;
				if($kas_awal == 0){
					$kas_awal = $value->kas_awal;
					$tgl_awal = $value->tanggal;
				}
				$tgl_akhir = $value->tanggal;
			}
			$tgl_akhir = date('Y-m-d', strtotime('+1 days', strtotime($tgl_akhir)));//agar melebihi 1 hari

			$kas 		= $data_kas_baru->kas_masuk;
			for($i=$tgl_awal; $i!=$tgl_akhir; $i=date('Y-m-d', strtotime('+1 days', strtotime($i)))){	
				$data_update_kas = array(
					'kas_awal' => $kas_awal,
					'kas_masuk' => ($i == $tanggal ? $kas : $kas_masuk[$i]),
					'kas_akhir' => ($i == $tanggal ? $kas+$kas_awal : $kas_masuk[$i]+$kas_awal),
					'updated_by' => $this->data['users']->id
				);
				$where_update_kas['histori_kas.tanggal'] = $i;
				$where_update_kas['histori_kas.cabang_id'] = $cabang_id;
				// echo $i.'<br>';
				// echo '<pre>',print_r($data_update_kas,1),'</pre>';
				$update = $this->histori_kas_model->update($data_update_kas, $where_update_kas);
				// edit kas di cabang
				$data_kas_cabang = array('kas'=> ($i == $tanggal ? $kas+$kas_awal : $kas_masuk[$i]+$kas_awal));
				$update = $this->cabang_model->update($data_kas_cabang, array("cabang.id" => $cabang_id));
				
				$kas_awal += ($i == $tanggal ? $kas : $kas_masuk[$i]);
			}
			$this->session->set_flashdata('message', "Data Histori Kas Berhasil Diedit");
			redirect("histori_kas");
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("cabang/edit/" . $id);
			} else {
				if ($this->data['is_can_edit']) {
					$this->data['id'] = $this->uri->segment(3);
					$this->data['kas'] = $this->histori_kas_model->getOneBy(array("histori_kas.id" => $this->data['id']));
					$this->data['content'] = 'admin/histori_kas/edit_v';
				} else {
					$this->data['content']  = 'errors/html/restrict';
				}
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	
}
