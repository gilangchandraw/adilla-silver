<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Laporan_harian extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('cabang_model');
		$this->load->model('penjualan_model');
		$this->load->model('penjualan_detail_model');
		$this->load->model('enum_transaksi_barang_model');
		$this->load->model('barang_kembali_model');
		$this->load->model('tukar_plus_model');
		$this->load->model('tukar_plus_detail_model');
		$this->load->model('barang_kembali_detail_model');
		$this->load->model('pengeluaran_model');
		$this->load->model('pengeluaran_detail_model');
		$this->load->model('enum_pengeluaran_model');
		$this->load->model('histori_kas_model');
		$this->load->model('barang_rusak_model');
		$this->load->model('barang_hilang_model');
		$this->load->model('uang_laci_model');
		$this->load->model('transaksi_sepuhan_model');
		$this->load->model('transaksi_sepuhan_detail_model');
		$this->load->model('transaksi_kotak_cincin_model');
		$this->load->model('transaksi_kotak_cincin_detail_model');
	}

	public function fixing(){
		// $where_kas['histori_kas.cabang_id'] = ?;
		// $data_kas = $this->histori_kas_model->getAllById($where_kas);
		$data_kas = $this->histori_kas_model->getAllById();
		$kas_masuk  = array();
		$kas_awal 	= 0;
		$kas_akhir 	= 0;
		$tgl_awal 	= '';
		$tgl_akhir 	= '';
		echo '<table border="1">
									<th>tanggal</th>
									<th>kas awal</th>
									<th>kas masuk</th>
									<th>kas akhir</th>';
		foreach ($data_kas as $key => $value) {
			$kas_masuk[$value->tanggal] = $value->id;
			$kas_masuk[$value->tanggal] = $value->kas_masuk;
			if($kas_awal == 0){
				$kas_awal = $value->kas_awal;
				$tgl_awal = $value->tanggal;
			}
			$tgl_akhir = $value->tanggal;
			echo '<tr>
										<td>'.$value->tanggal.'</td>
										<td>'.number_format($value->kas_awal).'</td>
										<td>'.number_format($value->kas_masuk).'</td>
										<td>'.number_format($value->kas_akhir).'</td>
									</tr>';
		}
		echo '</table>';
		$tgl_akhir = date('Y-m-d', strtotime('+1 days', strtotime($tgl_akhir)));//agar melebihi 1 hari
		// data yg salah
		//masukkan format tanggal dan jumlah kas yg masuk 
		$tanggal  = '2020-05-20';
		$kas 		= 150000;

		echo '<br>'.$tanggal.'<br>'.number_format($kas).'<br>';
		echo 'tabel hasil';
						echo '<table border="1">
									<th>tanggal</th>
									<th>kas awal</th>
									<th>kas masuk</th>
									<th>kas akhir</th>';
						for($i=$tgl_awal; $i!=$tgl_akhir; $i=date('Y-m-d', strtotime('+1 days', strtotime($i)))){
							
							$data_update_kas = array(
								'kas_awal' => $kas_awal,
								'kas_masuk' => ($i == $tanggal ? $kas : $kas_masuk[$i]),
								'kas_akhir' => ($i == $tanggal ? $kas+$kas_awal : $kas_masuk[$i]+$kas_awal),
								'updated_by' => $this->data['users']->id
							);
							$update = $this->histori_kas_model->update($data_update_kas, array("histori_kas.tanggal" => $i));
							// edit kas di cabang
							$data_kas_cabang = array('kas'=> ($i == $tanggal ? $kas+$kas_awal : $kas_masuk[$i]+$kas_awal));
							$update = $this->cabang_model->update($data_kas_cabang, array("cabang.id" => 1));
							echo '<tr>
										<td>'.$i.'</td>
										<td>'.number_format($kas_awal).'</td>
										<td>'.($i == $tanggal ? number_format($kas) : number_format($kas_masuk[$i])).'</td>
										<td>'.($i == $tanggal ? number_format($kas+$kas_awal) : number_format($kas_masuk[$i]+$kas_awal)).'</td>
									</tr>';
									$kas_awal += ($i == $tanggal ? $kas : $kas_masuk[$i]);
						}
						echo '</table>';
		// for($i=$tgl_awal; $i!=$tgl_akhir; $i=date('Y-m-d', strtotime('+1 days', strtotime($i)))){

		// }
		// print_r($kas_masuk);

	}

	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$this->data['cabang'] = $this->cabang_model->getAllById();
			$this->data['content'] = 'admin/laporan_harian/create_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function get_data(){
		// get data cabang untuk kasir
		$data_cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
		// $laporan = $this->input->get('laporan');
		// if ($laporan == "pembukuan") {
		// 	$laporan = 0;
		// }
		$cabang_id = $this->input->get('cabang_id');
		if ($this->data['users_groups']->id == 4) {
			$cabang_id = $data_cabang->id;
			$laporan = 1;
		}
		$laporan = 1;
		$tanggal = $this->input->get('tanggal');

		$cek_garut = 0;
		if ($cabang_id == 11) {
			$expire = '2020-08-01';
			$today_time = strtotime($tanggal);
			$expire_time = strtotime($expire);
			if ($today_time < $expire_time) {
				$cek_garut = 1;
			}
		}
		if ($cek_garut == 0) {
			//penjualan
			$where_penjualan['penjualan.tanggal'] = $tanggal;
			$where_penjualan['penjualan.cabang_id'] = $cabang_id;
			$where_penjualan['penjualan.enum'] = $laporan;
			if ($this->data['users_groups']->id == 4) {
				$where_penjualan['penjualan.cabang_id'] = $data_cabang->id;
				$where_penjualan['penjualan.enum'] = 1;
			}
			$where_penjualan['penjualan.is_deleted'] = 0;
			$penjualan = $this->penjualan_model->getOneBy($where_penjualan);
			//bk
			$where_bk['barang_kembali.tanggal'] = $tanggal;
			$where_bk['barang_kembali.cabang_id'] = $cabang_id;
			$where_bk['barang_kembali.enum'] = $laporan;
			if ($this->data['users_groups']->id == 4) {
				$where_bk['barang_kembali.cabang_id'] = $data_cabang->id;
				$where_bk['barang_kembali.enum'] = 1;
			}
			$barang_kembali = $this->barang_kembali_model->getOneBy($where_bk);
			//tukar plus
			$where_tukar['tukar_plus.tanggal'] = $tanggal;
			$where_tukar['tukar_plus.cabang_id'] = $cabang_id;
			$where_tukar['tukar_plus.enum'] = $laporan;
			if ($this->data['users_groups']->id == 4) {
				$where_tukar['tukar_plus.cabang_id'] = $data_cabang->id;
				$where_tukar['tukar_plus.enum'] = 1;
			}
			$tukar = $this->tukar_plus_model->getOneBy($where_tukar);
			//pengeluaran
			$where_pengeluaran['pengeluaran.tanggal'] = $tanggal;
			$where_pengeluaran['pengeluaran.cabang_id'] = $cabang_id;
			$where_pengeluaran['pengeluaran.enum'] = $laporan;
			if ($this->data['users_groups']->id == 4) {
				$where_pengeluaran['pengeluaran.cabang_id'] = $data_cabang->id;
				$where_pengeluaran['pengeluaran.enum'] = 1;
			}		
			$pengeluaran = $this->pengeluaran_model->getOneBy($where_pengeluaran);
			//kas
			$where_kas['tanggal'] = $tanggal;
			$where_kas['cabang_id'] = $cabang_id;
			$kas = $this->histori_kas_model->getOneBy($where_kas);
			//uang laci
			$where_laci['tanggal'] = $tanggal;
			$where_laci['cabang_id'] = $cabang_id;
			$uang_laci = $this->uang_laci_model->getOneBy($where_laci);
			//sepuhan
			$where_sepuhan['tanggal'] = $tanggal;
			$where_sepuhan['cabang_id'] = $cabang_id;
			$sepuhan = $this->transaksi_sepuhan_model->getOneBy($where_sepuhan);
			//kc
			$where_kc['tanggal'] = $tanggal;
			$where_kc['cabang_id'] = $cabang_id;
			$kc = $this->transaksi_kotak_cincin_model->getOneBy($where_kc);

			if($penjualan || $barang_kembali || $tukar || $pengeluaran || $uang_laci || $sepuhan || $kc){

				$where_pk['penjualan_detail.penjualan_id'] = $penjualan->id;
				$penjualan_detail = $this->penjualan_detail_model->getAllById($where_pk);
				$berat_penjualan_25 = 0.0;
				$harga_penjualan_25 = 0;
				$berat_penjualan_30 = 0.0;
				$harga_penjualan_30 = 0;
				$berat_penjualan_35 = 0.0;
				$harga_penjualan_35 = 0;				
				// total penjualan berat dan harga
				$total_penjualan_berat = 0;
				$total_penjualan_harga = 0;
				if (!empty($penjualan_detail)) {
					foreach ($penjualan_detail as $key => $value) {
						$total_penjualan_berat += $value->berat;
						$total_penjualan_harga += $value->harga;
						if ($value->jenis_transaksi_id == 1) {
							$berat_penjualan_25 += $value->berat;
							$harga_penjualan_25 += $value->harga;
						}elseif ($value->jenis_transaksi_id == 2) {
							$berat_penjualan_30 += $value->berat;
							$harga_penjualan_30 += $value->harga;

						}elseif ($value->jenis_transaksi_id == 3) {
							$berat_penjualan_35 += $value->berat;
							$harga_penjualan_35 += $value->harga;
						}
					}
				}
				$tukar_detail = false;
				if (!empty($tukar)) {
					$where_tukar_detail['tukar_plus_detail.tukar_plus_id'] = $tukar->id;
					$where_tukar_detail['tukar_plus_detail.status'] = 'Tukar Plus';
					// $where_tukar_detail['tukar_plus_detail.is_deleted'] = 0;
					$where_tukar_detail['tukar_plus_detail.barang_id !='] = 0;
					$tukar_detail = $this->tukar_plus_detail_model->getAllById($where_tukar_detail);
				}
				// inisialisasi
				$berat_tukar_25 = 0.0;
				$harga_tukar_25 = 0;
				$berat_tukar_30 = 0.0;
				$harga_tukar_30 = 0;
				$berat_tukar_35 = 0.0;
				$harga_tukar_35 = 0;
				// total penjualan berat dan harga
				$total_tukar_berat = 0;
				$total_tukar_harga = 0;

				if ($tukar_detail) {
					foreach ($tukar_detail as $key => $value) {
						$total_tukar_berat += $value->berat_plus;
						if ($value->potongan_rusak != 0) {
							$total_tukar_harga += $value->harga_plus - $value->potongan_rusak;
						}else{
							$total_tukar_harga += $value->harga_plus;
						}
						if ($value->jenis_transaksi_id == 1) {
							$berat_tukar_25 += $value->berat_plus;
							if ($value->potongan_rusak != 0) {
								$harga_tukar_25 += $value->harga_plus - $value->potongan_rusak;
							}else{
								$harga_tukar_25 += $value->harga_plus;
							}
						}elseif ($value->jenis_transaksi_id == 2) {
							$berat_tukar_30 += $value->berat_plus;
							if ($value->potongan_rusak != 0) {
								$harga_tukar_30 += $value->harga_plus - $value->potongan_rusak;
							}else{
								$harga_tukar_30 += $value->harga_plus;
							}

						}elseif ($value->jenis_transaksi_id == 3) {
							$berat_tukar_35 += $value->berat_plus;
							if ($value->potongan_rusak != 0) {
								$harga_tukar_35 += $value->harga_plus - $value->potongan_rusak;
							}else{
								$harga_tukar_35 += $value->harga_plus;
							}
						}
					}
				}
				$total_berat_penjualan = 0.0;
				$total_harga_penjualan = 0;
				if ($penjualan && $tukar) {
					$total_berat_penjualan = $total_penjualan_berat + $total_tukar_berat;
					$total_harga_penjualan = $total_penjualan_harga + $total_tukar_harga;
				}else{
					$total_berat_penjualan = $total_penjualan_berat;
					$total_harga_penjualan = $total_penjualan_harga;
				}
				$barang_rusak = [];
				$barang_hilang = [];
				if (!empty($barang_kembali)) {
					$where_bk_detail['barang_kembali_detail.barang_kembali_id'] = $barang_kembali->id;
					$where_bk_detail['barang_kembali_detail.is_deleted'] = 0;
					$bk_detail = $this->barang_kembali_detail_model->getAllById($where_bk_detail);
					$data_barang_rusak = $this->barang_rusak_model->getAllById(['barang_kembali_id' => $barang_kembali->id]);
					if ($data_barang_rusak) {
						$barang_rusak = $data_barang_rusak;
					}
					$data_barang_hilang = $this->barang_hilang_model->getAllById(['barang_kembali_id' => $barang_kembali->id]);
					if ($data_barang_hilang) {
						$barang_hilang = $data_barang_hilang;
					}
				}
				$berat_bk_20 = 0.0;
				$harga_bk_20 = 0;
				//
				$berat_bk_22 = 0.0;
				$harga_bk_22 = 0;
				//
				$berat_bk_23 = 0.0;
				$harga_bk_23 = 0;
				//
				$berat_bk_24 = 0.0;
				$harga_bk_24 = 0;
				//
				$berat_bk_29 = 0.0;
				$harga_bk_29 = 0;
				//
				$berat_bk_25 = 0.0;
				$harga_bk_25 = 0;
				//
				$berat_bk_27 = 0.0;
				$harga_bk_27 = 0;
				//
				$berat_bk_28 = 0.0;
				$harga_bk_28 = 0;
				//
				$berat_bk_30 = 0.0;
				$harga_bk_30 = 0;
				//
				$berat_bk_19 = 0.0;
				$harga_bk_19 = 0;
				//
				$berat_bk_18 = 0.0;
				$harga_bk_18 = 0;
				//
				$berat_bk_17 = 0.0;
				$harga_bk_17 = 0;
				//
				//total
				$total_berat_bk = 0.0;
				$total_harga_bk = 0;
				$data_uda = [];
				if(!empty($bk_detail)){
					foreach ($bk_detail as $key => $value) {
						if ($value->jenis_transaksi_id == 7) {
							$berat_bk_20 += $value->berat;
							$harga_bk_20 += $value->harga;
						}elseif ($value->jenis_transaksi_id == 8) {
							$berat_bk_22 += $value->berat;
							$harga_bk_22 += $value->harga;
						}elseif ($value->jenis_transaksi_id == 9) {
							$berat_bk_23 += $value->berat;
							$harga_bk_23 += $value->harga;
						}elseif ($value->jenis_transaksi_id == 10) {
							$berat_bk_25 += $value->berat;
							$harga_bk_25 += $value->harga;
						}elseif ($value->jenis_transaksi_id == 11) {
							$berat_bk_27 += $value->berat;
							$harga_bk_27 += $value->harga;
						}elseif ($value->jenis_transaksi_id == 12) {
							$berat_bk_30 += $value->berat;
							$harga_bk_30 += $value->harga;
						}elseif ($value->jenis_transaksi_id == 13) {
							$berat_bk_28 += $value->berat;
							$harga_bk_28 += $value->harga;
						}elseif ($value->jenis_transaksi_id == 14) {
							$berat_bk_19 += $value->berat;
							$harga_bk_19 += $value->harga;
						}elseif ($value->jenis_transaksi_id == 15) {
							$berat_bk_18 += $value->berat;
							$harga_bk_18 += $value->harga;
						}elseif ($value->jenis_transaksi_id == 16) {
							$berat_bk_17 += $value->berat;
							$harga_bk_17 += $value->harga;
						}elseif ($value->jenis_transaksi_id == 17) {
							$berat_bk_29 += $value->berat;
							$harga_bk_29 += $value->harga;
						}elseif ($value->jenis_transaksi_id == 18) {
							$berat_bk_24 += $value->berat;
							$harga_bk_24 += $value->harga;
						}
					}
				}

				$total_berat_bk = $berat_bk_20 + $berat_bk_22 + $berat_bk_23 + $berat_bk_25 + $berat_bk_27 + $berat_bk_28 + $berat_bk_30 + $berat_bk_19 + $berat_bk_18 + $berat_bk_17 + $berat_bk_24 + $berat_bk_29;
				$total_harga_bk = $harga_bk_20 + $harga_bk_22 + $harga_bk_23 + $harga_bk_25 + $harga_bk_27 + $harga_bk_28 + $harga_bk_30 + $harga_bk_19 + $harga_bk_18 + $harga_bk_17 + $harga_bk_24 + $harga_bk_29;;
				// pengeluaran
				$total_pengeluaran = 0;
				if (!empty($pengeluaran)) {
					$where_pengeluaran_detail['pengeluaran_detail.pengeluaran_id'] = $pengeluaran->id;
					$pengeluaran_detail = $this->pengeluaran_detail_model->getAllById($where_pengeluaran_detail);
					if (!empty($pengeluaran_detail)) {
						foreach ($pengeluaran_detail as $key => $value) {
							$total_pengeluaran += $value->harga;
						}
					}
				}
				// get data kas
				$cabang = $this->cabang_model->getOneBy(['cabang.id' => $cabang_id]);
				if ($kas) {
					// perhitungan kas
					$total_kas = $kas->kas_awal + $total_harga_penjualan;
					$total_kas = $total_kas - $total_harga_bk;
					$total_kas = $total_kas - $total_pengeluaran;
					//perhitungan kas masuk
					$kas_masuk = $total_harga_penjualan - $total_harga_bk;
					$total_kas_masuk = $kas_masuk - $total_pengeluaran;
					// cek if
					if($total_kas == $kas->kas_akhir && $kas_masuk == $kas->kas_masuk){
						$total_kas = $kas->kas_akhir;
					}else{
						//get data histori kas
						$data_kas = $this->histori_kas_model->getAllById(['cabang_id' => $cabang_id]);
						$kas_masuk  = array();
						$kas_awal 	= 0;
						$kas_akhir 	= 0;
						$tgl_awal 	= '';
						$tgl_akhir 	= '';

						foreach ($data_kas as $key => $value) {
							$kas_masuk[$value->tanggal] = $value->id;
							$kas_masuk[$value->tanggal] = $value->kas_masuk;
							if($kas_awal == 0){
								$kas_awal = $value->kas_awal;
								$tgl_awal = $value->tanggal;
							}
							$tgl_akhir = $value->tanggal;
						}
						$tgl_akhir = date('Y-m-d', strtotime('+1 days', strtotime($tgl_akhir)));//agar melebihi 1 hari
						// data kas masuk dan tanggal yg bermasalah
						$tanggal  = $tanggal;
						$kas 		= $total_kas_masuk;
						for($i=$tgl_awal; $i!=$tgl_akhir; $i=date('Y-m-d', strtotime('+1 days', strtotime($i)))){	
							$data_update_kas = array(
								'kas_awal' => $kas_awal,
								'kas_masuk' => ($i == $tanggal ? $kas : $kas_masuk[$i]),
								'kas_akhir' => ($i == $tanggal ? $kas+$kas_awal : $kas_masuk[$i]+$kas_awal),
								'updated_by' => $this->data['users']->id
							);
							$where_update_kas['histori_kas.tanggal'] = $i;
							$where_update_kas['histori_kas.cabang_id'] = $cabang_id;
							$update = $this->histori_kas_model->update($data_update_kas, $where_update_kas);
							// edit kas di cabang
							$data_kas_cabang = array('kas'=> ($i == $tanggal ? $kas+$kas_awal : $kas_masuk[$i]+$kas_awal));
							$update = $this->cabang_model->update($data_kas_cabang, array("cabang.id" => $cabang_id));
							
							$kas_awal += ($i == $tanggal ? $kas : $kas_masuk[$i]);
						}
					}
				}else{
					// perhitungan kas
					$total_kas = $cabang->kas + $total_harga_penjualan;
					$total_kas = $total_kas - $total_harga_bk;
					$total_kas = $total_kas - $total_pengeluaran;
					//perhitungan kas masuk
					$kas_masuk = $total_harga_penjualan - $total_harga_bk;
					$kas_masuk = $kas_masuk - $total_pengeluaran;
					//update histori
					$data_insert_kas = array(
						'cabang_id' => $cabang_id,
						'tanggal' => $tanggal,
						'kas_awal' => $cabang->kas,
						'kas_masuk' => $kas_masuk,
						'kas_akhir' => $total_kas,
						'created_by' => $this->data['users']->id,
					);
					$insert = $this->histori_kas_model->insert($data_insert_kas);
					//update cabang
					$update_data_kas = array(
						'kas' => $total_kas,
						// 'kas_awal' => $cabang->kas,
					);
					$update_kas = $this->cabang_model->update($update_data_kas,['cabang.id' => $cabang_id]);
				}
				// sepuhan
				$sepuhan_detail = [];
				if ($sepuhan) {
					$sepuhan_detail = $this->transaksi_sepuhan_detail_model->getAllById(['transaksi_sepuhan_id' => $sepuhan->id]);
				}

				// kotak cincn
				$kc_detail = [];
				if ($kc) {
					$kc_detail = $this->transaksi_kotak_cincin_detail_model->getAllById(['transaksi_kotak_cincin_id' => $kc->id]);
				}
				
				$data['status'] = true;
				$data['cabang'] = $penjualan->kode_cabang.' - '.$penjualan->nama_cabang;
				//penjualan
				$data['berat_penjualan_25'] = $berat_penjualan_25 == 0 ? '' : number_format((float)$berat_penjualan_25, 2, '.', '');
				$data['harga_penjualan_25'] = $harga_penjualan_25 == 0 ? '' : number_format($harga_penjualan_25);
				$data['berat_penjualan_30'] = $berat_penjualan_30 == 0 ? '' : number_format((float)$berat_penjualan_30, 2, '.', '');
				$data['harga_penjualan_30'] = $harga_penjualan_30 == 0 ? '' : number_format($harga_penjualan_30);
				$data['berat_penjualan_35'] = $berat_penjualan_35 == 0 ? '' : number_format((float)$berat_penjualan_35, 2, '.', '');
				$data['harga_penjualan_35'] = $harga_penjualan_35 == 0 ? '' : number_format($harga_penjualan_35);
				// tukar barang
				$data['berat_tukar_25'] = $berat_tukar_25 == 0 ? '' : number_format((float)$berat_tukar_25, 2, '.', '');
				$data['harga_tukar_25'] = $harga_tukar_25 == 0 ? '' : number_format($harga_tukar_25);
				$data['berat_tukar_30'] = $berat_tukar_30 == 0 ? '' : number_format((float)$berat_tukar_30, 2, '.', '');
				$data['harga_tukar_30'] = $harga_tukar_30 == 0 ? '' : number_format($harga_tukar_30);
				$data['berat_tukar_35'] = $berat_tukar_35 == 0 ? '' : number_format((float)$berat_tukar_35, 2, '.', '');
				$data['harga_tukar_35'] = $harga_tukar_35 == 0 ? '' : number_format($harga_tukar_35);
				// tukar barang
				$data['total_berat_penjualan'] = number_format((float)$total_berat_penjualan, 2, '.', '');
				$data['total_harga_penjualan'] = number_format($total_harga_penjualan);
				// BK
				$data['berat_bk_20'] = $berat_bk_20 == 0 ? '' : number_format((float)$berat_bk_20, 2, '.', '');
				$data['harga_bk_20'] = $harga_bk_20 == 0 ? '' : number_format($harga_bk_20);
				$data['berat_bk_22'] = $berat_bk_22 == 0 ? '' : number_format((float)$berat_bk_22, 2, '.', '');
				$data['harga_bk_22'] = $harga_bk_22 == 0 ? '' :number_format($harga_bk_22);
				$data['berat_bk_23'] = $berat_bk_23 == 0 ? '' : number_format((float)$berat_bk_23, 2, '.', '');
				$data['harga_bk_23'] = $harga_bk_23 == 0 ? '' : number_format($harga_bk_23);
				//
				$data['berat_bk_25'] = $berat_bk_25 == 0 ? '' : number_format((float)$berat_bk_25, 2, '.', '');
				$data['harga_bk_25'] = $harga_bk_25 == 0 ? '' : number_format($harga_bk_25);
				$data['berat_bk_27'] = $berat_bk_27 == 0 ? '' : number_format((float)$berat_bk_27, 2, '.', '');
				$data['harga_bk_27'] = $harga_bk_27 == 0 ? '' : number_format($harga_bk_27);
				$data['berat_bk_30'] = $berat_bk_30 == 0 ? '' : number_format((float)$berat_bk_30, 2, '.', '');
				$data['harga_bk_30'] = $harga_bk_30 == 0 ? '' : number_format($harga_bk_30);
				$data['berat_bk_28'] = $berat_bk_28 == 0 ? '' : number_format((float)$berat_bk_28, 2, '.', '');
				$data['harga_bk_28'] = $harga_bk_28 == 0 ? '' : number_format($harga_bk_28);
				//penambahan baru
				$data['berat_bk_19'] = $berat_bk_19 == 0 ? '' : number_format((float)$berat_bk_19, 2, '.', '');
				$data['harga_bk_19'] = $harga_bk_19 == 0 ? '' : number_format($harga_bk_19);
				$data['berat_bk_18'] = $berat_bk_18 == 0 ? '' : number_format((float)$berat_bk_18, 2, '.', '');
				$data['harga_bk_18'] = $harga_bk_18 == 0 ? '' : number_format($harga_bk_18);
				$data['berat_bk_17'] = $berat_bk_17 == 0 ? '' : number_format((float)$berat_bk_17, 2, '.', '');
				$data['harga_bk_17'] = $harga_bk_17 == 0 ? '' : number_format($harga_bk_17);
				//
				$data['berat_bk_24'] = $berat_bk_24 == 0 ? '' : number_format((float)$berat_bk_24, 2, '.', '');
				$data['harga_bk_24'] = $harga_bk_24 == 0 ? '' : number_format($harga_bk_24);
				$data['berat_bk_29'] = $berat_bk_29 == 0 ? '' : number_format((float)$berat_bk_29, 2, '.', '');
				$data['harga_bk_29'] = $harga_bk_29 == 0 ? '' : number_format($harga_bk_29);
				$data['total_berat_bk'] = number_format((float)$total_berat_bk, 2, '.', '');
				$data['total_harga_bk'] = number_format($total_harga_bk);

				$data['jumlah_pengeluaran'] = NULL;
				$data['pengeluaran'] = NULL;
				//pengeluaran
				if (!empty($pengeluaran_detail)) {
					# code...
					$data['pengeluaran'] = $pengeluaran_detail;
					$jumlah_pengeluaran = count($pengeluaran_detail);
					$jumlah_pengeluaran = $jumlah_pengeluaran + 1;
					$data['jumlah_pengeluaran'] = $jumlah_pengeluaran;
				}
				$data['total_pengeluaran'] = $total_pengeluaran;
				//kas
				if ($laporan == 0) {
					$data['kas'] = 0;
				} else {
					$data['kas'] = $total_kas;
				}
				//barang rusak
				$total_gram_br = 0;
	            $total_potong_br = 0;
	            $total_harga_br = 0;
				if (!empty($barang_rusak)) {
					foreach ($barang_rusak as $key => $value) {
						$total_gram_br += $value->berat;
						$total_potong_br += $value->potong;
						$total_harga_br += $value->potongan_rusak;
					}
				}
				$data['total_gram_br'] = number_format((float)$total_gram_br, 2, '.', '');
				$data['total_potong_br'] = number_format($total_potong_br);
				$data['total_harga_br'] = number_format($total_harga_br);
				$data['barang_rusak'] = $barang_rusak;
				//barang_hilang
				$total_gram_awal_bh = 0;
				$total_selisih_bh = 0;
				$total_gram_akhir_bh = 0;
				$total_harga_bh = 0;
				if (!empty($barang_hilang)) {
					foreach ($barang_hilang as $key => $value) {
						$total_gram_awal_bh += $value->gram_awal;
						$total_selisih_bh += $value->berat;
						$total_gram_akhir_bh = $value->gram_awal - $value->berat;
						$total_harga_bh += $value->potongan_hilang;
					}
				}
				$data['total_gram_awal_bh'] = number_format((float)$total_gram_awal_bh, 2, '.', '');
				$data['total_selisih_bh'] = number_format((float)$total_selisih_bh, 2, '.', '');
				$data['total_gram_akhir_bh'] = number_format((float)$total_gram_akhir_bh, 2, '.', '');
				$data['total_harga_bh'] = number_format($total_harga_bh);
				$data['barang_hilang'] = $barang_hilang;
				//uang laci
				$uang_laci_kosong = [];
				$data['rp_100000'] = !empty($uang_laci) ? number_format($uang_laci->rp_100000) : '';
				$data['rp_50000'] = !empty($uang_laci) ? number_format($uang_laci->rp_50000) : '';
				$data['rp_20000'] = !empty($uang_laci) ? number_format($uang_laci->rp_20000) : '';
				$data['rp_10000'] = !empty($uang_laci) ? number_format($uang_laci->rp_10000) : '';
				$data['rp_5000'] = !empty($uang_laci) ? number_format($uang_laci->rp_5000) : '';
				$data['rp_2000'] = !empty($uang_laci) ? number_format($uang_laci->rp_2000) : '';
				$data['rp_1000'] = !empty($uang_laci) ? number_format($uang_laci->rp_1000) : '';
				$data['rp_500'] = !empty($uang_laci) ? number_format($uang_laci->rp_500) : '';
				$data['uda'] = !empty($uang_laci) ? $uang_laci->uda : '';
				$data['uang_brangkas'] = !empty($uang_laci) ? number_format($uang_laci->uang_brangkas) : '';
				$data['uang_jelek'] = !empty($uang_laci) ? number_format($uang_laci->uang_jelek) : '';
				$data['uang_setor'] = !empty($uang_laci) ? number_format($uang_laci->uang_setor) : '';
				$data['uang_kas_pagi'] = !empty($uang_laci) ? number_format($uang_laci->uang_kas_pagi) : '';
				// transaksi sepuhan
				$data['sepuhan'] = $sepuhan_detail;
				// transaksi kotak cincin
				$data['kc'] = $kc_detail;
			}else{
				$data['status'] = false;
			}
			echo json_encode($data);
		} else {
			$data['status'] = false;
			echo json_encode($data);
		}
		
	}

	public function print_pdf()
	{
		$data_cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
		$cabang_id = $this->input->get('cabang_id');
		if ($this->data['users_groups']->id == 4) {
			$cabang_id = $data_cabang->id;
			$laporan = 1;
		}
		$tanggal = $this->input->get('tanggal');
		// data
		//penjualan
		$where_penjualan['penjualan.tanggal'] = $tanggal;
		$where_penjualan['penjualan.cabang_id'] = $cabang_id;
		$where_penjualan['penjualan.enum'] = $laporan;
		$where_penjualan['penjualan.is_deleted'] = 0;
		$penjualan = $this->penjualan_model->getOneBy($where_penjualan);
		//bk
		$where_bk['barang_kembali.tanggal'] = $tanggal;
		$where_bk['barang_kembali.cabang_id'] = $cabang_id;
		$where_bk['barang_kembali.enum'] = $laporan;
		$barang_kembali = $this->barang_kembali_model->getOneBy($where_bk);
		//tukar plus
		$where_tukar['tukar_plus.tanggal'] = $tanggal;
		$where_tukar['tukar_plus.cabang_id'] = $cabang_id;
		$where_tukar['tukar_plus.enum'] = $laporan;
		$tukar = $this->tukar_plus_model->getOneBy($where_tukar);
		//pengeluaran
		$where_pengeluaran['pengeluaran.tanggal'] = $tanggal;
		$where_pengeluaran['pengeluaran.cabang_id'] = $cabang_id;
		$where_pengeluaran['pengeluaran.enum'] = $laporan;
		$pengeluaran = $this->pengeluaran_model->getOneBy($where_pengeluaran);
		//kas
		$where_kas['tanggal'] = $tanggal;
		$where_kas['cabang_id'] = $cabang_id;
		$kas = $this->histori_kas_model->getOneBy($where_kas);
		//uang laci
		$where_laci['tanggal'] = $tanggal;
		$where_laci['cabang_id'] = $cabang_id;
		$uang_laci = $this->uang_laci_model->getOneBy($where_laci);
		//sepuhan
		$where_sepuhan['tanggal'] = $tanggal;
		$where_sepuhan['cabang_id'] = $cabang_id;
		$sepuhan = $this->transaksi_sepuhan_model->getOneBy($where_sepuhan);
		//kc
		$where_kc['tanggal'] = $tanggal;
		$where_kc['cabang_id'] = $cabang_id;
		$kc = $this->transaksi_kotak_cincin_model->getOneBy($where_kc);

		if($penjualan || $barang_kembali || $tukar || $pengeluaran || $uang_laci){

			$where_pk['penjualan_detail.penjualan_id'] = $penjualan->id;
			// $where_pk['penjualan_detail.is_deleted'] = 0;
			$penjualan_detail = $this->penjualan_detail_model->getAllById($where_pk);
			$berat_penjualan_25 = 0.0;
			$harga_penjualan_25 = 0;
			$berat_penjualan_30 = 0.0;
			$harga_penjualan_30 = 0;
			$berat_penjualan_35 = 0.0;
			$harga_penjualan_35 = 0;			
			// total penjualan berat dan harga
			$total_penjualan_berat = 0;
			$total_penjualan_harga = 0;
			if (!empty($penjualan_detail)) {
				foreach ($penjualan_detail as $key => $value) {
					$total_penjualan_berat += $value->berat;
					$total_penjualan_harga += $value->harga;
					if ($value->jenis_transaksi_id == 1) {
						$berat_penjualan_25 += $value->berat;
						$harga_penjualan_25 += $value->harga;
					}elseif ($value->jenis_transaksi_id == 2) {
						$berat_penjualan_30 += $value->berat;
						$harga_penjualan_30 += $value->harga;

					}elseif ($value->jenis_transaksi_id == 3) {
						$berat_penjualan_35 += $value->berat;
						$harga_penjualan_35 += $value->harga;
					}
				}
			}
			$tukar_detail = [];
			if ($tukar) {
				$where_tukar_detail['tukar_plus_detail.tukar_plus_id'] = $tukar->id;
				$where_tukar_detail['tukar_plus_detail.status'] = 'Tukar Plus';
				$tukar_detail = $this->tukar_plus_detail_model->getAllById($where_tukar_detail);
			}
			// inisialisasi
			$berat_tukar_25 = 0.0;
			$harga_tukar_25 = 0;
			$berat_tukar_30 = 0.0;
			$harga_tukar_30 = 0;
			$berat_tukar_35 = 0.0;
			$harga_tukar_35 = 0;
			// total penjualan berat dan harga
			$total_tukar_berat = 0;
			$total_tukar_harga = 0;
			if ($tukar_detail) {
				foreach ($tukar_detail as $key => $value) {
					$total_tukar_berat += $value->berat_plus;
					$total_tukar_harga += $value->harga_plus;
					if ($value->jenis_transaksi_id == 1) {
						$berat_tukar_25 += $value->berat_plus;
						$harga_tukar_25 += $value->harga_plus;
					}elseif ($value->jenis_transaksi_id == 2) {
						$berat_tukar_30 += $value->berat_plus;
						$harga_tukar_30 += $value->harga_plus;

					}elseif ($value->jenis_transaksi_id == 3) {
						$berat_tukar_35 += $value->berat_plus;
						$harga_tukar_35 += $value->harga_plus;
					}
				}
			}
			$total_berat_penjualan = 0.0;
			$total_harga_penjualan = 0;
			// sum penjualan
			if ($penjualan && $tukar) {
				$total_berat_penjualan = $total_penjualan_berat + $total_tukar_berat;
				$total_harga_penjualan = $total_penjualan_harga + $total_tukar_harga;
			}else{
				$total_berat_penjualan = $total_penjualan_berat;
				$total_harga_penjualan = $total_penjualan_harga;
			}

			$barang_rusak = [];
			$barang_hilang = [];
			if (!empty($barang_kembali)) {
				$where_bk_detail['barang_kembali_detail.barang_kembali_id'] = $barang_kembali->id;
				$where_bk_detail['barang_kembali_detail.is_deleted'] = 0;
				$bk_detail = $this->barang_kembali_detail_model->getAllById($where_bk_detail);
				$data_barang_rusak = $this->barang_rusak_model->getAllById(['barang_kembali_id' => $barang_kembali->id]);
				if ($data_barang_rusak) {
					$barang_rusak = $data_barang_rusak;
				}
				$data_barang_hilang = $this->barang_hilang_model->getAllById(['barang_kembali_id' => $barang_kembali->id]);
				if ($data_barang_hilang) {
					$barang_hilang = $data_barang_hilang;
				}
			}
			$berat_bk_20 = 0.0;
			$harga_bk_20 = 0;
			$berat_bk_22 = 0.0;
			$harga_bk_22 = 0;
			$berat_bk_23 = 0.0;
			$harga_bk_23 = 0;
			$berat_bk_25 = 0.0;
			$harga_bk_25 = 0;
			$berat_bk_27 = 0.0;
			$harga_bk_27 = 0;
			$berat_bk_28 = 0.0;
			$harga_bk_28 = 0;
			$berat_bk_30 = 0.0;
			$harga_bk_30 = 0;
			//total
			$total_berat_bk = 0.0;
			$total_harga_bk = 0;
			//data uda
			$data_uda = [];
			if(!empty($bk_detail)){
				foreach ($bk_detail as $key => $value) {
					if ($value->jenis_transaksi_id == 7) {
						$berat_bk_20 += $value->berat;
						$harga_bk_20 += $value->harga;
					}elseif ($value->jenis_transaksi_id == 8) {
						$berat_bk_22 += $value->berat;
						$harga_bk_22 += $value->harga;
					}elseif ($value->jenis_transaksi_id == 9) {
						$berat_bk_23 += $value->berat;
						$harga_bk_23 += $value->harga;
					}elseif ($value->jenis_transaksi_id == 10) {
						$berat_bk_25 += $value->berat;
						$harga_bk_25 += $value->harga;
					}elseif ($value->jenis_transaksi_id == 11) {
						$berat_bk_27 += $value->berat;
						$harga_bk_27 += $value->harga;
					}elseif ($value->jenis_transaksi_id == 12) {
						$berat_bk_30 += $value->berat;
						$harga_bk_30 += $value->harga;
					}elseif ($value->jenis_transaksi_id == 13) {
						$berat_bk_28 += $value->berat;
						$harga_bk_28 += $value->harga;
					}
					//get data uda
					if ($value->cabang_id_asal != $cabang_id) {
						$object_uda =  new stdClass();
		                $object_uda->cabang = $value->nama_cabang;
		                $object_uda->harga = $value->harga;
		                array_push($data_uda, $object_uda);
					}	
				}
			}
			$total_berat_bk = $berat_bk_20 + $berat_bk_22 + $berat_bk_23 + $berat_bk_25 + $berat_bk_27 + $berat_bk_28 + $berat_bk_30;
			$total_harga_bk = $harga_bk_20 + $harga_bk_22 + $harga_bk_23 + $harga_bk_25 + $harga_bk_27 + $harga_bk_28 + $harga_bk_30;
			// pengeluaran
			$total_pengeluaran = 0;
			if (!empty($pengeluaran)) {
				$where_pengeluaran_detail['pengeluaran_detail.pengeluaran_id'] = $pengeluaran->id;
				$pengeluaran_detail = $this->pengeluaran_detail_model->getAllById($where_pengeluaran_detail);
				if (!empty($pengeluaran_detail)) {
					foreach ($pengeluaran_detail as $key => $value) {
						$total_pengeluaran += $value->harga;
					}
				}
			}
			// sepuhan
			$sepuhan_detail = [];
			if ($sepuhan) {
				$sepuhan_detail = $this->transaksi_sepuhan_detail_model->getAllById(['transaksi_sepuhan_id' => $sepuhan->id]);
			}
			// kotak cincn
			$kc_detail = [];
			if ($kc) {
				$kc_detail = $this->transaksi_kotak_cincin_detail_model->getAllById(['transaksi_kotak_cincin_id' => $kc->id]);
			}			
			$data['status'] = true;
			$data['tanggal'] = $tanggal;
			$data['cabang'] = $penjualan->kode_cabang.' - '.$penjualan->nama_cabang;
			//penjualan
			$data['berat_penjualan_25'] = $berat_penjualan_25 == 0 ? '' : $berat_penjualan_25;
			$data['harga_penjualan_25'] = $harga_penjualan_25 == 0 ? '' : number_format($harga_penjualan_25);
			$data['berat_penjualan_30'] = $berat_penjualan_30 == 0 ? '' : $berat_penjualan_30;
			$data['harga_penjualan_30'] = $harga_penjualan_30 == 0 ? '' : number_format($harga_penjualan_30);
			$data['berat_penjualan_35'] = $berat_penjualan_35 == 0 ? '' : $berat_penjualan_35;
			$data['harga_penjualan_35'] = $harga_penjualan_35 == 0 ? '' : number_format($harga_penjualan_35);
			// tukar barang
			$data['berat_tukar_25'] = $berat_tukar_25 == 0 ? '' : $berat_tukar_25;
			$data['harga_tukar_25'] = $harga_tukar_25 == 0 ? '' : number_format($harga_tukar_25);
			$data['berat_tukar_30'] = $berat_tukar_30 == 0 ? '' : $berat_tukar_30;
			$data['harga_tukar_30'] = $harga_tukar_30 == 0 ? '' : number_format($harga_tukar_30);
			$data['berat_tukar_35'] = $berat_tukar_35 == 0 ? '' : $berat_tukar_35;
			$data['harga_tukar_35'] = $harga_tukar_35 == 0 ? '' : number_format($harga_tukar_35);
			// tukar barang
			$data['total_berat_penjualan'] = $total_berat_penjualan;
			$data['total_harga_penjualan'] = number_format($total_harga_penjualan);
			// BK
			$data['berat_bk_20'] = $berat_bk_20 == 0 ? '' : $berat_bk_20;
			$data['harga_bk_20'] = $harga_bk_20 == 0 ? '' : number_format($harga_bk_20);
			$data['berat_bk_22'] = $berat_bk_22 == 0 ? '' : $berat_bk_22;
			$data['harga_bk_22'] = $harga_bk_22 == 0 ? '' :number_format($harga_bk_22);
			$data['berat_bk_23'] = $berat_bk_23 == 0 ? '' : $berat_bk_23;
			$data['harga_bk_23'] = $harga_bk_23 == 0 ? '' : number_format($harga_bk_23);
			//
			$data['berat_bk_25'] = $berat_bk_25 == 0 ? '' : $berat_bk_25;
			$data['harga_bk_25'] = $harga_bk_25 == 0 ? '' : number_format($harga_bk_25);
			$data['berat_bk_27'] = $berat_bk_27 == 0 ? '' : $berat_bk_27;
			$data['harga_bk_27'] = $harga_bk_27 == 0 ? '' : number_format($harga_bk_27);
			$data['berat_bk_30'] = $berat_bk_30 == 0 ? '' : $berat_bk_30;
			$data['harga_bk_30'] = $harga_bk_30 == 0 ? '' : number_format($harga_bk_30);
			$data['berat_bk_28'] = $berat_bk_28 == 0 ? '' : $berat_bk_28;
			$data['harga_bk_28'] = $harga_bk_28 == 0 ? '' : number_format($harga_bk_28);
			$data['total_berat_bk'] = $total_berat_bk;
			$data['total_harga_bk'] = number_format($total_harga_bk);
			//pengeluaran
			$data['jumlah_pengeluaran'] = NULL;
			$data['pengeluaran'] = NULL;
			if (!empty($pengeluaran_detail)) {
				# code...
				$data['pengeluaran'] = $pengeluaran_detail;
				$jumlah_pengeluaran = count($pengeluaran_detail);
				$jumlah_pengeluaran = $jumlah_pengeluaran + 1;
				$data['jumlah_pengeluaran'] = $jumlah_pengeluaran;
			}
			$data['total_pengeluaran'] = $total_pengeluaran;
			//kas
			if ($laporan == 0) {
				$data['kas'] = 0;
			} else {
				$data['kas'] = $kas->kas_akhir;
			}
			//data uda
			$data['uda'] = $data_uda;
			//barang rusak
			$total_gram_br = 0;
            $total_potong_br = 0;
            $total_harga_br = 0;
			if (!empty($barang_rusak)) {
				foreach ($barang_rusak as $key => $value) {
					$total_gram_br += $value->berat;
					$total_potong_br += $value->potong;
					$total_harga_br += $value->harga;
				}
			}
			$data['total_gram_br'] = number_format((float)$total_gram_br, 2, '.', '');
			$data['total_potong_br'] = number_format($total_potong_br);
			$data['total_harga_br'] = number_format($total_harga_br);
			$data['barang_rusak'] = $barang_rusak;
			//barang_hilang
			$total_gram_awal_bh = 0;
			$total_selisih_bh = 0;
			$total_gram_akhir_bh = 0;
			$total_harga_bh = 0;
			if (!empty($barang_hilang)) {
				foreach ($barang_hilang as $key => $value) {
					$total_gram_awal_bh += $value->gram_awal;
					$total_selisih_bh += $value->berat;
					$total_gram_akhir_bh = $value->gram_awal - $value->berat;
					$total_harga_bh += $value->harga;
				}
			}
			$data['total_gram_awal_bh'] = number_format((float)$total_gram_awal_bh, 2, '.', '');
			$data['total_selisih_bh'] = number_format((float)$total_selisih_bh, 2, '.', '');
			$data['total_gram_akhir_bh'] = number_format((float)$total_gram_akhir_bh, 2, '.', '');
			$data['total_harga_bh'] = number_format($total_harga_bh);
			$data['barang_hilang'] = $barang_hilang;
			//uang laci
			$uang_laci_kosong = [];
			$data['rp_100000'] = !empty($uang_laci) ? number_format($uang_laci->rp_100000) : '';
			$data['rp_50000'] = !empty($uang_laci) ? number_format($uang_laci->rp_50000) : '';
			$data['rp_20000'] = !empty($uang_laci) ? number_format($uang_laci->rp_20000) : '';
			$data['rp_10000'] = !empty($uang_laci) ? number_format($uang_laci->rp_10000) : '';
			$data['rp_5000'] = !empty($uang_laci) ? number_format($uang_laci->rp_5000) : '';
			$data['rp_2000'] = !empty($uang_laci) ? number_format($uang_laci->rp_2000) : '';
			$data['rp_1000'] = !empty($uang_laci) ? number_format($uang_laci->rp_1000) : '';
			$data['rp_500'] = !empty($uang_laci) ? number_format($uang_laci->rp_500) : '';
			$data['uang_brangkas'] = !empty($uang_laci) ? number_format($uang_laci->uang_brangkas) : '';
			$data['uang_jelek'] = !empty($uang_laci) ? number_format($uang_laci->uang_jelek) : '';
			$data['uang_setor'] = !empty($uang_laci) ? number_format($uang_laci->uang_setor) : '';
			$data['uang_kas_pagi'] = !empty($uang_laci) ? number_format($uang_laci->uang_setor) : '';

			// transaksi sepuhan
			$data['sepuhan'] = $sepuhan_detail;
			// transaksi kotak cincin
			$data['kc'] = $kc_detail;

			require_once BASEPATH. 'vendor/autoload.php';
	        // $mpdf = new \Mpdf\Mpdf(['mode' => 'utf-8', 'format' => [216, 350]]);
	        $mpdf = new \Mpdf\Mpdf();
	        $html = $this->load->view('admin/laporan_harian/print_v',$data,TRUE);
	        // print_r($html);
	        // die();
	        $mpdf->WriteHTML($html);
	        $mpdf->Output("laporan-harian~".$tanggal.'-'.time().".pdf","I");
		}else{
			$data['status'] = false;
		}

	}
}
