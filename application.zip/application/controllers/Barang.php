<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Barang extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('barang_model');
	}

	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$this->data['content'] = 'admin/barang/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function create()
	{
		$this->form_validation->set_rules('kode_barang', "kode_barang Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$kode_barang = $this->input->post('kode_barang');
			$jenis         = $this->input->post('jenis');
			
			// $foto         = $this->input->post('foto');
			// $location_path = './uploads/foto-barang/';
			// $name = $this->input->post('kode_barang');
			// $name = str_replace(' ', '-', $name);
			// $uploaded      = uploadFile("foto".$foto, $location_path,$name);
		 //    if($uploaded['status']==1){
		 //    	$data_foto['foto'] = str_replace(' ', '_', $uploaded['message']);
		 //    }
			$data_insert = array(
				'kode_barang' => $kode_barang,
				'jenis' => $jenis,
				// 'foto' => $data_foto['foto'],
				'nama_barang' => $this->input->post('nama_barang'),
				'stok' => $this->input->post('stok'),
				// 'harga' => $this->input->post('harga'),
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			$insert = $this->barang_model->insert($data_insert);

			if ($insert) {
				$this->session->set_flashdata('message', "Data Barang Baru Berhasil Disimpan");
				redirect("barang");
			} else {
				$this->session->set_flashdata('message_error', "Data Barang Baru Gagal Disimpan");
				redirect("barang");
			}
		} else {
			if ($this->data['is_can_create']) {
				$this->data['content'] = 'admin/barang/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function edit()
	{
		$this->form_validation->set_rules('kode_barang', "kode_barang Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$id = $this->input->post('id');
			$jenis         = $this->input->post('jenis');
			// if (empty($_FILES['foto']['name'])) {
			// 	$data_update = array(
			// 		'kode_barang' => $this->input->post('kode_barang'),
			// 		'nama_barang' => $this->input->post('nama_barang'),
			// 		'jenis' => $jenis,
			// 		'stok' => $this->input->post('stok'),
			// 		// 'harga' => $this->input->post('harga'),
			// 		'updated_by' => $this->data['users']->id
			// 	);
			// }else{
			// 	$kode_barang = $this->input->post('kode_barang');
				
			// 	$foto         = $this->input->post('foto');
			// 	$location_path = './uploads/foto-barang/';
			// 	$name = $this->input->post('kode_barang');
			// 	$name = str_replace(' ', '-', $name);
			// 	$uploaded      = uploadFile("foto".$foto, $location_path,$name);
			//     if($uploaded['status']==1){
			//     	$data_foto['foto'] = str_replace(' ', '_', $uploaded['message']);
			//     }
			//     $data_update = array(
			// 		'kode_barang' => $kode_barang,
			// 		'jenis' => $jenis,
			// 		'foto' => $data_foto['foto'],
			// 		'nama_barang' => $this->input->post('nama_barang'),
			// 		'stok' => $this->input->post('stok'),
			// 		// 'harga' => $this->input->post('harga'),
			// 		'created_by' => $this->data['users']->id,
			// 		'updated_by' => $this->data['users']->id
			// 	);
			// }
			$data_update = array(
				'kode_barang' => $this->input->post('kode_barang'),
				'nama_barang' => $this->input->post('nama_barang'),
				'jenis' => $jenis,
				'stok' => $this->input->post('stok'),
				// 'harga' => $this->input->post('harga'),
				'updated_by' => $this->data['users']->id
			);
			$update = $this->barang_model->update($data_update, array("id" => $id));
			if ($update) {
				$this->session->set_flashdata('message', "Data Barang Berhasil Diedit");
				redirect("barang");
			} else {
				$this->session->set_flashdata('message_error', "Data Barang Gagal Diedit");
				redirect("barang");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("barang/edit/" . $id);
			} else {
				if ($this->data['is_can_edit']) {
					$this->data['id'] = $this->uri->segment(3);
					$this->data['barang'] = $this->barang_model->getOneBy(array("barang.id" => $this->data['id']));
					$this->data['content'] = 'admin/barang/edit_v';
				} else {
					$this->data['content']  = 'errors/html/restrict';
				}
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function detail()
	{
		$this->data['id'] = $this->uri->segment(3);
		$this->data['barang'] = $this->barang_model->getOneBy(array("barang.id" => $this->data['id']));

		$this->data['content'] = 'admin/barang/detail_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
			1 => 'barang.kode_barang',
			2 => 'barang.nama_barang',
			3 => 'barang.stok',
			4 => 'barang.harga',
			5 => 'action'
		);

		$where = array();
		// if(!$this->data['is_superadmin']){
		// 	$where['barang.office_id'] = $this->data['users']->office_id;
		// }

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->barang_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		if (!empty($this->input->post('search')['value'])) {
			$search_value = $this->input->post('search')['value'];
			$search = array(
				"barang.kode_barang" => $search_value,
				"barang.nama_barang" => $search_value,
				"barang.stok" => $search_value,
			);
			$totalFiltered = $this->barang_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->barang_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$edit_url = "";
				$delete_url = "";
				if ($this->data['is_can_edit'] && $data->is_deleted == 0) {
					// $edit_url = "<a href='".base_url()."barang/edit/".$data->id."' class='btn btn-sm btn-info'>Ubah</a>";
					$edit_url = "<a href='" . base_url() . "barang/edit/" . $data->id . "' class='btn btn-sm btn-warning' data-toggle='tooltip' title='Edit Data' data-placement='bottom'><i class='fa fa-edit fa-w-20'></i></a>";
				}
				if ($this->data['is_can_edit']) {
					if ($data->is_deleted == 0) {
						$delete_url = "<a href='#' 
	        				url='" . base_url() . "barang/destroy/" . $data->id . "/" . $data->is_deleted . "' class='btn btn-sm btn-danger delete' data-toggle='tooltip' title='Non Aktifkan Data' data-placement='bottom'><i class='fa fa-times fa-w-20'></i></a>";
					} else {
						$delete_url = "<a href='#' 
	        				url='" . base_url() . "barang/destroy/" . $data->id . "/" . $data->is_deleted . "' class='btn btn-sm btn-success delete' data-toggle='tooltip' title='Aktifkan Data' data-placement='bottom'><i class='fa fa-check fa-w-20'></i></a>";
					}
				}
				if(empty($data->foto)){
                	$nestedData['foto'] = ''; 	
                }else{
                	$foto = explode(".", $data->foto);
                	$nestedData['foto'] = "<img width='80px' src=".base_url()."uploads/foto-barang/".$data->foto.">"; 
                }
				$nestedData['id'] = $start + $key + 1;
				$nestedData['kode_barang'] = $data->kode_barang;
				$nestedData['nama_barang'] = $data->nama_barang;
				$nestedData['stok'] = number_format($data->stok) . ' gram';
				$nestedData['action'] = $edit_url . " " . $delete_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function destroy()
	{
		$response_data = array();
		$response_data['status'] = false;
		$response_data['msg'] = "";
		$response_data['data'] = array();

		$id = $this->uri->segment(3);
		$is_deleted = $this->uri->segment(4);
		if (!empty($id)) {
			$this->load->model("barang_model");
			$data = array(
				'is_deleted' => ($is_deleted == 1) ? 0 : 1
			);
			$update = $this->barang_model->update($data, array("id" => $id));

			$response_data['data'] = $data;
			$response_data['status'] = true;
		} else {
			$response_data['msg'] = "ID Harus Diisi";
		}

		echo json_encode($response_data);
	}

	public function getbarang()
	{
		$where = array();
		$office_id = $this->input->get('office_id');

		if ($office_id != '') {
			$where['barang.office_id'] = $office_id;
		}

		$barang = $this->barang_model->getAllById($where);

		$data = array();
		if ($barang) {
			$data['status'] = true;
			$data['data'] = $barang;
			$data['message'] = "Success get data barang.";
		} else {
			$data['status'] = false;
			$data['data'] = [];
			$data['message'] = "Failed get data barang.";
		}

		echo json_encode($data);
	}
}
