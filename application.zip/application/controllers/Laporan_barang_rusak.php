<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Laporan_barang_rusak extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('cabang_model');
		$this->load->model('barang_rusak_model');
		$this->load->model('barang_kembali_model');
	}


	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$this->data['cabang'] = $this->cabang_model->getAllById();
			$this->data['content'] = 'admin/laporan_barang_rusak/create_v';
			// $this->data['content'] = 'admin/laporan_barang_rusak/print_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function get_data()
	{
		// / get data cabang untuk kasir
		$cabang_id = $this->input->get('cabang_id');
		$tanggal = $this->input->get('tanggal');

		$data_cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
		if ($this->data['users_groups']->id == 4) {
			$cabang_id = $data_cabang->id;
		}
		if ($this->data['users_groups']->id != 4) {
			$data_cabang = $this->cabang_model->getOneBy(['cabang.id' => $cabang_id]);
		}
		$tanggal = explode('-', $tanggal);
		$bulan = $tanggal[0];
		$tahun = $tanggal[1];

		$no_bulan = $bulan;
		
		if ($bulan < 10) {
			$no_bulan = explode(0, $bulan);
			$no_bulan = $no_bulan[1];
		}
		// inisialisasi nama bulan
		if ($no_bulan == 1) {
			$nama_no_bulan = 'Januari';
		} elseif ($no_bulan == 2) {
			$nama_bulan = 'Februari';
		} elseif ($no_bulan == 3) {
			$nama_bulan = 'Maret';
		} elseif ($no_bulan == 4) {
			$nama_bulan = 'April';
		} elseif ($no_bulan == 5) {
			$nama_bulan = 'Mei';
		} elseif ($no_bulan == 6) {
			$nama_bulan = 'Juni';
		} elseif ($no_bulan == 7) {
			$nama_bulan = 'Juli';
		} elseif ($no_bulan == 8) {
			$nama_bulan = 'Agustus';
		} elseif ($no_bulan == 9) {
			$nama_bulan = 'September';
		} elseif ($no_bulan == 10) {
			$nama_bulan = 'Oktober';
		} elseif ($no_bulan == 11) {
			$nama_bulan = 'November';
		} elseif ($no_bulan == 12) {
			$nama_bulan = 'Desember';
		}

		
		$where['barang_kembali.cabang_id'] = $cabang_id;
		$where['MONTH(barang_kembali.tanggal)'] = $bulan;
		$where['YEAR(barang_kembali.tanggal)'] = $tahun;
		// untuk cabang
		if ($this->data['users_groups']->id == 4) {
			$where['barang_kembali.cabang_id'] = $cabang_id;
		}
		$where['barang_kembali.is_deleted'] = 0;
		$bk = $this->barang_kembali_model->getAllById($where);
		$data_id = [];
		if (!empty($bk)) {
			foreach ($bk as $key => $value) {
				
				$data_br = $this->barang_rusak_model->getAllById(['barang_kembali_id' => $value->id]);
				if (!empty($data_br)) {
					$obj =  new stdClass();
	                $obj->id = $value->id;
	                $obj->tanggal = $value->tanggal;

					array_push($data_id, $obj);
					
				}
			}

		}
		if (!empty($data_id)) {
			$data_fix = [];
			$total_saldo = 0;
			$saldo = 0;
			$qty = 0;
			foreach ($data_id as $key => $value) {
				$br = $this->barang_rusak_model->getAllById(['barang_kembali_id' => $value->id]);
				$qty =  count($br);
				$nama_barang_rusak = '';
				$masuk = 0;
				$nama_barang =[];
				foreach ($br as $key_br => $value_br) {
					$nama_barang[] = $value_br->nama_barang;
					$masuk += $value_br->potongan_rusak;
				}
				if ($key == 0) {
					$total_saldo = $masuk;
					$saldo = $masuk;
				} else {
					$total_saldo = $total_saldo + $masuk ;
				}
				
				$data_nama_barang = implode(',', $nama_barang);
				$obj_rusak =  new stdClass();
	            $obj_rusak->tanggal = $value->tanggal;
	            $obj_rusak->nama_barang = $data_nama_barang;
	            $obj_rusak->qty = $qty;
	            $obj_rusak->masuk = number_format($masuk);
	            $obj_rusak->saldo = number_format($total_saldo);

				array_push($data_fix, $obj_rusak);
			}
			$days_in_month = cal_days_in_month(CAL_GREGORIAN,$no_bulan,$tahun);
			$result = [];
			for ($i=1; $i <= $days_in_month; $i++) {
				if ($i <10) {
	                $i = '0'.$i;
	            }
	            $date = $tahun.'-'.$bulan.'-'.$i;
	            $object_data =  new stdClass();
                $object_data->tanggal = $date;
                $object_data->nama_barang = '';
                $object_data->qty = '';
                $object_data->masuk = '';
                $object_data->saldo = '';
                
                if (!empty($data_fix)) {
	            	foreach ($data_fix as $key => $value) {
	            		if ($value->tanggal == $date) {
	            			$object_data->nama_barang = $value->nama_barang;
	            			$object_data->qty = $value->qty;
	            			$object_data->masuk = $value->masuk;
	            			$object_data->saldo = $value->saldo;
	            		}
	            		
	            	}
                		array_push($result, $object_data);
	            }
			}

			$data['status'] = true;
			$data['cabang'] = $data_cabang->nama_cabang;
			$data['bulan'] = $nama_bulan;
			
			//barang_rusak
			$data['barang_rusak'] = $result;
		}else {
			$data['status'] = false;
		}
		
		echo json_encode($data);
	}

	public function print_pdf()
	{
		// / get data cabang untuk kasir
		$cabang_id = $this->input->get('cabang_id');
		$tanggal = $this->input->get('tanggal');

		$data_cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
		if ($this->data['users_groups']->id == 4) {
			$cabang_id = $data_cabang->id;
		}
		if ($this->data['users_groups']->id != 4) {
			$data_cabang = $this->cabang_model->getOneBy(['cabang.id' => $cabang_id]);
		}
		$tanggal = explode('-', $tanggal);
		$bulan = $tanggal[0];
		$tahun = $tanggal[1];

		$no_bulan = $bulan;
		if ($bulan < 10) {
			$no_bulan = explode(0, $bulan);
			$no_bulan = $no_bulan[1];
		}
		// inisialisasi nama bulan
		if ($no_bulan == 1) {
			$nama_no_bulan = 'Januari';
		} elseif ($no_bulan == 2) {
			$nama_bulan = 'Februari';
		} elseif ($no_bulan == 3) {
			$nama_bulan = 'Maret';
		} elseif ($no_bulan == 4) {
			$nama_bulan = 'April';
		} elseif ($no_bulan == 5) {
			$nama_bulan = 'Mei';
		} elseif ($no_bulan == 6) {
			$nama_bulan = 'Juni';
		} elseif ($no_bulan == 7) {
			$nama_bulan = 'Juli';
		} elseif ($no_bulan == 8) {
			$nama_bulan = 'Agustus';
		} elseif ($no_bulan == 9) {
			$nama_bulan = 'September';
		} elseif ($no_bulan == 10) {
			$nama_bulan = 'Oktober';
		} elseif ($no_bulan == 11) {
			$nama_bulan = 'November';
		} elseif ($no_bulan == 12) {
			$nama_bulan = 'Desember';
		}

		
		$where['barang_kembali.cabang_id'] = $cabang_id;
		$where['MONTH(barang_kembali.tanggal)'] = $bulan;
		$where['YEAR(barang_kembali.tanggal)'] = $tahun;
		// untuk cabang
		if ($this->data['users_groups']->id == 4) {
			$where['barang_kembali.cabang_id'] = $cabang_id;
		}
		$where['barang_kembali.is_deleted'] = 0;
		$bk = $this->barang_kembali_model->getAllById($where);
		$data_id = [];
		if (!empty($bk)) {
			foreach ($bk as $key => $value) {
				
				$data_br = $this->barang_rusak_model->getAllById(['barang_kembali_id' => $value->id]);
				if (!empty($data_br)) {
					$obj =  new stdClass();
	                $obj->id = $value->id;
	                $obj->tanggal = $value->tanggal;

					array_push($data_id, $obj);
					
				}
			}

		}
		if (!empty($data_id)) {
			$data_fix = [];
			$total_saldo = 0;
			$saldo = 0;
			$qty = 0;
			foreach ($data_id as $key => $value) {
				$br = $this->barang_rusak_model->getAllById(['barang_kembali_id' => $value->id]);
				$qty =  count($br);
				$nama_barang_rusak = '';
				$masuk = 0;
				$nama_barang =[];
				foreach ($br as $key_br => $value_br) {
					$nama_barang[] = $value_br->nama_barang;
					$masuk += $value_br->potongan_rusak;
				}
				if ($key == 0) {
					$total_saldo = $masuk;
					$saldo = $masuk;
				} else {
					$total_saldo = $total_saldo + $masuk ;
				}
				
				$data_nama_barang = implode(',', $nama_barang);
				$obj_rusak =  new stdClass();
	            $obj_rusak->tanggal = $value->tanggal;
	            $obj_rusak->nama_barang = $data_nama_barang;
	            $obj_rusak->qty = $qty;
	            $obj_rusak->masuk = number_format($masuk);
	            $obj_rusak->saldo = number_format($total_saldo);

				array_push($data_fix, $obj_rusak);
			}
			$days_in_month = cal_days_in_month(CAL_GREGORIAN,$no_bulan,$tahun);
			$result = [];
			for ($i=1; $i <= $days_in_month; $i++) {
				if ($i <10) {
	                $i = '0'.$i;
	            }
	            $date = $tahun.'-'.$bulan.'-'.$i;
	            $object_data =  new stdClass();
                $object_data->tanggal = $date;
                $object_data->nama_barang = '';
                $object_data->qty = '';
                $object_data->masuk = '';
                $object_data->saldo = '';
                
                if (!empty($data_fix)) {
	            	foreach ($data_fix as $key => $value) {
	            		if ($value->tanggal == $date) {
	            			$object_data->nama_barang = $value->nama_barang;
	            			$object_data->qty = $value->qty;
	            			$object_data->masuk = $value->masuk;
	            			$object_data->saldo = $value->saldo;
	            		}
	            		
	            	}
                		array_push($result, $object_data);
	            }
			}

			$data['status'] = true;
			$data['cabang'] = $data_cabang->nama_cabang;
			$data['bulan'] = $nama_bulan;
			
			//barang_rusak
			$data['barang_rusak'] = $result;

			require_once BASEPATH. 'vendor/autoload.php';
	        $mpdf = new \Mpdf\Mpdf(['orientation' => 'L']);
	        $html = $this->load->view('admin/laporan_barang_rusak/print_v',$data,TRUE);
	        // print_r($html);
	        // die();
	        $mpdf->WriteHTML($html);
	        $mpdf->Output("laporan-barang-rusak-".$nama_bulan.'-'.time().".pdf","I");
		}else {
			$data['status'] = false;
		}
		
		echo json_encode($data);
	}
}
