<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Uang_laci extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('uang_laci_model');
		$this->load->model('cabang_model');
	}
	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$cek_insert = true;
			$this->data['data_cabang'] = $this->cabang_model->getAllById();
			if($this->data['users_groups']->id == 4){
				$where['cabang.users_id'] = $this->data['users']->id;
				$this->data['cabang'] = $this->cabang_model->getOneBy($where); 	
				$where_cek['uang_laci.tanggal'] = date('Y-m-d');
				$where_cek['uang_laci.cabang_id'] = $this->data['cabang']->id;
				$cek_insert = $this->uang_laci_model->getOneBy($where_cek);
			}
			$this->data['cek_insert'] = $cek_insert ? 1 : 0;

			$this->data['content'] = 'admin/uang_laci/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function create()
	{
		$this->form_validation->set_rules('uda', "uda Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);

			$data_uang_laci = array(
				'users_id' => $this->data['users']->id,
				'cabang_id' => $cabang->id,
				'tanggal' => $this->input->post('tanggal'),
				'rp_100000' => $this->input->post('rp_100000'),
				'rp_50000' => $this->input->post('rp_50000'),
				'rp_20000' => $this->input->post('rp_20000'),
				'uda' => $this->input->post('uda'),
				'rp_10000' => $this->input->post('rp_10000'),
				'rp_5000' => $this->input->post('rp_5000'),
				'rp_2000' => $this->input->post('rp_2000'),
				'rp_1000' => $this->input->post('rp_1000'),
				'rp_500' => $this->input->post('rp_500'),
				'uang_brangkas' => $this->input->post('uang_brangkas'),
				'uang_jelek' => $this->input->post('uang_jelek'),
				'uang_setor' => $this->input->post('uang_setor'),
				'uang_kas_pagi' => $this->input->post('uang_kas_pagi'),
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			$insert_uang_laci = $this->uang_laci_model->insert($data_uang_laci);
			
			if ($insert_uang_laci) {
				$this->session->set_flashdata('message', "Data uang_laci Baru Berhasil Disimpan");
				redirect("uang_laci");
			} else {
				$this->session->set_flashdata('message_error', "Data uang_laci Baru Gagal Disimpan");
				redirect("uang_laci");
			}
		} else {
			if ($this->data['is_can_create']) {
				$this->data['content'] = 'admin/uang_laci/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function edit()
	{
		$this->form_validation->set_rules('tanggal', "tanggal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$id = $this->input->post('id');
			$data_uang_laci = array(
				'rp_100000' => $this->input->post('rp_100000'),
				'rp_50000' => $this->input->post('rp_50000'),
				'rp_20000' => $this->input->post('rp_20000'),
				'rp_10000' => $this->input->post('rp_10000'),
				'rp_5000' => $this->input->post('rp_5000'),
				'uda' => $this->input->post('uda'),
				'rp_2000' => $this->input->post('rp_2000'),
				'rp_1000' => $this->input->post('rp_1000'),
				'rp_500' => $this->input->post('rp_500'),
				'uang_brangkas' => $this->input->post('uang_brangkas'),
				'uang_jelek' => $this->input->post('uang_jelek'),
				'uang_setor' => $this->input->post('uang_setor'),
				'uang_kas_pagi' => $this->input->post('uang_kas_pagi'),
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			$update = $this->uang_laci_model->update($data_uang_laci, array("id" => $id));
			if ($update) {
				$this->session->set_flashdata('message', "Data Uang Laci Berhasil Diedit");
				redirect("uang_laci");
			} else {
				$this->session->set_flashdata('message_error', "Data Uang Laci Gagal Diedit");
				redirect("uang_laci");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("uang_laci/edit/" . $id);
			} else {
				if ($this->data['is_can_edit']) {
					$this->data['id'] = $this->uri->segment(3);
					$this->data['uang_laci'] = $this->uang_laci_model->getOneBy(array("uang_laci.id" => $this->data['id']));
					$this->data['content'] = 'admin/uang_laci/edit_v';
				} else {
					$this->data['content']  = 'errors/html/restrict';
				}
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function detail()
	{
		$this->data['id'] = $this->uri->segment(3);
		$this->data['uang_laci'] = $this->uang_laci_model->getOneBy(array("uang_laci.id" => $this->data['id']));
		$this->data['content'] = 'admin/uang_laci/detail_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
		);

		if(!$this->data['is_superadmin']){
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
			$where['uang_laci.cabang_id'] = $cabang->id;
		}
		$where['uang_laci.is_deleted'] = 0;

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->uang_laci_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);

		
		$searchColumn = $this->input->post('columns');
        $isSearchColumn = false;

        if(!empty($searchColumn[0]['search']['value'])){
            $value = $searchColumn[0]['search']['value'];
            $isSearchColumn = true;
            $where['uang_laci.tanggal'] = $value;
        }

        if($isSearchColumn){
			$totalFiltered = $this->uang_laci_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
			$totalData = $totalFiltered;
        }else{
        	$totalFiltered = $totalData;
        }

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->uang_laci_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$detail_url = "";
				$edit_url = "";
				$delete_url = "";
				if ($data->tanggal == date('Y-m-d')) {
					$edit_url = "<a href='" . base_url() . "uang_laci/edit/" . $data->id . "' class='btn btn-sm btn-warning' data-toggle='tooltip' title='Edit Data' data-placement='bottom'><i class='fa fa-edit fa-w-20'></i></a>";
				}

				$detail_url = "<a href='" . base_url() . "uang_laci/detail/" . $data->id . "' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";
				

				$nestedData['id'] = $start + $key + 1;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['action'] = $detail_url.' '.$edit_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function dataListAdmin()
	{
		$columns = array(
			0 => 'id',
		);

		$where['uang_laci.is_deleted'] = 0;

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->uang_laci_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);

		
		$searchColumn = $this->input->post('columns');
        $isSearchColumn = false;

        if(!empty($searchColumn[0]['search']['value'])){
            $value = $searchColumn[0]['search']['value'];
            $isSearchColumn = true;
            $where['uang_laci.tanggal'] = $value;
        }
        if(!empty($searchColumn[1]['search']['value'])){
            $value = $searchColumn[1]['search']['value'];
            $isSearchColumn = true;
            $where['uang_laci.cabang_id'] = $value;
        }
        if(!empty($searchColumn[2]['search']['value'])){
            $value = $searchColumn[2]['search']['value'];
            $isSearchColumn = true;
            if ($value == 2) {
            	$value = 0;
            }
            $where['uang_laci.status_audit'] = $value;
        }

        if($isSearchColumn){
			$totalFiltered = $this->uang_laci_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
			$totalData = $totalFiltered;
        }else{
        	$totalFiltered = $totalData;
        }

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->uang_laci_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$detail_url = "";
				$edit_url = "";
				$delete_url = "";
				$audit_url = "";
				if($this->data['is_superadmin']){
					$edit_url = "<a href='" . base_url() . "uang_laci/edit/" . $data->id . "' class='btn btn-sm btn-warning' data-toggle='tooltip' title='Edit Data' data-placement='bottom'><i class='fa fa-edit fa-w-20'></i></a>";
				}

				$detail_url = "<a href='" . base_url() . "uang_laci/detail/" . $data->id . "' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";
				if ($data->status_audit == 0 && $this->data['users_groups']->id == 3) {
            		$audit_url = "<a href='#' 
	        				url='" . base_url() . "uang_laci/destroy/" . $data->id . "/" . $data->status_audit . "' class='btn btn-sm btn-danger delete' data-toggle='tooltip' title='Data telah Diaudit' data-placement='bottom'><i class='fa fa-check-circle fa-w-20'></i></a>";
            	}

				$nestedData['id'] = $start + $key + 1;
				$nestedData['cabang'] = $data->nama_cabang;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['status_audit'] = $data->status_audit == 0 ? '<b style="color:red;">Belum</b>' : '<b style="color:green;">Selesai</b>';
				$nestedData['action'] = $detail_url.' '.$edit_url.' '.$audit_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function destroy()
	{
		$response_data = array();
		$response_data['status'] = false;
		$response_data['msg'] = "";
		$response_data['data'] = array();

		$id = $this->uri->segment(3);
		$status_audit = $this->uri->segment(4);
		if (!empty($id)) {
			$this->load->model("uang_laci_model");
			$data = array(
				'status_audit' => ($status_audit == 1) ? 0 : 1
			);
			$update = $this->uang_laci_model->update($data, array("id" => $id));

			$response_data['data'] = $data;
			$response_data['status'] = true;
		} else {
			$response_data['msg'] = "ID Harus Diisi";
		}

		echo json_encode($response_data);
	}
}
