<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class User extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('user_model');
		$this->load->model('ion_auth_model');
		$this->load->model("roles_model");
	}
	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$this->data['content'] = 'admin/user/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}
		$this->load->view('admin/layouts/page', $this->data);
	}
	public function create()
	{
		$this->form_validation->set_rules('name', "Nama", 'trim|required');
		$this->form_validation->set_rules('username', "Username", 'trim|required');
		$this->form_validation->set_rules('phone', "Phone", 'trim|required');
		$this->form_validation->set_rules('password', "Password", 'trim|required');
		$this->form_validation->set_rules('role_id', "Role", 'trim|required');
		if ($this->form_validation->run() === TRUE) {
			// upload file
			$foto         = $this->input->post('foto');
			$location_path = './uploads/foto-user/';
			$name = $this->input->post('name');
			$name = str_replace(' ', '-', $name);
			$uploaded      = uploadFile("foto".$foto, $location_path,$name);
		    if($uploaded['status']==1){
		    	$data_foto['foto'] = str_replace(' ', '_', $uploaded['message']);
		    }
			$data = array(
				'first_name' 	=> $this->input->post('name'),
				'username' 		=> $this->input->post('username'),
				'phone' 		=> $this->input->post('phone'),
				'foto' 		=> $data_foto['foto'],
				'is_deleted' 	=> 0
			);
			$role = array($this->input->post('role_id'));
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			$email = "";
			$insert = $this->ion_auth->register($username, $password, $email, $data, $role);
			if ($insert) {
				$this->session->set_flashdata('message', "User Baru Berhasil Disimpan");
				redirect("user");
			} else {
				$this->session->set_flashdata('message_error', $this->ion_auth->errors());
				redirect("user");
			}
		} else {
			$this->data['roles'] = $this->roles_model->getAllById();
			$this->data['content'] = 'admin/user/create_v';
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function edit($id)
	{
		$this->form_validation->set_rules('name', "Nama", 'trim|required');
		$this->form_validation->set_rules('phone', "Phone", 'trim|required');
		$this->form_validation->set_rules('role_id', "Role", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			if (empty($_FILES['foto']['name'])) {
				$data = array(
					'first_name' => $this->input->post('name'),
					'username' => $this->input->post('username'),
					'phone' => $this->input->post('phone'),
					'role_id' => $this->input->post('role_id'),
					'password' => $this->input->post('password'),
				);
			}else{
				$foto         = $this->input->post('foto');
				$location_path = './uploads/foto-user/';
				$name = $this->input->post('name');
				$name = str_replace(' ', '-', $name);
				$uploaded      = uploadFile("foto".$foto, $location_path,$name);
			    if($uploaded['status']==1){
			    	$data_foto['foto'] = str_replace(' ', '_', $uploaded['message']);
			    }
			    $data = array(
					'first_name' 	=> $this->input->post('name'),
					'username' 		=> $this->input->post('username'),
					'phone' 		=> $this->input->post('phone'),
					'role_id' => $this->input->post('role_id'),
					'foto' 		=> $data_foto['foto'],
				);
			}
			$user_id = $this->input->post('id');
			$update = $this->ion_auth->update($user_id, $data);
			$data_update = array('role_id' => $this->input->post('role_id'));
			$update_users_roles = $this->user_model->update_users_roles($data_update,['user_id' => $user_id]);
			if ($update_users_roles)
			{
				$this->session->set_flashdata('message', "User Berhasil Diubah");
				redirect("user", "refresh");
			} else {
				$this->session->set_flashdata('message_error', "User Gagal Diubah");
				redirect("user", "refresh");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("user/edit/" . $id);
			} else {
				$this->data['id'] = $id;
				$data = $this->user_model->getOneBy(array("users.id" => $this->data['id']));
				$this->data['roles'] = $this->roles_model->getAllBy(null, null, null, null, null);
				$this->data['first_name'] =   (!empty($data)) ? $data->first_name : "";
				$this->data['last_name'] =   (!empty($data)) ? $data->last_name : "";
				$this->data['username'] =   (!empty($data)) ? $data->username : "";
				$this->data['address'] =   (!empty($data)) ? $data->address : "";
				$this->data['email'] =   (!empty($data)) ? $data->email : "";
				$this->data['phone'] =   (!empty($data)) ? $data->phone : "";
				$this->data['role_id'] =   (!empty($data)) ? $data->role_id : "";
				$this->data['foto'] =   (!empty($data)) ? $data->foto : "";
				$this->data['content'] = 'admin/user/edit_v';
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
			1 => 'users.first_name',
			2 => 'role_name',
			3 => 'users.username',
			4 => 'users.phone',
			5 => 'users.photo',
			6 => 'action'
		);
		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$where = array();
		// $where= array("roles.id >"=>"1");

		$limit = 0;
		$start = 0;
		$totalData = $this->user_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);

		$searchColumn = $this->input->post('columns');
		$isSearchColumn = false;

		if (!empty($this->input->post('search')['value'])) {
			$search_value = $this->input->post('search')['value'];
			$search = array(
				"users.first_name" => $search_value,
				"users.username" => $search_value,
				"users.phone" => $search_value
			);
			$totalFiltered = $this->user_model->getCountAllBy($limit, $start, $search, $order, $dir);
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->user_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$edit_url = "";
				$delete_url = "";

				if ($this->data['is_can_edit'] && $data->is_deleted == 0) {
					$edit_url = "<a href='" . base_url() . "user/edit/" . $data->id . "' class='btn btn-sm btn-warning' data-toggle='tooltip' title='Ubah Data' data-placement='bottom'><i class='fa fa-edit fa-w-20'></i></a>";
				}
				if ($this->data['is_can_delete']) {
					if ($data->is_deleted == 0) {
						$delete_url = "<a href='#' url='" . base_url() . "user/destroy/" . $data->id . "/" . $data->is_deleted . "' class='btn btn-sm btn-danger delete' data-toggle='tooltip' title='Non Aktifkan Data' data-placement='bottom'><i class='fa fa-times fa-w-20'></i></a>";
					} else {
						$delete_url = "<a href='#' url='" . base_url() . "user/destroy/" . $data->id . "/" . $data->is_deleted . "' class='btn btn-sm btn-success delete' data-toggle='tooltip' title='Mengaktifkan Data' data-placement='bottom'><i class='fa fa-check fa-w-20'></i></a>";
					}
				}


				$nestedData['id'] 			= $start + $key + 1;
				$nestedData['name'] 		= $data->first_name;
				$nestedData['username'] 	= $data->username;
				$nestedData['current_password'] 	= $data->current_password;
				$nestedData['role_name'] 	= $data->role_name;
				// $nestedData['groups'] 	= $data->group_name;  
				$nestedData['phone'] = $data->phone;
				// $nestedData['email'] = $data->email;
				if(empty($data->foto)){
                	$nestedData['foto'] = ''; 	
                }else{
                	$foto = explode(".", $data->foto);
                	$nestedData['foto'] = "<img width='80px' src=".base_url()."uploads/foto-user/".$data->foto.">"; 
                }
				$nestedData['action'] = $edit_url . " " . $delete_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function destroy()
	{
		$response_data = array();
		$response_data['status'] = false;
		$response_data['msg'] = "";
		$response_data['data'] = array();

		$id = $this->uri->segment(3);
		$is_deleted = $this->uri->segment(4);
		if (!empty($id)) {
			$this->load->model("user_model");
			$data = array(
				'is_deleted' => ($is_deleted == 1) ? 0 : 1
			);
			$update = $this->user_model->update($data, array("id" => $id));

			$response_data['data'] = $data;
			$response_data['status'] = true;
		} else {
			$response_data['msg'] = "ID Harus Diisi";
		}

		echo json_encode($response_data);
	}
}
