<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Transaksi_nota extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('transaksi_nota_model');
		$this->load->model('transaksi_nota_detail_model');
		$this->load->model('cabang_model');
	}
	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$cek_insert = $this->transaksi_nota_model->getOneBy(['transaksi_nota.tanggal' => date('Y-m-d')]);
			$this->data['cek_insert'] = $cek_insert ? 1 : 0;
			$this->data['content'] = 'admin/transaksi_nota/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function pemesanan_create()
	{
		$this->form_validation->set_rules('tanggal', "tanggal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {

			$cabang_id = $this->input->post('cabang');
			$tanggal = $this->input->post('tanggal');
			$angka_awal = $this->input->post('angka_awal');
			$angka_akhir = $this->input->post('angka_akhir');
			$huruf_nota = $this->input->post('huruf_nota');


			$data_transaksi_nota = array(
				'tanggal' => $tanggal,
				'cabang_id' => $cabang_id,
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			$insert_transaksi_nota = $this->transaksi_nota_model->insert($data_transaksi_nota);
			$data_transaksi_nota_detail = array(
				'transaksi_nota_id' => $insert_transaksi_nota,
				'huruf_nota' => $huruf_nota,
				'angka_awal' => $angka_awal,
				'angka_akhir' => $angka_akhir,
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			$insert_transaksi_nota_detail = $this->transaksi_nota_detail_model->insert($data_transaksi_nota_detail);

			if ($insert_transaksi_nota_detail) {
				$this->session->set_flashdata('message', "Data Transaksi Nota Baru Berhasil Disimpan");
				redirect("transaksi_nota/pemesanan_create_more/" . $insert_transaksi_nota);
			} else {
				$this->session->set_flashdata('message_error', "Data Transaksi Nota Baru Gagal Disimpan");
				redirect("transaksi_nota");
			}
		} else {
			if ($this->data['is_can_create']) {
				$this->data['cabang'] = $this->cabang_model->getAllById();
				$this->data['content'] = 'admin/transaksi_nota/pemesanan_create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}
	public function pemesanan_create_more($id)
	{
		$this->form_validation->set_rules('id', "id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {

			$id = $this->input->post('id');
			$data_transaksi_nota_detail = array(
				'transaksi_nota_id' => $id,
				'huruf_nota' => $this->input->post('huruf_nota'),
				'angka_awal' => $this->input->post('angka_awal'),
				'angka_akhir' => $this->input->post('angka_akhir'),
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			$insert_transaksi_nota_detail = $this->transaksi_nota_detail_model->insert($data_transaksi_nota_detail);

			if ($insert_transaksi_nota_detail) {
				$this->session->set_flashdata('message', "Data Transaksi Nota Baru Berhasil Disimpan");
				redirect("transaksi_nota/pemesanan_create_more/" . $id);
			} else {
				$this->session->set_flashdata('message_error', "Data Transaksi Nota Baru Gagal Disimpan");
				redirect("transaksi_nota");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("transaksi_nota");
			} else {
				$this->data['id'] = $id;
				$this->data['nota'] = $this->transaksi_nota_model->getOneBy(array("transaksi_nota.id" => $this->data['id']));
				$this->data['data_nota'] = $this->transaksi_nota_detail_model->getAllById(['transaksi_nota_id' => $id]);
				$this->data['cabang'] = $this->cabang_model->getAllById();
				$this->data['content'] = 'admin/transaksi_nota/pemesanan_create_more_v';
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function detail()
	{
		$this->data['id'] = $this->uri->segment(3);
		$this->data['data_nota'] = $this->transaksi_nota_model->getOneBy(array("transaksi_nota.id" => $this->data['id']));
		$this->data['data_nota_detail'] = $this->transaksi_nota_detail_model->getAllById(['transaksi_nota_id' => $this->data['id']]);
		$this->data['cek_insert'] = $this->data['data_nota']->tanggal == date('Y-m-d') ? 1 : 0;
		$this->data['content'] = 'admin/transaksi_nota/detail_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
			1 => 'transaksi_nota.tanggal',
			2 => 'transaksi_nota.cabang_id',
			3 => 'action'
		);
		$where = array();

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->transaksi_nota_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);

		$searchColumn = $this->input->post('columns');
		$isSearchColumn = false;

		if (!empty($searchColumn[0]['search']['value'])) {
			$value = $searchColumn[0]['search']['value'];
			$isSearchColumn = true;
			$where['transaksi_nota.tanggal'] = $value;
		}

		if ($isSearchColumn) {
			$totalFiltered = $this->transaksi_nota_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
			$totalData = $totalFiltered;
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->transaksi_nota_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$detail_url = "";
				$add_url = "";
				$add_url = "<a href='" . base_url() . "transaksi_nota/pemesanan_create_more/" . $data->id . "' class='btn btn-sm btn-success' data-toggle='tooltip' title='Tambah Data' data-placement='bottom'><i class='fa fa-plus fa-w-20'></i></a>";
				$detail_url = "<a href='" . base_url() . "transaksi_nota/detail/" . $data->id . "' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";

				$nestedData['id'] = $start + $key + 1;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['cabang'] = $data->cabang_id;
				$nestedData['action'] = $detail_url . ' ' . $add_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function destroy()
	{
		$response_data = array();
		$response_data['status'] = false;
		$response_data['msg'] = "";
		$response_data['data'] = array();

		$id = $this->uri->segment(3);
		$is_deleted = $this->uri->segment(4);
		if (!empty($id)) {
			$this->load->model("transaksi_nota_model");
			$data = array(
				'is_deleted' => ($is_deleted == 1) ? 0 : 1
			);

			$response_data['data'] = $data;
			$response_data['status'] = true;
		} else {
			$response_data['msg'] = "ID Harus Diisi";
		}

		echo json_encode($response_data);
	}
}
