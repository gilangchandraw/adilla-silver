<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH.'core/Admin_Controller.php';
class nota extends Admin_Controller {
 	public function __construct()
	{
		parent::__construct(); 
	 	$this->load->model('nota_model');
	 	$this->load->model('cabang_model');
	 	$this->load->model('pemesanan_nota_cabang_model');
	 	$this->load->model('pemesanan_nota_cabang_detail_model');
	 	$this->load->model('pemesanan_nota_detail_model');
	 	$this->load->model('pemesanan_nota_model');
	}

	public function index()
	{
		$this->load->helper('url');
		if($this->data['is_can_read']){
			$this->data['content'] = 'admin/nota/list_v'; 	
		}else{
			$this->data['content'] = 'errors/html/restrict'; 
		}
		
		$this->load->view('admin/layouts/page',$this->data);  
	}

	

	public function edit()
	{ 
		$this->form_validation->set_rules('kode_nota', "kode_nota Is Required", 'trim|required'); 
		   
		if ($this->form_validation->run() === TRUE)
		{
		 	$id = $this->input->post('id');
			$data = array(
				'kode_nota' => $this->input->post('kode_nota'),
				'nama_nota' => $this->input->post('nama_nota'),
				'stok' => $this->input->post('stok'),
				'updated_by' => $this->data['users']->id
			); 
			$update = $this->nota_model->update($data,array("id"=>$this->input->post('id')));
			if ($update)
			{ 
				$this->session->set_flashdata('message', "Data nota Berhasil Diedit");
				redirect("nota");
			}
			else
			{
				$this->session->set_flashdata('message_error',"Data nota Gagal Diedit");
				redirect("nota");
			}
		} 
		else
		{
			if(!empty($_POST)){ 
				$id = $this->input->post('id'); 
				$this->session->set_flashdata('message_error',validation_errors());
				return redirect("nota/edit/".$id);	
			}else{
				if($this->data['is_can_edit']){    
					$this->data['id']= $this->uri->segment(3);
					$this->data['nota'] = $this->nota_model->getOneBy(array("nota.id"=>$this->data['id']));
					$this->data['content'] = 'admin/nota/edit_v';
		        }else{
		            $this->data['content']  = 'errors/html/restrict'; 
		        } 
		        $this->load->view('admin/layouts/page',$this->data);
			}  
		}    
		
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
			1 => 'cabang.kode_cabang',
			2 => 'cabang.nama_cabang',
			3 => 'cabang.alamat',
			4 => 'action'
		);

		$where = array();
		// if(!$this->data['is_superadmin']){
		// 	$where['cabang.office_id'] = $this->data['users']->office_id;
		// }

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->cabang_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		if (!empty($this->input->post('search')['value'])) {
			$search_value = $this->input->post('search')['value'];
			$search = array(
				"cabang.kode_cabang" => $search_value,
				"cabang.nama_cabang" => $search_value,
				"cabang.alamat" => $search_value,
			);
			$totalFiltered = $this->cabang_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->cabang_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$tambah_url = "";
				if ($this->data['is_can_edit'] && $data->is_deleted == 0) {
					$tambah_url = "<a href='" . base_url() . "nota/pemesanan/" . $data->id . "' class='btn btn-sm btn-primary' data-toggle='tooltip' title='Tambah Pemesanan Nota' data-placement='bottom'><i class='fa fa-plus fa-w-20'></i></a>";
				}
				$nestedData['id'] = $start + $key + 1;
				$nestedData['kode_cabang'] = $data->kode_cabang;
				$nestedData['nama_cabang'] = $data->nama_cabang;
				$nestedData['action'] = $tambah_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function pemesanan($id)
	{
		$this->load->helper('url');
		if($this->data['is_can_read']){
			$this->data['cabang_id'] = $id; 	
			$this->data['content'] = 'admin/nota/list_pemesanan_v'; 	
		}else{
			$this->data['content'] = 'errors/html/restrict'; 
		}
		
		$this->load->view('admin/layouts/page',$this->data);  
	}

	public function pemesanan_create($cabang_id)
	{ 
		$this->form_validation->set_rules('cabang_id',"cabang_id Is Required", 'trim|required');
		 
		if ($this->form_validation->run() === TRUE)
		{ 
			$cabang_id = $this->input->post('cabang_id');
			$tanggal = $this->input->post('tanggal');
			$pemesanan_nota_id = $this->input->post('huruf_nota');
			
			// insert pemesanan nota cabang
			$data = array(
				'tanggal' => $tanggal,
				'cabang_id' => $cabang_id,
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			); 
			$insert_pemesanan = $this->pemesanan_nota_cabang_model->insert($data);
			// insert pemesanan nota detail
			$data_detail = array(
				'pemesanan_nota_cabang_id' => $insert_pemesanan,
				'pemesanan_nota_detail_id' => $pemesanan_nota_id,
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			); 
			$insert_pemesanan_detail = $this->pemesanan_nota_cabang_detail_model->insert($data_detail);

			//update status stok nota jadi 1 karna sudah pindah ke cabang
			$data_update = array('status_stok_nota' => 1);
			$update = $this->pemesanan_nota_detail_model->update($data_update,['pemesanan_nota_detail.id' => $pemesanan_nota_id]);
			//update ke nota
			$data_update = array('status_stok_nota' => 1, 'pemesanan_nota_cabang_id' => $insert_pemesanan);
			$update_nota = $this->nota_model->update($data_update,['nota.pemesanan_nota_detail_id' => $pemesanan_nota_id]);

			
			if ($insert_pemesanan_detail)
			{ 
				$this->session->set_flashdata('message', "Data nota Baru Berhasil Disimpan");
				redirect("nota/pemesanan_create_more/".$insert_pemesanan);
			}
			else
			{
				$this->session->set_flashdata('message_error',"Data nota Baru Gagal Disimpan");
				redirect("nota");
			}
		}else{  
			if($this->data['is_can_create']){ 
				$this->data['cabang_id'] = $cabang_id;
				$where_stok['cabang_id'] = $cabang_id;
				$where_stok['jenis_nota'] = 1;
				$where_stok['status_stok_nota'] = 0;
				$this->data['stok'] = $this->pemesanan_nota_detail_model->getAllById($where_stok);
				$this->data['content'] = 'admin/nota/pemesanan_create_v'; 
	        }else{
	            $this->data['content']  = 'errors/html/restrict'; 
	        } 
	        $this->load->view('admin/layouts/page',$this->data);
		}
	} 

	public function pemesanan_create_more($pemesanan_nota_id)
	{ 
		$this->form_validation->set_rules('pemesanan_nota_cabang_id',"pemesanan_nota_cabang_id Is Required", 'trim|required');
		 
		if ($this->form_validation->run() === TRUE)
		{ 
			$pemesanan_nota_cabang_id = $this->input->post('pemesanan_nota_cabang_id');
			$pemesanan_nota_id = $this->input->post('huruf_nota');
			
			// insert pemesanan nota detail
			$data_detail = array(
				'pemesanan_nota_cabang_id' => $pemesanan_nota_cabang_id,
				'pemesanan_nota_detail_id' => $pemesanan_nota_id,
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			); 
			$insert_pemesanan_detail = $this->pemesanan_nota_cabang_detail_model->insert($data_detail);

			//update status stok nota jadi 1 karna sudah pindah ke cabang
			$data_update = array('status_stok_nota' => 1);
			$update = $this->pemesanan_nota_detail_model->update($data_update,['pemesanan_nota_detail.id' => $pemesanan_nota_id]);
			//update ke nota
			$data_update = array('status_stok_nota' => 1, 'pemesanan_nota_cabang_id' => $pemesanan_nota_cabang_id);
			$update_nota = $this->nota_model->update($data_update,['nota.pemesanan_nota_detail_id' => $pemesanan_nota_id]);
			
			if ($update_nota)
			{ 
				$this->session->set_flashdata('message', "Data nota Baru Berhasil Disimpan");
				redirect("nota/pemesanan_create_more/".$pemesanan_nota_cabang_id);
			}
			else
			{
				$this->session->set_flashdata('message_error',"Data nota Baru Gagal Disimpan");
				redirect("nota");
			}
		}else{  
			if($this->data['is_can_create']){ 
				// GET MASTER
				$this->data['pemesanan'] = $this->pemesanan_nota_cabang_model->getOneBy(['pemesanan_nota_cabang.id' => $pemesanan_nota_id]);

				$where_stok['jenis_nota'] = 1;
				$where_stok['status_stok_nota'] = 0;
				$where_stok['cabang_id'] = $this->data['pemesanan']->cabang_id;
				$this->data['stok'] = $this->pemesanan_nota_detail_model->getAllById($where_stok);
				// echo '<pre>',print_r($this->data['stok'],1),'</pre>';
				// // echo $pemesanan_nota_id;
				// die();
				$this->data['pemesanan_nota_id'] = $pemesanan_nota_id; 
				$pemesanan_detail = $this->pemesanan_nota_cabang_detail_model->getOneBy(['pemesanan_nota_cabang_id' => $pemesanan_nota_id]);
				// get detail 
				$data_detail = $this->pemesanan_nota_detail_model->getOneBy(['id' => $pemesanan_detail->pemesanan_nota_detail_id]);
				if ($data_detail) {
					$data_detail = $this->pemesanan_nota_detail_model->getAllById(['pemesanan_nota_id' => $data_detail->pemesanan_nota_id, 'status_stok_nota' => 1]);
				}
				
				$this->data['pemesanan_detail'] = $data_detail; 
				$this->data['content'] = 'admin/nota/pemesanan_create_more_v'; 
	        }else{
	            $this->data['content']  = 'errors/html/restrict'; 
	        } 
	        $this->load->view('admin/layouts/page',$this->data);
		}
	} 

	public function dataListPemesanan()
	{
		$columns = array(
			0 => 'id',
			1 => 'cabang.kode_cabang',
			2 => 'cabang.nama_cabang',
			3 => 'cabang.alamat',
			4 => 'action'
		);

		$where = array();
		$cabang_id = $this->uri->segment(3);
		$where['pemesanan_nota_cabang.cabang_id'] = $cabang_id;
		// if(!$this->data['is_superadmin']){
		// 	$where['cabang.office_id'] = $this->data['users']->office_id;
		// }

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->pemesanan_nota_cabang_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		if (!empty($this->input->post('search')['value'])) {
			$search_value = $this->input->post('search')['value'];
			$search = array(
				"cabang.kode_cabang" => $search_value,
				"cabang.nama_cabang" => $search_value,
				"cabang.alamat" => $search_value,
			);
			$totalFiltered = $this->pemesanan_nota_cabang_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->pemesanan_nota_cabang_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$detail_url = "";
				$add_url = "";
     			
            	$add_url = "<a href='".base_url()."nota/pemesanan_create_more/".$data->id."' class='btn btn-sm btn-success' data-toggle='tooltip' title='Tambah Data' data-placement='bottom'><i class='fa fa-plus fa-w-20'></i></a>";
            	$detail_url = "<a href='".base_url()."nota/detail/".$data->id."' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";
				$nestedData['id'] = $start + $key + 1;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['action'] = $detail_url.' '.$add_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function detail($pemesanan_nota_cabang_id)
	{
		$this->load->helper('url');
		if($this->data['is_can_read']){
			$this->data['pemesanan_nota_cabang_id'] = $pemesanan_nota_cabang_id; 	
			$this->data['content'] = 'admin/nota/list_nota_v'; 	
		}else{
			$this->data['content'] = 'errors/html/restrict'; 
		}
		
		$this->load->view('admin/layouts/page',$this->data);  
	}

	public function dataListNota()
	{
		$columns = array(
			0 => 'id',
			1 => 'cabang.kode_cabang',
			2 => 'cabang.nama_cabang',
			3 => 'cabang.alamat',
			4 => 'action'
		);

		$where = array();
		$pemesanan_nota_cabang_id = $this->uri->segment(3);
		$where['nota.pemesanan_nota_cabang_id'] = $pemesanan_nota_cabang_id;
		$where['nota.status_stok_nota'] = 1;

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->nota_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		$searchColumn = $this->input->post('columns');
        $isSearchColumn = false;

        if(!empty($searchColumn[0]['search']['value'])){
            $value = $searchColumn[0]['search']['value'];
            $isSearchColumn = true;
            $where['nota.huruf_nota'] = $value;
        }
        if(!empty($searchColumn[1]['search']['value'])){
            $value = $searchColumn[1]['search']['value'];
            $isSearchColumn = true;
            if ($value == 'baru') {
            	$where['nota.status'] = 0;
            } else {
            	$where['nota.status'] = $value;
            }
            
            
        }
        
        if($isSearchColumn){
			$totalFiltered = $this->nota_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
			$totalData = $totalFiltered;
        }else{
        	$totalFiltered = $totalData;
        }

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->nota_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$nestedData['id'] = $start + $key + 1;
				$nestedData['no_nota'] = $data->no_nota;
				if ($data->status == 0) {
					$nestedData['status'] = 'Nota Baru';
				}elseif ($data->status == 1) {
					$nestedData['status'] = 'Nota Sudah Terjual';
				}elseif ($data->status == 2) {
					$nestedData['status'] = 'Nota Sudah Kembali';
				}elseif ($data->status == 3) {
					$nestedData['status'] = 'Nota Batal';
				}elseif ($data->status == 4) {
					$nestedData['status'] = 'Nota Tukar Plus';
				}elseif ($data->status == 5) {
					$nestedData['status'] = 'Nota Tukar Min';
				}elseif ($data->status == 6) {
					$nestedData['status'] = 'Nota Hilang 2R';
				}elseif ($data->status == 7) {
					$nestedData['status'] = 'Nota Hilang 3R';
				}

				
				
				// $nestedData['action'] = $detail_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function get_nota(){

		$huruf_nota = $this->input->post('huruf_nota');
		$cabang_id = $this->input->post('cabang_id');
		$where['cabang_id'] = $cabang_id;
		$where['jenis_nota'] = 0;
		if (!$this->data['is_superadmin']) {
			$cabang = $this->cabang_model->getOneBy(['users_id' => $this->data['users']->id]);
			$where['cabang_id'] = $cabang->id;
			$where['jenis_nota'] = 1;
			$where['status_stok_nota'] = 1;
		}
		// untuk admin
		if ($this->data['is_superadmin']) {
			$cabang_id_admin = $this->input->post('cabang_id_admin');
			$cabang = $this->cabang_model->getOneBy(['cabang.id' => $cabang_id_admin]);
			$where['cabang_id'] = $cabang->id;
			$where['jenis_nota'] = 1;
			$where['status_stok_nota'] = 1;
		}
		$where['huruf_nota'] = $huruf_nota;
		$where['status'] = 0;
		$data_nota = $this->nota_model->getOneBy($where);
		if($data_nota){
			$data['status'] = true;
			$no_nota = explode('~', $data_nota->no_nota);
			$data['no_nota_view'] = $no_nota[0];
			if (!$this->data['is_superadmin']) {
				$data['no_nota'] = $data_nota->no_nota;
			} else {
				$data['no_nota'] = $data_nota->no_nota;
			}
			
		}else{
			$data['status'] = false;
		}
		echo json_encode($data);
	}

}
