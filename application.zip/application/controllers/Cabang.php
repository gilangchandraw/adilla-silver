<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Cabang extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('cabang_model');
		$this->load->model('user_model');
		$this->load->model('uang_nota_model');
	}

	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$this->data['content'] = 'admin/cabang/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function create()
	{
		$this->form_validation->set_rules('nama_cabang', "nama_cabang Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$kode_cabang = $this->cabang_model->kode_cabang();
			$data = array(
				'kode_cabang' => $this->input->post('kode_cabang'),
				'nama_cabang' => $this->input->post('nama_cabang'),
				'tanggal_awal_kontrak' => $this->input->post('tanggal_awal_kontrak'),
				'tanggal_akhir_kontrak' => $this->input->post('tanggal_akhir_kontrak'),
				'alamat' => $this->input->post('alamat'),
				'kas' => $this->input->post('kas'),
				// 'kas_awal' => $this->input->post('kas'),
				'stok_925' => $this->input->post('stok_925'),
				'stok_sp' => $this->input->post('stok_sp'),
				'kas_sepuhan' => $this->input->post('kas_sepuhan'),
				'users_id' => $this->input->post('users_id'),
				'stok_retur_bk_925' => $this->input->post('stok_retur_bk_925'),
				'stok_retur_pajang_925' => $this->input->post('stok_retur_pajang_925'),
				'stok_retur_bk_sp' => $this->input->post('stok_retur_bk_sp'),
				'stok_retur_pajang_sp' => $this->input->post('stok_retur_pajang_sp'),
				'tipe_cabang' => $this->input->post('tipe_cabang'),
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			$insert = $this->cabang_model->insert($data);
			//insert stok sepuhan untuk cabang
			for ($y = 1; $y <= 49; $y++) {
				$data_stok_sepuhan_cabang = array(
					'cabang_id' => $insert,
					'sepuhan_id' => $y,
					'stok' => 0
				);
				$this->db->insert('stok_sepuhan_cabang', $data_stok_sepuhan_cabang);
			}
			//insert stok kotak cincin untuk cabang
			for ($y = 1; $y <= 23; $y++) {
				$data_stok_kotak_cincin_cabang = array(
					'cabang_id' => $insert,
					'kotak_cincin_id' => $y,
					'stok' => 0
				);
				$this->db->insert('stok_kotak_cincin_cabang', $data_stok_kotak_cincin_cabang);
			}

			if ($insert) {
				$this->session->set_flashdata('message', "Data cabang Baru Berhasil Disimpan");
				redirect("cabang");
			} else {
				$this->session->set_flashdata('message_error', "Data cabang Baru Gagal Disimpan");
				redirect("cabang");
			}
		} else {
			if ($this->data['is_can_create']) {
				$this->data['kode_cabang'] = $this->cabang_model->kode_cabang();
				$this->data['kepala_cabang'] = $this->user_model->getAllById(['roles.id' => 4, 'users.is_deleted' => 0]);
				$this->data['content'] = 'admin/cabang/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function edit()
	{
		$this->form_validation->set_rules('nama_cabang', "nama_cabang Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$id = $this->input->post('id');
			$data = array(
				'kode_cabang' => $this->input->post('kode_cabang'),
				'nama_cabang' => $this->input->post('nama_cabang'),
				'users_id' => $this->input->post('users_id'),
				'alamat' => $this->input->post('alamat'),
				'kas' => $this->input->post('kas'),
				'tanggal_awal_kontrak' => $this->input->post('tanggal_awal_kontrak'),
				'tanggal_akhir_kontrak' => $this->input->post('tanggal_akhir_kontrak'),
				// 'kas_awal' => $this->input->post('kas'),
				'stok_925' => $this->input->post('stok_925'),
				'stok_sp' => $this->input->post('stok_sp'),
				'kas_sepuhan' => $this->input->post('kas_sepuhan'),
				'stok_retur_bk_925' => $this->input->post('stok_retur_bk_925'),
				'stok_retur_pajang_925' => $this->input->post('stok_retur_pajang_925'),
				'stok_retur_bk_sp' => $this->input->post('stok_retur_bk_sp'),
				'stok_retur_pajang_sp' => $this->input->post('stok_retur_pajang_sp'),
				'tipe_cabang' => $this->input->post('tipe_cabang'),
				'updated_by' => $this->data['users']->id
			);
			$update = $this->cabang_model->update($data, array("id" => $id));
			if ($update) {
				$this->session->set_flashdata('message', "Data cabang Berhasil Diedit");
				redirect("cabang");
			} else {
				$this->session->set_flashdata('message_error', "Data cabang Gagal Diedit");
				redirect("cabang");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("cabang/edit/" . $id);
			} else {
				if ($this->data['is_can_edit']) {
					$this->data['kepala_cabang'] = $this->user_model->getAllById(['roles.id' => 4, 'users.is_deleted' => 0]);
					$this->data['id'] = $this->uri->segment(3);
					$this->data['cabang'] = $this->cabang_model->getOneBy(array("cabang.id" => $this->data['id']));
					$this->data['content'] = 'admin/cabang/edit_v';
				} else {
					$this->data['content']  = 'errors/html/restrict';
				}
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}
	public function detail()
	{

		$this->data['id'] = $this->uri->segment(3);

		$this->data['cabang'] = $this->cabang_model->getOneBy(['cabang.id' => $this->data['id']]);
		$this->data['content'] = 'admin/cabang/detail_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
			1 => 'cabang.kode_cabang',
			2 => 'cabang.nama_cabang',
			3 => 'cabang.alamat',
			4 => 'action'
		);

		$where = array();
		// if(!$this->data['is_superadmin']){
		// 	$where['cabang.office_id'] = $this->data['users']->office_id;
		// }

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->cabang_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		if (!empty($this->input->post('search')['value'])) {
			$search_value = $this->input->post('search')['value'];
			$search = array(
				"cabang.kode_cabang" => $search_value,
				"cabang.nama_cabang" => $search_value,
				"cabang.alamat" => $search_value,
			);
			$totalFiltered = $this->cabang_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->cabang_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$detail_url = "";
				$edit_url = "";
				$delete_url = "";
				if ($data->is_deleted == 0) {
					// $edit_url = "<a href='".base_url()."cabang/edit/".$data->id."' class='btn btn-sm btn-info'>Ubah</a>";
						$edit_url = "<a href='" . base_url() . "cabang/edit/" . $data->id . "' class='btn btn-sm btn-warning' data-toggle='tooltip' title='Edit Data' data-placement='bottom'><i class='fa fa-edit fa-w-20'></i></a>";
					$detail_url = "<a href='" . base_url() . "cabang/detail/" . $data->id . "' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";
				}
				if ($this->data['is_can_edit']) {
					if ($data->is_deleted == 0) {
						$delete_url = "<a href='#' 
							url='" . base_url() . "cabang/destroy/" . $data->id . "/" . $data->is_deleted . "' class='btn btn-sm btn-danger delete' data-toggle='tooltip' title='Non Aktifkan Data' data-placement='bottom'><i class='fa fa-times fa-w-20'></i></a>";
					} else {
						$delete_url = "<a href='#' 
	        				url='" . base_url() . "cabang/destroy/" . $data->id . "/" . $data->is_deleted . "' class='btn btn-sm btn-success delete' data-toggle='tooltip' title='Aktifkan Data' data-placement='bottom'><i class='fa fa-check fa-w-20'></i></a>";
					}
				}

				$nestedData['id'] = $start + $key + 1;
				$nestedData['kode_cabang'] = $data->kode_cabang;
				$nestedData['first_name'] = $data->first_name;
				$nestedData['nama_cabang'] = $data->nama_cabang;
				$limtiDeskripsi = 30;
				$nestedData['alamat'] = substr($data->alamat, 0, $limtiDeskripsi) . '...';
				$nestedData['kas'] = 'Rp. ' . number_format($data->kas);
				$nestedData['stok_925'] = $data->stok_925;
				$nestedData['stok_sp'] = $data->stok_sp;
				$nestedData['kas_sepuhan'] = 'Rp. ' . number_format($data->kas_sepuhan);
				$nestedData['action'] = $detail_url . " " . $delete_url.' '.$edit_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function destroy()
	{
		$response_data = array();
		$response_data['status'] = false;
		$response_data['msg'] = "";
		$response_data['data'] = array();

		$id = $this->uri->segment(3);
		$is_deleted = $this->uri->segment(4);
		if (!empty($id)) {
			$this->load->model("cabang_model");
			$data = array(
				'is_deleted' => ($is_deleted == 1) ? 0 : 1
			);
			$update = $this->cabang_model->update($data, array("id" => $id));

			$response_data['data'] = $data;
			$response_data['status'] = true;
		} else {
			$response_data['msg'] = "ID Harus Diisi";
		}

		echo json_encode($response_data);
	}

	public function get_data_cabang()
	{

		$cabang_id = $this->input->get('cabang_id');
		$where['cabang.id'] = $cabang_id;
		$cabang = $this->cabang_model->getOneBy($where);
		if ($cabang) {
			$data['status'] = true;
			$data['stok_retur_bk_925'] = $cabang->stok_retur_bk_925;
			$data['stok_retur_pajang_925'] = $cabang->stok_retur_pajang_925;
			$data['stok_retur_bk_sp'] = $cabang->stok_retur_bk_sp;
			$data['stok_retur_pajang_sp'] = $cabang->stok_retur_pajang_sp;
		} else {
			$data['status'] = false;
		}
		echo json_encode($data);
	}

	public function get_data_uang_nota()
	{

		$cabang_id = $this->input->get('cabang_id');
		$where['cabang_id'] = $cabang_id;
		$cabang = $this->uang_nota_model->getOneBy($where);
		if ($cabang) {
			$data['status'] = true;
			$data['total'] = $cabang->total;
		} else {
			$data['status'] = false;
		}
		echo json_encode($data);
	}
}
