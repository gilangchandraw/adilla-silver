<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Laporan_bulanan extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('cabang_model');
		$this->load->model('penjualan_model');
		$this->load->model('penjualan_detail_model');
		$this->load->model('enum_transaksi_barang_model');
		$this->load->model('barang_kembali_model');
		$this->load->model('tukar_plus_model');
		$this->load->model('tukar_plus_detail_model');
		$this->load->model('barang_kembali_detail_model');
		$this->load->model('pengeluaran_model');
		$this->load->model('pengeluaran_detail_model');
		$this->load->model('enum_pengeluaran_model');
		$this->load->model('histori_kas_model');
		$this->load->model('barang_rusak_model');
		$this->load->model('barang_hilang_model');
		$this->load->model('transaksi_sepuhan_detail_model');
		$this->load->model('transaksi_sepuhan_model');
	}


	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$this->data['cabang'] = $this->cabang_model->getAllById();
			$this->data['content'] = 'admin/laporan_bulanan/create_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function get_data(){

		$laporan = 1;
		$data_cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
		$cabang_id = $this->input->get('cabang_id');
		if (!$this->data['is_superadmin']) {
			$cabang_id = $data_cabang->id;
			$laporan = 1;
		}
		if ($this->data['is_superadmin']) {
			$data_cabang = $this->cabang_model->getOneBy(['cabang.id' => $cabang_id]);
		}
		$tanggal = $this->input->get('tanggal');
		$tanggal = explode('-', $tanggal);
		$bulan = $tanggal[0];
		$tahun = $tanggal[1];

		$no_bulan = $bulan;
		if ($bulan < 10) {
			$no_bulan = explode(0, $bulan);
			$no_bulan = $no_bulan[1];
		}
		// inisialisasi nama bulan
		if ($no_bulan == 1) {
			$nama_no_bulan = 'Januari';
		}elseif ($no_bulan == 2) {
			$nama_bulan = 'Februari';
		}elseif ($no_bulan == 3) {
			$nama_bulan = 'Maret';
		}elseif ($no_bulan == 4) {
			$nama_bulan = 'April';
		}elseif ($no_bulan == 5) {
			$nama_bulan = 'Mei';
		}elseif ($no_bulan == 6) {
			$nama_bulan = 'Juni';
		}elseif ($no_bulan == 7) {
			$nama_bulan = 'Juli';
		}elseif ($no_bulan == 8) {
			$nama_bulan = 'Agustus';
		}elseif ($no_bulan == 9) {
			$nama_bulan = 'September';
		}elseif ($no_bulan == 10) {
			$nama_bulan = 'Oktober';
		}elseif ($no_bulan == 11) {
			$nama_bulan = 'November';
		}elseif ($no_bulan == 12) {
			$nama_bulan = 'Desember';
		}
		//penjualan 25
		$where_penjualan_25['MONTH(penjualan_detail.created_at)'] = $bulan;
		$where_penjualan_25['YEAR(penjualan_detail.created_at)'] = $tahun;
		$where_penjualan_25['penjualan_detail.cabang_penjualan'] = $cabang_id;
		$where_penjualan_25['penjualan_detail.enum_penjualan'] = 2;
		$where_penjualan_25['penjualan_detail.jenis_transaksi_id'] = 1;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_penjualan_25['penjualan_detail.cabang_penjualan'] = $data_cabang->id;
		}
		$penjualan_25 = $this->penjualan_detail_model->sum($where_penjualan_25);
		//penjualan 30
		$where_penjualan_30['MONTH(penjualan_detail.created_at)'] = $bulan;
		$where_penjualan_30['YEAR(penjualan_detail.created_at)'] = $tahun;
		$where_penjualan_30['penjualan_detail.cabang_penjualan'] = $cabang_id;
		$where_penjualan_30['penjualan_detail.enum_penjualan'] = 2;
		$where_penjualan_30['penjualan_detail.jenis_transaksi_id'] = 2;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_penjualan_30['penjualan_detail.cabang_penjualan'] = $data_cabang->id;
		}
		$penjualan_30 = $this->penjualan_detail_model->sum($where_penjualan_30);
		//penjualan 35
		$where_penjualan_35['MONTH(penjualan_detail.created_at)'] = $bulan;
		$where_penjualan_35['YEAR(penjualan_detail.created_at)'] = $tahun;
		$where_penjualan_35['penjualan_detail.cabang_penjualan'] = $cabang_id;
		$where_penjualan_35['penjualan_detail.enum_penjualan'] = 2;
		$where_penjualan_35['penjualan_detail.jenis_transaksi_id'] = 3;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_penjualan_35['penjualan_detail.cabang_penjualan'] = $data_cabang->id;
		}
		$penjualan_35 = $this->penjualan_detail_model->sum($where_penjualan_35);
		//penjualan potong
		$where_penjualan_potong['MONTH(penjualan_detail.created_at)'] = $bulan;
		$where_penjualan_potong['YEAR(penjualan_detail.created_at)'] = $tahun;
		$where_penjualan_potong['penjualan_detail.cabang_penjualan'] = $cabang_id;
		$where_penjualan_potong['penjualan_detail.enum_penjualan'] = 2;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_penjualan_potong['penjualan_detail.cabang_penjualan'] = $data_cabang->id;
		}
		$penjualan_potong = $this->penjualan_detail_model->sum_potong($where_penjualan_potong);
		//TOTAL penjualan
		$where_penjualan['MONTH(penjualan_detail.created_at)'] = $bulan;
		$where_penjualan['YEAR(penjualan_detail.created_at)'] = $tahun;
		$where_penjualan['penjualan_detail.cabang_penjualan'] = $cabang_id;
		$where_penjualan['penjualan_detail.enum_penjualan'] = 2;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_penjualan['penjualan_detail.cabang_penjualan'] = $data_cabang->id;
		}
		$total_penjualan = $this->penjualan_detail_model->sum($where_penjualan);
		//Tukar plus 25
		$where_tukar_25['MONTH(tukar_plus_detail.created_at)'] = $bulan;
		$where_tukar_25['YEAR(tukar_plus_detail.created_at)'] = $tahun;
		$where_tukar_25['tukar_plus_detail.status'] = 'Tukar Plus';
		$where_tukar_25['tukar_plus_detail.cabang_tukar'] = $cabang_id;
		$where_tukar_25['tukar_plus_detail.jenis_transaksi_id'] = 1;
		$where_tukar_25['tukar_plus_detail.enum_tukar'] = 2;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_tukar_25['tukar_plus_detail.cabang_tukar'] = $data_cabang->id;
		}
		$tukar_25 = $this->tukar_plus_detail_model->sum($where_tukar_25);
		//Tukar plus 30
		$where_tukar_30['MONTH(tukar_plus_detail.created_at)'] = $bulan;
		$where_tukar_30['YEAR(tukar_plus_detail.created_at)'] = $tahun;
		$where_tukar_30['tukar_plus_detail.status'] = 'Tukar Plus';
		$where_tukar_30['tukar_plus_detail.cabang_tukar'] = $cabang_id;
		$where_tukar_30['tukar_plus_detail.jenis_transaksi_id'] = 2;
		$where_tukar_30['tukar_plus_detail.enum_tukar'] = 2;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_tukar_30['tukar_plus_detail.cabang_tukar'] = $data_cabang->id;
		}
		$tukar_30 = $this->tukar_plus_detail_model->sum($where_tukar_30);
		//Tukar plus 35
		$where_tukar_35['MONTH(tukar_plus_detail.created_at)'] = $bulan;
		$where_tukar_35['YEAR(tukar_plus_detail.created_at)'] = $tahun;
		$where_tukar_35['tukar_plus_detail.status'] = 'Tukar Plus';
		$where_tukar_35['tukar_plus_detail.cabang_tukar'] = $cabang_id;
		$where_tukar_35['tukar_plus_detail.jenis_transaksi_id'] = 3;
		$where_tukar_35['tukar_plus_detail.enum_tukar'] = 2;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_tukar_35['tukar_plus_detail.cabang_tukar'] = $data_cabang->id;
		}
		$tukar_35 = $this->tukar_plus_detail_model->sum($where_tukar_35);
		//Tukar plus`
		$where_tukar['MONTH(tukar_plus_detail.created_at)'] = $bulan;
		$where_tukar['YEAR(tukar_plus_detail.created_at)'] = $tahun;
		$where_tukar['tukar_plus_detail.status'] = 'Tukar Plus';
		$where_tukar['tukar_plus_detail.cabang_tukar'] = $cabang_id;
		$where_tukar['tukar_plus_detail.enum_tukar'] = 2;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_tukar['tukar_plus_detail.cabang_tukar'] = $data_cabang->id;
		}
		//Tukar plus potong
		$where_tukar_potong['MONTH(tukar_plus_detail.created_at)'] = $bulan;
		$where_tukar_potong['YEAR(tukar_plus_detail.created_at)'] = $tahun;
		$where_tukar_potong['tukar_plus_detail.status'] = 'Tukar Plus';
		$where_tukar_potong['tukar_plus_detail.cabang_tukar'] = $cabang_id;
		$where_tukar_potong['tukar_plus_detail.enum_tukar'] = 2;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_tukar_potong['tukar_plus_detail.cabang_tukar'] = $data_cabang->id;
		}
		$tukar_potong = $this->tukar_plus_detail_model->sum_potong($where_tukar_potong);
		$total_tukar = $this->tukar_plus_detail_model->sum($where_tukar);

		$total_berat_penjualan = $total_penjualan->berat + $total_tukar->berat;
		$total_harga_penjualan = $total_penjualan->harga + $total_tukar->harga;
		// BARANG RUSAK
		$where_rusak['MONTH(barang_rusak.created_at)'] = $bulan;
		$where_rusak['YEAR(barang_rusak.created_at)'] = $tahun;
		$where_rusak['barang_rusak.cabang_id'] = $cabang_id;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_rusak['barang_rusak.cabang_id'] = $data_cabang->id;
		}
		$barang_rusak = $this->barang_rusak_model->sum($where_rusak);

		//BK 17
		$where_bk_17['MONTH(barang_kembali_detail.created_at)'] = $bulan;
		$where_bk_17['YEAR(barang_kembali_detail.created_at)'] = $tahun;
		$where_bk_17['barang_kembali_detail.cabang_id_asal'] = $cabang_id;
		$where_bk_17['barang_kembali_detail.jenis_transaksi_id'] = 16;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_bk_17['barang_kembali_detail.cabang_id_asal'] = $data_cabang->id;
		}
		$bk_17 = $this->barang_kembali_detail_model->sum($where_bk_17);
		//BK 18
		$where_bk_18['MONTH(barang_kembali_detail.created_at)'] = $bulan;
		$where_bk_18['YEAR(barang_kembali_detail.created_at)'] = $tahun;
		$where_bk_18['barang_kembali_detail.cabang_id_asal'] = $cabang_id;
		$where_bk_18['barang_kembali_detail.jenis_transaksi_id'] = 15;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_bk_18['barang_kembali_detail.cabang_id_asal'] = $data_cabang->id;
		}
		$bk_18 = $this->barang_kembali_detail_model->sum($where_bk_18);
		//BK 19
		$where_bk_19['MONTH(barang_kembali_detail.created_at)'] = $bulan;
		$where_bk_19['YEAR(barang_kembali_detail.created_at)'] = $tahun;
		$where_bk_19['barang_kembali_detail.cabang_id_asal'] = $cabang_id;
		$where_bk_19['barang_kembali_detail.jenis_transaksi_id'] = 14;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_bk_19['barang_kembali_detail.cabang_id_asal'] = $data_cabang->id;
		}
		$bk_19 = $this->barang_kembali_detail_model->sum($where_bk_19);
		//BK 20
		$where_bk_20['MONTH(barang_kembali_detail.created_at)'] = $bulan;
		$where_bk_20['YEAR(barang_kembali_detail.created_at)'] = $tahun;
		$where_bk_20['barang_kembali_detail.cabang_id_asal'] = $cabang_id;
		$where_bk_20['barang_kembali_detail.jenis_transaksi_id'] = 7;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_bk_20['barang_kembali_detail.cabang_id_asal'] = $data_cabang->id;
		}
		$bk_20 = $this->barang_kembali_detail_model->sum($where_bk_20);
		//BK 22
		$where_bk_22['MONTH(barang_kembali_detail.created_at)'] = $bulan;
		$where_bk_22['YEAR(barang_kembali_detail.created_at)'] = $tahun;
		$where_bk_22['barang_kembali_detail.cabang_id_asal'] = $cabang_id;
		$where_bk_22['barang_kembali_detail.jenis_transaksi_id'] = 8;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_bk_22['barang_kembali_detail.cabang_id_asal'] = $data_cabang->id;
		}
		$bk_22 = $this->barang_kembali_detail_model->sum($where_bk_22);
		//BK 23
		$where_bk_23['MONTH(barang_kembali_detail.created_at)'] = $bulan;
		$where_bk_23['YEAR(barang_kembali_detail.created_at)'] = $tahun;
		$where_bk_23['barang_kembali_detail.cabang_id_asal'] = $cabang_id;
		$where_bk_23['barang_kembali_detail.jenis_transaksi_id'] = 9;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_bk_23['barang_kembali_detail.cabang_id_asal'] = $data_cabang->id;
		}
		$bk_23 = $this->barang_kembali_detail_model->sum($where_bk_23);
		//BK 24
		$where_bk_24['MONTH(barang_kembali_detail.created_at)'] = $bulan;
		$where_bk_24['YEAR(barang_kembali_detail.created_at)'] = $tahun;
		$where_bk_24['barang_kembali_detail.cabang_id_asal'] = $cabang_id;
		$where_bk_24['barang_kembali_detail.jenis_transaksi_id'] = 18;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_bk_24['barang_kembali_detail.cabang_id_asal'] = $data_cabang->id;
		}
		$bk_24 = $this->barang_kembali_detail_model->sum($where_bk_24);
		//BK 25
		$where_bk_25['MONTH(barang_kembali_detail.created_at)'] = $bulan;
		$where_bk_25['YEAR(barang_kembali_detail.created_at)'] = $tahun;
		$where_bk_25['barang_kembali_detail.cabang_id_asal'] = $cabang_id;
		$where_bk_25['barang_kembali_detail.jenis_transaksi_id'] = 10;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_bk_25['barang_kembali_detail.cabang_id_asal'] = $data_cabang->id;
		}
		$bk_25 = $this->barang_kembali_detail_model->sum($where_bk_25);
		//BK 27
		$where_bk_27['MONTH(barang_kembali_detail.created_at)'] = $bulan;
		$where_bk_27['YEAR(barang_kembali_detail.created_at)'] = $tahun;
		$where_bk_27['barang_kembali_detail.cabang_id_asal'] = $cabang_id;
		$where_bk_27['barang_kembali_detail.jenis_transaksi_id'] = 11;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_bk_27['barang_kembali_detail.cabang_id_asal'] = $data_cabang->id;
		}
		$bk_27 = $this->barang_kembali_detail_model->sum($where_bk_27);
		//BK 28
		$where_bk_28['MONTH(barang_kembali_detail.created_at)'] = $bulan;
		$where_bk_28['YEAR(barang_kembali_detail.created_at)'] = $tahun;
		$where_bk_28['barang_kembali_detail.cabang_id_asal'] = $cabang_id;
		$where_bk_28['barang_kembali_detail.jenis_transaksi_id'] = 13;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_bk_28['barang_kembali_detail.cabang_id_asal'] = $data_cabang->id;
		}
		$bk_28 = $this->barang_kembali_detail_model->sum($where_bk_28);

		//BK 29
		$where_bk_29['MONTH(barang_kembali_detail.created_at)'] = $bulan;
		$where_bk_29['YEAR(barang_kembali_detail.created_at)'] = $tahun;
		$where_bk_29['barang_kembali_detail.cabang_id_asal'] = $cabang_id;
		$where_bk_29['barang_kembali_detail.jenis_transaksi_id'] = 17;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_bk_29['barang_kembali_detail.cabang_id_asal'] = $data_cabang->id;
		}
		$bk_29 = $this->barang_kembali_detail_model->sum($where_bk_29);
		//BK 30
		$where_bk_30['MONTH(barang_kembali_detail.created_at)'] = $bulan;
		$where_bk_30['YEAR(barang_kembali_detail.created_at)'] = $tahun;
		$where_bk_30['barang_kembali_detail.cabang_id_asal'] = $cabang_id;
		$where_bk_30['barang_kembali_detail.jenis_transaksi_id'] = 12;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_bk_30['barang_kembali_detail.cabang_id_asal'] = $data_cabang->id;
		}
		$bk_30 = $this->barang_kembali_detail_model->sum($where_bk_30);
		//BK
		$where_bk['MONTH(barang_kembali_detail.created_at)'] = $bulan;
		$where_bk['YEAR(barang_kembali_detail.created_at)'] = $tahun;
		$where_bk['barang_kembali_detail.cabang_id_asal'] = $cabang_id;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_bk['barang_kembali_detail.cabang_id_asal'] = $data_cabang->id;
		}
		$bk = $this->barang_kembali_detail_model->sum($where_bk);
		//potong
		$where_potong['MONTH(barang_kembali_detail.created_at)'] = $bulan;
		$where_potong['YEAR(barang_kembali_detail.created_at)'] = $tahun;
		$where_potong['barang_kembali_detail.cabang_id_asal'] = $cabang_id;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_potong['barang_kembali_detail.cabang_id_asal'] = $data_cabang->id;
		}
		$potong = $this->barang_kembali_detail_model->sum_potong($where_potong);
		// SEPUHAN
		$where_sepuhan['MONTH(transaksi_sepuhan.created_at)'] = $bulan;
		$where_sepuhan['YEAR(transaksi_sepuhan.created_at)'] = $tahun;
		$where_sepuhan['transaksi_sepuhan.cabang_id'] = $cabang_id;
		// untuk cabang
		if (!$this->data['is_superadmin']) {
			$where_sepuhan['transaksi_sepuhan.cabang_id'] = $data_cabang->id;
		}
		$sepuhan = $this->transaksi_sepuhan_model->getAllById($where_sepuhan);
		//pengeluaran
		$where_pengeluaran['MONTH(pengeluaran.tanggal)'] = $bulan;
		$where_pengeluaran['YEAR(pengeluaran.tanggal)'] = $tahun;
		$where_pengeluaran['pengeluaran.cabang_id'] = $cabang_id;
		$where_pengeluaran['pengeluaran.enum'] = $laporan;
		if (!$this->data['is_superadmin']) {
			$where_pengeluaran['pengeluaran.cabang_id'] = $data_cabang->id;
			$where_pengeluaran['pengeluaran.enum'] = 1;
		}		
		$pengeluaran = $this->pengeluaran_model->getAllById($where_pengeluaran);
		// TOTAL PENGELUARAN
		$where_pengeluaran_total['MONTH(pengeluaran_detail.created_at)'] = $bulan;
		$where_pengeluaran_total['YEAR(pengeluaran_detail.created_at)'] = $tahun;
		$where_pengeluaran_total['pengeluaran_detail.cabang_id'] = $cabang_id;
		if (!$this->data['is_superadmin']) {
			$where_pengeluaran_total['pengeluaran_detail.cabang_id'] = $data_cabang->id;
		}		
		$pengeluaran_total = $this->pengeluaran_detail_model->sum($where_pengeluaran_total);
		//kas
		$where_kas['MONTH(tanggal)'] = $bulan;
		$where_kas['YEAR(tanggal)'] = $tahun;
		$where_kas['cabang_id'] = $cabang_id;
		$kas = $this->histori_kas_model->getAllById($where_kas);
		$cek_laporan = true;
		if($pengeluaran || $kas || $cek_laporan){

			$total_sepuhan = 0;
			if (!empty($sepuhan)) {
				foreach ($sepuhan as $key => $value) {
					$sepuhan_detail = $this->transaksi_sepuhan_detail_model->getAllById(['transaksi_sepuhan_detail.transaksi_sepuhan_id' => $value->id]);
					if (!empty($sepuhan_detail)) {
						foreach ($sepuhan_detail as $key_d => $value_d) {
							if ($value_d->transaksi_sepuhan_id == $value->id) {
								$total_sepuhan += $value_d->harga_pemasukan;
							}
						}
					}
				}
			}
			// pengeluaran
			$total_pengeluaran = 0;
			$data_pengeluaran = [];
			$data_pengeluaran_10 = [];
			if (!empty($pengeluaran)) {
				foreach ($pengeluaran as $key => $value) {
					$where_pengeluaran_detail['pengeluaran_detail.pengeluaran_id'] = $value->id;
					$where_pengeluaran_detail['pengeluaran_detail.is_deleted'] = 0;
					$pengeluaran_detail = $this->pengeluaran_detail_model->getAllById($where_pengeluaran_detail);
					if (!empty($pengeluaran_detail)) {
						foreach ($pengeluaran_detail as $key_detail => $value_detail) {
							if ($value_detail->enum_pengeluaran_id != 10) {
								$object_pengeluaran =  new stdClass();
								$object_pengeluaran->enum_pengeluaran_id = $value_detail->enum_pengeluaran_id;
								$object_pengeluaran->nama_pengeluaran = $value_detail->nama_pengeluaran;
								$object_pengeluaran->keterangan = $value_detail->keterangan;
				                $object_pengeluaran->harga = $value_detail->harga;
				                array_push($data_pengeluaran, $object_pengeluaran);
							} elseif($value_detail->enum_pengeluaran_id == 10) {
								$object_pengeluaran_10 =  new stdClass();
								$object_pengeluaran_10->enum_pengeluaran_id = $value_detail->enum_pengeluaran_id;
								$object_pengeluaran_10->nama_pengeluaran = $value_detail->nama_pengeluaran;
								$object_pengeluaran_10->keterangan = $value_detail->keterangan;
				                $object_pengeluaran_10->harga = $value_detail->harga;
				                array_push($data_pengeluaran_10, $object_pengeluaran_10);
							}
							
						}
					}
				}
			}
			$total_pengeluaran_1 = 0;
			$total_pengeluaran_2 = 0;
			$total_pengeluaran_3 = 0;
			$total_pengeluaran_4 = 0;
			$total_pengeluaran_5 = 0;
			$total_pengeluaran_6 = 0;
			$total_pengeluaran_7 = 0;
			$total_pengeluaran_8 = 0;
			$total_pengeluaran_9 = 0;
			$total_pengeluaran_11 = 0;
			$total_pengeluaran_12 = 0;
			if (!empty($data_pengeluaran)) {
				foreach ($data_pengeluaran as $key => $value) {
					$total_pengeluaran += $value->harga;
					if ($value->enum_pengeluaran_id == 1) {
						$total_pengeluaran_1 += $value->harga;
					}elseif ($value->enum_pengeluaran_id == 2) {
						$total_pengeluaran_2 += $value->harga;
					}elseif ($value->enum_pengeluaran_id == 3) {
						$total_pengeluaran_3 += $value->harga;
					}elseif ($value->enum_pengeluaran_id == 4) {
						$total_pengeluaran_4 += $value->harga;
					}elseif ($value->enum_pengeluaran_id == 5) {
						$total_pengeluaran_5 += $value->harga;
					}elseif ($value->enum_pengeluaran_id == 6) {
						$total_pengeluaran_6 += $value->harga;
					}elseif ($value->enum_pengeluaran_id == 7) {
						$total_pengeluaran_7 += $value->harga;
					}elseif ($value->enum_pengeluaran_id == 8) {
						$total_pengeluaran_8 += $value->harga;
					}elseif ($value->enum_pengeluaran_id == 9) {
						$total_pengeluaran_9 += $value->harga;
					}elseif ($value->enum_pengeluaran_id == 11) {
						$total_pengeluaran_11 += $value->harga;
					}elseif ($value->enum_pengeluaran_id == 12) {
						$total_pengeluaran_12 += $value->harga;
					}
				}
			}			
			//kas
			$total_kas = 0;
			if (!empty($kas)) {
				foreach ($kas as $key => $value) {
					$total_kas += $value->kas_masuk;
				}
			}
			
			$data['status'] = true;
			$data['cabang'] = $data_cabang->kode_cabang.' - '.$data_cabang->nama_cabang;
			$data['bulan'] = $nama_bulan;
			$potong_penjualan = 0;
			//penjualan
			$data['berat_penjualan_25'] = $penjualan_25->berat == 0 ? '' : $penjualan_25->berat;
			$data['harga_penjualan_25'] = $penjualan_25->harga == 0 ? '' : number_format($penjualan_25->harga);
			$data['berat_penjualan_30'] = $penjualan_30->berat == 0 ? '' : $penjualan_30->berat;
			$data['harga_penjualan_30'] = $penjualan_30->harga == 0 ? '' : number_format($penjualan_30->harga);
			$data['berat_penjualan_35'] = $penjualan_35->berat == 0 ? '' : $penjualan_35->berat;
			$data['harga_penjualan_35'] = $penjualan_35->harga == 0 ? '' : number_format($penjualan_35->harga);
			$data['potong_penjualan'] = $potong_penjualan == 0 ? '' : $potong_penjualan;
			// tukar barang
			$data['berat_tukar_25'] = $tukar_25->berat == 0 ? '' : $tukar_25->berat;
			$data['harga_tukar_25'] = $tukar_25->harga == 0 ? '' : number_format($tukar_25->harga);
			$data['berat_tukar_30'] = $tukar_30->berat == 0 ? '' : $tukar_30->berat;
			$data['harga_tukar_30'] = $tukar_30->harga == 0 ? '' : number_format($tukar_30->harga);
			$data['berat_tukar_35'] = $tukar_35->berat == 0 ? '' : $tukar_35->berat;
			$data['harga_tukar_35'] = $tukar_35->harga == 0 ? '' : number_format($tukar_35->harga);
			// tukar barang
			$data['total_berat_penjualan'] = $total_berat_penjualan;
			$data['total_harga_penjualan'] = number_format($total_harga_penjualan);

			// BARANG RUSAK
			$data['total_berat_rusak'] = $barang_rusak->berat;
			$data['total_harga_rusak'] = number_format($barang_rusak->harga);
			// BK
			// 17
			$data['berat_bk_17'] = $bk_17->berat == 0 ? '' : $bk_17->berat;
			$data['harga_bk_17'] = $bk_17->harga == 0 ? '' : number_format($bk_17->harga);
			// 18
			$data['berat_bk_18'] = $bk_18->berat == 0 ? '' : $bk_18->berat;
			$data['harga_bk_18'] = $bk_18->harga == 0 ? '' : number_format($bk_18->harga);
			// 19
			$data['berat_bk_19'] = $bk_19->berat == 0 ? '' : $bk_19->berat;
			$data['harga_bk_19'] = $bk_19->harga == 0 ? '' : number_format($bk_19->harga);
			// 20
			$data['berat_bk_20'] = $bk_20->berat == 0 ? '' : $bk_20->berat;
			$data['harga_bk_20'] = $bk_20->harga == 0 ? '' : number_format($bk_20->harga);
			// 22
			$data['berat_bk_22'] = $bk_22->berat == 0 ? '' : $bk_22->berat;
			$data['harga_bk_22'] = $bk_22->harga == 0 ? '' : number_format($bk_22->harga);
			// 23
			$data['berat_bk_23'] = $bk_23->berat == 0 ? '' : $bk_23->berat;
			$data['harga_bk_23'] = $bk_23->harga == 0 ? '' : number_format($bk_23->harga);
			// 24
			$data['berat_bk_24'] = $bk_24->berat == 0 ? '' : $bk_24->berat;
			$data['harga_bk_24'] = $bk_24->harga == 0 ? '' : number_format($bk_24->harga);
			// 25
			$data['berat_bk_25'] = $bk_25->berat == 0 ? '' : $bk_25->berat;
			$data['harga_bk_25'] = $bk_25->harga == 0 ? '' : number_format($bk_25->harga);
			// 27
			$data['berat_bk_27'] = $bk_27->berat == 0 ? '' : $bk_27->berat;
			$data['harga_bk_27'] = $bk_27->harga == 0 ? '' : number_format($bk_27->harga);
			// 28
			$data['berat_bk_28'] = $bk_28->berat == 0 ? '' : $bk_28->berat;
			$data['harga_bk_28'] = $bk_28->harga == 0 ? '' : number_format($bk_28->harga);
			// 29
			$data['berat_bk_29'] = $bk_29->berat == 0 ? '' : $bk_29->berat;
			$data['harga_bk_29'] = $bk_29->harga == 0 ? '' : number_format($bk_29->harga);
			// 30
			$data['berat_bk_30'] = $bk_30->berat == 0 ? '' : $bk_30->berat;
			$data['harga_bk_30'] = $bk_30->harga == 0 ? '' : number_format($bk_30->harga);

			$data['total_berat_bk'] = $bk->berat;
			$data['total_harga_bk'] = number_format($bk->harga);
			$data['potong_bk'] = $potong->potong;
			$data['total_potong_penjualan'] = $penjualan_potong->potong + $tukar_potong->potong;

			// SEPUHAN
			$data['total_sepuhan'] = number_format($total_sepuhan);

			$data['jumlah_pengeluaran'] = NULL;
			$data['pengeluaran'] = NULL;
			//pengeluaran
			$data['total_pengeluaran_1'] = $total_pengeluaran_1 == 0 ? '' : number_format($total_pengeluaran_1);
			$data['total_pengeluaran_2'] = $total_pengeluaran_2 == 0 ? '' : number_format($total_pengeluaran_2);
			$data['total_pengeluaran_3'] = $total_pengeluaran_3 == 0 ? '' : number_format($total_pengeluaran_3);
			$data['total_pengeluaran_4'] = $total_pengeluaran_4 == 0 ? '' : number_format($total_pengeluaran_4);
			$data['total_pengeluaran_5'] = $total_pengeluaran_5 == 0 ? '' : number_format($total_pengeluaran_5);
			$data['total_pengeluaran_6'] = $total_pengeluaran_6 == 0 ? '' : number_format($total_pengeluaran_6);
			$data['total_pengeluaran_7'] = $total_pengeluaran_7 == 0 ? '' : number_format($total_pengeluaran_7);
			$data['total_pengeluaran_8'] = $total_pengeluaran_8 == 0 ? '' : number_format($total_pengeluaran_8);
			$data['total_pengeluaran_9'] = $total_pengeluaran_9 == 0 ? '' : number_format($total_pengeluaran_9);
			$data['total_pengeluaran_11'] = $total_pengeluaran_11 == 0 ? '' : number_format($total_pengeluaran_11);
			$data['total_pengeluaran_12'] = $total_pengeluaran_12 == 0 ? '' : number_format($total_pengeluaran_12);
			if (!empty($data_pengeluaran_10)) {
				$data['pengeluaran'] = $data_pengeluaran_10;
				$jumlah_pengeluaran = count($data_pengeluaran_10);
				$jumlah_pengeluaran = $jumlah_pengeluaran + 12;
				$data['jumlah_pengeluaran'] = $jumlah_pengeluaran;
			}
			$data['total_pengeluaran'] = $pengeluaran_total->total_harga == 0 ? '' : number_format($pengeluaran_total->total_harga);
			//kas
			$data['total_kas'] = $total_kas == 0 ? '' : number_format($total_kas);
			
		}else{
			$data['status'] = false;
		}
		echo json_encode($data);
	}

	
}
