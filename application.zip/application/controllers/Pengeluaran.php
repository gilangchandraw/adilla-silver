<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Pengeluaran extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('pengeluaran_model');
		$this->load->model('pengeluaran_detail_model');
		$this->load->model('cabang_model');
		$this->load->model('enum_pengeluaran_model');
		$this->load->model('histori_kas_model');
	}
	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$cek_insert = true;
			$this->data['data_cabang'] = $this->cabang_model->getAllById();
			if ($this->data['users_groups']->id == 4) {
				$where['cabang.users_id'] = $this->data['users']->id;
				$this->data['cabang'] = $this->cabang_model->getOneBy($where);
				$where_cek['pengeluaran.tanggal'] = date('Y-m-d');
				$where_cek['pengeluaran.enum'] = 1;
				$where_cek['pengeluaran.cabang_id'] = $this->data['cabang']->id;
				$cek_insert = $this->pengeluaran_model->getOneBy($where_cek);
			}
			$this->data['cek_insert'] = $cek_insert ? 1 : 0;

			$this->data['content'] = 'admin/pengeluaran/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function create()
	{
		$this->form_validation->set_rules('tanggal', "tanggal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$tanggal = $this->input->post('tanggal');
			$harga = $this->input->post('harga');
			$enum_pengeluaran_id = $this->input->post('enum_pengeluaran_id');
			if ($this->data['is_superadmin']) {
				$cabang_id = $this->input->post('cabang_id');
			} else {
				$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
				$cabang_id = $cabang->id;
			}

			// HANDLE DOUBLE KLIK
			$where_cek['pengeluaran.cabang_id'] = $cabang_id;
			$where_cek['pengeluaran.enum'] = 1;
			$where_cek['pengeluaran.tanggal'] = $tanggal;
			$cek_double = $this->pengeluaran_model->getOneBy($where_cek);
			if ($cek_double) {
				$this->session->set_flashdata('message_error',"Anda Klik simpan 2x Silahkan cek kembali pengeluaran ".$tanggal);
				redirect("pengeluaran");
			}
			
			$data_pengeluaran = array(
				'users_id' => $this->data['users']->id,
				'tanggal' => $tanggal,
				'enum' => 1,
				'cabang_id' => $cabang_id,
				'total_harga_keseluruhan' => $harga,
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			$insert_pengeluaran = $this->pengeluaran_model->insert($data_pengeluaran);
			if ($enum_pengeluaran_id == 10) {
				$data_pengeluaran_detail = array(
					'pengeluaran_id' => $insert_pengeluaran,
					'cabang_id' => $cabang_id,
					'enum_pengeluaran_id' => $enum_pengeluaran_id,
					'harga' => $harga,
					'keterangan' => $this->input->post('keterangan'),
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
			} else {
				$data_pengeluaran_detail = array(
					'pengeluaran_id' => $insert_pengeluaran,
					'cabang_id' => $cabang_id,
					'enum_pengeluaran_id' => $this->input->post('enum_pengeluaran_id'),
					'harga' => $harga,
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
			}

			$insert_pengeluaran_detail = $this->pengeluaran_detail_model->insert($data_pengeluaran_detail);

			if ($insert_pengeluaran_detail) {
				$this->session->set_flashdata('message', "Data pengeluaran Baru Berhasil Disimpan");
				redirect("pengeluaran/create_more/" . $insert_pengeluaran);
			} else {
				$this->session->set_flashdata('message_error', "Data pengeluaran Baru Gagal Disimpan");
				redirect("pengeluaran");
			}
		} else {
			if ($this->data['is_can_create']) {
				$this->data['data_cabang'] = $this->cabang_model->getAllById();
				$this->data['enum_pengeluaran'] = $this->enum_pengeluaran_model->getAllById();
				$this->data['content'] = 'admin/pengeluaran/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function create_more($id)
	{
		$this->form_validation->set_rules('pengeluaran_id', "pengeluaran_id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {

			$pengeluaran_id = $this->input->post('pengeluaran_id');
			$harga = $this->input->post('harga');
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);

			$enum_pengeluaran_id = $this->input->post('enum_pengeluaran_id');

			if ($enum_pengeluaran_id == 10) {
				$pengeluaran_detail = array(
					'pengeluaran_id' => $pengeluaran_id,
					'enum_pengeluaran_id' => $enum_pengeluaran_id,
					'cabang_id' => $cabang->id,
					'keterangan' => $this->input->post('keterangan'),
					'harga' => $harga,
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
			} else {
				$pengeluaran_detail = array(
					'pengeluaran_id' => $pengeluaran_id,
					'enum_pengeluaran_id' => $enum_pengeluaran_id,
					'cabang_id' => $cabang->id,
					'harga' => $harga,
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
			}
			$insert_pengeluaran_detail = $this->pengeluaran_detail_model->insert($pengeluaran_detail);
			// ubah master pengeluaran
			$data_pengeluaran = $this->pengeluaran_model->getOneBy(['pengeluaran.id' => $pengeluaran_id]);
			//update harga
			$update_harga = $data_pengeluaran->total_harga_keseluruhan + $harga;
			// update jumlah_transaksi
			$data_update_pengeluaran = array(
				'total_harga_keseluruhan'			=> $update_harga,
				'updated_by' => $this->data['users']->id

			);
			$update_master_pengeluaran = $this->pengeluaran_model->update($data_update_pengeluaran, array("pengeluaran.id" => $pengeluaran_id));

			if ($update_master_pengeluaran) {
				$this->session->set_flashdata('message', "Data pengeluaran baru Berhasil Disimpan");
				redirect("pengeluaran/create_more/" . $pengeluaran_id);
			} else {
				$this->session->set_flashdata('message_error', "Data pengeluaran baru Gagal Disimpan");
				redirect("pengeluaran");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("pengeluaran/edit/" . $id);
			} else {
				$this->data['id'] = $id;
				$this->data['pengeluaran'] = $this->pengeluaran_model->getOneBy(array("pengeluaran.id" => $this->data['id']));
				$this->data['data_pengeluaran_detail'] = $this->pengeluaran_detail_model->getAllById(['pengeluaran_id' => $id]);
				$this->data['enum_pengeluaran'] = $this->enum_pengeluaran_model->getAllById();
				$this->data['content'] = 'admin/pengeluaran/create_more_v';
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function detail()
	{
		$this->data['id'] = $this->uri->segment(3);
		$this->data['pengeluaran'] = $this->pengeluaran_model->getOneBy(array("pengeluaran.id" => $this->data['id']));
		$this->data['data_pengeluaran_detail'] = $this->pengeluaran_detail_model->getAllById(['pengeluaran_id' => $this->data['id']]);
		$this->data['cek_insert'] = $this->data['pengeluaran']->tanggal == date('Y-m-d') ? 1 : 0;
		$this->data['content'] = 'admin/pengeluaran/detail_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
		);
		if (!$this->data['is_superadmin']) {
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
			$where['pengeluaran.cabang_id'] = $cabang->id;
		}
		$where['pengeluaran.enum'] = 1;
		$where['pengeluaran.is_deleted'] = 0;

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->pengeluaran_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);


		$searchColumn = $this->input->post('columns');
		$isSearchColumn = false;

		if (!empty($searchColumn[0]['search']['value'])) {
			$value = $searchColumn[0]['search']['value'];
			$isSearchColumn = true;
			$where['pengeluaran.tanggal'] = $value;
		}

		if ($isSearchColumn) {
			$totalFiltered = $this->pengeluaran_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
			$totalData = $totalFiltered;
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->pengeluaran_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$detail_url = "";
				$add_url = "";

				$detail_url = "<a href='" . base_url() . "pengeluaran/detail/" . $data->id . "' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";
				if ($data->tanggal == date('Y-m-d')) {
					$add_url = "<a href='" . base_url() . "pengeluaran/create_more/" . $data->id . "' class='btn btn-sm btn-success' data-toggle='tooltip' title='Tambah Data' data-placement='bottom'><i class='fa fa-plus fa-w-20'></i></a>";
				}

				$nestedData['id'] = $start + $key + 1;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['total_harga_keseluruhan'] = number_format($data->total_harga_keseluruhan);
				$nestedData['action'] = $detail_url . ' ' . $add_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function dataListAdmin()
	{
		$columns = array(
			0 => 'id',
		);
		$where['pengeluaran.enum'] = 1;
		$where['pengeluaran.is_deleted'] = 0;

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->pengeluaran_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);


		$searchColumn = $this->input->post('columns');
		$isSearchColumn = false;

		if (!empty($searchColumn[0]['search']['value'])) {
			$value = $searchColumn[0]['search']['value'];
			$isSearchColumn = true;
			$where['pengeluaran.tanggal'] = $value;
		}
		if (!empty($searchColumn[1]['search']['value'])) {
			$value = $searchColumn[1]['search']['value'];
			$isSearchColumn = true;
			$where['pengeluaran.cabang_id'] = $value;
		}
		if(!empty($searchColumn[2]['search']['value'])){
            $value = $searchColumn[2]['search']['value'];
            $isSearchColumn = true;
            if ($value == 2) {
            	$value = 0;
            }
            $where['pengeluaran.status_audit'] = $value;
        }

		if ($isSearchColumn) {
			$totalFiltered = $this->pengeluaran_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
			$totalData = $totalFiltered;
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->pengeluaran_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$detail_url = "";
				$add_url = "";
				$audit_url = "";

				$detail_url = "<a href='" . base_url() . "pengeluaran/detail/" . $data->id . "' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";
				$add_url = "<a href='".base_url()."pengeluaran/create_more/".$data->id."' class='btn btn-sm btn-success' data-toggle='tooltip' title='Tambah Data' data-placement='bottom'><i class='fa fa-plus fa-w-20'></i></a>";
				if ($data->status_audit == 0 && $this->data['users_groups']->id == 3) {
            		$audit_url = "<a href='#' 
	        				url='" . base_url() . "pengeluaran/destroy/" . $data->id . "/" . $data->status_audit . "' class='btn btn-sm btn-danger delete' data-toggle='tooltip' title='Data telah Diaudit' data-placement='bottom'><i class='fa fa-check-circle fa-w-20'></i></a>";
            	}

				$nestedData['id'] = $start + $key + 1;
				$nestedData['cabang'] = $data->nama_cabang;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['total_harga_keseluruhan'] = number_format($data->total_harga_keseluruhan);
				$nestedData['status_audit'] = $data->status_audit == 0 ? '<b style="color:red;">Belum</b>' : '<b style="color:green;">Selesai</b>';
           		$nestedData['action'] = $detail_url.' '.$add_url.' '.$audit_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function destroy()
	{
		$response_data = array();
		$response_data['status'] = false;
		$response_data['msg'] = "";
		$response_data['data'] = array();

		$id = $this->uri->segment(3);
		$status_audit = $this->uri->segment(4);
		if (!empty($id)) {
			$this->load->model("pengeluaran_model");
			$data = array(
				'status_audit' => ($status_audit == 1) ? 0 : 1
			);
			$update = $this->pengeluaran_model->update($data, array("id" => $id));

			$response_data['data'] = $data;
			$response_data['status'] = true;
		} else {
			$response_data['msg'] = "ID Harus Diisi";
		}

		echo json_encode($response_data);
	}

	public function edit()
	{
		$this->form_validation->set_rules('id', "id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$id = $this->input->post('id');
			$cek = $this->pengeluaran_detail_model->getOneBy(['pengeluaran_detail.id' => $id]);
			$enum_pengeluaran_id = $this->input->post('enum_pengeluaran_id');
			$harga = $this->input->post('harga');
			if ($enum_pengeluaran_id == 10) {
				$data = array(
					'enum_pengeluaran_id' => $enum_pengeluaran_id,
					'harga' => $harga,
					'keterangan' => $this->input->post('keterangan'),
					'updated_by' => $this->data['users']->id
				);
			} else {
				$data = array(
					'enum_pengeluaran_id' => $enum_pengeluaran_id,
					'harga' => $harga,
					'updated_by' => $this->data['users']->id
				);
			}
			$update = $this->pengeluaran_detail_model->update($data, array("pengeluaran_detail.id" => $id));

			$cek_detail = $this->pengeluaran_detail_model->getAllById(['pengeluaran_detail.pengeluaran_id' => $cek->pengeluaran_id]);
			if (!empty($cek_detail)) {
				$total_harga_keseluruhan = 0;
				foreach ($cek_detail as $key => $value) {
					$total_harga_keseluruhan += $value->harga;
				}
				$data_update = array(
					'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
					'updated_by' => $this->data['users']->id

				);
				$update = $this->pengeluaran_model->update($data_update, array("pengeluaran.id" => $cek->pengeluaran_id));
			}
			if ($update) {
				$this->session->set_flashdata('message', "Data Pengeluaran Berhasil Diedit");
				redirect("pengeluaran");
			} else {
				$this->session->set_flashdata('message_error', "Data Pengeluaran Gagal Diedit");
				redirect("pengeluaran");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("cabang/edit/" . $id);
			} else {
				if ($this->data['is_can_edit']) {
					$this->data['id'] = $this->uri->segment(3);
					$this->data['data'] = $this->pengeluaran_detail_model->getOneBy(array("pengeluaran_detail.id" => $this->data['id']));
					$this->data['enum_pengeluaran'] = $this->enum_pengeluaran_model->getAllById();
					$this->data['content'] = 'admin/pengeluaran/edit_v';
				} else {
					$this->data['content']  = 'errors/html/restrict';
				}
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}
}
