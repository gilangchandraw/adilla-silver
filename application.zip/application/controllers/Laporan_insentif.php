<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Laporan_insentif extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('cabang_model');
		$this->load->model('data_karyawan_model');
		$this->load->model('insentif_model');
		$this->load->model('insentif_detail_model');
		// $this->load->model('enum_transaksi_barang_model');
		// $this->load->model('barang_kembali_model');
		// $this->load->model('tukar_plus_model');
		// $this->load->model('tukar_plus_detail_model');
		// $this->load->model('barang_kembali_detail_model');
		// $this->load->model('pengeluaran_model');
		// $this->load->model('pengeluaran_detail_model');
		// $this->load->model('enum_pengeluaran_model');
		// $this->load->model('histori_kas_model');
	}


	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			if($this->data['users_groups']->id == 4){
				$where['data_karyawan.is_deleted'] = 0;
				$where['data_karyawan.users_id'] = $this->data['users']->id;
				$this->data['karyawan'] = $this->data_karyawan_model->getAllById($where); 
            }
			$this->data['cabang'] = $this->cabang_model->getAllById();
			$this->data['content'] = 'admin/laporan_insentif/create_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function get_data(){
		// get data cabang untuk kasir
		$cabang_id = $this->input->get('cabang_id');
		$tanggal = $this->input->get('tanggal');
		$karyawan_id = $this->input->get('karyawan_id');
		$karyawan = $this->data_karyawan_model->getOneBy(['data_karyawan.id' => $karyawan_id]);

		$data_cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
		if ($this->data['users_groups']->id == 4) {
			$cabang_id = $data_cabang->id;
		}
		if ($this->data['users_groups']->id != 4) {
			$data_cabang = $this->cabang_model->getOneBy(['cabang.id' => $cabang_id]);
		}
		$tanggal = explode('-', $tanggal);
		$bulan = $tanggal[0];
		$tahun = $tanggal[1];

		$no_bulan = $bulan;
		
		if ($bulan < 10) {
			$no_bulan = explode(0, $bulan);
			$no_bulan = $no_bulan[1];
		}
		// inisialisasi nama bulan
		if ($no_bulan == 1) {
			$nama_no_bulan = 'Januari';
		}elseif ($no_bulan == 2) {
			$nama_bulan = 'Februari';
		}elseif ($no_bulan == 3) {
			$nama_bulan = 'Maret';
		}elseif ($no_bulan == 4) {
			$nama_bulan = 'April';
		}elseif ($no_bulan == 5) {
			$nama_bulan = 'Mei';
		}elseif ($no_bulan == 6) {
			$nama_bulan = 'Juni';
		}elseif ($no_bulan == 7) {
			$nama_bulan = 'Juli';
		}elseif ($no_bulan == 8) {
			$nama_bulan = 'Agustus';
		}elseif ($no_bulan == 9) {
			$nama_bulan = 'September';
		}elseif ($no_bulan == 10) {
			$nama_bulan = 'Oktober';
		}elseif ($no_bulan == 11) {
			$nama_bulan = 'November';
		}elseif ($no_bulan == 12) {
			$nama_bulan = 'Desember';
		}
		
		
		$where_insentif['MONTH(insentif.tanggal)'] = $bulan;
		$where_insentif['YEAR(insentif.tanggal)'] = $tahun;
		$where_insentif['insentif.cabang_id'] = $cabang_id;
		// untuk cabang
		if ($this->data['users_groups']->id == 4) {
			$where_insentif['insentif.cabang_id'] = $cabang_id;
		}
		$where_insentif['insentif.is_deleted'] = 0;
		$insentif = $this->insentif_model->getAllById($where_insentif);
		
		if(!empty($insentif)){

			$data_insentif_detail = [];
			if (!empty($insentif)) {
				$total_berat = 0;
				$total_harga = 0;
				foreach ($insentif as $key => $value) {
					$where_pk['insentif_detail.insentif_id'] = $value->id;
					$where_pk['insentif_detail.is_deleted'] = 0;
					$where_pk['insentif_detail.karyawan_id'] = $karyawan_id;
					$insentif_detail = $this->insentif_detail_model->getAllById($where_pk);
					if (!empty($insentif_detail)) {
						foreach ($insentif_detail as $key_detail => $value_detail) {
							$total_berat += $value_detail->berat;
							$total_harga += $value_detail->harga;
							$object_detail =  new stdClass();
			                $object_detail->tanggal = $value_detail->tanggal;
			                $object_detail->no_nota_masing2 = $value_detail->no_nota_awal;
			                $object_detail->no_nota_cadangan = $value_detail->no_nota_akhir;
			                $object_detail->jumlah_nota = $value_detail->jumlah_nota;
			                $object_detail->no_nota_batal = $value_detail->no_nota_batal;
			                $object_detail->jumlah_nota_batal = $value_detail->jumlah_nota_batal;
			                $object_detail->berat = $value_detail->berat;
			                $object_detail->huruf_nota = $value_detail->huruf_nota;
			                // $object_detail->total_berat = $value_detail->total_berat;
			                $object_detail->harga = number_format($value_detail->harga);
			                // $object_detail->total_harga = number_format($value_detail->total_harga);
			                array_push($data_insentif_detail, $object_detail);
						}
					}
				}
			}
			
			$days_in_month = cal_days_in_month(CAL_GREGORIAN,$no_bulan,$tahun);
			$result = [];
			$huruf_nota = '';
			for ($i=1; $i <= $days_in_month; $i++) {
				if ($i <10) {
	                $i = '0'.$i;
	            }
	            $date = $tahun.'-'.$bulan.'-'.$i;
	            $object_data =  new stdClass();
                $object_data->tanggal = $date;
                $object_data->no_nota_masing2 = '';
                $object_data->no_nota_cadangan = '';
                $object_data->jumlah_nota = '';
                $object_data->no_nota_batal = '';
                $object_data->jumlah_nota_batal = '';
                $object_data->berat = '';
                $object_data->total_berat = '';
                $object_data->harga = '';
                $object_data->total_harga = '';
                
                if (!empty($data_insentif_detail)) {
	            	foreach ($data_insentif_detail as $key => $value) {
	            		if ($value->tanggal == $date) {
	            			$object_data->no_nota_masing2 = $value_detail->no_nota_awal;
			                $object_data->no_nota_cadangan = $value_detail->no_nota_akhir;
	            			$object_data->jumlah_nota = $value->jumlah_nota;
	            			$object_data->no_nota_batal = $value->no_nota_batal;
	            			$object_data->jumlah_nota_batal = $value->jumlah_nota_batal;
	            			$object_data->berat = $value->berat;
	            			// $object_data->total_berat = $value->total_berat;
	            			$object_data->harga = $value->harga;
	            			// $object_data->total_harga = $value->total_harga;
	            		}
	            		$huruf_nota = $value->huruf_nota;
	            	}
                		array_push($result, $object_data);
	            }
			}
			
			
			
			$data['status'] = true;
			$data['cabang'] = $data_cabang->nama_cabang;
			$data['bulan'] = $nama_bulan;
			$data['karyawan'] = $karyawan->nama_karyawan;
			$data['huruf_nota'] = $huruf_nota;
			//insentif
			$data['insentif'] = $result;
			$data['total_berat'] = $total_berat;
			$data['total_harga_sebelum'] = number_format($total_harga);
			$total_harga = $total_harga * 0.004;
			$data['total_harga'] = number_format($total_harga);
			
			
		}else{
			$data['status'] = false;
		}
		echo json_encode($data);
	}

	public function print_pdf()
	{
		$cabang_id = $this->input->get('cabang_id');
		$tanggal = $this->input->get('tanggal');
		$karyawan_id = $this->input->get('karyawan_id');
		$karyawan = $this->data_karyawan_model->getOneBy(['data_karyawan.id' => $karyawan_id]);

		$data_cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
		if ($this->data['users_groups']->id == 4) {
			$cabang_id = $data_cabang->id;
		}
		if ($this->data['users_groups']->id != 4) {
			$data_cabang = $this->cabang_model->getOneBy(['cabang.id' => $cabang_id]);
		}
		$tanggal = explode('-', $tanggal);
		$bulan = $tanggal[0];
		$tahun = $tanggal[1];

		if ($bulan < 10) {
			$no_bulan = explode(0, $bulan);
			$no_bulan = $no_bulan[1];
		}
		// inisialisasi nama bulan
		if ($no_bulan == 1) {
			$nama_no_bulan = 'Januari';
		}elseif ($no_bulan == 2) {
			$nama_bulan = 'Februari';
		}elseif ($no_bulan == 3) {
			$nama_bulan = 'Maret';
		}elseif ($no_bulan == 4) {
			$nama_bulan = 'April';
		}elseif ($no_bulan == 5) {
			$nama_bulan = 'Mei';
		}elseif ($no_bulan == 6) {
			$nama_bulan = 'Juni';
		}elseif ($no_bulan == 7) {
			$nama_bulan = 'Juli';
		}elseif ($no_bulan == 8) {
			$nama_bulan = 'Agustus';
		}elseif ($no_bulan == 9) {
			$nama_bulan = 'September';
		}elseif ($no_bulan == 10) {
			$nama_bulan = 'Oktober';
		}elseif ($no_bulan == 11) {
			$nama_bulan = 'November';
		}elseif ($no_bulan == 12) {
			$nama_bulan = 'Desember';
		}
		
		
		$where_insentif['MONTH(insentif.tanggal)'] = $bulan;
		$where_insentif['YEAR(insentif.tanggal)'] = $tahun;
		$where_insentif['insentif.cabang_id'] = $cabang_id;
		// untuk cabang
		if ($this->data['users_groups']->id == 4) {
			$where_insentif['insentif.cabang_id'] = $cabang_id;
		}
		$where_insentif['insentif.is_deleted'] = 0;
		$insentif = $this->insentif_model->getAllById($where_insentif);
		// print_r($insentif);
		// die();
		if(!empty($insentif)){

			$data_insentif_detail = [];
			if (!empty($insentif)) {
				foreach ($insentif as $key => $value) {
					$where_pk['insentif_detail.insentif_id'] = $value->id;
					$where_pk['insentif_detail.is_deleted'] = 0;
					$where_pk['insentif_detail.karyawan_id'] = $karyawan_id;
					$insentif_detail = $this->insentif_detail_model->getAllById($where_pk);
					if (!empty($insentif_detail)) {
						foreach ($insentif_detail as $key_detail => $value_detail) {
							$object_detail =  new stdClass();
			                $object_detail->tanggal = $value_detail->tanggal;
			                $object_detail->no_nota = $value_detail->no_nota_awal.'-'.$value_detail->no_nota_akhir;
			                $object_detail->jumlah_nota = $value_detail->jumlah_nota;
			                $object_detail->no_nota_batal = $value_detail->no_nota_batal;
			                $object_detail->jumlah_nota_batal = $value_detail->jumlah_nota_batal;
			                $object_detail->berat = $value_detail->berat;
			                $object_detail->huruf_nota = $value_detail->huruf_nota;
			                $object_detail->total_berat = $value_detail->total_berat;
			                $object_detail->harga = number_format($value_detail->harga);
			                $object_detail->total_harga = number_format($value_detail->total_harga);
			                array_push($data_insentif_detail, $object_detail);
						}
					}
				}
			}
			$days_in_month = cal_days_in_month(CAL_GREGORIAN,$no_bulan,$tahun);
			$result = [];
			$huruf_nota = '';
			for ($i=1; $i <= $days_in_month; $i++) {
				if ($i <10) {
	                $i = '0'.$i;
	            }
	            $date = $tahun.'-'.$bulan.'-'.$i;
	            $object_data =  new stdClass();
                $object_data->tanggal = $date;
                $object_data->no_nota = '';
                $object_data->jumlah_nota = '';
                $object_data->no_nota_batal = '';
                $object_data->jumlah_nota_batal = '';
                $object_data->berat = '';
                $object_data->total_berat = '';
                $object_data->harga = '';
                $object_data->total_harga = '';
                
                if (!empty($data_insentif_detail)) {
	            	foreach ($data_insentif_detail as $key => $value) {
	            		if ($value->tanggal == $date) {
	            			$object_data->no_nota = $value->no_nota;
	            			$object_data->jumlah_nota = $value->jumlah_nota;
	            			$object_data->no_nota_batal = $value->no_nota_batal;
	            			$object_data->jumlah_nota_batal = $value->jumlah_nota_batal;
	            			$object_data->berat = $value->berat;
	            			$object_data->total_berat = $value->total_berat;
	            			$object_data->harga = $value->harga;
	            			$object_data->total_harga = $value->total_harga;
	            		}
	            		$huruf_nota = $value->huruf_nota;
	            	}
                		array_push($result, $object_data);
	            }
			}
			
			
			
			$data['status'] = true;
			$data['cabang'] = $data_cabang->nama_cabang;
			$data['bulan'] = $nama_bulan;
			$data['karyawan'] = $karyawan->nama_karyawan;
			$data['huruf_nota'] = $huruf_nota;
			//insentif
			$data['insentif'] = $result;

			require_once BASEPATH. 'vendor/autoload.php';
	        // $mpdf = new \Mpdf\Mpdf(['mode' => 'utf-8', 'format' => [216, 350]]);
	        // $mpdf = new \Mpdf\Mpdf(['mode' => 'utf-8', 'format' => [190, 236]]);
	        $mpdf = new \Mpdf\Mpdf(['orientation' => 'L']);
	        $html = $this->load->view('admin/laporan_insentif/print_v',$data,TRUE);
	        // print_r($html);
	        // die();
	        $mpdf->WriteHTML($html);
	        $mpdf->Output("laporan-insetif~".$nama_bulan.'-'.time().".pdf","I");
		}else{
			$data['status'] = false;
		}

	}

	
}
