<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Tarik_uang_nota extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('penarikan_uang_nota_model');
		$this->load->model('uang_nota_model');
		$this->load->model('cabang_model');
		$this->load->model('kas_kantor_model');
	}

	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$this->data['content'] = 'admin/tarik_uang_nota/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function create()
	{
		$this->form_validation->set_rules('tanggal', "tanggal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {

			$tanggal = $this->input->post('tanggal');
			$cabang_id = $this->input->post('cabang_id');
			$jumlah_penarikan = $this->input->post('jumlah_penarikan');
			
			$data = array(
				'cabang_id' => $cabang_id,
				'tanggal' => $tanggal,
				'jumlah_penarikan' => $jumlah_penarikan,
				'created_by' => $this->data['users']->id,
			);
			$insert = $this->penarikan_uang_nota_model->insert($data);

			$kantor = $this->kas_kantor_model->getOneBy();
			$update_nota = array('kas_nota' => $kantor->kas_nota + $jumlah_penarikan);
			$this->kas_kantor_model->update($update_nota, array("id" => 1));
			
			// update di tabel uang nota
			$data_master = $this->uang_nota_model->getOneBy(['cabang_id' => $cabang_id]);
			$update_total = $data_master->total - $jumlah_penarikan;

			$data_update = array(
				'total' => $update_total,
			);
			$update = $this->uang_nota_model->update($data_update, array("cabang_id" => $cabang_id));

			if ($insert && $update) {
				$this->session->set_flashdata('message', "Data Penarikan Uang Nota Berhasil Disimpan");
				redirect("tarik_uang_nota");
			} else {
				$this->session->set_flashdata('message_error', "Data Penarikan Uang Nota Gagal Disimpan");
				redirect("tarik_uang_nota");
			}
		} else {
			if ($this->data['is_can_create']) {
				$this->data['cabang'] = $this->cabang_model->getAllById(['cabang.is_deleted' => 0]);
				$this->data['content'] = 'admin/tarik_uang_nota/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function edit()
	{
		$this->form_validation->set_rules('tanggal', "tanggal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$id = $this->input->post('id');
			$jumlah_penarikan = $this->input->post('jumlah_penarikan');
			$data = array(
				'tanggal' => $this->input->post('tanggal'),
				'jumlah_penarikan' => $jumlah_penarikan,
				'created_by' => $this->data['users']->id,
			);
			$update = $this->penarikan_uang_nota_model->update($data, array("id" => $id));

			$jumlah_penarikan_lama = $this->input->post('jumlah_penarikan_lama');
			$cabang_id = $this->input->post('cabang_id');

			// update di tabel uang nota
			$data_master = $this->uang_nota_model->getOneBy(['cabang_id' => $cabang_id]);
			$update_total = $data_master->total + $jumlah_penarikan_lama - $jumlah_penarikan;

			$data_update = array(
				'total' => $update_total,
			);
			$update_master = $this->uang_nota_model->update($data_update, array("cabang_id" => $cabang_id));

			$kantor = $this->kas_kantor_model->getOneBy();
			$update_nota = array('kas_nota' => $kantor->kas_nota - $jumlah_penarikan_lama + $jumlah_penarikan);
			$this->kas_kantor_model->update($update_nota, array("id" => 1));

			if ($update && $update_master) {
				$this->session->set_flashdata('message', "Data Penarikan Uang Nota Berhasil Diedit");
				redirect("tarik_uang_nota");
			} else {
				$this->session->set_flashdata('message_error', "Data Penarikan Uang Nota Gagal Diedit");
				redirect("tarik_uang_nota");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("tarik_uang_nota/edit/" . $id);
			} else {
				if ($this->data['is_can_edit']) {
					$this->data['id'] = $this->uri->segment(3);
					$this->data['cabang'] = $this->cabang_model->getAllById(['cabang.is_deleted' => 0]);
					$this->data['penarikan'] = $this->penarikan_uang_nota_model->getOneBy(array("penarikan_uang_nota.id" => $this->data['id']));
					$this->data['sisa'] = $this->uang_nota_model->getOneBy(array("uang_nota.cabang_id" => $this->data['penarikan']->cabang_id));

					$this->data['content'] = 'admin/tarik_uang_nota/edit_v';
				} else {
					$this->data['content']  = 'errors/html/restrict';
				}
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
			1 => 'tarik_uang_nota.kode_tarik_uang_nota',
			2 => 'tarik_uang_nota.nama_tarik_uang_nota',
			3 => 'tarik_uang_nota.alamat',
			4 => 'action'
		);

		$where = [];

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->penarikan_uang_nota_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		if (!empty($this->input->post('search')['value'])) {
			$search_value = $this->input->post('search')['value'];
			$search = array(
				"tarik_uang_nota.kode_tarik_uang_nota" => $search_value,
				"tarik_uang_nota.nama_tarik_uang_nota" => $search_value,
				"tarik_uang_nota.alamat" => $search_value,
			);
			$totalFiltered = $this->penarikan_uang_nota_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->penarikan_uang_nota_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$delete_url = "<a href='#' 
    				id='" . $data->id. "' class='btn btn-sm btn-danger delete' data-toggle='tooltip' title='Non Aktifkan Data' data-placement='bottom'><i class='fa fa-times fa-w-20'></i></a>";
    			$edit_url = "<a href='" . base_url() . "tarik_uang_nota/edit/" . $data->id . "' class='btn btn-sm btn-warning' data-toggle='tooltip' title='Edit Data' data-placement='bottom'><i class='fa fa-edit fa-w-20'></i></a>";
				
				$nestedData['id'] = $start + $key + 1;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['nama_cabang'] = $data->nama_cabang;
				$nestedData['jumlah_penarikan'] = number_format($data->jumlah_penarikan);
				$nestedData['action'] = $edit_url.' '.$delete_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function delete()
	{
		$id = $this->uri->segment(3);

		$penarikan = $this->penarikan_uang_nota_model->getOneBy(array("penarikan_uang_nota.id" => $id));

		// update di tabel uang nota
		$data_master = $this->uang_nota_model->getOneBy(['cabang_id' => $penarikan->cabang_id]);
		$update_total = $data_master->total + $penarikan->jumlah_penarikan;

		$data_update = array(
			'total' => $update_total,
		);
		$update_master = $this->uang_nota_model->update($data_update, array("cabang_id" => $penarikan->cabang_id));

		$kantor = $this->kas_kantor_model->getOneBy();
		$update_nota = array('kas_nota' => $kantor->kas_nota - $penarikan->jumlah_penarikan);
		$this->kas_kantor_model->update($update_nota, array("id" => 1));

		$delete = $this->penarikan_uang_nota_model->delete(['id' => $id]);
		
		if ($delete && $update_master) {
			$this->session->set_flashdata('message', "Data Penarikan Uang Nota Berhasil Dihapus");
			redirect("tarik_uang_nota");
		} else {
			$this->session->set_flashdata('message_error', "Data Penarikan Uang Nota Gagal Dihapus");
			redirect("tarik_uang_nota");
		}
	}
}
