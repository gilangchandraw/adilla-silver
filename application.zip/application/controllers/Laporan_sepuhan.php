<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Laporan_sepuhan extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('cabang_model');
		$this->load->model('transaksi_sepuhan_model');
		$this->load->model('transaksi_sepuhan_detail_model');
		
	}


	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$this->data['cabang'] = $this->cabang_model->getAllById();
			$this->data['content'] = 'admin/laporan_sepuhan/create_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function get_data(){
		// / get data cabang untuk kasir
		$cabang_id = $this->input->get('cabang_id');
		$tanggal = $this->input->get('tanggal');
		
		$data_cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
		if ($this->data['users_groups']->id == 4) {
			$cabang_id = $data_cabang->id;
		}
		if ($this->data['users_groups']->id != 4) {
			$data_cabang = $this->cabang_model->getOneBy(['cabang.id' => $cabang_id]);
		}
		$tanggal = explode('-', $tanggal);
		$bulan = $tanggal[0];
		$tahun = $tanggal[1];

		$no_bulan = $bulan;
		if ($bulan < 10) {
			$no_bulan = explode(0, $bulan);
			$no_bulan = $no_bulan[1];
		}
		// inisialisasi nama bulan
		if ($no_bulan == 1) {
			$nama_no_bulan = 'Januari';
		}elseif ($no_bulan == 2) {
			$nama_bulan = 'Februari';
		}elseif ($no_bulan == 3) {
			$nama_bulan = 'Maret';
		}elseif ($no_bulan == 4) {
			$nama_bulan = 'April';
		}elseif ($no_bulan == 5) {
			$nama_bulan = 'Mei';
		}elseif ($no_bulan == 6) {
			$nama_bulan = 'Juni';
		}elseif ($no_bulan == 7) {
			$nama_bulan = 'Juli';
		}elseif ($no_bulan == 8) {
			$nama_bulan = 'Agustus';
		}elseif ($no_bulan == 9) {
			$nama_bulan = 'September';
		}elseif ($no_bulan == 10) {
			$nama_bulan = 'Oktober';
		}elseif ($no_bulan == 11) {
			$nama_bulan = 'November';
		}elseif ($no_bulan == 12) {
			$nama_bulan = 'Desember';
		}

		$where['MONTH(transaksi_sepuhan.tanggal)'] = $bulan;
		$where['YEAR(transaksi_sepuhan.tanggal)'] = $tahun;
		$where['transaksi_sepuhan.cabang_id'] = $cabang_id;
		// untuk cabang
		if ($this->data['users_groups']->id == 4) {
			$where['transaksi_sepuhan.cabang_id'] = $cabang_id;
		}
		$where['transaksi_sepuhan.is_deleted'] = 0;
		$transaksi_sepuhan = $this->transaksi_sepuhan_model->getAllById($where);

		if($transaksi_sepuhan){

			$data_sepuhan_detail = [];
			if (!empty($transaksi_sepuhan)) {
				foreach ($transaksi_sepuhan as $key => $value) {
					$where_detail['transaksi_sepuhan_detail.transaksi_sepuhan_id'] = $value->id;
					$transaksi_sepuhan_detail = $this->transaksi_sepuhan_detail_model->getAllById($where_detail);
					if (!empty($transaksi_sepuhan_detail)) {
						$nama_pemasukan =[];
						$harga_pemasukan = 0;
						$nama_pengeluaran =[];
						$harga_pengeluaran = 0;
						$kas_sepuhan_akhir = '';
						$data_akhir =  array_key_last($transaksi_sepuhan_detail);
						foreach ($transaksi_sepuhan_detail as $key_detail => $value_detail) {
								$nama_pemasukan[] = $value_detail->nama_pemasukan;
								$harga_pemasukan += $value_detail->harga_pemasukan;
								$nama_pengeluaran[] = $value_detail->nama_pengeluaran;
								$harga_pengeluaran += $value_detail->harga_pengeluaran;
								if ($key_detail == $data_akhir) {
									$kas_sepuhan_akhir = $value_detail->kas_sepuhan_akhir;
								}
								
						}
						$data_nama_pemasukan = implode(',', $nama_pemasukan);
						$data_nama_pengeluaran = implode(',', $nama_pengeluaran);

						$object_detail =  new stdClass();
		                $object_detail->tanggal = $value->tanggal;
		                $object_detail->nama_pemasukan = $data_nama_pemasukan;
		                $object_detail->harga_pemasukan = $harga_pemasukan;
		                $object_detail->nama_pengeluaran = $data_nama_pengeluaran;
		                $object_detail->harga_pengeluaran = $harga_pengeluaran;
		                $object_detail->kas_sepuhan_akhir = $kas_sepuhan_akhir;
		                array_push($data_sepuhan_detail, $object_detail);
					}
				}
			}
			
			$days_in_month = cal_days_in_month(CAL_GREGORIAN,$no_bulan,$tahun);
			$result = [];
			
			for ($i=1; $i <= $days_in_month; $i++) {
				if ($i <10) {
	                $i = '0'.$i;
	            }
	            $date = $tahun.'-'.$bulan.'-'.$i;
	            $object_data =  new stdClass();
                $object_data->tanggal = $date;
                $object_data->nama_pemasukan = '';
                $object_data->harga_pemasukan = '';
                $object_data->nama_pengeluaran = '';
                $object_data->harga_pengeluaran = '';
                $object_data->kas_sepuhan_akhir = '';
                
                if (!empty($data_sepuhan_detail)) {
	            	foreach ($data_sepuhan_detail as $key => $value) {
	            		if ($value->tanggal == $date) {
	            			$object_data->nama_pemasukan = $value->nama_pemasukan;
	            			$object_data->harga_pemasukan = $value->harga_pemasukan;
	            			$object_data->nama_pengeluaran = $value->nama_pengeluaran;
	            			$object_data->harga_pengeluaran = $value->harga_pengeluaran;
	            			$object_data->kas_sepuhan_akhir = $value->kas_sepuhan_akhir;
	            		}
	            		
	            	}
                		array_push($result, $object_data);
	            }
			}
			
			$data['status'] = true;
			$data['cabang'] = $data_cabang->nama_cabang;
			$data['bulan'] = $nama_bulan;
			
			//sepuhan
			$data['sepuhan'] = $result;
			
		}else{
			$data['status'] = false;
		}
		

		echo json_encode($data);
	}

	public function print_pdf(){
		// / get data cabang untuk kasir
		$cabang_id = $this->input->get('cabang_id');
		$tanggal = $this->input->get('tanggal');
		
		$data_cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
		if ($this->data['users_groups']->id == 4) {
			$cabang_id = $data_cabang->id;
		}
		if ($this->data['users_groups']->id != 4) {
			$data_cabang = $this->cabang_model->getOneBy(['cabang.id' => $cabang_id]);
		}
		$tanggal = explode('-', $tanggal);
		$bulan = $tanggal[0];
		$tahun = $tanggal[1];
		$no_bulan = $bulan;
		if ($bulan < 10) {
			$no_bulan = explode(0, $bulan);
			$no_bulan = $no_bulan[1];
		}
		// inisialisasi nama bulan
		if ($no_bulan == 1) {
			$nama_no_bulan = 'Januari';
		}elseif ($no_bulan == 2) {
			$nama_bulan = 'Februari';
		}elseif ($no_bulan == 3) {
			$nama_bulan = 'Maret';
		}elseif ($no_bulan == 4) {
			$nama_bulan = 'April';
		}elseif ($no_bulan == 5) {
			$nama_bulan = 'Mei';
		}elseif ($no_bulan == 6) {
			$nama_bulan = 'Juni';
		}elseif ($no_bulan == 7) {
			$nama_bulan = 'Juli';
		}elseif ($no_bulan == 8) {
			$nama_bulan = 'Agustus';
		}elseif ($no_bulan == 9) {
			$nama_bulan = 'September';
		}elseif ($no_bulan == 10) {
			$nama_bulan = 'Oktober';
		}elseif ($no_bulan == 11) {
			$nama_bulan = 'November';
		}elseif ($no_bulan == 12) {
			$nama_bulan = 'Desember';
		}

		$where['MONTH(transaksi_sepuhan.tanggal)'] = $bulan;
		$where['YEAR(transaksi_sepuhan.tanggal)'] = $tahun;
		$where['transaksi_sepuhan.cabang_id'] = $cabang_id;
		// untuk cabang
		if ($this->data['users_groups']->id == 4) {
			$where['transaksi_sepuhan.cabang_id'] = $cabang_id;
		}
		$where['transaksi_sepuhan.is_deleted'] = 0;
		$transaksi_sepuhan = $this->transaksi_sepuhan_model->getAllById($where);

		if($transaksi_sepuhan){

			$data_sepuhan_detail = [];
			if (!empty($transaksi_sepuhan)) {
				foreach ($transaksi_sepuhan as $key => $value) {
					$where_detail['transaksi_sepuhan_detail.transaksi_sepuhan_id'] = $value->id;
					$transaksi_sepuhan_detail = $this->transaksi_sepuhan_detail_model->getAllById($where_detail);
					if (!empty($transaksi_sepuhan_detail)) {
						$nama_pemasukan =[];
						$harga_pemasukan = 0;
						$nama_pengeluaran =[];
						$harga_pengeluaran = 0;
						$kas_sepuhan_akhir = '';
						$data_akhir =  array_key_last($transaksi_sepuhan_detail);
						foreach ($transaksi_sepuhan_detail as $key_detail => $value_detail) {
								$nama_pemasukan[] = $value_detail->nama_pemasukan;
								$harga_pemasukan += $value_detail->harga_pemasukan;
								$nama_pengeluaran[] = $value_detail->nama_pengeluaran;
								$harga_pengeluaran += $value_detail->harga_pengeluaran;
								if ($key_detail == $data_akhir) {
									$kas_sepuhan_akhir = $value_detail->kas_sepuhan_akhir;
								}
								
						}
						$data_nama_pemasukan = implode(',', $nama_pemasukan);
						$data_nama_pengeluaran = implode(',', $nama_pengeluaran);

						$object_detail =  new stdClass();
		                $object_detail->tanggal = $value->tanggal;
		                $object_detail->nama_pemasukan = $data_nama_pemasukan;
		                $object_detail->harga_pemasukan = $harga_pemasukan;
		                $object_detail->nama_pengeluaran = $data_nama_pengeluaran;
		                $object_detail->harga_pengeluaran = $harga_pengeluaran;
		                $object_detail->kas_sepuhan_akhir = $kas_sepuhan_akhir;
		                array_push($data_sepuhan_detail, $object_detail);
					}
				}
			}
			
			$days_in_month = cal_days_in_month(CAL_GREGORIAN,$no_bulan,$tahun);
			$result = [];
			
			for ($i=1; $i <= $days_in_month; $i++) {
				if ($i <10) {
	                $i = '0'.$i;
	            }
	            $date = $tahun.'-'.$bulan.'-'.$i;
	            $object_data =  new stdClass();
                $object_data->tanggal = $date;
                $object_data->nama_pemasukan = '';
                $object_data->harga_pemasukan = '';
                $object_data->nama_pengeluaran = '';
                $object_data->harga_pengeluaran = '';
                $object_data->kas_sepuhan_akhir = '';
                
                if (!empty($data_sepuhan_detail)) {
	            	foreach ($data_sepuhan_detail as $key => $value) {
	            		if ($value->tanggal == $date) {
	            			$object_data->nama_pemasukan = $value->nama_pemasukan;
	            			$object_data->harga_pemasukan = $value->harga_pemasukan;
	            			$object_data->nama_pengeluaran = $value->nama_pengeluaran;
	            			$object_data->harga_pengeluaran = $value->harga_pengeluaran;
	            			$object_data->kas_sepuhan_akhir = $value->kas_sepuhan_akhir;
	            		}
	            		
	            	}
                		array_push($result, $object_data);
	            }
			}
			
			$data['status'] = true;
			$data['cabang'] = $data_cabang->nama_cabang;
			$data['bulan'] = $nama_bulan;
			
			//sepuhan
			$data['sepuhan'] = $result;

			require_once BASEPATH. 'vendor/autoload.php';
	        // $mpdf = new \Mpdf\Mpdf(['mode' => 'utf-8', 'format' => [216, 350]]);
	        $mpdf = new \Mpdf\Mpdf(['orientation' => 'L']);
	        $html = $this->load->view('admin/laporan_sepuhan/print_v',$data,TRUE);
	        // print_r($html);
	        // die();
	        $mpdf->WriteHTML($html);
	        $mpdf->Output("laporan-sepuhan-".$nama_bulan.'-'.time().".pdf","I");
			
		}else{
			$data['status'] = false;
		}
		

		echo json_encode($data);
	}

	
}
