<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Barang_keluar extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('barang_keluar_model');
		$this->load->model('barang_model');
		$this->load->model('barang_sepuhan_model');
		$this->load->model('barang_kotak_cincin_model');
		$this->load->model('cabang_model');
		$this->load->model('stok_sepuhan_cabang_model');
		$this->load->model('stok_kotak_cincin_cabang_model');
	}

	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$this->data['content'] = 'admin/barang_keluar/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function create()
	{
		$this->form_validation->set_rules('tanggal', "tanggal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$status_sk = $this->input->post('status_sk');
			$cabang_id = $this->input->post('nama_cabang');
			$barang_id = $this->input->post('barang_id');
			$barang_sepuhan_id = $this->input->post('barang_sepuhan_id');
			$barang_kotak_cincin_id = $this->input->post('barang_kotak_cincin_id');
			$jumlah_barang = $this->input->post('jumlah_barang');

			if ($status_sk == 1) {
				$data = array(
					'tanggal' => $this->input->post('tanggal'),
					'barang_id' => $barang_id,
					'cabang_id' => $cabang_id,
					'jumlah_barang' => $jumlah_barang,
					'total_harga' => $this->input->post('total_harga'),
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$get_stok_barang = $this->barang_model->getOneBy(['id' => $barang_id]);
				// stok opname kantor
				$stok_kantor = $get_stok_barang->stok - $jumlah_barang;
				$data_stok_kantor = array('stok' => $stok_kantor);
				$update_kantor = $this->barang_model->update($data_stok_kantor, ['barang.id' => $barang_id]);
				// stok opname cabang
				$where_cabang['cabang.id'] = $cabang_id;
				$get_stok_barang_cabang = $this->cabang_model->getOneBy($where_cabang);
				
				$jenis_barang = $this->barang_model->getOneBy(['id' => $barang_id]);
				if ($jenis_barang->jenis == '925') {
					$stok_cabang = $get_stok_barang_cabang->stok_925 + $jumlah_barang;
					$data_stok_cabang = array('stok_925' => $stok_cabang);
				} else {
					$stok_cabang = $get_stok_barang_cabang->stok_sp + $jumlah_barang;
					$data_stok_cabang = array('stok_sp' => $stok_cabang);
				}

				$update_cabang = $this->cabang_model->update($data_stok_cabang, $where_cabang);
			} else if ($status_sk == 2) {
				$data = array(
					'tanggal' => $this->input->post('tanggal'),
					'barang_sepuhan_id' => $barang_sepuhan_id,
					'cabang_id' => $cabang_id,
					'jumlah_barang' => $jumlah_barang,
					'total_harga' => $this->input->post('total_harga'),
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$get_stok_sepuhan = $this->barang_sepuhan_model->getOneBy(['id' => $barang_sepuhan_id]);
				// stok opname kantor
				$stok_kantor = $get_stok_sepuhan->stok - $jumlah_barang;
				$data_stok_kantor = array('stok' => $stok_kantor);
				$update_kantor = $this->barang_sepuhan_model->update($data_stok_kantor, ['barang_sepuhan.id' => $barang_sepuhan_id]);
				// stok opname cabang
				$where_cabang['cabang_id'] = $cabang_id;
				$where_cabang['sepuhan_id'] = $barang_sepuhan_id;
				$get_stok_sepuhan_cabang = $this->stok_sepuhan_cabang_model->getOneBy($where_cabang);

				$stok_cabang = $get_stok_sepuhan_cabang->stok + $jumlah_barang;
				$data_stok_cabang = array('stok' => $stok_cabang);
				$update_cabang = $this->stok_sepuhan_cabang_model->update($data_stok_cabang, $where_cabang);
			} else if ($status_sk == 3) {
				$data = array(
					'tanggal' => $this->input->post('tanggal'),
					'barang_kotak_cincin_id' => $barang_kotak_cincin_id,
					'cabang_id' => $cabang_id,
					'jumlah_barang' => $jumlah_barang,
					'total_harga' => $this->input->post('total_harga'),
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$get_stok_kotak_cincin = $this->barang_kotak_cincin_model->getOneBy(['id' => $barang_kotak_cincin_id]);
				// stok opname kantor
				$stok_kantor = $get_stok_kotak_cincin->stok - $jumlah_barang;
				$data_stok_kantor = array('stok' => $stok_kantor);
				$update_kantor = $this->barang_kotak_cincin_model->update($data_stok_kantor, ['barang_kotak_cincin.id' => $barang_kotak_cincin_id]);
				// stok opname cabang
				$where_cabang['cabang_id'] = $cabang_id;
				$where_cabang['kotak_cincin_id'] = $barang_kotak_cincin_id;
				$get_stok_kotak_cincin_cabang = $this->stok_kotak_cincin_cabang_model->getOneBy($where_cabang);

				$stok_cabang = $get_stok_kotak_cincin_cabang->stok + $jumlah_barang;
				$data_stok_cabang = array('stok' => $stok_cabang);
				$update_cabang = $this->stok_kotak_cincin_cabang_model->update($data_stok_cabang, $where_cabang);
			}

			$insert = $this->barang_keluar_model->insert($data);
			if ($insert) {
				$this->session->set_flashdata('message', "Data Barang Keluar Baru Berhasil Disimpan");
				redirect("barang_keluar");
			} else {
				$this->session->set_flashdata('message_error', "Data Barang Keluar Baru Gagal Disimpan");
				redirect("barang_keluar");
			}
		} else {
			if ($this->data['is_can_create']) {
				$this->data['barang'] = $this->barang_model->getAllById();
				$this->data['barang_sepuhan'] = $this->barang_sepuhan_model->getAllById();
				$this->data['barang_kotak_cincin'] = $this->barang_kotak_cincin_model->getAllById();
				$this->data['cabang'] = $this->cabang_model->getAllById();
				$this->data['content'] = 'admin/barang_keluar/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function create_old()
	{
		$this->form_validation->set_rules('tanggal', "tanggal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$status_sk = $this->input->post('status_sk');
			$cabang_id = $this->input->post('nama_cabang');
			$barang_sepuhan_id = $this->input->post('barang_sepuhan_id');
			$barang_kotak_cincin_id = $this->input->post('barang_kotak_cincin_id');
			$jumlah_barang = $this->input->post('jumlah_barang');

			if ($status_sk == 1) {
				$data = array(
					'tanggal' => $this->input->post('tanggal'),
					'barang_sepuhan_id' => $barang_sepuhan_id,
					'cabang_id' => $cabang_id,
					'jumlah_barang' => $jumlah_barang,
					'total_harga' => $this->input->post('total_harga'),
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$get_stok_sepuhan = $this->barang_sepuhan_model->getOneBy(['id' => $barang_sepuhan_id]);
				// stok opname kantor
				$stok_kantor = $get_stok_sepuhan->stok - $jumlah_barang;
				$data_stok_kantor = array('stok' => $stok_kantor);
				$update_kantor = $this->barang_sepuhan_model->update($data_stok_kantor, ['barang_sepuhan.id' => $barang_sepuhan_id]);
				// stok opname cabang
				$where_cabang['cabang_id'] = $cabang_id;
				$where_cabang['sepuhan_id'] = $barang_sepuhan_id;
				$get_stok_sepuhan_cabang = $this->stok_sepuhan_cabang_model->getOneBy($where_cabang);

				$stok_cabang = $get_stok_sepuhan_cabang->stok + $jumlah_barang;
				$data_stok_cabang = array('stok' => $stok_cabang);
				$update_cabang = $this->stok_sepuhan_cabang_model->update($data_stok_cabang, $where_cabang);
			} else {
				$data = array(
					'tanggal' => $this->input->post('tanggal'),
					'barang_kotak_cincin_id' => $barang_kotak_cincin_id,
					'cabang_id' => $cabang_id,
					'jumlah_barang' => $jumlah_barang,
					'total_harga' => $this->input->post('total_harga'),
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$get_stok_kotak_cincin = $this->barang_kotak_cincin_model->getOneBy(['id' => $barang_kotak_cincin_id]);
				// stok opname kantor
				$stok_kantor = $get_stok_kotak_cincin->stok - $jumlah_barang;
				$data_stok_kantor = array('stok' => $stok_kantor);
				$update_kantor = $this->barang_kotak_cincin_model->update($data_stok_kantor, ['barang_kotak_cincin.id' => $barang_kotak_cincin_id]);
				// stok opname cabang
				$where_cabang['cabang_id'] = $cabang_id;
				$where_cabang['kotak_cincin_id'] = $barang_kotak_cincin_id;
				$get_stok_kotak_cincin_cabang = $this->stok_kotak_cincin_cabang_model->getOneBy($where_cabang);

				$stok_cabang = $get_stok_kotak_cincin_cabang->stok + $jumlah_barang;
				$data_stok_cabang = array('stok' => $stok_cabang);
				$update_cabang = $this->stok_kotak_cincin_cabang_model->update($data_stok_cabang, $where_cabang);
			}
			$insert = $this->barang_keluar_model->insert($data);
			if ($insert) {
				$this->session->set_flashdata('message', "Data Barang Keluar Baru Berhasil Disimpan");
				redirect("barang_keluar");
			} else {
				$this->session->set_flashdata('message_error', "Data Barang Keluar Baru Gagal Disimpan");
				redirect("barang_keluar");
			}
		} else {
			if ($this->data['is_can_create']) {
				$this->data['barang_sepuhan'] = $this->barang_sepuhan_model->getAllById();
				$this->data['barang_kotak_cincin'] = $this->barang_kotak_cincin_model->getAllById();
				$this->data['cabang'] = $this->cabang_model->getAllById();
				$this->data['content'] = 'admin/barang_keluar/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function edit()
	{
		$this->form_validation->set_rules('tanggal', "tanggal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$id = $this->input->post('id');
			$data = array(
				'tanggal' => $this->input->post('tanggal'),
				'cabang_id' => $this->input->post('nama_cabang'),
				'nama_barang' => $this->input->post('nama_barang'),
				'stok' => $this->input->post('stok'),
				'updated_by' => $this->data['users']->id
			);
			$update = $this->barang_keluar_model->update($data, array("id" => $this->input->post('id')));
			if ($update) {
				$this->session->set_flashdata('message', "Data Barang Keluar Berhasil Diedit");
				redirect("barang_keluar");
			} else {
				$this->session->set_flashdata('message_error', "Data Barang Keluar Gagal Diedit");
				redirect("barang_keluar");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("barang_keluar/edit/" . $id);
			} else {
				if ($this->data['is_can_edit']) {
					$this->data['id'] = $this->uri->segment(3);
					$this->data['cabang'] = $this->cabang_model->getAllById();
					$this->data['barang_keluar'] = $this->barang_keluar_model->getOneBy(array("barang_keluar.id" => $this->data['id']));
					$this->data['content'] = 'admin/barang_keluar/edit_v';
				} else {
					$this->data['content']  = 'errors/html/restrict';
				}
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function edit_old()
	{
		$this->form_validation->set_rules('tanggal', "tanggal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$id = $this->input->post('id');
			$data = array(
				'tanggal' => $this->input->post('tanggal'),
				'kode_barang' => $this->input->post('kode_barang'),
				'nama_barang' => $this->input->post('nama_barang'),
				'stok' => $this->input->post('stok'),
				'updated_by' => $this->data['users']->id
			);
			$update = $this->barang_keluar_model->update($data, array("id" => $this->input->post('id')));
			if ($update) {
				$this->session->set_flashdata('message', "Data Barang Keluar Berhasil Diedit");
				redirect("barang_keluar");
			} else {
				$this->session->set_flashdata('message_error', "Data Barang Keluar Gagal Diedit");
				redirect("barang_keluar");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("barang_keluar/edit/" . $id);
			} else {
				if ($this->data['is_can_edit']) {
					$this->data['id'] = $this->uri->segment(3);
					$this->data['barang_keluar'] = $this->barang_keluar_model->getOneBy(array("barang_keluar.id" => $this->data['id']));
					$this->data['content'] = 'admin/barang_keluar/edit_v';
				} else {
					$this->data['content']  = 'errors/html/restrict';
				}
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function detail()
	{
		$this->data['id'] = $this->uri->segment(3);
		$this->data['barang_keluar'] = $this->barang_keluar_model->getOneBy(array("barang_keluar.id" => $this->data['id']));

		$this->data['content'] = 'admin/barang_keluar/detail_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
			1 => 'barang_keluar.tanggal',
			2 => 'barang_keluar.cabang_id',
			3 => 'barang_keluar.nama_barang',
			4 => 'barang_keluar.jumlah_barang',
			5 => 'barang_keluar.total_harga',
			6 => 'action'
		);

		$where['barang_keluar.is_deleted'] = 0;

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->barang_keluar_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		if (!empty($this->input->post('search')['value'])) {
			$search_value = $this->input->post('search')['value'];
			$search = array(
				"barang_keluar.tanggal" => $search_value,
				"barang_keluar.cabang_id" => $search_value,
				"barang_keluar.nama_barang" => $search_value,
				"barang_keluar.jumlah_barang" => $search_value,
				"barang_keluar.total_harga" => $search_value,
			);
			$totalFiltered = $this->barang_keluar_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->barang_keluar_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				// $edit_url = "";
				$delete_url = "";
				if ($this->data['is_can_edit'] && $data->is_deleted == 0) {
					// $edit_url = "<a href='".base_url()."barang_keluar/edit/".$data->id."' class='btn btn-sm btn-info'>Ubah</a>";
					$edit_url = "<a href='" . base_url() . "barang_keluar/edit/" . $data->id . "' class='btn btn-sm btn-warning' data-toggle='tooltip' title='Edit Data' data-placement='bottom'><i class='fa fa-edit fa-w-20'></i></a>";
				}
				if ($this->data['is_can_edit']) {
					if ($data->is_deleted == 0) {
						$delete_url = "<a href='#' 
	        				url='" . base_url() . "barang_keluar/destroy/" . $data->id . "/" . $data->is_deleted . "' class='btn btn-sm btn-danger delete' data-toggle='tooltip' title='Non Aktifkan Data' data-placement='bottom'><i class='fa fa-times fa-w-20'></i></a>";
					} else {
						$delete_url = "<a href='#' 
	        				url='" . base_url() . "barang_keluar/destroy/" . $data->id . "/" . $data->is_deleted . "' class='btn btn-sm btn-success delete' data-toggle='tooltip' title='Aktifkan Data' data-placement='bottom'><i class='fa fa-check fa-w-20'></i></a>";
					}
				}

				$nestedData['id'] = $start + $key + 1;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['cabang_id'] = $data->cabang_id;
				if ($data->barang_sepuhan_id == NULL) {
					$nestedData['nama_barang'] = $data->barang_kotak_cincin_id == NULL ? $data->nama_barang : $data->nama_barang_kotak_cincin;
				}elseif ($data->barang_kotak_cincin_id == NULL) {
					$nestedData['nama_barang'] = $data->barang_sepuhan_id == NULL ? $data->nama_barang : $data->nama_barang_sepuhan;
				}elseif ($data->barang_id == NULL) {
					$nestedData['nama_barang'] = $data->barang_sepuhan_id == NULL ? $data->nama_barang_kotak_cincin : $data->nama_barang_sepuhan;
				}

				$nestedData['jumlah_barang'] = $data->jumlah_barang;
				$nestedData['total_harga'] = 'Rp. ' . number_format($data->total_harga);
				$nestedData['action'] =  $delete_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function destroy()
	{
		$response_data = array();
		$response_data['status'] = false;
		$response_data['msg'] = "";
		$response_data['data'] = array();

		$id = $this->uri->segment(3);

		$is_deleted = $this->uri->segment(4);
		if (!empty($id)) {
			$data_barang = $this->barang_keluar_model->getOneBy(['barang_keluar.id' => $id]);
			if ($data_barang->barang_sepuhan_id != NULL) {
				$get_stok_sepuhan = $this->barang_sepuhan_model->getOneBy(['id' => $data_barang->barang_sepuhan_id]);
				// stok opname kantor
				$stok_kantor = $get_stok_sepuhan->stok + $data_barang->jumlah_barang;
				$data_stok_kantor = array('stok' => $stok_kantor);

				$update_kantor = $this->barang_sepuhan_model->update($data_stok_kantor, ['barang_sepuhan.id' => $data_barang->barang_sepuhan_id]);
				// stok opname cabang
				$where_cabang['cabang_id'] = $data_barang->cabang_id;
				$where_cabang['sepuhan_id'] = $data_barang->barang_sepuhan_id;
				$get_stok_sepuhan_cabang = $this->stok_sepuhan_cabang_model->getOneBy($where_cabang);

				$stok_cabang = $get_stok_sepuhan_cabang->stok - $data_barang->jumlah_barang;
				$data_stok_cabang = array('stok' => $stok_cabang);
				$update_cabang = $this->stok_sepuhan_cabang_model->update($data_stok_cabang, $where_cabang);
			}elseif ($data_barang->barang_kotak_cincin_id != NULL) {
				$get_stok_kotak_cincin = $this->barang_kotak_cincin_model->getOneBy(['id' => $data_barang->barang_kotak_cincin_id]);
				// stok opname kantor
				$stok_kantor = $get_stok_kotak_cincin->stok + $data_barang->jumlah_barang;
				$data_stok_kantor = array('stok' => $stok_kantor);

				$update_kantor = $this->barang_kotak_cincin_model->update($data_stok_kantor, ['barang_kotak_cincin.id' => $data_barang->barang_kotak_cincin_id]);
				// stok opname cabang
				$where_cabang['cabang_id'] = $data_barang->cabang_id;
				$where_cabang['kotak_cincin_id'] = $data_barang->barang_kotak_cincin_id;
				$get_stok_kotak_cincin_cabang = $this->stok_kotak_cincin_cabang_model->getOneBy($where_cabang);

				$stok_cabang = $get_stok_kotak_cincin_cabang->stok - $data_barang->jumlah_barang;
				$data_stok_cabang = array('stok' => $stok_cabang);
				$update_cabang = $this->stok_kotak_cincin_cabang_model->update($data_stok_cabang, $where_cabang);
			}elseif ($data_barang->barang_id != NULL) {

				$get_stok_barang = $this->barang_model->getOneBy(['id' => $data_barang->barang_id]);
				// stok opname kantor
				$stok_kantor = $get_stok_barang->stok + $data_barang->jumlah_barang;
				$data_stok_kantor = array('stok' => $stok_kantor);
				$update_kantor = $this->barang_model->update($data_stok_kantor, ['barang.id' => $data_barang->barang_id]);
				// stok opname cabang
				$where_cabang['cabang.id'] = $data_barang->cabang_id;
				$get_stok_barang_cabang = $this->cabang_model->getOneBy($where_cabang);
				
				$jenis_barang = $this->barang_model->getOneBy(['id' => $data_barang->barang_id]);
				if ($jenis_barang->jenis == '925') {
					$stok_cabang = $get_stok_barang_cabang->stok_925 - $data_barang->jumlah_barang;
					$data_stok_cabang = array('stok_925' => $stok_cabang);
				} else {
					$stok_cabang = $get_stok_barang_cabang->stok_sp - $data_barang->jumlah_barang;
					$data_stok_cabang = array('stok_sp' => $stok_cabang);
				}

				$update_cabang = $this->cabang_model->update($data_stok_cabang, $where_cabang);
			}

			$data = array(
				'is_deleted' => ($is_deleted == 1) ? 0 : 1
			);
			$update = $this->barang_keluar_model->update($data, array("id" => $id));

			$response_data['data'] = $data;
			$response_data['status'] = true;
		} else {
			$response_data['msg'] = "ID Harus Diisi";
		}

		echo json_encode($response_data);
	}

	public function getbarang_keluar()
	{
		$where = array();
		$office_id = $this->input->get('office_id');

		if ($office_id != '') {
			$where['barang_keluar.office_id'] = $office_id;
		}

		$barang_keluar = $this->barang_keluar_model->getAllById($where);

		$data = array();
		if ($barang_keluar) {
			$data['status'] = true;
			$data['data'] = $barang_keluar;
			$data['message'] = "Success get data barang_keluar.";
		} else {
			$data['status'] = false;
			$data['data'] = [];
			$data['message'] = "Failed get data barang_keluar.";
		}

		echo json_encode($data);
	}
}
