<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Pembukuan_barang_kembali extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('barang_kembali_model');
		$this->load->model('barang_kembali_detail_model');
		$this->load->model('cabang_model');
		$this->load->model('data_karyawan_model');
		$this->load->model('barang_model');
		$this->load->model('enum_transaksi_barang_model');
		$this->load->model('penjualan_detail_model');
		$this->load->model('nota_model');
		$this->load->model('barang_rusak_model');
		$this->load->model('barang_hilang_model');
		$this->load->model('penjualan_model');

	}

	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$this->data['data_cabang'] = $this->cabang_model->getAllById(); 	
			$this->data['content'] = 'admin/pembukuan_barang_kembali/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function cek_nota()
	{
		$this->data['content'] = 'admin/pembukuan_barang_kembali/cek_nota_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function create()
	{
		$this->form_validation->set_rules('no_nota_id', "no_nota_id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$no_nota_id = $this->input->post('no_nota_id');
			$tanggal = $this->input->post('tanggal');
			$cabang_id = $this->input->post('cabang_id_bk');
			$data_barang_kembali = array(
				'users_id' => $this->data['users']->id,
				'tanggal' => $tanggal,
				'cabang_id' => $cabang_id,
				'total_berat' => 0,
				'jumlah_transaksi' => 1,
				'enum' => 0,
				'total_harga_keseluruhan' => 0,
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			$insert_barang_kembali = $this->barang_kembali_model->insert($data_barang_kembali);
			// get no nota
			$no_nota = $this->nota_model->getOneBy(['nota.id' => $no_nota_id]);
			
			$data_barang_kembali_detail = array(
					'barang_kembali_id' => $insert_barang_kembali,
					'no_nota' => $no_nota->no_nota,
					'enum' => 0,
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);			
			$insert_barang_kembali_detail = $this->barang_kembali_detail_model->insert($data_barang_kembali_detail);
			$data_update_nota = array(
					'status' => 2
			);
			//update status nota di tabel nota
			$update_nota = $this->nota_model->update($data_update_nota, ['nota.id' => $no_nota_id]);
			if ($update_nota) {
				$this->session->set_flashdata('message', "Data Pembukuan Baru Berhasil Disimpan");
				redirect("pembukuan_barang_kembali/create_more/" . $insert_barang_kembali);
			} else {
				$this->session->set_flashdata('message_error', "Data Pembukuan Baru Gagal Disimpan");
				redirect("pembukuan_barang_kembali");
			}
			// $potongan = $this->input->post('potongan');
			// //cek kualitas
			// $kualitas = $this->input->post('kualitas');
			// $harga_jenis_barang_kembali = $this->input->post('harga_jenis_barang_kembali');
			// //get enum transaksi
			// $where_enum['enum_transaksi_barang.jenis_transaksi'] = 'barang_kembali';
			// $where_enum['enum_transaksi_barang.harga'] = $harga_jenis_barang_kembali;
			// $enum_transaksi = $this->enum_transaksi_barang_model->getOneBy($where_enum);
			// $where_penjualan['penjualan_detail.no_nota'] = $no_nota;
			// $where_penjualan['penjualan_detail.enum'] = 0;
			// $penjualan_detail = $this->penjualan_detail_model->getOneBy($where_penjualan);

			
			// if ($kualitas != 1) {
			// 	// insert data
			// 	$data_barang_kembali = array(
			// 		'users_id' => $this->data['users']->id,
			// 		'tanggal' => $this->input->post('tanggal'),
			// 		'cabang_id' => $this->input->post('cabang_id'),
			// 		'total_berat' => $penjualan_detail->berat,
			// 		'jumlah_transaksi' => 1,
			// 		'enum' => 0,
			// 		'total_harga_keseluruhan' => $this->input->post('hasil_before_pengurangan'),
			// 		'created_by' => $this->data['users']->id,
			// 		'updated_by' => $this->data['users']->id
			// 	);
			// 	$insert_barang_kembali = $this->barang_kembali_model->insert($data_barang_kembali);

			// 	$data_barang_kembali_detail = array(
			// 		'barang_kembali_id' => $insert_barang_kembali,
			// 		'karyawan_id' => $penjualan_detail->karyawan_id,
			// 		'no_nota' => $penjualan_detail->no_nota,
			// 		'jenis_transaksi_id' => $enum_transaksi->id,
			// 		'barang_id' => $penjualan_detail->barang_id,
			// 		'berat' => $penjualan_detail->berat,
			// 		'potong' => $penjualan_detail->potong,
			// 		'harga' => $this->input->post('hasil_before_pengurangan'),
			// 		'potongan' => $potongan,
			// 		'created_by' => $this->data['users']->id,
			// 		'updated_by' => $this->data['users']->id
			// 	);
			// }else{

			// 	$data_barang_kembali = array(
			// 		'users_id' => $this->data['users']->id,
			// 		'tanggal' => $this->input->post('tanggal'),
			// 		'cabang_id' => $this->input->post('cabang_id'),
			// 		'total_berat' => $penjualan_detail->berat,
			// 		'jumlah_transaksi' => 1,
			// 		'enum' => 0,
			// 		'total_harga_keseluruhan' => $harga,
			// 		'created_by' => $this->data['users']->id,
			// 		'updated_by' => $this->data['users']->id
			// 	);
			// 	$insert_barang_kembali = $this->barang_kembali_model->insert($data_barang_kembali);
				
			// 	$data_barang_kembali_detail = array(
			// 		'barang_kembali_id' => $insert_barang_kembali,
			// 		'karyawan_id' => $penjualan_detail->karyawan_id,
			// 		'no_nota' => $penjualan_detail->no_nota,
			// 		'jenis_transaksi_id' => $enum_transaksi->id,
			// 		'barang_id' => $penjualan_detail->barang_id,
			// 		'berat' => $penjualan_detail->berat,
			// 		'potong' => $penjualan_detail->potong,
			// 		'harga' => $harga,
			// 		'potongan' => $potongan,
			// 		'created_by' => $this->data['users']->id,
			// 		'updated_by' => $this->data['users']->id
			// 	);
			// }
			
			// $insert_barang_kembali_detail = $this->barang_kembali_detail_model->insert($data_barang_kembali_detail);
			// //barang rusak
			// if ($kualitas == 2) {
			// 	$data_barang_kembali_detail = array(
			// 		'barang_kembali_id' => $insert_barang_kembali,
			// 		'karyawan_id' => $penjualan_detail->karyawan_id,
			// 		'no_nota' => $penjualan_detail->no_nota,
			// 		'jenis_transaksi_id' => $enum_transaksi->id,
			// 		'barang_id' => $penjualan_detail->barang_id,
			// 		'berat' => $penjualan_detail->berat,
			// 		'potong' => $penjualan_detail->potong,
			// 		'potongan_rusak' => $this->input->post('potongan_rusak'),
			// 		'harga' => $harga,
			// 		'potongan' => $potongan,
			// 		'created_by' => $this->data['users']->id,
			// 		'updated_by' => $this->data['users']->id
			// 	);
			// 	$insert_barang_kembali_detail = $this->barang_rusak_model->insert($data_barang_kembali_detail);
			// //barang hilang
			// } elseif ($kualitas == 3) {
			// 	$data_barang_kembali_detail = array(
			// 		'barang_kembali_id' => $insert_barang_kembali,
			// 		'karyawan_id' => $penjualan_detail->karyawan_id,
			// 		'no_nota' => $penjualan_detail->no_nota,
			// 		'jenis_transaksi_id' => $enum_transaksi->id,
			// 		'barang_id' => $penjualan_detail->barang_id,
			// 		'berat' => $this->input->post('berat_barang_hilang'),
			// 		'potong' => $penjualan_detail->potong,
			// 		'potongan_hilang' => $this->input->post('potongan_hilang'),
			// 		'harga' => $harga,
			// 		'potongan' => $potongan,
			// 		'created_by' => $this->data['users']->id,
			// 		'updated_by' => $this->data['users']->id
			// 	);
			// 	$insert_barang_kembali_detail = $this->barang_hilang_model->insert($data_barang_kembali_detail);
			// }
			
			
			// //hapus nota di penjualan setelah barang kembali
			// $data_update = array('penjualan_detail.is_deleted' => 1);
			// //update is deleted penjualan transaksi
			// $where_deleted_penjualan['penjualan_detail.no_nota'] = $no_nota;
			// $where_deleted_penjualan['penjualan_detail.enum'] = 0;
			// $this->penjualan_detail_model->update($data_update, $where_deleted_penjualan);
			// //
			// $where_cek_detail['penjualan_detail.penjualan_id'] = $penjualan_detail->penjualan_id;
			// $where_cek_detail['penjualan_detail.is_deleted'] = 0;
			// $where_cek_detail['penjualan_detail.enum'] = 0;
			// $cek_detail = $this->penjualan_detail_model->getAllById($where_cek_detail);
			// if (!empty($cek_detail)) {
			// 	$total_berat = 0.0;
			// 	$total_harga_keseluruhan = 0;
			// 	$jumlah_transaksi = count($cek_detail);
			// 	foreach ($cek_detail as $key => $value) {
			// 		$total_berat += $value->berat;
			// 		$total_harga_keseluruhan += $value->harga;
			// 	}
			// 	$data_update_penjualan = array(
			// 		'jumlah_transaksi' 					=> $jumlah_transaksi,
			// 		'total_berat' 					=> $total_berat,
			// 		'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
			// 		'updated_by' => $this->data['users']->id

			// 	); 
			// 	$update_master_penjualan = $this->penjualan_model->update($data_update_penjualan,array("penjualan.id" => $penjualan_detail->penjualan_id));
			// }
			// if (empty($cek_detail)) {
			// 	$data_update = array('penjualan.is_deleted' => 1);
			// 	$this->penjualan_model->update($data_update,array('penjualan.id' => $penjualan_detail->penjualan_id));		
			// }
			// $data_update_nota = array(
			// 		'status' => 2
			// );
			// //update status nota di tabel nota
			// $where_update_nota['nota.no_nota'] = $no_nota;
			// $where_update_nota['nota.jenis_nota'] = 0;
			// $this->nota_model->update($data_update_nota, $where_update_nota);

			// if ($value_tambah == 1) {
			// 	if ($insert_barang_kembali_detail) {
			// 		$this->session->set_flashdata('message', "Data transaksi Baru Berhasil Disimpan");
			// 		redirect("pembukuan_barang_kembali/create_more/" . $insert_barang_kembali);
			// 	} else {
			// 		$this->session->set_flashdata('message_error', "Data transaksi Baru Gagal Disimpan");
			// 		redirect("pembukuan_barang_kembali");
			// 	}
			// }
		} else {
			if ($this->data['is_can_create']) {
				$where['data_karyawan.is_deleted'] = 0;
				$where['data_karyawan.users_id'] = $this->data['users']->id;
				$this->data['karyawan'] = $this->data_karyawan_model->getAllById($where);
				$this->data['enum_transaksi'] = $this->enum_transaksi_barang_model->getAllById(['jenis_transaksi' => 'barang_kembali']);
				$this->data['barang'] = $this->barang_model->getAllById();
				$this->data['cabang'] = $this->cabang_model->getAllById();
				$this->data['content'] = 'admin/pembukuan_barang_kembali/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function create_more($id)
	{
		$this->form_validation->set_rules('barang_kembali_id', "barang_kembali_id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$barang_kembali_id = $this->input->post('barang_kembali_id');
			$no_nota_id = $this->input->post('no_nota_id');
			$cabang_id = $this->input->post('cabang_id_bk');

			//get no nota
			$no_nota = $this->nota_model->getOneBy(['nota.id' => $no_nota_id]);

			$data_barang_kembali_detail = array(
					'barang_kembali_id' => $barang_kembali_id,
					'no_nota' => $no_nota->no_nota,
					'enum' => 0,
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);			
			$insert_barang_kembali_detail = $this->barang_kembali_detail_model->insert($data_barang_kembali_detail);
			$data_update_nota = array(
					'status' => 2
			);
			//update status nota di tabel nota
			$update_nota = $this->nota_model->update($data_update_nota, ['nota.id' => $no_nota_id]);
			// update jumlah_transaksi
			//  ubah master barang_kembali
				$data_barang_kembali = $this->barang_kembali_model->getOneBy(['barang_kembali.id' => $barang_kembali_id]);
				$update_jumlah = $data_barang_kembali->jumlah_transaksi + 1;
				$data_update_barang_kembali = array(
					'jumlah_transaksi' 					=> $update_jumlah,
					'updated_by' => $this->data['users']->id

				);
				$update_master_barang_kembali = $this->barang_kembali_model->update($data_update_barang_kembali, array("barang_kembali.id" => $barang_kembali_id));
			if ($update_master_barang_kembali) {
				$this->session->set_flashdata('message', "Data Pembukuan Baru Berhasil Disimpan");
				redirect("pembukuan_barang_kembali/create_more/" . $barang_kembali_id);
			} else {
				$this->session->set_flashdata('message_error', "Data Pembukuan Baru Gagal Disimpan");
				redirect("pembukuan_barang_kembali");
			}
			/*
				kodingan lama

			$value_tambah = $this->input->post('value-btn-tambah');
			$harga = $this->input->post('harga_barang_kembali');
			$no_nota = $this->input->post('no_nota');
			$harga_jenis_barang_kembali = $this->input->post('harga_jenis_barang_kembali');
			//cek kualitas
			$kualitas = $this->input->post('kualitas');
			//get enum transaksi
			$where_enum['enum_transaksi_barang.jenis_transaksi'] = 'barang_kembali';
			$where_enum['enum_transaksi_barang.harga'] = $harga_jenis_barang_kembali;
			$enum_transaksi = $this->enum_transaksi_barang_model->getOneBy($where_enum);
			$penjualan_detail = $this->penjualan_detail_model->getOneBy(['penjualan_detail.no_nota' => $no_nota]);
			$potongan = $this->input->post('potongan');
			//value tambah
			if ($value_tambah == 1) {
				if ($kualitas != 1) {
					$data_barang_kembali_detail = array(
						'barang_kembali_id' => $barang_kembali_id,
						'karyawan_id' => $penjualan_detail->karyawan_id,
						'no_nota' => $penjualan_detail->no_nota,
						'jenis_transaksi_id' => $enum_transaksi->id,
						'barang_id' => $penjualan_detail->barang_id,
						'berat' => $penjualan_detail->berat,
						'potong' => $penjualan_detail->potong,
						'potongan' => $potongan,
						'harga' => $this->input->post('hasil_before_pengurangan'),
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
				}else{
					$data_barang_kembali_detail = array(
						'barang_kembali_id' => $barang_kembali_id,
						'karyawan_id' => $penjualan_detail->karyawan_id,
						'no_nota' => $penjualan_detail->no_nota,
						'jenis_transaksi_id' => $enum_transaksi->id,
						'barang_id' => $penjualan_detail->barang_id,
						'berat' => $penjualan_detail->berat,
						'potong' => $penjualan_detail->potong,
						'potongan' => $potongan,
						'harga' => $harga,
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
				}
				$insert_barang_kembali_detail = $this->barang_kembali_detail_model->insert($data_barang_kembali_detail);
				//barang rusak
				if ($kualitas == 2) {
					$data_barang_kembali_detail = array(
						'barang_kembali_id' => $barang_kembali_id,
						'karyawan_id' => $penjualan_detail->karyawan_id,
						'no_nota' => $penjualan_detail->no_nota,
						'jenis_transaksi_id' => $enum_transaksi->id,
						'barang_id' => $penjualan_detail->barang_id,
						'berat' => $penjualan_detail->berat,
						'potong' => $penjualan_detail->potong,
						'potongan_rusak' => $this->input->post('potongan_rusak'),
						'harga' => $harga,
						'potongan' => $potongan,
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
					$insert_barang_kembali_detail = $this->barang_rusak_model->insert($data_barang_kembali_detail);
				//barang hilang
				} elseif ($kualitas == 3) {
					$data_barang_kembali_detail = array(
						'barang_kembali_id' => $barang_kembali_id,
						'karyawan_id' => $penjualan_detail->karyawan_id,
						'no_nota' => $penjualan_detail->no_nota,
						'jenis_transaksi_id' => $enum_transaksi->id,
						'barang_id' => $penjualan_detail->barang_id,
						'berat' => $this->input->post('berat_barang_hilang'),
						'potong' => $penjualan_detail->potong,
						'potongan_hilang' => $this->input->post('potongan_hilang'),
						'harga' => $harga,
						'potongan' => $potongan,
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
					$insert_barang_kembali_detail = $this->barang_hilang_model->insert($data_barang_kembali_detail);
				}
				// ubah master barang_kembali
				$data_barang_kembali = $this->barang_kembali_model->getOneBy(['barang_kembali.id' => $barang_kembali_id]);
				//update harga
				if ($kualitas != 1) {
					$update_harga = $this->input->post('hasil_before_pengurangan') + $data_barang_kembali->total_harga_keseluruhan;
				} else {
					$update_harga = $harga + $data_barang_kembali->total_harga_keseluruhan;
				}
				
				// update jumlah_transaksi
				$update_jumlah = $data_barang_kembali->jumlah_transaksi + 1;
				// update berat
				$update_berat = $data_barang_kembali->total_berat + $penjualan_detail->berat;
				$data_update_barang_kembali = array(
					'jumlah_transaksi' 					=> $update_jumlah,
					'total_harga_keseluruhan'			=> $update_harga,
					'total_berat' 					=> $update_berat,
					'updated_by' => $this->data['users']->id

				);
				$update_master_barang_kembali = $this->barang_kembali_model->update($data_update_barang_kembali, array("barang_kembali.id" => $barang_kembali_id));
				$where_cek_detail['penjualan_detail.penjualan_id'] = $penjualan_detail->penjualan_id;
				$where_cek_detail['penjualan_detail.is_deleted'] = 0;
				$where_cek_detail['penjualan_detail.enum'] = 0;
				$cek_detail = $this->penjualan_detail_model->getAllById($where_cek_detail);
				if (!empty($cek_detail)) {
					$total_berat = 0.0;
					$total_harga_keseluruhan = 0;
					$jumlah_transaksi = count($cek_detail);
					foreach ($cek_detail as $key => $value) {
						$total_berat += $value->berat;
						$total_harga_keseluruhan += $value->harga;
					}
					$data_update_penjualan = array(
						'jumlah_transaksi' 					=> $jumlah_transaksi,
						'total_berat' 					=> $total_berat,
						'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
						'updated_by' => $this->data['users']->id

					); 
					$update_master_penjualan = $this->penjualan_model->update($data_update_penjualan,array("penjualan.id" => $penjualan_detail->penjualan_id));
				}
				if (empty($cek_detail)) {
					$data_update = array('penjualan.is_deleted' => 1);
					$this->penjualan_model->update($data_update,array('penjualan.id' => $penjualan_detail->penjualan_id));		
				}
				//hapus nota di penjualan setelah barang kembali
				$data_update = array('penjualan_detail.is_deleted' => 1);
				//update is deleted penjualan transaksi
				$where_deleted_penjualan['penjualan_detail.no_nota'] = $no_nota;
				$where_deleted_penjualan['penjualan_detail.enum'] = 0;
				$this->penjualan_detail_model->update($data_update, $where_deleted_penjualan);
				$data_update_nota = array(
						'status' => 2
				);
				//update status nota di tabel nota
				$where_update_nota['nota.no_nota'] = $no_nota;
				$where_update_nota['nota.jenis_nota'] = 0;
				$this->nota_model->update($data_update_nota, $where_update_nota);
				if ($update_master_barang_kembali) {
					$this->session->set_flashdata('message', "Data barang_kembali baru Berhasil Disimpan");
					redirect("pembukuan_barang_kembali/create_more/" . $barang_kembali_id);
				} else {
					$this->session->set_flashdata('message_error', "Data barang_kembali baru Gagal Disimpan");
					redirect("pembukuan_barang_kembali");
				}
			}
			penutup
			*/

		} else {
			if (!empty($_POST)) {
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("pembukuan_barang_kembali/create_more/" . $id);
			} else {
				$this->data['id'] = $id;
				$this->data['barang_kembali'] = $this->barang_kembali_model->getOneBy(array("barang_kembali.id" => $this->data['id']));
				$where_nota['nota.cabang_id'] = $this->data['barang_kembali']->cabang_id;
				$where_nota['nota.status'] = 1;
				$where_nota['nota.jenis_nota'] = 0;
				$this->data['nota_pembukuan'] = $this->nota_model->getAllById($where_nota);
				$this->data['data_barang_kembali_detail'] = $this->barang_kembali_detail_model->getAllById(['barang_kembali_id' => $id]);
				// $where['data_karyawan.is_deleted'] = 0;
				// $where['data_karyawan.users_id'] = $this->data['users']->id;
				// $this->data['karyawan'] = $this->data_karyawan_model->getAllById($where);
				// $this->data['enum_transaksi'] = $this->enum_transaksi_barang_model->getAllById(['jenis_transaksi' => 'barang_kembali']);
				// $this->data['barang'] = $this->barang_model->getAllById();
				// $this->data['data_barang_rusak'] = $this->barang_rusak_model->getAllById(['barang_kembali_id' => $id]);
				// $this->data['data_barang_hilang'] = $this->barang_hilang_model->getAllById(['barang_kembali_id' => $id]);
				$this->data['cabang'] = $this->cabang_model->getAllById();

				$this->data['content'] = 'admin/pembukuan_barang_kembali/create_more_v';
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function detail()
	{
		$this->data['id'] = $this->uri->segment(3);
		$this->data['barang_kembali'] = $this->barang_kembali_model->getOneBy(array("barang_kembali.id" => $this->data['id']));
		$this->data['data_barang_kembali_detail'] = $this->barang_kembali_detail_model->getAllById(['barang_kembali_id' => $this->data['id']]);
		$this->data['data_barang_rusak'] = $this->barang_rusak_model->getAllById(['barang_kembali_id' => $this->data['id']]);
				$this->data['data_barang_hilang'] = $this->barang_hilang_model->getAllById(['barang_kembali_id' => $this->data['id']]);
		$this->data['content'] = 'admin/pembukuan_barang_kembali/detail_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
		);

		$where['barang_kembali.enum'] = 0;
		$where['barang_kembali.is_deleted'] = 0;
		
		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->barang_kembali_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		$searchColumn = $this->input->post('columns');
        $isSearchColumn = false;

        if(!empty($searchColumn[0]['search']['value'])){
            $value = $searchColumn[0]['search']['value'];
            $isSearchColumn = true;
            $where['barang_kembali.tanggal'] = $value;
        }
        if(!empty($searchColumn[1]['search']['value'])){
            $value = $searchColumn[1]['search']['value'];
            $isSearchColumn = true;
            $where['barang_kembali.cabang_id'] = $value;
        }

        if($isSearchColumn){
			$totalFiltered = $this->barang_kembali_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
			$totalData = $totalFiltered;
        }else{
        	$totalFiltered = $totalData;
        }

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->barang_kembali_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$detail_url = "";
				$add_url = "";

				$detail_url = "<a href='" . base_url() . "pembukuan_barang_kembali/detail/" . $data->id . "' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";
				$add_url = "<a href='".base_url()."pembukuan_barang_kembali/create_more/".$data->id."' class='btn btn-sm btn-success' data-toggle='tooltip' title='Tambah Data' data-placement='bottom'><i class='fa fa-plus fa-w-20'></i></a>";

				$nestedData['id'] = $start + $key + 1;
				$nestedData['cabang'] = $data->kode_cabang.' - '.$data->nama_cabang;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['jumlah_transaksi'] = $data->jumlah_transaksi;
				$nestedData['action'] = $detail_url.' '.$add_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}
	public function delete(){
		$barang_kembali_detail_id = $this->uri->segment('3');
		
		$bk_detail = $this->barang_kembali_detail_model->getOneBy(['barang_kembali_detail.id' => $barang_kembali_detail_id]);
		// delete detail
		$this->db->where('barang_kembali_detail.id', $barang_kembali_detail_id);
   		$this->db->delete('barang_kembali_detail'); 
		$no_nota = $bk_detail->no_nota;		
		$nota = $this->nota_model->getOneBy(['no_nota' => $no_nota]);
		$data_update_nota = array('status' => 1);
		//update nota
		$update = $this->nota_model->update($data_update_nota, ['nota.id' => $nota->id]);
		//update master
		$cek_detail = $this->barang_kembali_detail_model->getAllById(['barang_kembali_detail.barang_kembali_id' => $bk_detail->barang_kembali_id]);
		if (!empty($cek_detail)) {
			$jumlah_transaksi = count($cek_detail);
		}else{
			$jumlah_transaksi = 0;

		}
		$data_update_master = array('jumlah_transaksi' => $jumlah_transaksi);
		$update = $this->barang_kembali_model->update($data_update_master, ['barang_kembali.id' => $bk_detail->barang_kembali_id]);


		if ($update) {
			$this->session->set_flashdata('message', "Data Berhasil Dihapus");
			redirect("pembukuan_barang_kembali/detail/".$bk_detail->barang_kembali_id);
		} else {
			$this->session->set_flashdata('message_error', "Data Gagal Dihapus");
			redirect("pembukuan_barang_kembali/detail/".$bk_detail->barang_kembali_id);
		}

	}

	public function destroy()
	{
		$response_data = array();
		$response_data['status'] = false;
		$response_data['msg'] = "";
		$response_data['data'] = array();

		$id = $this->uri->segment(3);
		$is_deleted = $this->uri->segment(4);
		if (!empty($id)) {
			$this->load->model("barang_kembali_model");
			$data = array(
				'is_deleted' => ($is_deleted == 1) ? 0 : 1
			);
			$update = $this->barang_kembali_model->update($data, array("id" => $id));

			$response_data['data'] = $data;
			$response_data['status'] = true;
		} else {
			$response_data['msg'] = "ID Harus Diisi";
		}

		echo json_encode($response_data);
	}

	public function hasil_nota(){
		$no_nota = $this->input->get('no_nota');
		$where['no_nota'] = $no_nota;
		$cek = $this->barang_kembali_detail_model->getOneBy($where);
		
		if($cek){
			$data['status'] = true;
			// $data['harga'] = $jenis->harga;
		}else{
			$data['status'] = false;
			// $data['harga'] = '';
		}
		echo json_encode($data);
	}

	public function edit_barang_rusak($barang_rusak_id)
	{
		$this->form_validation->set_rules('barang_rusak_id', "barang_rusak_id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$barang_rusak_id = $this->input->post('barang_rusak_id');
			$harga = $this->input->post('harga_barang_kembali');
			
			$get_id = $this->barang_rusak_model->getOneBy(['barang_rusak.id' => $barang_rusak_id]);
			$data_rusak = array(
				'potongan_rusak' => $this->input->post('potongan_rusak'),
				'harga' => $harga,
				'updated_by' => $this->data['users']->id
			);
			$update = $this->barang_rusak_model->update($data_rusak, array("id" => $barang_rusak_id));
			
			if ($update) {
				$this->session->set_flashdata('message', "Data Barang Rusak Berhasil Diedit");
				redirect("pembukuan_barang_kembali/detail/".$get_id->barang_kembali_id);
			} else {
				$this->session->set_flashdata('message_error', "Data Barang Rusak Gagal Diedit");
				redirect("pembukuan_barang_kembali/detail/".$get_id->barang_kembali_id);
			}
		} else {
			if ($this->data['is_can_edit']) {
				$this->data['barang_rusak_id'] = $barang_rusak_id;
				$this->data['data'] = $this->barang_rusak_model->getOneBy(array("barang_rusak.id" => $barang_rusak_id));
				$this->data['bk'] = $this->barang_kembali_detail_model->getOneBy(array("barang_kembali_detail.no_nota" => $this->data['data']->no_nota));

				$this->data['barang'] = $this->barang_model->getAllById(); 
				$this->data['enum_transaksi'] = $this->enum_transaksi_barang_model->getAllById(['jenis_transaksi' => 'barang_kembali']); 
				$this->data['content'] = 'admin/pembukuan_barang_kembali/edit_barang_rusak_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function edit_barang_hilang($barang_hilang_id)
	{
		$this->form_validation->set_rules('barang_hilang_id', "barang_hilang_id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$barang_hilang_id = $this->input->post('barang_hilang_id');
			$harga = $this->input->post('harga_barang_kembali');
			
			$get_id = $this->barang_hilang_model->getOneBy(['barang_hilang.id' => $barang_hilang_id]);
			$data_hilang = array(
				'potongan_hilang' => $this->input->post('potongan_hilang'),
				'berat' => $this->input->post('berat_barang_hilang'),
				'harga' => $harga,
				'updated_by' => $this->data['users']->id
			);
			$update = $this->barang_hilang_model->update($data_hilang, array("id" => $barang_hilang_id));
			
			if ($update) {
				$this->session->set_flashdata('message', "Data Barang Rusak Berhasil Diedit");
				redirect("pembukuan_barang_kembali/detail/".$get_id->barang_kembali_id);
			} else {
				$this->session->set_flashdata('message_error', "Data Barang Rusak Gagal Diedit");
				redirect("pembukuan_barang_kembali/detail/".$get_id->barang_kembali_id);
			}
		} else {
			if ($this->data['is_can_edit']) {
				$this->data['barang_hilang_id'] = $barang_hilang_id;
				$this->data['data'] = $this->barang_hilang_model->getOneBy(array("barang_hilang.id" => $barang_hilang_id));
				$this->data['bk'] = $this->barang_kembali_detail_model->getOneBy(array("barang_kembali_detail.no_nota" => $this->data['data']->no_nota));

				$this->data['barang'] = $this->barang_model->getAllById(); 
				$this->data['enum_transaksi'] = $this->enum_transaksi_barang_model->getAllById(['jenis_transaksi' => 'barang_kembali']); 
				$this->data['content'] = 'admin/pembukuan_barang_kembali/edit_barang_hilang_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}


}
