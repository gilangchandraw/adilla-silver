<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH.'core/Admin_Controller.php';
require_once BASEPATH. 'vendor/autoload.php';
class Harga extends Admin_Controller {
 	public function __construct()
	{
		parent::__construct();
		$this->load->model('harga_model');

	}
	public function per_km()
	{
		
		$this->load->helper('url');
		if($this->data['is_can_read']){ 
			$this->data['content'] = 'admin/harga/per_km/list_v'; 	
		}else{
			$this->data['content'] = 'errors/html/restrict'; 
		}
		
		$this->load->view('admin/layouts/page',$this->data);  
	}


	public function per_km_create()
	{ 
		$this->form_validation->set_rules('range_awal',"range_awal", 'trim|required'); 
		if ($this->form_validation->run() === TRUE)
		{
			$where['is_deleted'] = 0;
			$where['tipe_harga'] = 'km';
			$range = $this->harga_model->getAllById($where);
			$range_awal = $this->input->post('range_awal');
			$range_akhir = $this->input->post('range_akhir');
			$hasil_cek = 0;
			if ($range) {
				foreach ($range as $key => $value) {
					if (($value->range_awal <= $range_awal) && ($range_akhir <= $value->range_akhir)) {
						$hasil_cek++;
					}elseif(($value->range_awal <= $range_awal) || ($range_akhir <= $value->range_akhir)){
						$hasil_cek++;
					}
					
				}
			}
			if ($hasil_cek > 0) {
				echo "<script>alert('Harga Range Per-KM Sudah Ada, Periksa Kembali Data Inputan!!!'); history.go(-1);</script>";
			} else {
				$data = array(
					'tipe_harga' 			=> 'km',
					'range_awal' 			=> $range_awal,
					'range_akhir' 			=> $range_akhir,
					'harga' 				=> $this->input->post('harga'),
					'created_by'			=> $this->data['users']->id

				); 
				
				$insert = $this->harga_model->insert($data);
				if ($insert)
				{ 
					$this->session->set_flashdata('message', "Data Per-KM Baru Berhasil Disimpan");
					redirect("harga/per_km");
				}
				else
				{
					$this->session->set_flashdata('message_error',"Data Per-KM Baru Gagal Disimpan");
					redirect("harga/per_km");
				}
			}
			
			
		}else{   
			$this->data['content'] = 'admin/harga/per_km/create_v'; 
			$this->load->view('admin/layouts/page',$this->data); 
		}
	}

	public function per_km_edit($id)
	{ 
		$this->form_validation->set_rules('range_awal',"range_awal", 'trim|required'); 
		   
		if ($this->form_validation->run() === TRUE)
		{
			$where['is_deleted'] = 0;
			$where['tipe_harga'] = 'km';
			$where_not_in = $id;
			$range = $this->harga_model->getAllByIdExcept($where,$where_not_in);
			$range_awal = $this->input->post('range_awal');
			$range_akhir = $this->input->post('range_akhir');
			$hasil_cek = 0;
			if ($range) {
				foreach ($range as $key => $value) {
					if (($value->range_awal <= $range_awal) && ($range_akhir <= $value->range_akhir)) {
						$hasil_cek++;
					}elseif(($value->range_awal <= $range_awal) || ($range_akhir <= $value->range_akhir)){
						$hasil_cek++;
					}
					
				}
			}

			if ($hasil_cek > 0) {
				echo "<script>alert('Harga Range Per-KM Sudah Ada, Periksa Kembali Data Inputan!!!'); history.go(-1);</script>";
			} else {
				$data = array(
					'range_awal' 			=> $range_awal,
					'range_akhir' 			=> $range_akhir,
					'harga' 				=> $this->input->post('harga'),
					'updated_by'			=> $this->data['users']->id

				);
				$update = $this->harga_model->update($data,array("harga.id"=>$id));
				if ($update)
				{ 
					$this->session->set_flashdata('message', "Data Per-KM Baru Berhasil Diedit");
					redirect("harga/per_km");
				}
				else
				{
					$this->session->set_flashdata('message_error',"Data Per-KM Baru Gagal Diedit");
					redirect("harga/per_km");
				}
			}
				
		} 
		else
		{
			if(!empty($_POST)){ 
				$id = $this->input->post('id'); 
				$this->session->set_flashdata('message_error',validation_errors());
				return redirect("harga/per_km_edit/".$id);	
			}else{
				$this->data['id']= $id;
				$data = $this->harga_model->getOneBy(array("id"=>$this->data['id'])); 
				$this->data['range_awal'] 		=   (!empty($data))?$data->range_awal:"";
				$this->data['range_akhir'] 		=   (!empty($data))?$data->range_akhir:"";
				$this->data['harga'] 			=   (!empty($data))?$data->harga:"";
				
				$this->data['content'] = 'admin/harga/per_km/edit_v'; 
				$this->load->view('admin/layouts/page',$this->data); 
			}  
		}    
		
	}

	public function dataListPerKm()
	{
		$columns = array( 
            0 =>'id',  
      		1 =>'range_awal', 
      		2 =>'range_akhir',
      		3 =>'harga',
            4 => 'action'
        ); 
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
  		$search = array();
  		$where= array();
  		$limit = 0;
  		$start = 0;
  		$totalData = $this->harga_model->getCountAllBy($limit,$start,$search,$order,$dir,$where); 

        if(!empty($this->input->post('search')['value'])){
            $search_value = $this->input->post('search')['value'];
            $search = array(
                "range_awal"=>$search_value,
                "range_awal"=>$search_value,
                "harga"=>$search_value,
            );
            $totalFiltered = $this->harga_model->getCountAllBy($limit,$start,$search,$order,$dir,$where);  
        }else{
            $totalFiltered = $totalData;
        }
  
  		$limit = $this->input->post('length');
        $start = $this->input->post('start');
		$datas = $this->harga_model->getAllBy($limit,$start,$search,$order,$dir,$where);

		
     	
        $new_data = array();
        if(!empty($datas))
        { 
            foreach ($datas as $key=>$data)
            {  

            	$edit_url = "";
     			$delete_url = "";
     		
            	if($this->data['is_can_edit'] && $data->is_deleted == 0){
            		$edit_url = "<a href='".base_url()."harga/per_km_edit/".$data->id."' class='btn btn-sm btn-warning' data-toggle='tooltip' title='Edit Data' data-placement='bottom'><i class='fa fa-edit fa-w-20'></i></a>";
            	}
            	if($this->data['is_can_delete']){
	            	if($data->is_deleted == 0){
	        			$delete_url = "<a href='#' 
	        				url='".base_url()."harga/destroy_perkm/".$data->id."/".$data->is_deleted."' class='btn btn-sm btn-danger delete' data-toggle='tooltip' title='Non Aktifkan Data' data-placement='bottom'><i class='fa fa-thumbs-down fa-w-20'></i></a>";
	        		}else{
	        			$delete_url = "<a href='#' 
	        				url='".base_url()."harga/destroy_perkm/".$data->id."/".$data->is_deleted."' class='btn btn-sm btn-danger delete' data-toggle='tooltip' title='Mengaktifkan Data' data-placement='bottom'><i class='fa fa-thumbs-up fa-w-20'></i></a>";
	        		} 
        		}
            	

                $nestedData['id'] 			= $start+$key+1;
                $nestedData['range_awal'] = $data->range_awal;  
                $nestedData['range_akhir'] = $data->range_akhir;  
                $nestedData['harga'] = $data->harga;  
                $nestedData['action'] 		= $edit_url." ".$delete_url;
                $new_data[] 				= $nestedData; 
            }
        }
          
        $json_data = array(
                    "draw"            => intval($this->input->post('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $new_data   
                    );
            
        echo json_encode($json_data); 
	}
	
	public function destroy_perkm(){
		$response_data = array();
        $response_data['status'] = false;
        $response_data['msg'] = "";
        $response_data['data'] = array();   

		$id =$this->uri->segment(3);
		$is_deleted = $this->uri->segment(4);
 		if(!empty($id)){
 			$data = array(
				'is_deleted' => ($is_deleted == 1)?0:1
			); 
			$update = $this->harga_model->update($data,array("id"=>$id));

        	$response_data['data'] = $data; 
         	$response_data['status'] = true;
 		}else{
 		 	$response_data['msg'] = "ID Harus Diisi";
 		}
		
        echo json_encode($response_data); 
	}
}
