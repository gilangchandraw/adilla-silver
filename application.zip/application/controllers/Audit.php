<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Audit extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('audit_model');
	}

	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$this->data['content'] = 'admin/audit/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function create()
	{
		$this->form_validation->set_rules('nama_audit', "nama_audit Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$data = array(
				'nama_audit' => $this->input->post('nama_audit'),
				'no_telepon' => $this->input->post('no_telepon'),
				'alamat' => $this->input->post('alamat'),
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			$insert = $this->audit_model->insert($data);

			if ($insert) {
				$this->session->set_flashdata('message', "Data audit Baru Berhasil Disimpan");
				redirect("audit");
			} else {
				$this->session->set_flashdata('message_error', "Data audit Baru Gagal Disimpan");
				redirect("audit");
			}
		} else {
			if ($this->data['is_can_create']) {
				$this->data['content'] = 'admin/audit/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function edit()
	{
		$this->form_validation->set_rules('nama_audit', "nama_audit Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$id = $this->input->post('id');
			$data = array(
				'nama_audit' => $this->input->post('nama_audit'),
				'no_telepon' => $this->input->post('no_telepon'),
				'alamat' => $this->input->post('alamat'),
				'updated_by' => $this->data['users']->id
			);
			$update = $this->audit_model->update($data, array("id" => $this->input->post('id')));
			if ($update) {
				$this->session->set_flashdata('message', "Data audit Berhasil Diedit");
				redirect("audit");
			} else {
				$this->session->set_flashdata('message_error', "Data audit Gagal Diedit");
				redirect("audit");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("audit/edit/" . $id);
			} else {
				if ($this->data['is_can_edit']) {
					$this->data['id'] = $this->uri->segment(3);
					$this->data['audit'] = $this->audit_model->getOneBy(array("audit.id" => $this->data['id']));
					$this->data['content'] = 'admin/audit/edit_v';
				} else {
					$this->data['content']  = 'errors/html/restrict';
				}
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function detail()
	{
		$this->data['id'] = $this->uri->segment(3);
		$this->data['audit'] = $this->audit_model->getOneBy(array("audit.id" => $this->data['id']));

		$this->data['content'] = 'admin/audit/detail_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function dataList()
	{
		$columns = array(
			0 => 'audit.id',
			1 => 'office.id',
			2 => 'audit.name',
			3 => 'audit.description',
			4 => 'action'
		);

		$where = array();
		// if(!$this->data['is_superadmin']){
		// 	$where['audit.office_id'] = $this->data['users']->office_id;
		// }

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->audit_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		if (!empty($this->input->post('search')['value'])) {
			$search_value = $this->input->post('search')['value'];
			$search = array(
				"audit.name" => $search_value,
				"audit.description" => $search_value
			);
			$totalFiltered = $this->audit_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->audit_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$edit_url = "";
				$delete_url = "";
				if ($this->data['is_can_edit'] && $data->is_deleted == 0) {
					// $edit_url = "<a href='".base_url()."audit/edit/".$data->id."' class='btn btn-sm btn-info'>Ubah</a>";
					$edit_url = "<a href='" . base_url() . "audit/edit/" . $data->id . "' class='btn btn-sm btn-warning' data-toggle='tooltip' title='Edit Data' data-placement='bottom'><i class='fa fa-edit fa-w-20'></i></a>";
				}
				if ($this->data['is_can_edit']) {
					if ($data->is_deleted == 0) {
						$delete_url = "<a href='#' 
	        				url='" . base_url() . "audit/destroy/" . $data->id . "/" . $data->is_deleted . "' class='btn btn-sm btn-danger delete' data-toggle='tooltip' title='Non Aktifkan Data' data-placement='bottom'><i class='fa fa-times fa-w-20'></i></a>";
					} else {
						$delete_url = "<a href='#' 
	        				url='" . base_url() . "audit/destroy/" . $data->id . "/" . $data->is_deleted . "' class='btn btn-sm btn-success delete' data-toggle='tooltip' title='Aktifkan Data' data-placement='bottom'><i class='fa fa-check fa-w-20'></i></a>";
					}
				}

				$nestedData['id'] = $start + $key + 1;
				$nestedData['nama_audit'] = $data->nama_audit;
				$nestedData['no_telepon'] = $data->no_telepon;
				$nestedData['alamat'] = $data->alamat;
				$nestedData['action'] = $edit_url . " " . $delete_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function destroy()
	{
		$response_data = array();
		$response_data['status'] = false;
		$response_data['msg'] = "";
		$response_data['data'] = array();

		$id = $this->uri->segment(3);
		$is_deleted = $this->uri->segment(4);
		if (!empty($id)) {
			$this->load->model("audit_model");
			$data = array(
				'is_deleted' => ($is_deleted == 1) ? 0 : 1
			);
			$update = $this->audit_model->update($data, array("id" => $id));

			$response_data['data'] = $data;
			$response_data['status'] = true;
		} else {
			$response_data['msg'] = "ID Harus Diisi";
		}

		echo json_encode($response_data);
	}

	public function getaudit()
	{
		$where = array();
		$office_id = $this->input->get('office_id');

		if ($office_id != '') {
			$where['audit.office_id'] = $office_id;
		}

		$audit = $this->audit_model->getAllById($where);

		$data = array();
		if ($audit) {
			$data['status'] = true;
			$data['data'] = $audit;
			$data['message'] = "Success get data audit.";
		} else {
			$data['status'] = false;
			$data['data'] = [];
			$data['message'] = "Failed get data audit.";
		}

		echo json_encode($data);
	}
}
