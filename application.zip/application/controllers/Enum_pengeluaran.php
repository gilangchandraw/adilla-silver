<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Enum_pengeluaran extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('enum_pengeluaran_model');
	}

	public function get_harga()
	{
		$jenis_transaksi_id = $this->input->get('jenis_transaksi_id');
		$where['id'] = $jenis_transaksi_id;
		$jenis = $this->enum_pengeluaran_model->getOneBy($where);
		if ($jenis) {
			$data['tanggal'] = true;
			$data['total_harga_keseluruhan'] = $jenis->harga;
		} else {
			$data['tanggal'] = false;
			$data['total_harga_keseluruhan'] = '';
		}
		echo json_encode($data);
	}
}
