<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH.'core/Admin_Controller.php';
class Penjualan extends Admin_Controller {
 	public function __construct()
	{
		parent::__construct(); 
	 	$this->load->model('penjualan_model');
	 	$this->load->model('penjualan_detail_model');
	 	$this->load->model('cabang_model');
	 	$this->load->model('data_karyawan_model');
	 	$this->load->model('barang_model');
	 	$this->load->model('enum_transaksi_barang_model');
	 	$this->load->model('nota_model');
	 	$this->load->model('histori_kas_model');
	 	$this->load->model('histori_stok_barang_model');
	 	$this->load->model('tukar_plus_model');
	 	$this->load->model('tukar_plus_detail_model');
	}

	public function index()
	{
		$this->load->helper('url');
		if($this->data['is_can_read']){
			$cek_insert = true;
			$this->data['data_cabang'] = $this->cabang_model->getAllById(); 	
			if($this->data['users_groups']->id == 4){
				$where['cabang.users_id'] = $this->data['users']->id;
				$this->data['cabang'] = $this->cabang_model->getOneBy($where); 	
				$where_cek['penjualan.tanggal'] = date('Y-m-d');
				$where_cek['penjualan.enum'] = 1;
				$where_cek['penjualan.cabang_id'] = $this->data['cabang']->id;
				$cek_insert = $this->penjualan_model->getOneBy($where_cek);
			}

			$this->data['cek_insert'] = $cek_insert ? 1 : 0;
			
			$this->data['content'] = 'admin/penjualan/list_v'; 	
		}else{
			$this->data['content'] = 'errors/html/restrict'; 
		}
		
		$this->load->view('admin/layouts/page',$this->data);  
	}

	public function create()
	{ 
		$this->form_validation->set_rules('tanggal',"tanggal Is Required", 'trim|required');
		 
		if ($this->form_validation->run() === TRUE)
		{ 
			$value_tambah = $this->input->post('value-btn-tambah');
			$harga = $this->input->post('harga');
			
			$no_nota = $this->input->post('no_nota');
			$where['nota.no_nota LIKE'] = '%'.$no_nota.'%';
			$where['nota.status_stok_nota'] = 1;
			$get = $this->nota_model->getOneBy($where);
			$no_nota = $get->no_nota;
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);

			$status_nota = $this->input->post('status_nota');

			$tanggal = $this->input->post('tanggal');
			/*
				CEK TANGGAL GANDA
			*/
			$cek_tanggal_ganda = $this->penjualan_model->getOneBy(['penjualan.users_id' => $this->data['users']->id, 'penjualan.tanggal' => $tanggal]);
			if ($cek_tanggal_ganda) {
				$this->session->set_flashdata('message_error',"Input Transaksi tanggal ".$tanggal." Telah ada, silahkan input ulang & masukan penjualan pada Gambar Hijau pada sisi Sebelah kanan pada tanggal hari ini!!!");
				redirect("penjualan/create_more/".$penjualan_id);
			}
			if ($status_nota == 2 || $status_nota == 3) {

				$data_penjualan = array(
					'users_id' => $this->data['users']->id,
					'tanggal' => $tanggal,
					'cabang_id' => $cabang->id,
					'jumlah_transaksi' => 0,
					'enum' => 1,
					'total_berat' => 0,
					'total_harga_keseluruhan' => 0,
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				); 
				$insert_penjualan = $this->penjualan_model->insert($data_penjualan);
				if ($status_nota == 2) {
					$data_penjualan_detail = array(
						'enum' => 1,
						'penjualan_id' => $insert_penjualan,
						'karyawan_id' => $this->input->post('karyawan_id'),
						'no_nota' => $no_nota,
						'jenis_transaksi_id' => 0,
						'barang_id' => 0,
						'berat' => 0,
						'potong' => 0,
						'harga' => 0,
						'status' => 'Nota Batal',
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
					$data_update_nota = array(
							'status' => 3
					);
				} else {
					$data_penjualan_detail = array(
						'enum' => 1,
						'penjualan_id' => $insert_penjualan,
						'karyawan_id' => $this->input->post('karyawan_id'),
						'no_nota' => $no_nota,
						'jenis_transaksi_id' => 0,
						'barang_id' => 0,
						'berat' => 0,
						'potong' => 0,
						'harga' => 0,
						'status' => 'Nota Hilang 3R',
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
					$data_update_nota = array(
							'status' => 7
					);
				}
				//update status nota di tabel nota
				$where_update_nota['nota.no_nota'] = $no_nota;
				$where_update_nota['nota.jenis_nota'] = 1;
				$where_update_nota['nota.status_stok_nota'] = 1;
				$this->nota_model->update($data_update_nota, $where_update_nota);
				$insert_penjualan_detail = $this->penjualan_detail_model->insert($data_penjualan_detail);

				if ($insert_penjualan_detail)
				{ 
					$this->session->set_flashdata('message', "Data transaksi Baru Berhasil Disimpan");
					redirect("penjualan/create_more/".$insert_penjualan);
				}
				else
				{
					$this->session->set_flashdata('message_error',"Data transaksi Baru Gagal Disimpan");
					redirect("penjualan");
				}
			}

			 
			$data_penjualan = array(
				'users_id' => $this->data['users']->id,
				'tanggal' => $tanggal,
				'cabang_id' => $cabang->id,
				'jumlah_transaksi' => 1,
				'enum' => 1,
				'total_berat' => $this->input->post('berat'),
				'total_harga_keseluruhan' => $harga,
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			); 
			$insert_penjualan = $this->penjualan_model->insert($data_penjualan);

			$foto         = $this->input->post('foto');
			$location_path = './uploads/foto-barang-penjualan/';
			$name = $no_nota;
			$name = str_replace(' ', '-', $name);
			$uploaded      = uploadFile("foto".$foto, $location_path,$name);
		    if($uploaded['status']==1){
		    	$data_foto['foto'] = str_replace(' ', '_', $uploaded['message']);
		    }
			//
			// cek nota J
			$cek_nota = explode('~', $no_nota);
				if ($status_nota == 1) {
					$data_update_nota = array(
							'status' => 1
					);
					if (strpos($cek_nota[0], 'J') !== false) {
						$data_penjualan_detail = array(
							'enum' => 1,
							'penjualan_id' => $insert_penjualan,
							'karyawan_id' => $this->input->post('karyawan_id'),
							'no_nota' => $no_nota,
							'jenis_transaksi_id' => $this->input->post('jenis_transaksi_id'),
							'barang_id' => $this->input->post('barang_id'),
							'berat' => $this->input->post('berat'),
							'potong' => $this->input->post('potong'),
							'potongan' => $this->input->post('potongan'),
							'harga' => $harga,
							'status_print' => 1,
							'foto' => $data_foto['foto'],
							'status' => 'Nota Terjual',
							'created_by' => $this->data['users']->id,
							'updated_by' => $this->data['users']->id
						);
					} else {
						$data_penjualan_detail = array(
							'enum' => 1,
							'penjualan_id' => $insert_penjualan,
							'karyawan_id' => $this->input->post('karyawan_id'),
							'no_nota' => $no_nota,
							'jenis_transaksi_id' => $this->input->post('jenis_transaksi_id'),
							'barang_id' => $this->input->post('barang_id'),
							'berat' => $this->input->post('berat'),
							'potong' => $this->input->post('potong'),
							'potongan' => $this->input->post('potongan'),
							'harga' => $harga,
							'foto' => $data_foto['foto'],
							'status' => 'Nota Terjual',
							'created_by' => $this->data['users']->id,
							'updated_by' => $this->data['users']->id
						);
					}
					
				}elseif ($status_nota == 4) {
					if (strpos($cek_nota[0], 'J') !== false) {
						$data_penjualan_detail = array(
							'enum' => 1,
							'penjualan_id' => $insert_penjualan,
							'karyawan_id' => $this->input->post('karyawan_id'),
							'no_nota' => $no_nota,
							'jenis_transaksi_id' => $this->input->post('jenis_transaksi_id'),
							'barang_id' => $this->input->post('barang_id'),
							'berat' => $this->input->post('berat'),
							'potongan' => $this->input->post('potongan'),
							'potong' => $this->input->post('potong'),
							'harga' => $harga,
							'status_print' => 1,
							'foto' => $data_foto['foto'],
							'status' => 'Nota Hilang 2R',
							'created_by' => $this->data['users']->id,
							'updated_by' => $this->data['users']->id
						);
					}else{
						$data_penjualan_detail = array(
							'enum' => 1,
							'penjualan_id' => $insert_penjualan,
							'karyawan_id' => $this->input->post('karyawan_id'),
							'no_nota' => $no_nota,
							'jenis_transaksi_id' => $this->input->post('jenis_transaksi_id'),
							'barang_id' => $this->input->post('barang_id'),
							'berat' => $this->input->post('berat'),
							'potongan' => $this->input->post('potongan'),
							'potong' => $this->input->post('potong'),
							'harga' => $harga,
							'foto' => $data_foto['foto'],
							'status' => 'Nota Hilang 2R',
							'created_by' => $this->data['users']->id,
							'updated_by' => $this->data['users']->id
						);
					}
					$data_update_nota = array(
							'status' => 6
					);
				}
				
				//update status nota di tabel nota
				$where_update_nota['nota.no_nota'] = $no_nota;
				$where_update_nota['nota.jenis_nota'] = 1;
				$where_update_nota['nota.status_stok_nota'] = 1;
				$this->nota_model->update($data_update_nota, $where_update_nota);
				$insert_penjualan_detail = $this->penjualan_detail_model->insert($data_penjualan_detail);
			// //insert histori kas dan update kas di field cabang
			// $kas = $cabang->kas + $harga;
			// $data_update_kas = array(
			// 		'kas' => $kas
			// );
			// $update_kas = $this->cabang_model->update($data_update_kas,['cabang.id' => $cabang->id]);

			// $data_kas = array(
			// 		'users_id' => $this->data['users']->id,
			// 		'cabang_id' => $cabang->id,
			// 		'tanggal' => $tanggal,
			// 		'kas' => $kas,
			// 		'created_by' => $this->data['users']->id,
			// 		'updated_by' => $this->data['users']->id
			// );
			// $insert_kas = $this->histori_kas_model->insert($data_kas);

			 // perhitungan stock opname
			$barang_id = $this->input->post('barang_id');
			$berat = $this->input->post('berat');
			$cek_jenis_barang = $this->barang_model->getOneBy(['id' => $barang_id]);
			if($cek_jenis_barang->jenis == '925'){
				// cabang
			    $stok_akhir = $cabang->stok_925 - $berat;
			    $data_stok_opname = array('stok_925' => $stok_akhir);
			    //histori stok
			    $data_histori = array(
			    	'cabang_id' => $cabang->id,
			    	'tanggal' => $tanggal,
			    	'stok_925_awal' => $cabang->stok_925,
			    	'total_stok_925' => $berat,
			    	'stok_925_penjualan' => $berat,
			    	'stok_925_akhir' => $stok_akhir,
			    	'stok_sp_awal' => $cabang->stok_sp,
			    );
			}else{
				$stok_akhir = $cabang->stok_sp - $berat;
			    $data_stok_opname = array('stok_sp' => $stok_akhir);
			    //histori stok
			    $data_histori = array(
			    	'cabang_id' => $cabang->id,
			    	'tanggal' => $tanggal,
			    	'stok_sp_awal' => $cabang->stok_sp,
			    	'stok_sp_penjualan' => $berat,
			    	'total_stok_sp' => $berat,
			    	'stok_sp_akhir' => $stok_akhir,
			    	'stok_925_awal' => $cabang->stok_925,
			    );
			}
			//insert histori barang
			$insert_histori = $this->histori_stok_barang_model->insert($data_histori);
			// update ke cabang
			$update_stok_opname = $this->cabang_model->update($data_stok_opname, ['id' => $cabang->id]);
			if ($update_stok_opname)
			{ 
				$this->session->set_flashdata('message', "Data transaksi Baru Berhasil Disimpan");
				redirect("penjualan/create_more/".$insert_penjualan);
			}
			else
			{
				$this->session->set_flashdata('message_error',"Data transaksi Baru Gagal Disimpan");
				redirect("penjualan");
			}
		}else{  
			if($this->data['is_can_create']){  
				$where['data_karyawan.is_deleted'] = 0;
				$where['data_karyawan.users_id'] = $this->data['users']->id;
				$this->data['karyawan'] = $this->data_karyawan_model->getAllById($where); 
				$this->data['enum_transaksi'] = $this->enum_transaksi_barang_model->getAllById(['jenis_transaksi' => 'penjualan']); 
				$this->data['barang'] = $this->barang_model->getAllById(); 
				$this->data['content'] = 'admin/penjualan/create_v'; 
	        }else{
	            $this->data['content']  = 'errors/html/restrict'; 
	        } 
	        $this->load->view('admin/layouts/page',$this->data);
		}
	} 

	public function create_more($id)
	{ 
		$this->form_validation->set_rules('penjualan_id', "penjualan_id Is Required", 'trim|required'); 
		   
		if ($this->form_validation->run() === TRUE)
		{
		 	$penjualan_id = $this->input->post('penjualan_id');
		 	$value_tambah = $this->input->post('value-btn-tambah');
			$harga = $this->input->post('harga');
			
			$no_nota = $this->input->post('no_nota');
			$no_nota = $this->input->post('no_nota');
			$jenis_transaksi_id = $this->input->post('jenis_transaksi_id');
			$berat = $this->input->post('berat');
			$where['no_nota LIKE'] = '%'.$no_nota.'%';
			$where['status_stok_nota'] = 1;
			$get = $this->nota_model->getOneBy($where);
			$no_nota = $get->no_nota;
			/*
				CEK NOTA GANDA
			*/
			$cek_nota_ganda = $this->penjualan_detail_model->getOneBy(['penjualan_detail.no_nota' => $no_nota]);
			if ($cek_nota_ganda) {
				$this->session->set_flashdata('message_error',"Nota Yang Anda Masukkan Telah melakukan Transaksi, silahkan refresh sistem & input Ulang Penjualan!!!");
				redirect("penjualan/create_more/".$penjualan_id);
			}
			/*
				CEK HARGA DENGAN KARAT
			*/
			$data_karat_harga = $this->enum_transaksi_barang_model->getOneBy(['enum_transaksi_barang.id' => $jenis_transaksi_id]);
			$cek_karat_harga = $berat * $data_karat_harga->harga;
			if ($harga != $cek_karat_harga) {
				$this->session->set_flashdata('message_error',"Transaksi Salah, Hasil perkalian dari karat dan berat hasilnya salah. Ulangi input Penjualan!!! ");
				redirect("penjualan/create_more/".$penjualan_id);
			}

			//value tambah
			if ($value_tambah == 1) {
				//nota batal
				$status_nota = $this->input->post('status_nota');
				if ($status_nota == 2 || $status_nota == 3) {

					if ($status_nota == 2) {
						$data_update_nota = array(
								'status' => 3
						);
						$data_penjualan_detail = array(
							'enum' => 1,
							'penjualan_id' => $penjualan_id,
							'karyawan_id' => $this->input->post('karyawan_id'),
							'no_nota' => $no_nota,
							'jenis_transaksi_id' => 0,
							'barang_id' => 0,
							'berat' => 0,
							'potong' => 0,
							'harga' => 0,
							'status' => 'Nota Batal',
							'created_by' => $this->data['users']->id,
							'updated_by' => $this->data['users']->id
						);						
					}else{
						$data_update_nota = array(
								'status' => 7
						);
						$data_penjualan_detail = array(
							'enum' => 1,
							'penjualan_id' => $penjualan_id,
							'karyawan_id' => $this->input->post('karyawan_id'),
							'no_nota' => $no_nota,
							'jenis_transaksi_id' => 0,
							'barang_id' => 0,
							'berat' => 0,
							'potong' => 0,
							'harga' => 0,
							'status' => 'Nota Hilang 3R',
							'created_by' => $this->data['users']->id,
							'updated_by' => $this->data['users']->id
						);						
					}
					//update status nota di tabel nota
					$where_update_nota['nota.no_nota'] = $no_nota;
					$where_update_nota['nota.jenis_nota'] = 1;
					$where_update_nota['nota.status_stok_nota'] = 1;
					$this->nota_model->update($data_update_nota, $where_update_nota);
					$insert_penjualan_detail = $this->penjualan_detail_model->insert($data_penjualan_detail);

					if ($insert_penjualan_detail)
					{ 
						$this->session->set_flashdata('message', "Data transaksi Baru Berhasil Disimpan");
						redirect("penjualan/create_more/".$penjualan_id);
					}
					else
					{
						$this->session->set_flashdata('message_error',"Data transaksi Baru Gagal Disimpan!!!");
						redirect("penjualan");
					}
				}

				// foto
				$foto         = $this->input->post('foto');
				$location_path = './uploads/foto-barang-penjualan/';
				$name = $no_nota;
				$name = str_replace(' ', '-', $name);
				$uploaded      = uploadFile("foto".$foto, $location_path,$name);
			    if($uploaded['status']==1){
			    	$data_foto['foto'] = str_replace(' ', '_', $uploaded['message']);
			    }
				// cek nota
				$cek_nota = explode('~', $no_nota);
				if ($status_nota == 1) {
					$data_update_nota = array(
							'status' => 1
					);
					if (strpos($cek_nota[0], 'J') !== false) {
						$data_penjualan_detail = array(
							'enum' => 1,
							'penjualan_id' => $penjualan_id,
							'karyawan_id' => $this->input->post('karyawan_id'),
							'no_nota' => $no_nota,
							'jenis_transaksi_id' => $jenis_transaksi_id,
							'barang_id' => $this->input->post('barang_id'),
							'berat' => $berat,
							'potong' => $this->input->post('potong'),
							'potongan' => $this->input->post('potongan'),
							'harga' => $harga,
							'status_print' => 1,
							'foto' => $data_foto['foto'],
							'status' => 'Nota Terjual',
							'created_by' => $this->data['users']->id,
							'updated_by' => $this->data['users']->id
						);
					}else{
						$data_penjualan_detail = array(
							'enum' => 1,
							'penjualan_id' => $penjualan_id,
							'karyawan_id' => $this->input->post('karyawan_id'),
							'no_nota' => $no_nota,
							'jenis_transaksi_id' => $jenis_transaksi_id,
							'barang_id' => $this->input->post('barang_id'),
							'berat' => $berat,
							'potong' => $this->input->post('potong'),
							'potongan' => $this->input->post('potongan'),
							'harga' => $harga,
							'foto' => $data_foto['foto'],
							'status' => 'Nota Terjual',
							'created_by' => $this->data['users']->id,
							'updated_by' => $this->data['users']->id
						);
					}
				}elseif ($status_nota == 4) {
					$data_update_nota = array(
							'status' => 6
					);
					if (strpos($cek_nota[0], 'J') !== false) {
						$data_penjualan_detail = array(
							'enum' => 1,
							'penjualan_id' => $penjualan_id,
							'karyawan_id' => $this->input->post('karyawan_id'),
							'no_nota' => $no_nota,
							'jenis_transaksi_id' => $jenis_transaksi_id,
							'barang_id' => $this->input->post('barang_id'),
							'berat' => $berat,
							'potong' => $this->input->post('potong'),
							'potongan' => $this->input->post('potongan'),
							'harga' => $harga,
							'status_print' => 1,
							'foto' => $data_foto['foto'],
							'status' => 'Nota Hilang 2R',
							'created_by' => $this->data['users']->id,
							'updated_by' => $this->data['users']->id
						);
					}else{
						$data_penjualan_detail = array(
							'enum' => 1,
							'penjualan_id' => $penjualan_id,
							'karyawan_id' => $this->input->post('karyawan_id'),
							'no_nota' => $no_nota,
							'jenis_transaksi_id' => $jenis_transaksi_id,
							'barang_id' => $this->input->post('barang_id'),
							'berat' => $berat,
							'potong' => $this->input->post('potong'),
							'potongan' => $this->input->post('potongan'),
							'harga' => $harga,
							'foto' => $data_foto['foto'],
							'status' => 'Nota Hilang 2R',
							'created_by' => $this->data['users']->id,
							'updated_by' => $this->data['users']->id
						);
					}
				}
				//update status nota di tabel nota
				$where_update_nota['nota.no_nota'] = $no_nota;
				$where_update_nota['nota.jenis_nota'] = 1;
				$where_update_nota['nota.status_stok_nota'] = 1;
				$this->nota_model->update($data_update_nota, $where_update_nota);
				
				$insert_penjualan_detail = $this->penjualan_detail_model->insert($data_penjualan_detail);
				// ubah master penjualan
				$data_penjualan = $this->penjualan_model->getOneBy(['penjualan.id' => $penjualan_id]);
				//update harga
				$update_harga = $harga + $data_penjualan->total_harga_keseluruhan;
				// update jumlah_transaksi
				$update_jumlah = $data_penjualan->jumlah_transaksi + 1;
				// update berat
				$update_berat = $data_penjualan->total_berat + $berat;
				$data_update_penjualan = array(
					'jumlah_transaksi' 					=> $update_jumlah,
					'total_berat' 					=> $update_berat,
					'total_harga_keseluruhan'			=> $update_harga,
					'updated_by' => $this->data['users']->id

				); 
				$update_master_penjualan = $this->penjualan_model->update($data_update_penjualan,array("penjualan.id" => $penjualan_id));

				// //update histori kas dan update kas di field cabang
				// $penjualan = $this->penjualan_model->getOneBy(['penjualan.id' => $penjualan_id]);

				// $kas = $cabang->kas + $harga;
				// $data_update_kas = array(
				// 		'kas' => $kas
				// );
				// $update_kas = $this->cabang_model->update($data_update_kas,['cabang.id' => $cabang->id]);
				// //update histori kas
				// $where_kas['histori_kas.tanggal'] = $penjualan->tanggal;
				// $where_kas['histori_kas.users_id'] = $this->data['users']->id;
				// $where_kas['histori_kas.cabang_id'] = $cabang->id;
				// $update_kas = $this->histori_kas_model->update($data_update_kas,$where_kas);

				// perhitungan stok opname
				if ($this->data['is_superadmin']) {
					$cabang_id_admin = $this->input->post('cabang_id_admin');
					$cabang = $this->cabang_model->getOneBy(['cabang.id' => $cabang_id_admin]);
				} else {
					$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
				}
				
				$barang_id = $this->input->post('barang_id');
				$berat = $this->input->post('berat');
				$cek_jenis_barang = $this->barang_model->getOneBy(['id' => $barang_id]);
				// get histori barang
				$cek_histori = $this->histori_stok_barang_model->getOneBy(['cabang_id' => $cabang->id, 'tanggal' => date('Y-m-d')]);
				if($cek_jenis_barang->jenis == '925'){
					// perhitungan cabang
				    $stok_akhir = $cabang->stok_925 - $berat;
				    $data_stok_opname = array('stok_925' => $stok_akhir);
				    //histori stok
				    $total_stok_925 = $cek_histori->total_stok_925 + $berat;
				    $data_histori = array(
				    	'total_stok_925' => $total_stok_925,
				    	'stok_925_penjualan' => $total_stok_925,
				    	'stok_925_akhir' => $stok_akhir,
				    );
				}else{
					$stok_akhir = $cabang->stok_sp - $berat;
				    $data_stok_opname = array('stok_sp' => $stok_akhir);
				    //histori stok
				    $total_stok_sp = $cek_histori->total_stok_sp + $berat;
				    $data_histori = array(
				    	'total_stok_sp' => $total_stok_sp,
				    	'stok_sp_penjualan' => $total_stok_sp,
				    	'stok_sp_akhir' => $stok_akhir,
				    );
				}
				// edit di histori
				$where_update_stok['cabang_id'] = $cabang->id;
				$where_update_stok['tanggal'] = date('Y-m-d');
				$update_stok_histori = $this->histori_stok_barang_model->update($data_histori, $where_update_stok);
				//edit di cabang
				$update_stok_opname = $this->cabang_model->update($data_stok_opname, ['id' => $cabang->id]);

				if ($update_stok_opname)
				{ 
					$this->session->set_flashdata('message', "Data penjualan baru Berhasil Disimpan");
					redirect("penjualan/create_more/".$penjualan_id);
				}
				else
				{
					$this->session->set_flashdata('message_error',"Data penjualan baru Gagal Disimpan");
					redirect("penjualan");
				}
			}
				
		} 
		else
		{
			if(!empty($_POST)){ 
				$this->session->set_flashdata('message_error',validation_errors());
				return redirect("penjualan/create_more/".$id);	
			}else{
				$this->data['id']= $id;
				$this->data['penjualan'] = $this->penjualan_model->getOneBy(array("penjualan.id"=>$this->data['id']));
				$this->data['data_penjualan_detail'] = $this->penjualan_detail_model->getAllById(['penjualan_id' => $id, 'penjualan_detail.is_deleted' => 0]);
				$where['data_karyawan.is_deleted'] = 0;
				$where['data_karyawan.users_id'] = $this->data['users']->id;
				$this->data['karyawan'] = $this->data_karyawan_model->getAllById($where); 
				$this->data['enum_transaksi'] = $this->enum_transaksi_barang_model->getAllById(['jenis_transaksi' => 'penjualan']); 
				$this->data['barang'] = $this->barang_model->getAllById(); 
				$this->data['content'] = 'admin/penjualan/create_more_v';
				$this->load->view('admin/layouts/page',$this->data);
				
			}  
		}    
		
	}

	public function detail()
	{ 
		$this->data['id']= $this->uri->segment(3);
		// penjualan
		$where_sortir['penjualan_detail.status'] = 'Nota Terjual';
		$where_sortir['penjualan_detail.penjualan_id'] = $this->data['id'];
		// $where_sortir['penjualan_detail.is_deleted'] = 0;
		$sortir = $this->penjualan_detail_model->getAllById($where_sortir);
		// Batal 
		$where_sortir_batal['penjualan_detail.status'] = 'Nota Batal';
		$where_sortir_batal['penjualan_detail.penjualan_id'] = $this->data['id'];
		// $where_sortir_batal['penjualan_detail.is_deleted'] = 0;
		$sortir_batal = $this->penjualan_detail_model->getAllById($where_sortir_batal);
		$data_sortir_batal = [];
		if (!empty($sortir_batal)) {
			foreach ($sortir_batal as $key => $value) {
				$no_nota_pisah = explode('~', $value->no_nota);
				$object =  new stdClass();
                $object->no_nota = $no_nota_pisah[0];
                array_push($data_sortir_batal, $object);				
			}
		}
		
		$data_sortir = [];
		if (!empty($sortir)) {
			foreach ($sortir as $key => $value) {
				// $no_nota_pisah = explode('~', );
				$object =  new stdClass();
                $object->no_nota = $value->no_nota;
                $object->berat = $value->berat;
                $object->harga = $value->harga;
                array_push($data_sortir, $object);				
			}
		}
		$berat_nota_a = 0.0;
		$harga_nota_a = 0;
		$jumlah_nota_a = 0;
		$nota_a_awal = '';
		$nota_a_akhir = '';
		$nota_a_batal = '';
		$jumlah_nota_a_batal = 0;
		// nota B
		$berat_nota_b = 0.0;
		$harga_nota_b = 0;
		$jumlah_nota_b = 0;
		$nota_b_awal = '';
		$nota_b_akhir = '';
		$nota_b_batal = '';
		$jumlah_nota_b_batal = 0;
		// nota C
		$berat_nota_c = 0.0;
		$harga_nota_c = 0;
		$jumlah_nota_c = 0;
		$nota_c_awal = '';
		$nota_c_akhir = '';
		$nota_c_batal = '';
		$jumlah_nota_c_batal = 0;
		// nota D
		$berat_nota_d = 0.0;
		$harga_nota_d = 0;
		$jumlah_nota_d = 0;
		$nota_d_awal = '';
		$nota_d_akhir = '';
		$nota_d_batal = '';
		$jumlah_nota_d_batal = 0;
		// nota E
		$berat_nota_e = 0.0;
		$harga_nota_e = 0;
		$jumlah_nota_e = 0;
		$nota_e_awal = '';
		$nota_e_akhir = '';
		$nota_e_batal = '';
		$jumlah_nota_e_batal = 0;
		// nota J
		$berat_nota_j = 0.0;
		$harga_nota_j = 0;
		$jumlah_nota_j = 0;
		$nota_j_awal = '';
		$nota_j_akhir = '';
		$nota_j_batal = '';
		$jumlah_nota_j_batal = 0;

		if (!empty($data_sortir_batal)) {
			$data_nota_a_batal = [];
			$data_nota_b_batal = [];
			$data_nota_c_batal = [];
			$data_nota_d_batal = [];
			$data_nota_e_batal = [];
			$data_nota_j_batal = [];
			foreach ($data_sortir_batal as $key => $value) {
				
				if (strpos($value->no_nota, 'A') !== false) {
					$obj_nota_a_batal =  new stdClass();
	                $obj_nota_a_batal->no_nota = $value->no_nota;
	                array_push($data_nota_a_batal, $obj_nota_a_batal);
				}elseif (strpos($value->no_nota, 'B') !== false) {
					$obj_nota_b_batal =  new stdClass();
	                $obj_nota_b_batal->no_nota = $value->no_nota;
	                array_push($data_nota_b_batal, $obj_nota_b_batal);
				}elseif (strpos($value->no_nota, 'C') !== false) {
					$obj_nota_c_batal =  new stdClass();
	                $obj_nota_c_batal->no_nota = $value->no_nota;
	                array_push($data_nota_c_batal, $obj_nota_c_batal);
				}elseif (strpos($value->no_nota, 'D') !== false) {
					$obj_nota_d_batal =  new stdClass();
	                $obj_nota_d_batal->no_nota = $value->no_nota;
	                array_push($data_nota_d_batal, $obj_nota_d_batal);
				}elseif (strpos($value->no_nota, 'E') !== false) {
					$obj_nota_e_batal =  new stdClass();
	                $obj_nota_e_batal->no_nota = $value->no_nota;
	                array_push($data_nota_e_batal, $obj_nota_e_batal);
				}elseif (strpos($value->no_nota, 'J') !== false) {
					$obj_nota_j_batal =  new stdClass();
	                $obj_nota_j_batal->no_nota = $value->no_nota;
	                array_push($data_nota_j_batal, $obj_nota_j_batal);
				}
			}
				
		}
		$data_batal_a = [];
		if (!empty($data_nota_a_batal)) {
			$jumlah_nota_a_batal =  count($data_nota_a_batal);
			foreach ($data_nota_a_batal as $key => $value) {
				$data_batal_a [] = $value->no_nota;
			}
			$nota_a_batal = implode(',', $data_batal_a);
		}
		$data_batal_b = [];
		if (!empty($data_nota_b_batal)) {
			$jumlah_nota_b_batal =  count($data_nota_b_batal);
			foreach ($data_nota_b_batal as $key => $value) {
				$data_batal_b [] = $value->no_nota;
			}
			$nota_b_batal = implode(',', $data_batal_b);
		}
		$data_batal_c = [];
		if (!empty($data_nota_c_batal)) {
			$jumlah_nota_c_batal =  count($data_nota_c_batal);
			foreach ($data_nota_c_batal as $key => $value) {
				$data_batal_c [] = $value->no_nota;
			}
			$nota_c_batal = implode(',', $data_batal_c);
		}
		$data_batal_d = [];
		if (!empty($data_nota_d_batal)) {
			$jumlah_nota_d_batal =  count($data_nota_d_batal);
			foreach ($data_nota_d_batal as $key => $value) {
				$data_batal_d [] = $value->no_nota;
			}
			$nota_d_batal = implode(',', $data_batal_d);
		}
		$data_batal_e = [];
		if (!empty($data_nota_e_batal)) {
			$jumlah_nota_e_batal =  count($data_nota_e_batal);
			foreach ($data_nota_e_batal as $key => $value) {
				$data_batal_e [] = $value->no_nota;
			}
			$nota_e_batal = implode(',', $data_batal_e);
		}
		$data_batal_j = [];
		if (!empty($data_nota_j_batal)) {
			$jumlah_nota_j_batal =  count($data_nota_j_batal);
			foreach ($data_nota_j_batal as $key => $value) {
				$data_batal_j [] = $value->no_nota;
			}
			$nota_j_batal = implode(',', $data_batal_j);
		}
		
		if (!empty($data_sortir)) {
			// _a
			$data_nota_a = [];
			$data_nota_b = [];
			$data_nota_c = [];
			$data_nota_d = [];
			$data_nota_e = [];
			$data_nota_j = [];
			foreach ($data_sortir as $key => $value) {
				$no_nota_pisah = explode('~', $value->no_nota);
				if (strpos($no_nota_pisah[0], 'A') !== false) {
					$obj_nota_a =  new stdClass();
	                $obj_nota_a->no_nota = $no_nota_pisah[0];
	                $obj_nota_a->berat = $value->berat;
	                $obj_nota_a->harga = $value->harga;
	                array_push($data_nota_a, $obj_nota_a);
				}elseif (strpos($no_nota_pisah[0], 'B') !== false) {
					$obj_nota_b =  new stdClass();
	                $obj_nota_b->no_nota = $no_nota_pisah[0];
	                $obj_nota_b->berat = $value->berat;
	                $obj_nota_b->harga = $value->harga;
	                array_push($data_nota_b, $obj_nota_b);
				}elseif (strpos($no_nota_pisah[0], 'C') !== false) {
					$obj_nota_c =  new stdClass();
					$no_nota_pisah = explode('~', $value->no_nota);
	                $obj_nota_c->no_nota = $no_nota_pisah[0];
	                $obj_nota_c->berat = $value->berat;
	                $obj_nota_c->harga = $value->harga;
	                array_push($data_nota_c, $obj_nota_c);
				}elseif (strpos($no_nota_pisah[0], 'D') !== false) {
					$obj_nota_d =  new stdClass();
					$no_nota_pisah = explode('~', $value->no_nota);
	                $obj_nota_d->no_nota = $no_nota_pisah[0];
	                $obj_nota_d->berat = $value->berat;
	                $obj_nota_d->harga = $value->harga;
	                array_push($data_nota_d, $obj_nota_d);
				}elseif (strpos($no_nota_pisah[0], 'E') !== false) {
					$obj_nota_e =  new stdClass();
					$no_nota_pisah = explode('~', $value->no_nota);
	                $obj_nota_e->no_nota = $no_nota_pisah[0];
	                $obj_nota_e->berat = $value->berat;
	                $obj_nota_e->harga = $value->harga;
	                array_push($data_nota_e, $obj_nota_e);
				}elseif (strpos($no_nota_pisah[0], 'J') !== false) {
					$obj_nota_j =  new stdClass();
					$no_nota_pisah = explode('~', $value->no_nota);
	                $obj_nota_j->no_nota = $no_nota_pisah[0];
	                $obj_nota_j->berat = $value->berat;
	                $obj_nota_j->harga = $value->harga;
	                array_push($data_nota_j, $obj_nota_j);
				}
			}

			
		}
		
		if (!empty($data_nota_a)) {
			$data_akhir_a = count($data_nota_a);
			$data_akhir_a =  $data_akhir_a - 1;
			foreach ($data_nota_a as $key => $value) {
				$berat_nota_a += $value->berat;
				$harga_nota_a += $value->harga;
				$jumlah_nota_a++;
				if ($key === 0) {
			        $nota_a_awal = $value->no_nota;
			    }
				if ($key == $data_akhir_a) {
					$nota_a_akhir = $value->no_nota;
				}			    
			}
		}
		if (!empty($data_nota_b)) {
			$data_akhir_b = count($data_nota_b);
			$data_akhir_b =  $data_akhir_b - 1;
			foreach ($data_nota_b as $key => $value) {
				$berat_nota_b += $value->berat;
				$harga_nota_b += $value->harga;
				$jumlah_nota_b++;
				if ($key === 0) {
			        $nota_b_awal = $value->no_nota;
			    }
				if ($key == $data_akhir_b) {
					$nota_b_akhir = $value->no_nota;
				}			    
			}
		}
		if (!empty($data_nota_c)) {
			$data_akhir_c = count($data_nota_c);
			$data_akhir_c =  $data_akhir_c - 1;
			foreach ($data_nota_c as $key => $value) {
				$berat_nota_c += $value->berat;
				$harga_nota_c += $value->harga;
				$jumlah_nota_c++;
				if ($key === 0) {
			        $nota_c_awal = $value->no_nota;
			    }
				if ($key == $data_akhir_c) {
					$nota_c_akhir = $value->no_nota;
				}			    
			}
		}
		if (!empty($data_nota_d)) {
			$data_akhir_d = count($data_nota_d);
			$data_akhir_d =  $data_akhir_d - 1;
			foreach ($data_nota_d as $key => $value) {
				$berat_nota_d += $value->berat;
				$harga_nota_d += $value->harga;
				$jumlah_nota_d++;
				if ($key === 0) {
			        $nota_d_awal = $value->no_nota;
			    }
				if ($key == $data_akhir_d) {
					$nota_d_akhir = $value->no_nota;
				}			    
			}
		}
		if (!empty($data_nota_e)) {
			$data_akhir_e = count($data_nota_e);
			$data_akhir_e =  $data_akhir_e - 1;
			foreach ($data_nota_e as $key => $value) {
				$berat_nota_e += $value->berat;
				$harga_nota_e += $value->harga;
				$jumlah_nota_e++;
				if ($key === 0) {
			        $nota_e_awal = $value->no_nota;
			    }
				if ($key == $data_akhir_e) {
					$nota_e_akhir = $value->no_nota;
				}			    
			}
		}
		if (!empty($data_nota_j)) {
			$data_akhir_j = count($data_nota_j);
			$data_akhir_j =  $data_akhir_j - 1;
			foreach ($data_nota_j as $key => $value) {
				$berat_nota_j += $value->berat;
				$harga_nota_j += $value->harga;
				$jumlah_nota_j++;
				if ($key === 0) {
			        $nota_j_awal = $value->no_nota;
			    }
				if ($key == $data_akhir_j) {
					$nota_j_akhir = $value->no_nota;
				}			    
			}
		}

		$this->data['berat_nota_a'] = $berat_nota_a;
		$this->data['harga_nota_a'] = $harga_nota_a;
		$this->data['jumlah_nota_a'] = $jumlah_nota_a;
		$this->data['nota_a_awal'] = $nota_a_awal;
		$this->data['nota_a_akhir'] = $nota_a_akhir;
		$this->data['nota_a_batal'] = $nota_a_batal;
		$this->data['jumlah_nota_a_batal'] = $jumlah_nota_a_batal;
		// nota B
		$this->data['berat_nota_b'] = $berat_nota_b;
		$this->data['harga_nota_b'] = $harga_nota_b;
		$this->data['jumlah_nota_b'] = $jumlah_nota_b;
		$this->data['nota_b_awal'] = $nota_b_awal;
		$this->data['nota_b_akhir'] = $nota_b_akhir;
		$this->data['nota_b_batal'] = $nota_b_batal;
		$this->data['jumlah_nota_b_batal'] = $jumlah_nota_b_batal;
		// nota C
		$this->data['berat_nota_c'] = $berat_nota_c;
		$this->data['harga_nota_c'] = $harga_nota_c;
		$this->data['jumlah_nota_c'] = $jumlah_nota_c;
		$this->data['nota_c_awal'] = $nota_c_awal;
		$this->data['nota_c_akhir'] = $nota_c_akhir;
		$this->data['nota_c_batal'] = $nota_c_batal;
		$this->data['jumlah_nota_c_batal'] = $jumlah_nota_c_batal;
		// nota D
		$this->data['berat_nota_d'] = $berat_nota_d;
		$this->data['harga_nota_d'] = $harga_nota_d;
		$this->data['jumlah_nota_d'] = $jumlah_nota_d;
		$this->data['nota_d_awal'] = $nota_d_awal;
		$this->data['nota_d_akhir'] = $nota_d_akhir;
		$this->data['nota_d_batal'] = $nota_d_batal;
		$this->data['jumlah_nota_d_batal'] = $jumlah_nota_d_batal;
		// nota E
		$this->data['berat_nota_e'] = $berat_nota_e;
		$this->data['harga_nota_e'] = $harga_nota_e;
		$this->data['jumlah_nota_e'] = $jumlah_nota_e;
		$this->data['nota_e_awal'] = $nota_e_awal;
		$this->data['nota_e_akhir'] = $nota_e_akhir;
		$this->data['nota_e_batal'] = $nota_e_batal;
		$this->data['jumlah_nota_e_batal'] = $jumlah_nota_e_batal;
		// nota J
		$this->data['berat_nota_j'] = $berat_nota_j;
		$this->data['harga_nota_j'] = $harga_nota_j;
		$this->data['jumlah_nota_j'] = $jumlah_nota_j;
		$this->data['nota_j_awal'] = $nota_j_awal;
		$this->data['nota_j_akhir'] = $nota_j_akhir;
		$this->data['nota_j_batal'] = $nota_j_batal;
		$this->data['jumlah_nota_j_batal'] = $jumlah_nota_j_batal;

		//
		$this->data['penjualan'] = $this->penjualan_model->getOneBy(array("penjualan.id"=>$this->data['id']));
		$this->data['data_penjualan_detail'] = $this->penjualan_detail_model->getAllById(['penjualan_id' => $this->data['id']]);
		$this->data['cek_insert'] = $this->data['penjualan']->tanggal == date('Y-m-d') ? 1 : 0;
		$this->data['content'] = 'admin/penjualan/detail_v'; 
		$this->load->view('admin/layouts/page',$this->data); 		
	} 

	public function dataList()
	{
		$columns = array( 
            0 =>'id',
        );
		if($this->data['users_groups']->id == 4){
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
			$where['penjualan.cabang_id'] = $cabang->id;
		}
		$where['penjualan.enum'] = 1;
		$where['penjualan.is_deleted'] = 0;
		
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
  		$search = array();
  		$limit = 0;
  		$start = 0;
        $totalData = $this->penjualan_model->getCountAllBy($limit,$start,$search,$order,$dir,$where); 
        


        $searchColumn = $this->input->post('columns');
        $isSearchColumn = false;

        if(!empty($searchColumn[0]['search']['value'])){
            $value = $searchColumn[0]['search']['value'];
            $isSearchColumn = true;
            $where['penjualan.tanggal'] = $value;
        }
        

        if($isSearchColumn){
			$totalFiltered = $this->penjualan_model->getCountAllBy($limit,$start,$search,$order,$dir,$where); 
			$totalData = $totalFiltered;
        }else{
        	$totalFiltered = $totalData;
        }
       
        $limit = $this->input->post('length');
        $start = $this->input->post('start');
     	$datas = $this->penjualan_model->getAllBy($limit,$start,$search,$order,$dir,$where);
     	
        $new_data = array();
        if(!empty($datas))
        { 
            foreach ($datas as $key => $data)
            {  

            	$detail_url = "";
            	$add_url = "";
     			if ($this->data['users_groups']->id == 4) {
	            	if ($data->tanggal == date('Y-m-d')) {
		            	$add_url = "<a href='".base_url()."penjualan/create_more/".$data->id."' class='btn btn-sm btn-success' data-toggle='tooltip' title='Tambah Data' data-placement='bottom'><i class='fa fa-plus fa-w-20'></i></a>";            		
	            	}
     			}
     			$detail_url = "<a href='".base_url()."penjualan/detail/".$data->id."' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";

                $nestedData['id'] = $start+$key+1;
                $nestedData['tanggal'] = $data->tanggal;
                $nestedData['jumlah_transaksi'] = $data->jumlah_transaksi;
                $nestedData['total_berat'] = $data->total_berat;
                $nestedData['total_harga_keseluruhan'] = 'Rp. '.number_format($data->total_harga_keseluruhan);
           		$nestedData['action'] = $detail_url.' '.$add_url;   
                $new_data[] = $nestedData; 
            }
        }
          
        $json_data = array(
                    "draw"            => intval($this->input->post('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $new_data   
                    );
            
        echo json_encode($json_data); 
	}

	public function dataListAdmin()
	{
		$columns = array( 
            0 =>'id',
        );
		if($this->data['users_groups']->id == 4){
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
			$where['penjualan.cabang_id'] = $cabang->id;
		}
		$where['penjualan.enum'] = 1;
		$where['penjualan.is_deleted'] = 0;
		
        $order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
  		$search = array();
  		$limit = 0;
  		$start = 0;
        $totalData = $this->penjualan_model->getCountAllBy($limit,$start,$search,$order,$dir,$where); 
        


        $searchColumn = $this->input->post('columns');
        $isSearchColumn = false;

        if(!empty($searchColumn[0]['search']['value'])){
            $value = $searchColumn[0]['search']['value'];
            $isSearchColumn = true;
            $where['penjualan.tanggal'] = $value;
        }
        if(!empty($searchColumn[1]['search']['value'])){
            $value = $searchColumn[1]['search']['value'];
            $isSearchColumn = true;
            $where['penjualan.cabang_id'] = $value;
        }
        if(!empty($searchColumn[2]['search']['value'])){
            $value = $searchColumn[2]['search']['value'];
            $isSearchColumn = true;
            if ($value == 2) {
            	$value = 0;
            }
            $where['penjualan.status_audit'] = $value;
        }
        if($isSearchColumn){
			$totalFiltered = $this->penjualan_model->getCountAllBy($limit,$start,$search,$order,$dir,$where); 
			$totalData = $totalFiltered;
        }else{
        	$totalFiltered = $totalData;
        }
       
        $limit = $this->input->post('length');
        $start = $this->input->post('start');
     	$datas = $this->penjualan_model->getAllBy($limit,$start,$search,$order,$dir,$where);
     	
        $new_data = array();
        if(!empty($datas))
        { 
            foreach ($datas as $key => $data)
            {  

            	$detail_url = "";
            	$add_url = "";
            	$audit_url = "";
     			
            	$detail_url = "<a href='".base_url()."penjualan/detail/".$data->id."' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";
            	if ($data->status_audit == 0 && $this->data['users_groups']->id == 3) {
            		$audit_url = "<a href='#' 
	        				url='" . base_url() . "penjualan/destroy/" . $data->id . "/" . $data->status_audit . "' class='btn btn-sm btn-danger delete' data-toggle='tooltip' title='Data telah Diaudit' data-placement='bottom'><i class='fa fa-check-circle fa-w-20'></i></a>";
            	}
            	$add_url = "<a href='".base_url()."penjualan/create_more/".$data->id."' class='btn btn-sm btn-success' data-toggle='tooltip' title='Tambah Data' data-placement='bottom'><i class='fa fa-plus fa-w-20'></i></a>";            		
            	// $add_url = "<a href='".base_url()."penjualan/create_more/".$data->id."' class='btn btn-sm btn-success' data-toggle='tooltip' title='Tambah Data' data-placement='bottom'><i class='fa fa-plus fa-w-20'></i></a>";
            	$edit_url = "<a href='" . base_url() . "uang_laci/edit/" . $data->id . "' class='btn btn-sm btn-warning' data-toggle='tooltip' title='Edit Data' data-placement='bottom'><i class='fa fa-edit fa-w-20'></i></a>";

                $nestedData['id'] = $start+$key+1;
                $nestedData['cabang'] = $data->nama_cabang;
                $nestedData['tanggal'] = $data->tanggal;
                $nestedData['jumlah_transaksi'] = $data->jumlah_transaksi;
                $nestedData['total_berat'] = $data->total_berat;
                $nestedData['total_harga_keseluruhan'] = 'Rp. '.number_format($data->total_harga_keseluruhan);
                $nestedData['status_audit'] = $data->status_audit == 0 ? '<b style="color:red;">Belum</b>' : '<b style="color:green;">Selesai</b>';
           		$nestedData['action'] = $detail_url.' '.$add_url.' '.$audit_url;   
                $new_data[] = $nestedData; 
            }
        }
          
        $json_data = array(
                    "draw"            => intval($this->input->post('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $new_data   
                    );
            
        echo json_encode($json_data); 
	}

	public function destroy(){
		$response_data = array();
        $response_data['status'] = false;
        $response_data['msg'] = "";
        $response_data['data'] = array();   

		$id =$this->uri->segment(3);
		$status_audit = $this->uri->segment(4);
 		if(!empty($id)){
			$data = array(
				'status_audit' => ($status_audit == 1)?0:1
			); 
			$update = $this->penjualan_model->update($data,array("id"=>$id));

        	$response_data['data'] = $data; 
         	$response_data['status'] = true;
 		}else{
 		 	$response_data['msg'] = "ID Harus Diisi";
 		}
		
        echo json_encode($response_data); 
	}

	public function get_data_nota(){
		$no_nota_tambah = $this->input->get('no_nota_tambah');
		$kode_cabang = $this->input->get('kode_cabang');
		$no_nota_tambah = $no_nota_tambah.'~'.$kode_cabang;
		$where['no_nota LIKE'] = '%'.$no_nota_tambah.'%';
		$where['barang_id !='] = 0;
		$where['penjualan_detail.is_deleted'] = 0;
		$get = $this->penjualan_detail_model->getOneBy($where);
		if($get){
			$penjualan = $this->penjualan_model->getOneBy(['penjualan.id' => $get->penjualan_id]);
			$data['status'] = true;
			$data['cabang'] = $penjualan->kode_cabang.' - '.$penjualan->nama_cabang;
			$data['tanggal'] = $penjualan->tanggal;
			$data['penjualan_id'] = $get->penjualan_id;
			$data['nama_karyawan'] = $get->nama_karyawan;
			if(!$this->data['is_superadmin']){
				$no_nota = explode('~', $get->no_nota);
				$data['no_nota_tukar'] = $no_nota[0];
				$data['no_nota'] = $get->no_nota;	
			}else{
				$data['no_nota'] = $get->no_nota;	
			}
			
			$data['nama_jenis'] = $get->nama_jenis;
			$data['harga_jenis'] = $get->harga_jenis;
			$data['nama_barang'] = $get->nama_barang;
			$data['jenis_transaksi_id'] = $get->jenis_transaksi_id;
			// $data['potongan'] = number_format($get->potongan);
			$data['potongan'] = $get->potongan;
			$data['berat'] = $get->berat;
			// $data['harga'] = number_format($get->harga);
			$data['harga'] = $get->harga;
		}else{
			$where_tukar['tukar_plus_detail.no_nota LIKE'] = '%'.$no_nota_tambah.'%';
			$where_tukar['tukar_plus_detail.barang_id !='] = 0;
			$where_tukar['tukar_plus_detail.is_deleted'] = 0;
			$get_tukar = $this->tukar_plus_detail_model->getOneBy($where_tukar);
			if ($get_tukar != false) {
				$tukar_plus = $this->tukar_plus_model->getOneBy(['tukar_plus.id' => $get_tukar->tukar_plus_id]);
				$data['status'] = true;
				$data['cabang'] = $tukar_plus->kode_cabang.' - '.$tukar_plus->nama_cabang;
				$data['tanggal'] = $tukar_plus->tanggal;
				$data['penjualan_id'] = $get_tukar->tukar_plus_id;
				$data['nama_karyawan'] = $get_tukar->nama_karyawan;
				if(!$this->data['is_superadmin']){
					$no_nota = explode('~', $get_tukar->no_nota);
					$data['no_nota_tukar'] = $no_nota[0];
					$data['no_nota'] = $get_tukar->no_nota;	
				}else{
					$data['no_nota'] = $get_tukar->no_nota;	
				}
				
				$data['nama_jenis'] = $get_tukar->nama_jenis;
				$data['harga_jenis'] = $get_tukar->harga_jenis;
				$data['nama_barang'] = $get_tukar->nama_barang;
				$data['jenis_transaksi_id'] = $get_tukar->jenis_transaksi_id;
				$data['potong'] = $get_tukar->potong;
				$data['berat'] = $get_tukar->berat;
				$data['harga'] = $get_tukar->harga;
			} else {
				$data['status'] = false;
			}
		}
		echo json_encode($data);
	}

	public function edit_stok_opname_925_and_sp(){
		//stok opname dulu daks
				// get penjualan_id
			$penjualan_detail = $this->penjualan_detail_model->getOneBy(['penjualan_detail.id' => $penjualan_detail_id]);
			$penjualan = $this->penjualan_model->getOneBy(['penjualan.id' => $penjualan_detail->penjualan_id]);
			$cabang_id = $penjualan->cabang_id;

			$data_stok = $this->histori_stok_barang_model->getAllById(['cabang_id' => $cabang_id]);
			
			
			/*
				kembaliin dulu data sebelumnya
			*/
			// perhitungan stok opname
				$berat_baru = $this->input->post('berat');
				$cek_jenis_barang = $this->barang_model->getOneBy(['id' => $penjualan_detail->barang_id]);
				// get histori barang
				$cek_histori = $this->histori_stok_barang_model->getOneBy(['cabang_id' => $cabang_id, 'tanggal' => $penjualan->tanggal]);
				if($cek_jenis_barang->jenis == '925'){
				    //histori stok kembaliin data sebelumnya
					$stok_925_penjualan = $cek_histori->stok_925_penjualan - $penjualan_detail->berat;
					$total_stok_925 = $cek_histori->total_stok_925 - $penjualan_detail->berat;
				    $data_histori = array(
				    	'stok_925_penjualan' => $stok_925_penjualan,
				    	'total_stok_925' => $total_stok_925,
				    );
				    //berat baru
				    $stok_925_penjualan_edit = $stok_925_penjualan + $berat_baru;
				    $total_stok_925_edit = $total_stok_925 + $berat_baru;
				    $data_histori_edit = array(
				    	'stok_925_penjualan' => $stok_925_penjualan_edit,
				    	'total_stok_925' => $total_stok_925_edit,
				    );
				    $total_stok_925  = array();
					$stok_925_awal 	= 0;
					$stok_925_akhir 	= 0;
					$tgl_awal 	= '';
					$tgl_akhir 	= '';
					foreach ($data_stok as $key => $value) {
						$total_stok_925[$value->tanggal] = $value->id;
						$total_stok_925[$value->tanggal] = $value->total_stok_925;
						if($stok_925_awal == 0){
							$stok_925_awal = $value->stok_925_awal;
							$tgl_awal = $value->tanggal;
						}
						$tgl_akhir = $value->tanggal;
					}
			
					$tgl_akhir = date('Y-m-d', strtotime('+1 days', strtotime($tgl_akhir)));//agar melebihi 1 hari
					// data yg salah
					//masukkan format tanggal dan jumlah kas yg masuk 
					$tanggal  = $penjualan->tanggal;
					$total_stok_925_baru 		= $total_stok_925_edit;

					for($i=$tgl_awal; $i!=$tgl_akhir; $i=date('Y-m-d', strtotime('+1 days', strtotime($i)))){
						
						$data_update_stok_barang = array(
							'stok_925_awal' => $stok_925_awal,
							'total_stok_925' => ($i == $tanggal ? $total_stok_925_baru : $total_stok_925[$i]),
							'stok_925_akhir' => ($i == $tanggal ? $stok_925_awal - $total_stok_925_baru : $stok_925_awal - $total_stok_925[$i]),
							'updated_by' => $this->data['users']->id
						);
						$where_update_stok_925['cabang_id'] = $cabang_id;
						$where_update_stok_925['tanggal'] = $i;
						$update = $this->histori_stok_barang_model->update($data_update_stok_barang, $where_update_stok_925);
						// edit kas di cabang
						$data_stok_cabang = array('stok_925' => ($i == $tanggal ? $stok_925_awal - $total_stok_925_baru : $stok_925_awal - $total_stok_925[$i]));
						$update = $this->cabang_model->update($data_stok_cabang, array("cabang.id" => $cabang_id));
						
						$stok_925_awal -= ($i == $tanggal ? $total_stok_925_baru : $total_stok_925[$i]);
					}
				}else{
					//histori stok kembaliin data sebelumnya
					$stok_sp_penjualan = $cek_histori->stok_sp_penjualan - $penjualan_detail->berat;
					$total_stok_sp = $cek_histori->total_stok_sp - $penjualan_detail->berat;
				    $data_histori = array(
				    	'stok_sp_penjualan' => $stok_sp_penjualan,
				    	'total_stok_sp' => $total_stok_sp,
				    );
				    //berat baru
				    $stok_sp_penjualan_edit = $stok_sp_penjualan + $berat_baru;
				    $total_stok_sp_edit = $total_stok_sp + $berat_baru;
				    $data_histori_edit = array(
				    	'stok_sp_penjualan' => $stok_sp_penjualan_edit,
				    	'total_stok_sp' => $total_stok_sp_edit,
				    );
				    $total_stok_sp  = array();
					$stok_sp_awal 	= 0;
					$stok_sp_akhir 	= 0;
					$tgl_awal 	= '';
					$tgl_akhir 	= '';
					foreach ($data_stok as $key => $value) {
						$total_stok_sp[$value->tanggal] = $value->id;
						$total_stok_sp[$value->tanggal] = $value->total_stok_sp;
						if($stok_sp_awal == 0){
							$stok_sp_awal = $value->stok_sp_awal;
							$tgl_awal = $value->tanggal;
						}
						$tgl_akhir = $value->tanggal;
					}
			
					$tgl_akhir = date('Y-m-d', strtotime('+1 days', strtotime($tgl_akhir)));//agar melebihi 1 hari
					// data yg salah
					//masukkan format tanggal dan jumlah kas yg masuk 
					$tanggal  = $penjualan->tanggal;
					$total_stok_sp_baru 		= $total_stok_sp_edit;

					for($i=$tgl_awal; $i!=$tgl_akhir; $i=date('Y-m-d', strtotime('+1 days', strtotime($i)))){
						
						$data_update_stok_barang = array(
							'stok_sp_awal' => $stok_sp_awal,
							'total_stok_sp' => ($i == $tanggal ? $total_stok_sp_baru : $total_stok_sp[$i]),
							'stok_sp_akhir' => ($i == $tanggal ? $stok_sp_awal - $total_stok_sp_baru : $stok_sp_awal - $total_stok_sp[$i]),
							'updated_by' => $this->data['users']->id
						);
						$where_update_stok_sp['cabang_id'] = $cabang_id;
						$where_update_stok_sp['tanggal'] = $i;
						$update = $this->histori_stok_barang_model->update($data_update_stok_barang, $where_update_stok_sp);
						// edit kas di cabang
						$data_stok_cabang = array('stok_sp' => ($i == $tanggal ? $stok_sp_awal - $total_stok_sp_baru : $stok_sp_awal - $total_stok_sp[$i]));
						$update = $this->cabang_model->update($data_stok_cabang, array("cabang.id" => $cabang_id));
						
						$stok_sp_awal -= ($i == $tanggal ? $total_stok_sp_baru : $total_stok_sp[$i]);
					}
				}
				$where_update_stok['cabang_id'] = $cabang_id;
				$where_update_stok['tanggal'] = $penjualan->tanggal;
				$update_stok_histori = $this->histori_stok_barang_model->update($data_histori, $where_update_stok);
				$update_stok_histori_edit = $this->histori_stok_barang_model->update($data_histori_edit, $where_update_stok);
	}

	public function edit($penjualan_detail_id)
	{
		$this->form_validation->set_rules('penjualan_detail_id', "penjualan_detail_id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$penjualan_detail_id = $this->input->post('penjualan_detail_id');

			$no_nota = $this->input->post('no_nota');
			$harga = $this->input->post('harga');
			
				
			
			$status_nota = $this->input->post('status_nota');
			if ($status_nota == 1 || $status_nota == 4) {
				//stok opname dulu daks
				// get penjualan_id
			$penjualan_detail = $this->penjualan_detail_model->getOneBy(['penjualan_detail.id' => $penjualan_detail_id]);
			$penjualan = $this->penjualan_model->getOneBy(['penjualan.id' => $penjualan_detail->penjualan_id]);
			$cabang_id = $penjualan->cabang_id;

			$data_stok = $this->histori_stok_barang_model->getAllById(['cabang_id' => $cabang_id]);
			
			
			/*
				kembaliin dulu data sebelumnya
			*/
			// perhitungan stok opname
				$berat_baru = $this->input->post('berat_edit');
				/*
					cek jenis stok apakah sama antara penjualan dengan tukar_plus
				*/
				// penjualan
				$cek_jenis_penjualan = $this->barang_model->getOneBy(['id' => $penjualan_detail->barang_id]);
				$jenis_penjualan = $cek_jenis_penjualan->jenis;
				// tukar_plus
				$barang_id = $this->input->post('barang_id');
				$cek_jenis_edit = $this->barang_model->getOneBy(['id' => $barang_id]);
				$jenis_edit = $cek_jenis_edit->jenis;
				$cek_histori = $this->histori_stok_barang_model->getOneBy(['cabang_id' => $cabang_id, 'tanggal' => $penjualan->tanggal]);

				if ($jenis_penjualan == $jenis_edit) {
					/* 
						tukar barang ke yg sama
					*/
					$cek_jenis_barang = $this->barang_model->getOneBy(['id' => $penjualan_detail->barang_id]);
					if($cek_jenis_barang->jenis == '925'){
					    //histori stok kembaliin data sebelumnya
						$stok_925_penjualan = $cek_histori->stok_925_penjualan - $penjualan_detail->berat;
						$total_stok_925 = $cek_histori->total_stok_925 - $penjualan_detail->berat;
					    $data_histori = array(
					    	'stok_925_penjualan' => $stok_925_penjualan,
					    	'total_stok_925' => $total_stok_925,
					    );
					    //berat baru
					    $stok_925_penjualan_edit = $stok_925_penjualan + $berat_baru;
					    $total_stok_925_edit = $total_stok_925 + $berat_baru;
					    $data_histori_edit = array(
					    	'stok_925_penjualan' => $stok_925_penjualan_edit,
					    	'total_stok_925' => $total_stok_925_edit,
					    );
					    $total_stok_925  = array();
						$stok_925_awal 	= 0;
						$stok_925_akhir 	= 0;
						$tgl_awal 	= '';
						$tgl_akhir 	= '';
						foreach ($data_stok as $key => $value) {
							$total_stok_925[$value->tanggal] = $value->id;
							$total_stok_925[$value->tanggal] = $value->total_stok_925;
							if($stok_925_awal == 0){
								$stok_925_awal = $value->stok_925_awal;
								$tgl_awal = $value->tanggal;
							}
							$tgl_akhir = $value->tanggal;
						}
				
						$tgl_akhir = date('Y-m-d', strtotime('+1 days', strtotime($tgl_akhir)));//agar melebihi 1 hari
						// data yg salah
						//masukkan format tanggal dan jumlah kas yg masuk 
						$tanggal  = $penjualan->tanggal;
						$total_stok_925_baru 		= $total_stok_925_edit;

						for($i=$tgl_awal; $i!=$tgl_akhir; $i=date('Y-m-d', strtotime('+1 days', strtotime($i)))){
							
							$data_update_stok_barang = array(
								'stok_925_awal' => $stok_925_awal,
								'total_stok_925' => ($i == $tanggal ? $total_stok_925_baru : $total_stok_925[$i]),
								'stok_925_akhir' => ($i == $tanggal ? $stok_925_awal - $total_stok_925_baru : $stok_925_awal - $total_stok_925[$i]),
								'updated_by' => $this->data['users']->id
							);
							$where_update_stok_925['cabang_id'] = $cabang_id;
							$where_update_stok_925['tanggal'] = $i;
							$update = $this->histori_stok_barang_model->update($data_update_stok_barang, $where_update_stok_925);
							// edit kas di cabang
							$data_stok_cabang = array('stok_925' => ($i == $tanggal ? $stok_925_awal - $total_stok_925_baru : $stok_925_awal - $total_stok_925[$i]));
							$update = $this->cabang_model->update($data_stok_cabang, array("cabang.id" => $cabang_id));
							
							$stok_925_awal -= ($i == $tanggal ? $total_stok_925_baru : $total_stok_925[$i]);
						}
					}else{
						//histori stok kembaliin data sebelumnya
						$stok_sp_penjualan = $cek_histori->stok_sp_penjualan - $penjualan_detail->berat;
						$total_stok_sp = $cek_histori->total_stok_sp - $penjualan_detail->berat;
					    $data_histori = array(
					    	'stok_sp_penjualan' => $stok_sp_penjualan,
					    	'total_stok_sp' => $total_stok_sp,
					    );
					    //berat baru
					    $stok_sp_penjualan_edit = $stok_sp_penjualan + $berat_baru;
					    $total_stok_sp_edit = $total_stok_sp + $berat_baru;
					    $data_histori_edit = array(
					    	'stok_sp_penjualan' => $stok_sp_penjualan_edit,
					    	'total_stok_sp' => $total_stok_sp_edit,
					    );
					    $total_stok_sp  = array();
						$stok_sp_awal 	= 0;
						$stok_sp_akhir 	= 0;
						$tgl_awal 	= '';
						$tgl_akhir 	= '';
						foreach ($data_stok as $key => $value) {
							$total_stok_sp[$value->tanggal] = $value->id;
							$total_stok_sp[$value->tanggal] = $value->total_stok_sp;
							if($stok_sp_awal == 0){
								$stok_sp_awal = $value->stok_sp_awal;
								$tgl_awal = $value->tanggal;
							}
							$tgl_akhir = $value->tanggal;
						}
				
						$tgl_akhir = date('Y-m-d', strtotime('+1 days', strtotime($tgl_akhir)));//agar melebihi 1 hari
						// data yg salah
						//masukkan format tanggal dan jumlah kas yg masuk 
						$tanggal  = $penjualan->tanggal;
						$total_stok_sp_baru 		= $total_stok_sp_edit;

						for($i=$tgl_awal; $i!=$tgl_akhir; $i=date('Y-m-d', strtotime('+1 days', strtotime($i)))){
							
							$data_update_stok_barang = array(
								'stok_sp_awal' => $stok_sp_awal,
								'total_stok_sp' => ($i == $tanggal ? $total_stok_sp_baru : $total_stok_sp[$i]),
								'stok_sp_akhir' => ($i == $tanggal ? $stok_sp_awal - $total_stok_sp_baru : $stok_sp_awal - $total_stok_sp[$i]),
								'updated_by' => $this->data['users']->id
							);
							$where_update_stok_sp['cabang_id'] = $cabang_id;
							$where_update_stok_sp['tanggal'] = $i;
							$update = $this->histori_stok_barang_model->update($data_update_stok_barang, $where_update_stok_sp);
							// edit kas di cabang
							$data_stok_cabang = array('stok_sp' => ($i == $tanggal ? $stok_sp_awal - $total_stok_sp_baru : $stok_sp_awal - $total_stok_sp[$i]));
							$update = $this->cabang_model->update($data_stok_cabang, array("cabang.id" => $cabang_id));
							
							$stok_sp_awal -= ($i == $tanggal ? $total_stok_sp_baru : $total_stok_sp[$i]);
						}
					}
					// get histori barang
					$where_update_stok['cabang_id'] = $cabang_id;
					$where_update_stok['tanggal'] = $penjualan->tanggal;
					$update_stok_histori = $this->histori_stok_barang_model->update($data_histori, $where_update_stok);
					$update_stok_histori_edit = $this->histori_stok_barang_model->update($data_histori_edit, $where_update_stok);
				} else {
					/*
						edit barang beda
					*/
					$cek_jenis_barang = $this->barang_model->getOneBy(['id' => $barang_id]);
					if($cek_jenis_barang->jenis == '925'){
					    //histori stok kembaliin data sebelumnya yg sp
						$stok_925_penjualan = $cek_histori->stok_925_penjualan + $berat_baru;
						$total_stok_925 = $cek_histori->total_stok_925 + $berat_baru;
					    $data_histori_925 = array(
					    	'stok_925_penjualan' => $stok_925_penjualan,
					    	'total_stok_925' => $total_stok_925,
					    );
					    //berat baru
					    $stok_925_penjualan_edit = $stok_925_penjualan;
					    $total_stok_925_edit = $total_stok_925;
					    $data_histori_edit_925 = array(
					    	'stok_925_penjualan' => $stok_925_penjualan_edit,
					    	'total_stok_925' => $total_stok_925_edit,
					    );
					    $total_stok_925  = array();
						$stok_925_awal 	= 0;
						$stok_925_akhir 	= 0;
						$tgl_awal 	= '';
						$tgl_akhir 	= '';
						foreach ($data_stok as $key => $value) {
							$total_stok_925[$value->tanggal] = $value->id;
							$total_stok_925[$value->tanggal] = $value->total_stok_925;
							if($stok_925_awal == 0){
								$stok_925_awal = $value->stok_925_awal;
								$tgl_awal = $value->tanggal;
							}
							$tgl_akhir = $value->tanggal;
						}
				
						$tgl_akhir = date('Y-m-d', strtotime('+1 days', strtotime($tgl_akhir)));//agar melebihi 1 hari
						// data yg salah
						//masukkan format tanggal dan jumlah kas yg masuk 
						$tanggal  = $penjualan->tanggal;
						$total_stok_925_baru 		= $total_stok_925_edit;

						for($i=$tgl_awal; $i!=$tgl_akhir; $i=date('Y-m-d', strtotime('+1 days', strtotime($i)))){
							
							$data_update_stok_barang = array(
								'stok_925_awal' => $stok_925_awal,
								'total_stok_925' => ($i == $tanggal ? $total_stok_925_baru : $total_stok_925[$i]),
								'stok_925_akhir' => ($i == $tanggal ? $stok_925_awal - $total_stok_925_baru : $stok_925_awal - $total_stok_925[$i]),
								'updated_by' => $this->data['users']->id
							);
							$where_update_stok_925['cabang_id'] = $cabang_id;
							$where_update_stok_925['tanggal'] = $i;
							$update = $this->histori_stok_barang_model->update($data_update_stok_barang, $where_update_stok_925);
							// edit kas di cabang
							$data_stok_cabang = array('stok_925' => ($i == $tanggal ? $stok_925_awal - $total_stok_925_baru : $stok_925_awal - $total_stok_925[$i]));
							$update = $this->cabang_model->update($data_stok_cabang, array("cabang.id" => $cabang_id));
							
							$stok_925_awal -= ($i == $tanggal ? $total_stok_925_baru : $total_stok_925[$i]);
						}
						// get histori barang
						$where_update_stok['cabang_id'] = $cabang_id;
						$where_update_stok['tanggal'] = $penjualan->tanggal;
						$update_stok_histori = $this->histori_stok_barang_model->update($data_histori_925, $where_update_stok);
						$update_stok_histori_edit = $this->histori_stok_barang_model->update($data_histori_edit_925, $where_update_stok);
						/*
							skrg tambah yg sp nya bro
						*/
						//histori stok kembaliin data sebelumnya
						$stok_sp_penjualan = $cek_histori->stok_sp_penjualan - $penjualan_detail->berat;
						$total_stok_sp = $cek_histori->total_stok_sp - $penjualan_detail->berat;
					    $data_histori_sp = array(
					    	'stok_sp_penjualan' => $stok_sp_penjualan,
					    	'total_stok_sp' => $total_stok_sp,
					    );
					    //berat baru
					    $stok_sp_penjualan_edit = $stok_sp_penjualan;
					    $total_stok_sp_edit = $total_stok_sp;
					    $data_histori_edit_sp = array(
					    	'stok_sp_penjualan' => $stok_sp_penjualan_edit,
					    	'total_stok_sp' => $total_stok_sp_edit,
					    );
					    $total_stok_sp  = array();
						$stok_sp_awal 	= 0;
						$stok_sp_akhir 	= 0;
						$tgl_awal 	= '';
						$tgl_akhir 	= '';
						foreach ($data_stok as $key => $value) {
							$total_stok_sp[$value->tanggal] = $value->id;
							$total_stok_sp[$value->tanggal] = $value->total_stok_sp;
							if($stok_sp_awal == 0){
								$stok_sp_awal = $value->stok_sp_awal;
								$tgl_awal = $value->tanggal;
							}
							$tgl_akhir = $value->tanggal;
						}
				
						$tgl_akhir = date('Y-m-d', strtotime('+1 days', strtotime($tgl_akhir)));//agar melebihi 1 hari
						// data yg salah
						//masukkan format tanggal dan jumlah kas yg masuk 
						$tanggal  = $penjualan->tanggal;
						$total_stok_sp_baru 		= $total_stok_sp_edit;

						for($i=$tgl_awal; $i!=$tgl_akhir; $i=date('Y-m-d', strtotime('+1 days', strtotime($i)))){
							
							$data_update_stok_barang = array(
								'stok_sp_awal' => $stok_sp_awal,
								'total_stok_sp' => ($i == $tanggal ? $total_stok_sp_baru : $total_stok_sp[$i]),
								'stok_sp_akhir' => ($i == $tanggal ? $stok_sp_awal - $total_stok_sp_baru : $stok_sp_awal - $total_stok_sp[$i]),
								'updated_by' => $this->data['users']->id
							);
							$where_update_stok_sp['cabang_id'] = $cabang_id;
							$where_update_stok_sp['tanggal'] = $i;
							$update = $this->histori_stok_barang_model->update($data_update_stok_barang, $where_update_stok_sp);
							// edit kas di cabang
							$data_stok_cabang = array('stok_sp' => ($i == $tanggal ? $stok_sp_awal - $total_stok_sp_baru : $stok_sp_awal - $total_stok_sp[$i]));
							$update = $this->cabang_model->update($data_stok_cabang, array("cabang.id" => $cabang_id));
							
							$stok_sp_awal -= ($i == $tanggal ? $total_stok_sp_baru : $total_stok_sp[$i]);
						}
						// update data
						$where_update_stok['cabang_id'] = $cabang_id;
						$where_update_stok['tanggal'] = $penjualan->tanggal;
						$update_stok_histori = $this->histori_stok_barang_model->update($data_histori_sp, $where_update_stok);
						$update_stok_histori_edit = $this->histori_stok_barang_model->update($data_histori_edit_sp, $where_update_stok);

					}else{
						//histori stok kembaliin data sebelumnya
						$stok_sp_penjualan = $cek_histori->stok_sp_penjualan + $berat_baru;
						$total_stok_sp = $cek_histori->total_stok_sp + $berat_baru;
					    $data_histori_sp = array(
					    	'stok_sp_penjualan' => $stok_sp_penjualan,
					    	'total_stok_sp' => $total_stok_sp,
					    );
					    //berat baru
					    $stok_sp_penjualan_edit = $stok_sp_penjualan;
					    $total_stok_sp_edit = $total_stok_sp;
					    $data_histori_edit_sp = array(
					    	'stok_sp_penjualan' => $stok_sp_penjualan_edit,
					    	'total_stok_sp' => $total_stok_sp_edit,
					    );
					    $total_stok_sp  = array();
						$stok_sp_awal 	= 0;
						$stok_sp_akhir 	= 0;
						$tgl_awal 	= '';
						$tgl_akhir 	= '';
						foreach ($data_stok as $key => $value) {
							$total_stok_sp[$value->tanggal] = $value->id;
							$total_stok_sp[$value->tanggal] = $value->total_stok_sp;
							if($stok_sp_awal == 0){
								$stok_sp_awal = $value->stok_sp_awal;
								$tgl_awal = $value->tanggal;
							}
							$tgl_akhir = $value->tanggal;
						}
				
						$tgl_akhir = date('Y-m-d', strtotime('+1 days', strtotime($tgl_akhir)));//agar melebihi 1 hari
						// data yg salah
						//masukkan format tanggal dan jumlah kas yg masuk 
						$tanggal  = $penjualan->tanggal;
						$total_stok_sp_baru 		= $total_stok_sp_edit;

						for($i=$tgl_awal; $i!=$tgl_akhir; $i=date('Y-m-d', strtotime('+1 days', strtotime($i)))){
							
							$data_update_stok_barang = array(
								'stok_sp_awal' => $stok_sp_awal,
								'total_stok_sp' => ($i == $tanggal ? $total_stok_sp_baru : $total_stok_sp[$i]),
								'stok_sp_akhir' => ($i == $tanggal ? $stok_sp_awal - $total_stok_sp_baru : $stok_sp_awal - $total_stok_sp[$i]),
								'updated_by' => $this->data['users']->id
							);
							$where_update_stok_sp['cabang_id'] = $cabang_id;
							$where_update_stok_sp['tanggal'] = $i;
							$update = $this->histori_stok_barang_model->update($data_update_stok_barang, $where_update_stok_sp);
							// edit kas di cabang
							$data_stok_cabang = array('stok_sp' => ($i == $tanggal ? $stok_sp_awal - $total_stok_sp_baru : $stok_sp_awal - $total_stok_sp[$i]));
							$update = $this->cabang_model->update($data_stok_cabang, array("cabang.id" => $cabang_id));
							
							$stok_sp_awal -= ($i == $tanggal ? $total_stok_sp_baru : $total_stok_sp[$i]);
						}
					}
					// get histori barang
					$where_update_stok['cabang_id'] = $cabang_id;
					$where_update_stok['tanggal'] = $penjualan->tanggal;
					$update_stok_histori = $this->histori_stok_barang_model->update($data_histori_sp, $where_update_stok);
					$update_stok_histori_edit = $this->histori_stok_barang_model->update($data_histori_edit_sp, $where_update_stok);
					/*
						skrg tambahin yg sp nya bro
					*/
					/*
							skrg tambah yg 925 nya bro
						*/
						//histori stok kembaliin data sebelumnya
						$stok_925_penjualan = $cek_histori->stok_925_penjualan - $penjualan_detail->berat;
						$total_stok_925 = $cek_histori->total_stok_925 - $penjualan_detail->berat;
					    $data_histori_925 = array(
					    	'stok_925_penjualan' => $stok_925_penjualan,
					    	'total_stok_925' => $total_stok_925,
					    );
					    //berat baru
					    $stok_925_penjualan_edit = $stok_925_penjualan;
					    $total_stok_925_edit = $total_stok_925;
					    $data_histori_edit_925 = array(
					    	'stok_925_penjualan' => $stok_925_penjualan_edit,
					    	'total_stok_925' => $total_stok_925_edit,
					    );
					    $total_stok_925  = array();
						$stok_925_awal 	= 0;
						$stok_925_akhir 	= 0;
						$tgl_awal 	= '';
						$tgl_akhir 	= '';
						foreach ($data_stok as $key => $value) {
							$total_stok_925[$value->tanggal] = $value->id;
							$total_stok_925[$value->tanggal] = $value->total_stok_925;
							if($stok_925_awal == 0){
								$stok_925_awal = $value->stok_925_awal;
								$tgl_awal = $value->tanggal;
							}
							$tgl_akhir = $value->tanggal;
						}
				
						$tgl_akhir = date('Y-m-d', strtotime('+1 days', strtotime($tgl_akhir)));//agar melebihi 1 hari
						// data yg salah
						//masukkan format tanggal dan jumlah kas yg masuk 
						$tanggal  = $penjualan->tanggal;
						$total_stok_925_baru 		= $total_stok_925_edit;

						for($i=$tgl_awal; $i!=$tgl_akhir; $i=date('Y-m-d', strtotime('+1 days', strtotime($i)))){
							
							$data_update_stok_barang = array(
								'stok_925_awal' => $stok_925_awal,
								'total_stok_925' => ($i == $tanggal ? $total_stok_925_baru : $total_stok_925[$i]),
								'stok_925_akhir' => ($i == $tanggal ? $stok_925_awal - $total_stok_925_baru : $stok_925_awal - $total_stok_925[$i]),
								'updated_by' => $this->data['users']->id
							);
							$where_update_stok_925['cabang_id'] = $cabang_id;
							$where_update_stok_925['tanggal'] = $i;
							$update = $this->histori_stok_barang_model->update($data_update_stok_barang, $where_update_stok_925);
							// edit kas di cabang
							$data_stok_cabang = array('stok_925' => ($i == $tanggal ? $stok_925_awal - $total_stok_925_baru : $stok_925_awal - $total_stok_925[$i]));
							$update = $this->cabang_model->update($data_stok_cabang, array("cabang.id" => $cabang_id));
							
							$stok_925_awal -= ($i == $tanggal ? $total_stok_925_baru : $total_stok_925[$i]);
						}
						// update data
						$where_update_stok['cabang_id'] = $cabang_id;
						$where_update_stok['tanggal'] = $penjualan->tanggal;
						$update_stok_histori = $this->histori_stok_barang_model->update($data_histori_925, $where_update_stok);
						$update_stok_histori_edit = $this->histori_stok_barang_model->update($data_histori_edit_925, $where_update_stok);
				}

				if ($status_nota == 1) {
					$data_penjualan_detail = array(
						'jenis_transaksi_id' => $this->input->post('jenis_transaksi_id'),
						'barang_id' => $this->input->post('barang_id'),
						'berat' => $this->input->post('berat_edit'),
						'potongan' => $this->input->post('potongan'),
						'harga' => $harga,
						'status' => 'Nota Terjual',
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
					$data_update_nota = array(
							'status' => 1
					);
				}elseif ($status_nota == 4) {
					$data_penjualan_detail = array(
						'jenis_transaksi_id' => $this->input->post('jenis_transaksi_id'),
						'barang_id' => $this->input->post('barang_id'),
						'berat' => $this->input->post('berat_edit'),
						'potongan' => $this->input->post('potongan'),
						'harga' => $harga,
						'status' => 'Nota Hilang 2R',
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
					$data_update_nota = array(
							'status' => 6
					);
				}
			}
			if ($status_nota == 2 || $status_nota == 3) {
				if ($status_nota == 2) {
					$data_penjualan_detail = array(
						'jenis_transaksi_id' => 0,
						'barang_id' => 0,
						'berat' => 0,
						'potong' => 0,
						'harga' => 0,
						'status' => 'Nota Batal',
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
					$data_update_nota = array(
							'status' => 3
					);
				}else{
					$data_penjualan_detail = array(
						'jenis_transaksi_id' => 0,
						'barang_id' => 0,
						'berat' => 0,
						'potong' => 0,
						'harga' => 0,
						'status' => 'Nota Hilang 3R',
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
					$data_update_nota = array(
							'status' => 7
					);
				}
			}
			//update status nota di tabel nota
			$where_update_nota['nota.no_nota'] = $no_nota;
			$where_update_nota['nota.jenis_nota'] = 1;
			$where_update_nota['nota.status_stok_nota'] = 1;
			$this->nota_model->update($data_update_nota, $where_update_nota);
			$update = $this->penjualan_detail_model->update($data_penjualan_detail, array("id" => $penjualan_detail_id));

			//get id penjualan
			$get_id = $this->penjualan_detail_model->getOneBy(['penjualan_detail.id' => $penjualan_detail_id]);
			$penjualan = $this->penjualan_detail_model->getAllById(['penjualan_detail.enum' => 1, 'penjualan_detail.penjualan_id' => $get_id->penjualan_id, 'penjualan_detail.is_deleted' => 0]);
			$jumlah_transaksi = count($penjualan);
			$update_total_berat = 0.0;
			$update_total_harga = 0;
			foreach ($penjualan as $key => $value) {
				$update_total_berat += $value->berat;
				$update_total_harga += $value->harga;
			}
			//update data penjualan
			$data_penjualan = array('jumlah_transaksi' => $jumlah_transaksi, 'total_berat' => $update_total_berat, 'total_harga_keseluruhan' => $update_total_harga); 
			$update = $this->penjualan_model->update($data_penjualan, array("penjualan.id" => $get_id->penjualan_id));
			
			if ($update) {
				$this->session->set_flashdata('message', "Data Penjualan Berhasil Diedit");
				redirect("penjualan/detail/".$get_id->penjualan_id);
			} else {
				$this->session->set_flashdata('message_error', "Data Penjualan Gagal Diedit");
				redirect("penjualan/detail/".$get_id->penjualan_id);
			}
		} else {
			if ($this->data['is_can_edit']) {
				$this->data['penjualan_detail_id'] = $penjualan_detail_id;
				$this->data['detail'] = $this->penjualan_detail_model->getOneBy(array("penjualan_detail.id" => $penjualan_detail_id));
				$this->data['barang'] = $this->barang_model->getAllById(); 
				$this->data['enum_transaksi'] = $this->enum_transaksi_barang_model->getAllById(['jenis_transaksi' => 'penjualan']);

				$this->data['content'] = 'admin/penjualan/edit_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}


	public function print_nota($penjualan_detail_id)
	{
		$penjualan_detail = $this->penjualan_detail_model->getOneBy(['penjualan_detail.id' => $penjualan_detail_id]);
		if ($penjualan_detail->status_print == 0) {
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
			if ($penjualan_detail && $cabang) {
				// ubah status print
		        $data = array('status_print' => 1);
				$update = $this->penjualan_detail_model->update($data, ['penjualan_detail.id' => $penjualan_detail_id]);
				// kedataan penjualan
				$number = '0123456789';
				$barcode = substr(str_shuffle($number), 0, 1);
				$penjualan = $this->penjualan_model->getOneBy(['penjualan.id' => $penjualan_detail->penjualan_id]);
				$data['penjualan'] = $penjualan;
				$data['barcode'] = $barcode;
				$data['tipe_cabang'] = $cabang->tipe_cabang;
				$data['penjualan_detail'] = $penjualan_detail;
				$data['cabang'] = $cabang;
				$this->load->view('admin/penjualan/print_v',$data);
			} else {
				$this->session->set_flashdata('message_error', "Gagal Nota Silahkan Coba Kembali, Apabila Masih Gagal silahkan hubungin Admin Adilla 925");
				redirect("penjualan/detail/".$penjualan->penjualan_id);
			}
		} else {
			// anu matih ieu bisa aya penambahan uang coy
			echo "<script>alert('Nota Telah Diprint, Anda Terdeteksi oleh sistem melakukan print nota Ganda!!!'); history.go(-1);</script>";
		}
		
			
		
	}

	public function nota_batal($penjualan_detail_id)
	{
		$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
		//data penjualan
		$data_penjualan = $this->penjualan_detail_model->getOneBy(['penjualan_detail.id' => $penjualan_detail_id]);
		if ($this->data['is_superadmin']) {
			$data_cabang =  $this->penjualan_model->getOneBy(['penjualan.id' => $data_penjualan->penjualan_id]);
			$cabang = $this->cabang_model->getOneBy(['cabang.id' => $data_cabang->cabang_id]);
		}
		// ambil data stok barang
		$where['cabang_id'] = $cabang->id;
		$where['tanggal'] = date('Y-m-d');
		$data_stok = $this->histori_stok_barang_model->getOneBy($where);
		// ambil data barang
		$cek_jenis_barang = $this->barang_model->getOneBy(['barang.id' => $data_penjualan->barang_id]);
		
		if ($cabang && $data_penjualan && $data_stok && $cek_jenis_barang) {
			if ($cek_jenis_barang->jenis == '925') {
				// kantor
			    $stok_akhir = $cabang->stok_925 + $data_penjualan->berat;
			    $data_stok_opname_cabang = array('stok_925' => $stok_akhir);
			    // buat cabang
			    $stok_925_penjualan = $data_stok->stok_925_penjualan - $data_penjualan->berat;
			    $total_stok_925 = $data_stok->total_stok_925 - $data_penjualan->berat;
			    $stok_925_akhir = $data_stok->stok_925_akhir + $data_penjualan->berat;
			    //histori stok
			    $data_histori = array(
			    	'stok_925_penjualan' => $stok_925_penjualan,
			    	'total_stok_925' => $total_stok_925,
			    	'stok_925_akhir' => $stok_925_akhir,
			    );
			}else{
				// kantor
			    $stok_akhir = $cabang->stok_sp + $data_penjualan->berat;
			    $data_stok_opname_cabang = array('stok_sp' => $stok_akhir);
			    // buat cabang
			    $stok_sp_penjualan = $data_stok->stok_sp_penjualan - $data_penjualan->berat;
			    $total_stok_sp = $data_stok->total_stok_sp - $data_penjualan->berat;
			    $stok_sp_akhir = $data_stok->stok_sp_akhir + $data_penjualan->berat;
			    //histori stok
			    $data_histori = array(
			    	'stok_sp_penjualan' => $stok_sp_penjualan,
			    	'total_stok_sp' => $total_stok_sp,
			    	'stok_sp_akhir' => $stok_sp_akhir,
			    );
			}
			// update stok kantor
			$where_update_kantor['cabang.id'] = $cabang->id;
			$kantor = $this->cabang_model->update($data_stok_opname_cabang, $where_update_kantor);
			// update histori stok barang
			$where_update_cabang['histori_stok_barang.id'] = $data_stok->id;
			$histori_stok_cabang = $this->histori_stok_barang_model->update($data_histori, $where_update_cabang);
			//update data penjualan  menjadi batal
			$data_penjualan_detail = array(
				'enum' => 1,
				'penjualan_id' => $data_penjualan->penjualan_id,
				'karyawan_id' => $data_penjualan->karyawan_id,
				'no_nota' => $data_penjualan->no_nota,
				'jenis_transaksi_id' => 0,
				'barang_id' => 0,
				'potongan' => 0,
				'berat' => 0,
				'potong' => 0,
				'harga' => 0,
				'status' => 'Nota Batal',
				'status_print' => 2,
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			$data_update_nota = array(
					'status' => 3
			);
			// update status nota di tabel nota
			$where_update_nota['nota.no_nota'] = $data_penjualan->no_nota;
			$where_update_nota['nota.jenis_nota'] = 1;
			$where_update_nota['nota.status_stok_nota'] = 1;
			$nota_update = $this->nota_model->update($data_update_nota, $where_update_nota);
			$penjualan_detail_update = $this->penjualan_detail_model->update($data_penjualan_detail, ['penjualan_detail.id' => $data_penjualan->id]);
			$no_nota = explode('~', $data_penjualan->no_nota);

			// update total penjualan
			$cek_detail = $this->penjualan_detail_model->getAllById(['penjualan_detail.penjualan_id' => $data_penjualan->penjualan_id, 'penjualan_detail.is_deleted' => 0]);
			if (!empty($cek_detail)) {
				$total_berat = 0.0;
				$total_harga_keseluruhan = 0;
				$jumlah_transaksi = count($cek_detail);
				foreach ($cek_detail as $key => $value) {
					$total_berat += $value->berat;
					$total_harga_keseluruhan += $value->harga;
				}
				$data_update_penjualan = array(
					'jumlah_transaksi' 					=> $jumlah_transaksi,
					'total_berat' 					=> $total_berat,
					'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
					'updated_by' => $this->data['users']->id

				); 
				$update_master_penjualan = $this->penjualan_model->update($data_update_penjualan,array("penjualan.id" => $data_penjualan->penjualan_id));
			}
			if ($update_master_penjualan)
			{ 
				$this->session->set_flashdata('message', "Data Penjualan Nota ".$no_nota[0]." menjadi Nota Batal");
				redirect("penjualan/detail/".$data_penjualan->penjualan_id);
			}
			else
			{
				$this->session->set_flashdata('message_error',"Data transaksi Baru Gagal Disimpan");
				redirect("penjualan");
			}
			
		} else {
			$this->session->set_flashdata('message_error',"Ubah nota Batal terjadi error, silahkan coba lagi");
			redirect("penjualan");
		}
	}

	public function print_nota_perhari($penjualan_id)
	{
		// get tanggal
		$penjualan = $this->penjualan_model->getOneBy(['penjualan.id' => $penjualan_id]);
		$data['tanggal'] = $penjualan->tanggal;
		// get cabang
		$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
		$data['cabang'] = $cabang->nama_cabang;
		$data['tipe_cabang'] = $cabang->tipe_cabang;
		$where['penjualan_detail.penjualan_id'] = $penjualan_id;
		$where['penjualan_detail.is_deleted'] = 0;
		$data['data_penjualan_detail'] = $this->penjualan_detail_model->getAllById($where);
		if (!empty($data['data_penjualan_detail'])) {
			require_once BASEPATH. 'vendor/autoload.php';
	        // $mpdf = new \Mpdf\Mpdf(['mode' => 'utf-8', 'format' => [216, 350]]);
	        $mpdf = new \Mpdf\Mpdf(['orientation' => 'L']);
	        $html = $this->load->view('admin/penjualan/print_nota_perhari_v',$data,TRUE);
	        // print_r($html);
	        // die();
	        $mpdf->WriteHTML($html);
	        // $mpdf->Output("laporan-nota-terjual~".$tanggal.'-'.time().".pdf","I");
	        $mpdf->Output("laporan-nota-terjual-".time().".pdf","I");
		} else {
			$this->session->set_flashdata('message_error',"print Nota Gagal, silahkan coba lagi");
			redirect("penjualan");
		}
	}

}
