<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Stok_kotak_cincin extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('stok_kotak_cincin_cabang_model');
		$this->load->model('cabang_model');
		$this->load->model('barang_kotak_cincin_model');
	}

	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$this->data['data_cabang'] = $this->cabang_model->getAllById(); 
			$this->data['kotak_cincin'] = $this->barang_kotak_cincin_model->getAllById();
			$this->data['content'] = 'admin/stok_kotak_cincin/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
			// 1 => 'stok_kotak_cincin.kode_stok_kotak_cincin',
			// 2 => 'stok_kotak_cincin.nama_stok_kotak_cincin',
			// 3 => 'stok_kotak_cincin.alamat',
			// 4 => 'action'
		);

		$where = array();
		$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
		$where['stok_kotak_cincin_cabang.cabang_id'] = $cabang->id;
		
		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->stok_kotak_cincin_cabang_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		$searchColumn = $this->input->post('columns');
        $isSearchColumn = false;

        if(!empty($searchColumn[0]['search']['value'])){
            $value = $searchColumn[0]['search']['value'];
            $isSearchColumn = true;
            $where['stok_kotak_cincin_cabang.kotak_cincin_id'] = $value;
        }
        

        if($isSearchColumn){
			$totalFiltered = $this->stok_kotak_cincin_cabang_model->getCountAllBy($limit,$start,$search,$order,$dir,$where); 
			$totalData = $totalFiltered;
        }else{
        	$totalFiltered = $totalData;
        }

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->stok_kotak_cincin_cabang_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$nestedData['id'] = $start + $key + 1;
				$nestedData['nama_kotak_cincin'] = $data->nama_kotak_cincin;
				$nestedData['stok'] = $data->stok;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function dataListAdmin()
	{
		$columns = array(
			0 => 'id',
			// 1 => 'stok_kotak_cincin.kode_stok_kotak_cincin',
			// 2 => 'stok_kotak_cincin.nama_stok_kotak_cincin',
			// 3 => 'stok_kotak_cincin.alamat',
			// 4 => 'action'
		);

		$where = array();
		
		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->stok_kotak_cincin_cabang_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		$searchColumn = $this->input->post('columns');
        $isSearchColumn = false;

        if(!empty($searchColumn[0]['search']['value'])){
            $value = $searchColumn[0]['search']['value'];
            $isSearchColumn = true;
            $where['stok_kotak_cincin_cabang.kotak_cincin_id'] = $value;
        }
        if(!empty($searchColumn[1]['search']['value'])){
            $value = $searchColumn[1]['search']['value'];
            $isSearchColumn = true;
            $where['stok_kotak_cincin_cabang.cabang_id'] = $value;
        }
        

        if($isSearchColumn){
			$totalFiltered = $this->stok_kotak_cincin_cabang_model->getCountAllBy($limit,$start,$search,$order,$dir,$where); 
			$totalData = $totalFiltered;
        }else{
        	$totalFiltered = $totalData;
        }

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->stok_kotak_cincin_cabang_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$nestedData['id'] = $start + $key + 1;
				$nestedData['cabang'] = $data->nama_cabang;
				$nestedData['nama_kotak_cincin'] = $data->nama_kotak_cincin;
				$nestedData['stok'] = $data->stok;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function cek_stok()
	{
		$kotak_cincin_id = $this->input->get('kotak_cincin_id');
		$qty = $this->input->get('qty');
		
		//get cabang
		$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
		$where['cabang_id'] = $cabang->id;
		$where['kotak_cincin_id'] = $kotak_cincin_id;
		$stok_kc = $this->stok_kotak_cincin_cabang_model->getOneBy($where);
		
		if ($qty <= $stok_kc->stok) {
			$data['status'] = true;
		} else {
			$data['status'] = false;
		}
		echo json_encode($data);
	}
}
