<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Pembukuan_pengeluaran extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('pengeluaran_model');
		$this->load->model('pengeluaran_detail_model');
		$this->load->model('cabang_model');
		$this->load->model('enum_pengeluaran_model');
	}
	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			if (!$this->data['is_superadmin']) {
				$where['cabang.users_id'] = $this->data['users']->id;
				$this->data['cabang'] = $this->cabang_model->getOneBy($where);
			}
			$this->data['content'] = 'admin/pembukuan_pengeluaran/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function create()
	{
		$this->form_validation->set_rules('tanggal', "tanggal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$value_simpan = $this->input->post('value-btn-simpan');
			$value_tambah = $this->input->post('value-btn-tambah');


			$data_pengeluaran = array(
				'users_id' => $this->data['users']->id,
				'tanggal' => $this->input->post('tanggal'),
				'total_harga_keseluruhan' => $this->input->post('harga'),
				'enum' => 0,
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			$insert_pengeluaran = $this->pengeluaran_model->insert($data_pengeluaran);
			$data_pengeluaran_detail = array(
				'pengeluaran_id' => $insert_pengeluaran,
				'enum_pengeluaran_id' => $this->input->post('enum_pengeluaran_id'),
				'harga' => $this->input->post('harga'),
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			$insert_pengeluaran_detail = $this->pengeluaran_detail_model->insert($data_pengeluaran_detail);
			if ($value_simpan == 1) {
				if ($insert_pengeluaran_detail) {
					$this->session->set_flashdata('message', "Data pengeluaran Baru Berhasil Disimpan");
					redirect("pembukuan_pengeluaran");
				} else {
					$this->session->set_flashdata('message_error', "Data pengeluaran Baru Gagal Disimpan");
					redirect("pembukuan_pengeluaran");
				}
			}
			if ($value_tambah == 1) {
				if ($insert_pengeluaran_detail) {
					$this->session->set_flashdata('message', "Data pengeluaran Baru Berhasil Disimpan");
					redirect("pembukuan_pengeluaran/create_more/" . $insert_pengeluaran);
				} else {
					$this->session->set_flashdata('message_error', "Data pengeluaran Baru Gagal Disimpan");
					redirect("pembukuan_pengeluaran");
				}
			}
		} else {
			if ($this->data['is_can_create']) {
				$this->data['enum_pengeluaran'] = $this->enum_pengeluaran_model->getAllById();
				$this->data['content'] = 'admin/pembukuan_pengeluaran/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}
	public function create_more($id)
	{
		$this->form_validation->set_rules('pengeluaran_id', "pengeluaran_id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {

			$pengeluaran_id = $this->input->post('pengeluaran_id');
			$harga = $this->input->post('harga');
			$value_tambah = $this->input->post('value-btn-tambah');
			//value tambah
			if ($value_tambah == 1) {
				$pengeluaran_detail = array(
					'pengeluaran_id' => $pengeluaran_id,
					'enum_pengeluaran_id' => $this->input->post('enum_pengeluaran_id'),
					'harga' => $this->input->post('harga'),
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$insert_pengeluaran_detail = $this->pengeluaran_detail_model->insert($pengeluaran_detail);
				// ubah master pengeluaran
				$data_pengeluaran = $this->pengeluaran_model->getOneBy(['pengeluaran.id' => $pengeluaran_id]);
				//update harga
				$update_harga = $data_pengeluaran->total_harga_keseluruhan + $harga;
				// update jumlah_transaksi
				$data_update_pengeluaran = array(
					'total_harga_keseluruhan'			=> $update_harga,
					'updated_by' => $this->data['users']->id

				);
				$update_master_pengeluaran = $this->pengeluaran_model->update($data_update_pengeluaran, array("pengeluaran.id" => $pengeluaran_id));
				if ($update_master_pengeluaran) {
					$this->session->set_flashdata('message', "Data Pembukuan Pengeluaran Baru Berhasil Disimpan");
					redirect("pembukuan_pengeluaran/create_more/" . $pengeluaran_id);
				} else {
					$this->session->set_flashdata('message_error', "Data Pembukuan Pengeluaran Baru Gagal Disimpan");
					redirect("pembukuan_pengeluaran");
				}
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("pembukuan_pengeluaran/edit/" . $id);
			} else {
				$this->data['id'] = $id;
				$this->data['pengeluaran'] = $this->pengeluaran_model->getOneBy(array("pengeluaran.id" => $this->data['id']));
				$this->data['data_pengeluaran_detail'] = $this->pengeluaran_detail_model->getAllById(['pengeluaran_id' => $id]);
				$this->data['enum_pengeluaran'] = $this->enum_pengeluaran_model->getAllById();
				$this->data['content'] = 'admin/pembukuan_pengeluaran/create_more_v';
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function detail()
	{
		$this->data['id'] = $this->uri->segment(3);
		$this->data['pengeluaran'] = $this->pengeluaran_model->getOneBy(array("pengeluaran.id" => $this->data['id']));
		$this->data['data_pengeluaran_detail'] = $this->pengeluaran_detail_model->getAllById(['pengeluaran_id' => $this->data['id']]);
		$this->data['content'] = 'admin/pembukuan_pengeluaran/detail_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
		);

		$where['pengeluaran.enum'] = 0;
		$where['pengeluaran.is_deleted'] = 0;

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->pengeluaran_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);

		$searchColumn = $this->input->post('columns');
        $isSearchColumn = false;

        if(!empty($searchColumn[0]['search']['value'])){
            $value = $searchColumn[0]['search']['value'];
            $isSearchColumn = true;
            $where['pengeluaran.tanggal'] = $value;
        }

        if($isSearchColumn){
			$totalFiltered = $this->pengeluaran_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
			$totalData = $totalFiltered;
        }else{
        	$totalFiltered = $totalData;
        }

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->pengeluaran_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$detail_url = "";

				$detail_url = "<a href='" . base_url() . "pembukuan_pengeluaran/detail/" . $data->id . "' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";

				$nestedData['id'] = $start + $key + 1;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['total_harga_keseluruhan'] = $data->total_harga_keseluruhan;
				$nestedData['action'] = $detail_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function destroy()
	{
		$response_data = array();
		$response_data['status'] = false;
		$response_data['msg'] = "";
		$response_data['data'] = array();

		$id = $this->uri->segment(3);
		$is_deleted = $this->uri->segment(4);
		if (!empty($id)) {
			$this->load->model("pengeluaran_model");
			$data = array(
				'is_deleted' => ($is_deleted == 1) ? 0 : 1
			);
			$update = $this->pengeluaran_model->update($data, array("id" => $id));

			$response_data['data'] = $data;
			$response_data['status'] = true;
		} else {
			$response_data['msg'] = "ID Harus Diisi";
		}

		echo json_encode($response_data);
	}
}
