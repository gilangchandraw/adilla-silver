<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Pengeluaran_kantor extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('pengeluaran_kantor_model');
		$this->load->model('pengeluaran_kantor_detail_model');
		$this->load->model('kas_kantor_model');
		$this->load->model('enum_kantor_model');
	}
	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$this->data['content'] = 'admin/pengeluaran_kantor/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function create()
	{
		$this->form_validation->set_rules('tanggal', "tanggal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$tanggal = $this->input->post('tanggal');
			$harga = $this->input->post('harga');
			$enum_pengeluaran_kantor_id = $this->input->post('enum_pengeluaran_kantor_id');
			$keterangan = $this->input->post('keterangan');
			$harga = $this->input->post('harga');
			// update ke kantor
			$kantor = $this->kas_kantor_model->getOneBy();
			if ($enum_pengeluaran_kantor_id == 1) {
				$update_kas = $kantor->kas_sepuhan - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_sepuhan' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($enum_pengeluaran_kantor_id == 2) {
				$update_kas = $kantor->kas_kotak_cincin - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_kotak_cincin' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($enum_pengeluaran_kantor_id == 3) {
				$update_kas = $kantor->kas_patrian - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_patrian' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($enum_pengeluaran_kantor_id == 4) {
				$update_kas = $kantor->kas_setor_kantor - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_setor_kantor' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($enum_pengeluaran_kantor_id == 5) {
				$update_kas = $kantor->kas_bayar_barang - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_bayar_barang' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($enum_pengeluaran_kantor_id == 6) {
				$update_kas = $kantor->kas_baju_ciranjang - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_baju_ciranjang' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($enum_pengeluaran_kantor_id == 7) {
				$update_kas = $kantor->kas_baju_banjaran - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_baju_banjaran' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($enum_pengeluaran_kantor_id == 8) {
				$update_kas = $kantor->kas_krw_uda - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_krw_uda' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($enum_pengeluaran_kantor_id == 9) {
				$update_kas = $kantor->kas_kontrak_toko - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_kontrak_toko' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($enum_pengeluaran_kantor_id == 10) {
				$update_kas = $kantor->kas_kantor - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_kantor' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($enum_pengeluaran_kantor_id == 11) {
				$update_kas = $kantor->kas_mobil - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_mobil' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($enum_pengeluaran_kantor_id == 12) {
				$update_kas = $kantor->kas_dll - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_dll' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($enum_pengeluaran_kantor_id == 13) {
				$update_kas = $kantor->kas_nota - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_nota' => $update_kas,
					'total_kas' => $update_total,
				);
			}
			$update = $this->kas_kantor_model->update($data_kas_kantor, array("id" => $kantor->id));
			
			$data_pengeluaran_kantor = array(
				'tanggal' => $tanggal,
				'created_by' => $this->data['users']->id,
			);
			$insert_pengeluaran_kantor = $this->pengeluaran_kantor_model->insert($data_pengeluaran_kantor);
			// if ($enum_pengeluaran_kantor_id != 12) {
			// 	$data_pengeluaran_kantor_detail = array(
			// 		'pengeluaran_kantor_id' => $insert_pengeluaran_kantor,
			// 		'enum_kantor_id' => $enum_pengeluaran_kantor_id,
			// 		'harga' => $harga,
			// 		'created_by' => $this->data['users']->id,
			// 	);
			// } else {
			// 	$data_pengeluaran_kantor_detail = array(
			// 		'pengeluaran_kantor_id' => $insert_pengeluaran_kantor,
			// 		'enum_kantor_id' => $enum_pengeluaran_kantor_id,
			// 		'harga' => $harga,
			// 		'keterangan' => $keterangan,
			// 		'created_by' => $this->data['users']->id,
			// 	);
			// }
			$data_pengeluaran_kantor_detail = array(
				'pengeluaran_kantor_id' => $insert_pengeluaran_kantor,
				'enum_kantor_id' => $enum_pengeluaran_kantor_id,
				'harga' => $harga,
				'keterangan' => $keterangan,
				'created_by' => $this->data['users']->id,
			);
			$insert_pengeluaran_kantor_detail = $this->pengeluaran_kantor_detail_model->insert($data_pengeluaran_kantor_detail);
			
			if ($insert_pengeluaran_kantor_detail) {
				$this->session->set_flashdata('message', "Data pengeluaran_kantor Baru Berhasil Disimpan");
				redirect("pengeluaran_kantor/create_more/" . $insert_pengeluaran_kantor);
			} else {
				$this->session->set_flashdata('message_error', "Data pengeluaran_kantor Baru Gagal Disimpan");
				redirect("pengeluaran_kantor");
			}
		} else {
			if ($this->data['is_can_create']) {
				$this->data['enum_pengeluaran_kantor'] = $this->enum_kantor_model->getAllById();
				$this->data['content'] = 'admin/pengeluaran_kantor/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function create_more($id)
	{
		$this->form_validation->set_rules('id', "id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {

			$id = $this->input->post('id');
			$harga = $this->input->post('harga');
			$enum_pengeluaran_kantor_id = $this->input->post('enum_pengeluaran_kantor_id');
			$keterangan = $this->input->post('keterangan');
			$harga = $this->input->post('harga');
			// update ke kantor
			$kantor = $this->kas_kantor_model->getOneBy();
			$kantor = $this->kas_kantor_model->getOneBy();
			if ($enum_pengeluaran_kantor_id == 1) {
				$update_kas = $kantor->kas_sepuhan - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_sepuhan' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($enum_pengeluaran_kantor_id == 2) {
				$update_kas = $kantor->kas_kotak_cincin - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_kotak_cincin' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($enum_pengeluaran_kantor_id == 3) {
				$update_kas = $kantor->kas_patrian - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_patrian' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($enum_pengeluaran_kantor_id == 4) {
				$update_kas = $kantor->kas_setor_kantor - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_setor_kantor' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($enum_pengeluaran_kantor_id == 5) {
				$update_kas = $kantor->kas_bayar_barang - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_bayar_barang' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($enum_pengeluaran_kantor_id == 6) {
				$update_kas = $kantor->kas_baju_ciranjang - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_baju_ciranjang' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($enum_pengeluaran_kantor_id == 7) {
				$update_kas = $kantor->kas_baju_banjaran - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_baju_banjaran' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($enum_pengeluaran_kantor_id == 8) {
				$update_kas = $kantor->kas_krw_uda - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_krw_uda' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($enum_pengeluaran_kantor_id == 9) {
				$update_kas = $kantor->kas_kontrak_toko - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_kontrak_toko' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($enum_pengeluaran_kantor_id == 10) {
				$update_kas = $kantor->kas_kantor - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_kantor' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($enum_pengeluaran_kantor_id == 11) {
				$update_kas = $kantor->kas_mobil - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_mobil' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($enum_pengeluaran_kantor_id == 12) {
				$update_kas = $kantor->kas_dll - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_dll' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($enum_pengeluaran_kantor_id == 13) {
				$update_kas = $kantor->kas_nota - $harga;
				$update_total = $kantor->total_kas - $harga;
				$data_kas_kantor = array(
					'kas_nota' => $update_kas,
					'total_kas' => $update_total,
				);
			}
			$update = $this->kas_kantor_model->update($data_kas_kantor, array("id" => $kantor->id));
			
			// if ($enum_pengeluaran_kantor_id != 12) {
			// 	$data_pengeluaran_kantor_detail = array(
			// 		'pengeluaran_kantor_id' => $id,
			// 		'enum_kantor_id' => $enum_pengeluaran_kantor_id,
			// 		'harga' => $harga,
			// 		'created_by' => $this->data['users']->id,
			// 	);
			// } else {
			// 	$data_pengeluaran_kantor_detail = array(
			// 		'pengeluaran_kantor_id' => $id,
			// 		'enum_kantor_id' => $enum_pengeluaran_kantor_id,
			// 		'harga' => $harga,
			// 		'keterangan' => $keterangan,
			// 		'created_by' => $this->data['users']->id,
			// 	);
			// }
			$data_pengeluaran_kantor_detail = array(
				'pengeluaran_kantor_id' => $id,
				'enum_kantor_id' => $enum_pengeluaran_kantor_id,
				'harga' => $harga,
				'keterangan' => $keterangan,
				'created_by' => $this->data['users']->id,
			);
			$insert_pengeluaran_kantor_detail = $this->pengeluaran_kantor_detail_model->insert($data_pengeluaran_kantor_detail);
			if ($insert_pengeluaran_kantor_detail) {
				$this->session->set_flashdata('message', "Data pengeluaran_kantor Baru Berhasil Disimpan");
				redirect("pengeluaran_kantor/create_more/" . $id);
			} else {
				$this->session->set_flashdata('message_error', "Data pengeluaran_kantor Baru Gagal Disimpan");
				redirect("pengeluaran_kantor");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("pengeluaran_kantor/edit/" . $id);
			} else {
				$this->data['id'] = $id;
				$this->data['pengeluaran_kantor'] = $this->pengeluaran_kantor_model->getOneBy(array("pengeluaran_kantor.id" => $this->data['id']));
				$this->data['data_pengeluaran_kantor_detail'] = $this->pengeluaran_kantor_detail_model->getAllById(['pengeluaran_kantor_id' => $id]);
				$this->data['enum_pengeluaran_kantor'] = $this->enum_kantor_model->getAllById();
				$this->data['content'] = 'admin/pengeluaran_kantor/create_more_v';
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function detail()
	{
		$this->data['id'] = $this->uri->segment(3);
		$this->data['pengeluaran_kantor'] = $this->pengeluaran_kantor_model->getOneBy(array("pengeluaran_kantor.id" => $this->data['id']));
		$this->data['data_pengeluaran_kantor_detail'] = $this->pengeluaran_kantor_detail_model->getAllById(['pengeluaran_kantor_id' => $this->data['id']]);
		$this->data['content'] = 'admin/pengeluaran_kantor/detail_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
		);
		$where = [];
		
		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->pengeluaran_kantor_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);


		$searchColumn = $this->input->post('columns');
		$isSearchColumn = false;

		if (!empty($searchColumn[0]['search']['value'])) {
			$value = $searchColumn[0]['search']['value'];
			$isSearchColumn = true;
			$where['pengeluaran_kantor.tanggal'] = $value;
		}
		

		if ($isSearchColumn) {
			$totalFiltered = $this->pengeluaran_kantor_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
			$totalData = $totalFiltered;
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->pengeluaran_kantor_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$detail_url = "";
				$add_url = "";
				$add_url = "<a href='".base_url()."pengeluaran_kantor/create_more/".$data->id."' class='btn btn-sm btn-success' data-toggle='tooltip' title='Tambah Data' data-placement='bottom'><i class='fa fa-plus fa-w-20'></i></a>";            		
				$detail_url = "<a href='" . base_url() . "pengeluaran_kantor/detail/" . $data->id . "' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";
				$delete_url = "<a href='#' id='" . $data->id ."' class='btn btn-sm btn-danger delete' data-toggle='tooltip' title='Hapus Data' data-placement='bottom'><i class='fa fa-times fa-w-20'></i></a>";
				$nestedData['id'] = $start + $key + 1;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['action'] = $detail_url.' '.$add_url.' '.$delete_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	

	public function destroy()
	{
		$response_data = array();
		$response_data['status'] = false;
		$response_data['msg'] = "";
		$response_data['data'] = array();

		$id = $this->uri->segment(3);
		$status_audit = $this->uri->segment(4);
		if (!empty($id)) {
			$this->load->model("pengeluaran_kantor_model");
			$data = array(
				'status_audit' => ($status_audit == 1) ? 0 : 1
			);
			$update = $this->pengeluaran_kantor_model->update($data, array("id" => $id));

			$response_data['data'] = $data;
			$response_data['status'] = true;
		} else {
			$response_data['msg'] = "ID Harus Diisi";
		}

		echo json_encode($response_data);
	}

	public function edit()
	{
		$this->form_validation->set_rules('id', "id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$id = $this->input->post('id');
			$cek = $this->pengeluaran_kantor_detail_model->getOneBy(['pengeluaran_kantor_detail.id' => $id]);
			$enum_pengeluaran_kantor_id = $this->input->post('enum_pengeluaran_kantor_id');
			$harga = $this->input->post('harga');
			// 'enum_pengeluaran_kantor_id' => $this->input->post('enum_pengeluaran_kantor_id'),
			// $data = array(
			// 	'harga' => $this->input->post('harga'),
			// 	'updated_by' => $this->data['users']->id
			// );
			if ($enum_pengeluaran_kantor_id == 10) {
				$data = array(
					'enum_pengeluaran_kantor_id' => $enum_pengeluaran_kantor_id,
					'harga' => $harga,
					'keterangan' => $this->input->post('keterangan'),
					'updated_by' => $this->data['users']->id
				);
			} else {
				$data = array(
					'enum_pengeluaran_kantor_id' => $enum_pengeluaran_kantor_id,
					'harga' => $harga,
					'updated_by' => $this->data['users']->id
				);
			}
			$update = $this->pengeluaran_kantor_detail_model->update($data, array("pengeluaran_kantor_detail.id" => $id));

			$cek_detail = $this->pengeluaran_kantor_detail_model->getAllById(['pengeluaran_kantor_detail.pengeluaran_kantor_id' => $cek->pengeluaran_kantor_id]);
			if (!empty($cek_detail)) {
				$total_harga_keseluruhan = 0;
				foreach ($cek_detail as $key => $value) {
					$total_harga_keseluruhan += $value->harga;
				}
				$data_update = array(
					'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
					'updated_by' => $this->data['users']->id

				);
				$update = $this->pengeluaran_kantor_model->update($data_update, array("pengeluaran_kantor.id" => $cek->pengeluaran_kantor_id));
			}
			if ($update) {
				$this->session->set_flashdata('message', "Data pengeluaran_kantor Berhasil Diedit");
				redirect("pengeluaran_kantor");
			} else {
				$this->session->set_flashdata('message_error', "Data pengeluaran_kantor Gagal Diedit");
				redirect("pengeluaran_kantor");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("cabang/edit/" . $id);
			} else {
				if ($this->data['is_can_edit']) {
					$this->data['id'] = $this->uri->segment(3);
					$this->data['data'] = $this->pengeluaran_kantor_detail_model->getOneBy(array("pengeluaran_kantor_detail.id" => $this->data['id']));
					$this->data['enum_pengeluaran_kantor'] = $this->enum_kantor_model->getAllById();
					$this->data['content'] = 'admin/pengeluaran_kantor/edit_v';
				} else {
					$this->data['content']  = 'errors/html/restrict';
				}
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function delete(){
		$pengeluaran_kantor_detail = $this->uri->segment('3');
		
		
		$detail = $this->pengeluaran_kantor_detail_model->getOneBy(['pengeluaran_kantor_detail.id' => $pengeluaran_kantor_detail]);
		
		$kantor = $this->kas_kantor_model->getOneBy();
		if ($kantor) {
			if ($detail->enum_kantor_id == 1) {
				$update_kas = $kantor->kas_sepuhan + $detail->harga;
				$update_total = $kantor->total_kas + $detail->harga;
				$data_kas_kantor = array(
					'kas_sepuhan' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($detail->enum_kantor_id == 2) {
				$update_kas = $kantor->kas_kotak_cincin + $detail->harga;
				$update_total = $kantor->total_kas + $detail->harga;
				$data_kas_kantor = array(
					'kas_kotak_cincin' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($detail->enum_kantor_id == 3) {
				$update_kas = $kantor->kas_patrian + $detail->harga;
				$update_total = $kantor->total_kas + $detail->harga;
				$data_kas_kantor = array(
					'kas_patrian' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($detail->enum_kantor_id == 4) {
				$update_kas = $kantor->kas_setor_kantor + $detail->harga;
				$update_total = $kantor->total_kas + $detail->harga;
				$data_kas_kantor = array(
					'kas_setor_kantor' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($detail->enum_kantor_id == 5) {
				$update_kas = $kantor->kas_bayar_barang + $detail->harga;
				$update_total = $kantor->total_kas + $detail->harga;
				$data_kas_kantor = array(
					'kas_bayar_barang' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($detail->enum_kantor_id == 6) {
				$update_kas = $kantor->kas_baju_ciranjang + $detail->harga;
				$update_total = $kantor->total_kas + $detail->harga;
				$data_kas_kantor = array(
					'kas_baju_ciranjang' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($detail->enum_kantor_id == 7) {
				$update_kas = $kantor->kas_baju_banjaran + $detail->harga;
				$update_total = $kantor->total_kas + $detail->harga;
				$data_kas_kantor = array(
					'kas_baju_banjaran' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($detail->enum_kantor_id == 8) {
				$update_kas = $kantor->kas_krw_uda + $detail->harga;
				$update_total = $kantor->total_kas + $detail->harga;
				$data_kas_kantor = array(
					'kas_krw_uda' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($detail->enum_kantor_id == 9) {
				$update_kas = $kantor->kas_kontrak_toko + $detail->harga;
				$update_total = $kantor->total_kas + $detail->harga;
				$data_kas_kantor = array(
					'kas_kontrak_toko' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($detail->enum_kantor_id == 10) {
				$update_kas = $kantor->kas_kantor + $detail->harga;
				$update_total = $kantor->total_kas + $detail->harga;
				$data_kas_kantor = array(
					'kas_kantor' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($detail->enum_kantor_id == 11) {
				$update_kas = $kantor->kas_mobil + $detail->harga;
				$update_total = $kantor->total_kas + $detail->harga;
				$data_kas_kantor = array(
					'kas_mobil' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($detail->enum_kantor_id == 12) {
				$update_kas = $kantor->kas_dll + $detail->harga;
				$update_total = $kantor->total_kas + $detail->harga;
				$data_kas_kantor = array(
					'kas_dll' => $update_kas,
					'total_kas' => $update_total,
				);
			}elseif ($detail->enum_kantor_id == 13) {
				$update_kas = $kantor->kas_nota + $detail->harga;
				$update_total = $kantor->total_kas + $detail->harga;
				$data_kas_kantor = array(
					'kas_nota' => $update_kas,
					'total_kas' => $update_total,
				);
			}
			$update = $this->kas_kantor_model->update($data_kas_kantor, array("id" => $kantor->id));
		}

		// delete detail
		$delete = $this->pengeluaran_kantor_detail_model->delete(['pengeluaran_kantor_detail.id' => $pengeluaran_kantor_detail]);

		if ($update && $delete) {
			$this->session->set_flashdata('message', "Data Berhasil Dihapus");
			redirect("pengeluaran_kantor");
		} else {
			$this->session->set_flashdata('message_error', "Data Gagal Dihapus");
			redirect("pengeluaran_kantor");
		}

	}
	public function delete_master(){
		$id = $this->uri->segment('3');

		$cek_detail = $this->pengeluaran_kantor_detail_model->getAllById(['pengeluaran_kantor_id' => $id]);
		if (!empty($cek_detail)) {

			$kantor = $this->kas_kantor_model->getOneBy();
			foreach ($cek_detail as $key => $value) {
				if ($value->enum_kantor_id == 1) {
					$update_kas = $kantor->kas_sepuhan + $value->harga;
					$data_kas_kantor = array(
						'kas_sepuhan' => $update_kas,
					);
				}elseif ($value->enum_kantor_id == 2) {
					$update_kas = $kantor->kas_kotak_cincin + $value->harga;
					$data_kas_kantor = array(
						'kas_kotak_cincin' => $update_kas,
					);
				}elseif ($value->enum_kantor_id == 3) {
					$update_kas = $kantor->kas_patrian + $value->harga;
					$data_kas_kantor = array(
						'kas_patrian' => $update_kas,
					);
				}elseif ($value->enum_kantor_id == 4) {
					$update_kas = $kantor->kas_setor_kantor + $value->harga;
					$data_kas_kantor = array(
						'kas_setor_kantor' => $update_kas,
					);
				}elseif ($value->enum_kantor_id == 5) {
					$update_kas = $kantor->kas_bayar_barang + $value->harga;
					$data_kas_kantor = array(
						'kas_bayar_barang' => $update_kas,
					);
				}elseif ($value->enum_kantor_id == 6) {
					$update_kas = $kantor->kas_baju_ciranjang + $value->harga;
					$data_kas_kantor = array(
						'kas_baju_ciranjang' => $update_kas,
					);
				}elseif ($value->enum_kantor_id == 7) {
					$update_kas = $kantor->kas_baju_banjaran + $value->harga;
					$data_kas_kantor = array(
						'kas_baju_banjaran' => $update_kas,
					);
				}elseif ($value->enum_kantor_id == 8) {
					$update_kas = $kantor->kas_krw_uda + $value->harga;
					$data_kas_kantor = array(
						'kas_krw_uda' => $update_kas,
					);
				}elseif ($value->enum_kantor_id == 9) {
					$update_kas = $kantor->kas_kontrak_toko + $value->harga;
					$data_kas_kantor = array(
						'kas_kontrak_toko' => $update_kas,
					);
				}elseif ($value->enum_kantor_id == 10) {
					$update_kas = $kantor->kas_kantor + $value->harga;
					$data_kas_kantor = array(
						'kas_kantor' => $update_kas,
					);
				}elseif ($value->enum_kantor_id == 11) {
					$update_kas = $kantor->kas_mobil + $value->harga;
					$data_kas_kantor = array(
						'kas_mobil' => $update_kas,
					);
				}elseif ($value->enum_kantor_id == 12) {
					$update_kas = $kantor->kas_dll + $value->harga;
					$data_kas_kantor = array(
						'kas_dll' => $update_kas,
					);
				}
				$update = $this->kas_kantor_model->update($data_kas_kantor, array("id" => $kantor->id));
			}
			// delete detail
			$this->db->where('pengeluaran_kantor_detail.pengeluaran_kantor_id', $id);
	   		$this->db->delete('pengeluaran_kantor_detail'); 
		}

		$this->db->where('pengeluaran_kantor.id', $id);
	   	$this->db->delete('pengeluaran_kantor'); 

	   	$this->session->set_flashdata('message', "Data Berhasil Dihapus");
		redirect("pengeluaran_kantor");


	}
}
