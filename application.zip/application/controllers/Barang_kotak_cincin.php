<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Barang_kotak_cincin extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('barang_kotak_cincin_model');
	}

	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$this->data['content'] = 'admin/barang_kotak_cincin/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function create()
	{
		$this->form_validation->set_rules('kode_kotak_cincin', "kode_kotak_cincin Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$data = array(
				'kode_kotak_cincin' => $this->input->post('kode_kotak_cincin'),
				'nama_barang' => $this->input->post('nama_barang'),
				'stok' => $this->input->post('stok'),
				'harga' => $this->input->post('harga'),
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			$insert = $this->barang_kotak_cincin_model->insert($data);

			if ($insert) {
				$this->session->set_flashdata('message', "Data Barang Kotak Cincin Baru Berhasil Disimpan");
				redirect("barang_kotak_cincin");
			} else {
				$this->session->set_flashdata('message_error', "Data Barang Kotak Cincin Baru Gagal Disimpan");
				redirect("barang_kotak_cincin");
			}
		} else {
			if ($this->data['is_can_create']) {
				$this->data['content'] = 'admin/barang_kotak_cincin/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function edit()
	{
		$this->form_validation->set_rules('kode_kotak_cincin', "kode_kotak_cincin Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$id = $this->input->post('id');
			$data = array(
				'kode_kotak_cincin' => $this->input->post('kode_kotak_cincin'),
				'nama_barang' => $this->input->post('nama_barang'),
				'stok' => $this->input->post('stok'),
				'harga' => $this->input->post('harga'),
				'updated_by' => $this->data['users']->id
			);
			$update = $this->barang_kotak_cincin_model->update($data, array("id" => $this->input->post('id')));
			if ($update) {
				$this->session->set_flashdata('message', "Data Barang Kotak Cincin Berhasil Diedit");
				redirect("barang_kotak_cincin");
			} else {
				$this->session->set_flashdata('message_error', "Data Barang Kotak Cincin Gagal Diedit");
				redirect("barang_kotak_cincin");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("barang_kotak_cincin/edit/" . $id);
			} else {
				if ($this->data['is_can_edit']) {
					$this->data['id'] = $this->uri->segment(3);
					$this->data['barang_kotak_cincin'] = $this->barang_kotak_cincin_model->getOneBy(array("barang_kotak_cincin.id" => $this->data['id']));
					$this->data['content'] = 'admin/barang_kotak_cincin/edit_v';
				} else {
					$this->data['content']  = 'errors/html/restrict';
				}
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function detail()
	{
		$this->data['id'] = $this->uri->segment(3);
		$this->data['barang_kotak_cincin'] = $this->barang_kotak_cincin_model->getOneBy(array("barang_kotak_cincin.id" => $this->data['id']));

		$this->data['content'] = 'admin/barang_kotak_cincin/detail_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
			1 => 'barang_kotak_cincin.kode_kotak_cincin',
			2 => 'barang_kotak_cincin.nama_barang',
			3 => 'barang_kotak_cincin.stok',
			4 => 'barang_kotak_cincin.harga',
			5 => 'action'
		);

		$where = array();
		// if(!$this->data['is_superadmin']){
		// 	$where['barang_kotak_cincin.office_id'] = $this->data['users']->office_id;
		// }

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->barang_kotak_cincin_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		if (!empty($this->input->post('search')['value'])) {
			$search_value = $this->input->post('search')['value'];
			$search = array(
				"barang_kotak_cincin.kode_kotak_cincin" => $search_value,
				"barang_kotak_cincin.nama_barang" => $search_value,
				"barang_kotak_cincin.stok" => $search_value,
				"barang_kotak_cincin.harga" => $search_value,
			);
			$totalFiltered = $this->barang_kotak_cincin_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->barang_kotak_cincin_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$edit_url = "";
				$delete_url = "";
				if ($this->data['is_can_edit'] && $data->is_deleted == 0) {
					// $edit_url = "<a href='".base_url()."barang_kotak_cincin/edit/".$data->id."' class='btn btn-sm btn-info'>Ubah</a>";
					$edit_url = "<a href='" . base_url() . "barang_kotak_cincin/edit/" . $data->id . "' class='btn btn-sm btn-warning' data-toggle='tooltip' title='Edit Data' data-placement='bottom'><i class='fa fa-edit fa-w-20'></i></a>";
				}
				if ($this->data['is_can_edit']) {
					if ($data->is_deleted == 0) {
						$delete_url = "<a href='#' 
	        				url='" . base_url() . "barang_kotak_cincin/destroy/" . $data->id . "/" . $data->is_deleted . "' class='btn btn-sm btn-danger delete' data-toggle='tooltip' title='Non Aktifkan Data' data-placement='bottom'><i class='fa fa-times fa-w-20'></i></a>";
					} else {
						$delete_url = "<a href='#' 
	        				url='" . base_url() . "barang_kotak_cincin/destroy/" . $data->id . "/" . $data->is_deleted . "' class='btn btn-sm btn-success delete' data-toggle='tooltip' title='Aktifkan Data' data-placement='bottom'><i class='fa fa-check fa-w-20'></i></a>";
					}
				}

				$nestedData['id'] = $start + $key + 1;
				$nestedData['kode_kotak_cincin'] = $data->kode_kotak_cincin;
				$nestedData['nama_barang'] = $data->nama_barang;
				$nestedData['stok'] = number_format($data->stok);
				$nestedData['harga'] = 'Rp. ' . number_format($data->harga);
				$nestedData['action'] = $edit_url . " " . $delete_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function destroy()
	{
		$response_data = array();
		$response_data['status'] = false;
		$response_data['msg'] = "";
		$response_data['data'] = array();

		$id = $this->uri->segment(3);
		$is_deleted = $this->uri->segment(4);
		if (!empty($id)) {
			$this->load->model("barang_kotak_cincin_model");
			$data = array(
				'is_deleted' => ($is_deleted == 1) ? 0 : 1
			);
			$update = $this->barang_kotak_cincin_model->update($data, array("id" => $id));

			$response_data['data'] = $data;
			$response_data['status'] = true;
		} else {
			$response_data['msg'] = "ID Harus Diisi";
		}

		echo json_encode($response_data);
	}

	public function get_harga()
	{
		$barang_kotak_cincin_id = $this->input->get('barang_kotak_cincin_id');
		$where['id'] = $barang_kotak_cincin_id;
		$barang_kotak_cincin = $this->barang_kotak_cincin_model->getOneBy($where);
		if ($barang_kotak_cincin) {
			$data['status'] = true;
			$data['harga'] = $barang_kotak_cincin->harga;
		} else {
			$data['status'] = false;
			$data['harga'] = '';
		}
		echo json_encode($data);
	}
}
