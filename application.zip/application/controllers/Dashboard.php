<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH.'core/Admin_Controller.php';
class Dashboard extends Admin_Controller {
 	public function __construct()
	{
		parent::__construct();
		$this->load->model('cabang_model');
		$this->load->model('kas_kantor_model');
		$this->load->model('histori_stok_barang_model');
		$this->load->model('histori_kas_model');
		$this->load->model('penjualan_detail_model');
		$this->load->model('pengeluaran_kantor_detail_model');
		$this->load->model('pemasukan_detail_model');
		$this->load->model('uang_nota_model');
		$this->load->model('tukar_plus_detail_model');
		$this->load->model('barang_kembali_detail_model');

		 
	}
	public function index()
	{
		if ($this->data['users_groups']->id == 4) {

			$cabang = $this->cabang_model->getOneBy(['users_id' => $this->data['users']->id]);
			$this->data['kas'] = 'Rp. '.number_format($cabang->kas);
			$this->data['kas_sepuhan'] = 'Rp. '.number_format($cabang->kas_sepuhan);
			$this->data['stok_925'] = $cabang->stok_925.' gr';
			$this->data['stok_sp'] = $cabang->stok_sp.' gr';
			$this->data['stok_retur_bk_925'] = $cabang->stok_retur_bk_925.' gr';
			$this->data['stok_retur_pajang_925'] = $cabang->stok_retur_pajang_925.' gr';
			$this->data['stok_retur_bk_sp'] = $cabang->stok_retur_bk_sp.' gr';
			$this->data['stok_retur_pajang_sp'] = $cabang->stok_retur_pajang_sp.' gr';
			$this->data['tanggal_akhir_kontrak'] = $cabang->tanggal_akhir_kontrak;
			/*
				cek apakah libur atau tidak 
				kalo libur insert histori kas dan histori stok barang
			*/
			$tanggal = date('Y-m-d');
			$tanggal_kemarin = date('Y-m-d', strtotime('-1 days', strtotime($tanggal)));
			$jam = date('H');
			// HISTORI KAS
			if ($jam > 15) {
				// CEK CABANG SAMARANG
				$where_kas_smrg['histori_kas.cabang_id'] = 3;
				$where_kas_smrg['histori_kas.tanggal'] = $tanggal;
				$cek_kas_smrg = $this->histori_kas_model->getOneBy($where_kas_smrg);
				if($cek_kas_smrg == FALSE){
					$where_kas_smrg['histori_kas.tanggal'] = $tanggal_kemarin;
					$kas = $this->histori_kas_model->getOneBy($where_kas_smrg);
					$data_kas = array(
						'cabang_id' => $kas->cabang_id,
						'tanggal' => $tanggal,
						'kas_awal' => $kas->kas_awal,
						'kas_masuk' => 0,
						'kas_akhir' => $kas->kas_awal,
						'updated_by' => $kas->updated_by,
					);
					$insert = $this->histori_kas_model->insert($data_kas);
				}
				// CEK CABANG CIRANJANG
				$where_kas_crjg['histori_kas.cabang_id'] = 14;
				$where_kas_crjg['histori_kas.tanggal'] = $tanggal;
				$cek_kas_crjg = $this->histori_kas_model->getOneBy($where_kas_crjg);
				if($cek_kas_crjg == FALSE){
					$where_kas_crjg['histori_kas.tanggal'] = $tanggal_kemarin;
					$kas = $this->histori_kas_model->getOneBy($where_kas_crjg);
					$data_kas = array(
						'cabang_id' => $kas->cabang_id,
						'tanggal' => $tanggal,
						'kas_awal' => $kas->kas_awal,
						'kas_masuk' => 0,
						'kas_akhir' => $kas->kas_awal,
						'updated_by' => $kas->updated_by,
					);
					$insert = $this->histori_kas_model->insert($data_kas);
				}
			}
			// HISTORI STOK BARANG

			// $where_stok['histori_stok_barang.cabang_id'] = $cabang->id;
			// $where_stok['histori_stok_barang.tanggal'] = $tanggal;
			// $cek_stok = $this->histori_stok_barang_model->getOneBy($where_stok);
			// //tanggal kemarin
			// if ($jam > 13) {
			// 	if($cek_stok == FALSE){
			// 		$where_stok['histori_stok_barang.tanggal'] = $tanggal_kemarin;
			// 		$stok_barang = $this->histori_stok_barang_model->getOneBy($where_stok);
			// 		$data_stok = array(
			// 			'cabang_id' => $stok_barang->cabang_id,
			// 			'tanggal' => $tanggal,
			// 			'stok_925_awal' => $stok_barang->stok_925_awal,
			// 			'stok_925_penjualan' => $stok_barang->stok_925_penjualan,
			// 			'stok_925_kembali' => $stok_barang->stok_925_kembali,
			// 			'total_stok_925' => $stok_barang->total_stok_925,
			// 			'stok_925_akhir' => $stok_barang->stok_925_akhir,
			// 			'stok_sp_awal' => $stok_barang->stok_sp_awal,
			// 			'stok_sp_penjualan' => $stok_barang->stok_sp_penjualan,
			// 			'stok_sp_kembali' => $stok_barang->stok_sp_kembali,
			// 			'total_stok_sp' => $stok_barang->total_stok_sp,
			// 			'stok_sp_akhir' => $stok_barang->stok_sp_akhir,
			// 			'stok_925_reparasi' => $stok_barang->stok_925_reparasi,
			// 			'stok_sp_reparasi' => $stok_barang->stok_sp_reparasi,
			// 			'stok_925_retur' => $stok_barang->stok_925_retur,
			// 			'stok_sp_retur' => $stok_barang->stok_sp_retur,
			// 			'updated_by' => $stok_barang->updated_by,
			// 			'created_by' => $stok_barang->created_by,
			// 		);
			// 		$insert = $this->histori_stok_barang_model->insert($data_stok);
			// 	}
			// }
			// DATA UANG NOTA
			$uang_nota = $this->uang_nota_model->getOneBy(['cabang_id' => $cabang->id]);
			$this->data['uang_nota'] = $uang_nota->total;
		}
		if ($this->data['is_superadmin']) {
			// $pengeluaran = $this->pengeluaran_kantor_detail_model->sumHarga();
			// $pemasukan = $this->pemasukan_detail_model->sumHarga();
			// // perhitungan kas
			// $kantor = $this->kas_kantor_model->getOneBy();

			// $total_kas = $pemasukan->total_pemasukan - $pengeluaran->total_pengeluaran + $kantor->kas_nota;
			
			// if ($kantor->total_kas != $total_kas) {
				// $data_kas_update = array('total_kas' => $total_kas);
				// $update = $this->kas_kantor_model->update($data_kas_update, array("id" => 1));
			// 	$kantor = $this->kas_kantor_model->getOneBy();
			// }
			// PERHITUNGAN DASHBOARD BARU
			$kantor = $this->kas_kantor_model->getOneBy();
			$total = $kantor->kas_sepuhan + $kantor->kas_kotak_cincin + $kantor->kas_patrian + $kantor->kas_setor_kantor + $kantor->kas_bayar_barang + $kantor->kas_baju_ciranjang + $kantor->kas_baju_banjaran + $kantor->kas_krw_uda + $kantor->kas_kontrak_toko + $kantor->kas_kantor + $kantor->kas_mobil + $kantor->kas_dll + $kantor->kas_nota;
			$data_kas_update = array('total_kas' => $total);
			$update = $this->kas_kantor_model->update($data_kas_update, array("id" => 1));
			$kantor = $this->kas_kantor_model->getOneBy();

			// data kas kantor
			$this->data['kas_sepuhan'] = $kantor ? number_format($kantor->kas_sepuhan) : 0;
			$this->data['kas_kotak_cincin'] = $kantor ? number_format($kantor->kas_kotak_cincin) : 0;
			$this->data['kas_patrian'] = $kantor ? number_format($kantor->kas_patrian) : 0;
			$this->data['kas_setor_kantor'] = $kantor ? number_format($kantor->kas_setor_kantor) : 0;
			$this->data['kas_bayar_barang'] = $kantor ? number_format($kantor->kas_bayar_barang) : 0;
			$this->data['kas_baju_ciranjang'] = $kantor ? number_format($kantor->kas_baju_ciranjang) : 0;
			$this->data['kas_baju_banjaran'] = $kantor ? number_format($kantor->kas_baju_banjaran) : 0;
			$this->data['kas_krw_uda'] = $kantor ? number_format($kantor->kas_krw_uda) : 0;
			$this->data['kas_kontrak_toko'] = $kantor ? number_format($kantor->kas_kontrak_toko) : 0;
			$this->data['kas_kantor'] = $kantor ? number_format($kantor->kas_kantor) : 0;
			$this->data['kas_mobil'] = $kantor ? number_format($kantor->kas_mobil) : 0;
			$this->data['kas_dll'] = $kantor ? number_format($kantor->kas_dll) : 0;
			$this->data['total_kas'] = $kantor ? number_format($kantor->total_kas) : 0;
			$this->data['kas_nota'] = $kantor ? number_format($kantor->kas_nota) : 0;
		}
		$this->data['content'] = 'admin/dashboard';
		$this->load->view('admin/layouts/page',$this->data);
	}

	public function getDataHargaTransaksi(){
		$bulan = date('m');
		$tahun = date('Y');
		if ($this->input->get('bulan')) {
			$bulan = $this->input->get('bulan');
		}
		if ($this->input->get('tahun')) {
			$tahun = $this->input->get('tahun');
		}		
		// inisialisasi nama bulan
		if ($bulan == 1) {
			$nama_bulan = 'Januari';
		}elseif ($bulan == 2) {
			$nama_bulan = 'Februari';
		}elseif ($bulan == 3) {
			$nama_bulan = 'Maret';
		}elseif ($bulan == 4) {
			$nama_bulan = 'April';
		}elseif ($bulan == 5) {
			$nama_bulan = 'Mei';
		}elseif ($bulan == 6) {
			$nama_bulan = 'Juni';
		}elseif ($bulan == 7) {
			$nama_bulan = 'Juli';
		}elseif ($bulan == 8) {
			$nama_bulan = 'Agustus';
		}elseif ($bulan == 9) {
			$nama_bulan = 'September';
		}elseif ($bulan == 10) {
			$nama_bulan = 'Oktober';
		}elseif ($bulan == 11) {
			$nama_bulan = 'November';
		}elseif ($bulan == 12) {
			$nama_bulan = 'Desember';
		}
		
		$cabang = $this->cabang_model->getAllById(['cabang.is_deleted' => 0]);
		$data_cabang = [];
		$penjualan = [];
		$barang_kembali = [];
		foreach ($cabang as $key => $value) {
			$data_cabang[] = $value->nama_cabang;
			//penjualan
			$where_pj['MONTH(penjualan_detail.created_at)'] = $bulan;
			$where_pj['YEAR(penjualan_detail.created_at)'] = $tahun;
			$where_pj['penjualan_detail.cabang_penjualan'] = $value->id;
			$where_pj['penjualan_detail.enum_penjualan'] = 2;
			$total_pj = $this->penjualan_detail_model->sum($where_pj);
			// TUKAR PLUS
			$where_tukar['MONTH(tukar_plus_detail.created_at)'] = $bulan;
			$where_tukar['YEAR(tukar_plus_detail.created_at)'] = $tahun;
			$where_tukar['tukar_plus_detail.status'] = 'Tukar Plus';
			$where_tukar['tukar_plus_detail.cabang_tukar'] = $value->id;
			$where_tukar['tukar_plus_detail.enum_tukar'] = 2;
			$total_pj_tukar = $this->tukar_plus_detail_model->sum($where_tukar);
			$total_penjualan = $total_pj->harga + $total_pj_tukar->harga;
			$penjualan[] = (int)$total_penjualan;
			//BK
			$where_bk['MONTH(barang_kembali_detail.created_at)'] = $bulan;
			$where_bk['YEAR(barang_kembali_detail.created_at)'] = $tahun;
			$where_bk['barang_kembali_detail.cabang_id_asal'] = $value->id;
			$where_bk['barang_kembali_detail.enum'] = 1;
			$total_bk = $this->barang_kembali_detail_model->sum($where_bk);
			$barang_kembali[] = (int)$total_bk->harga;
		}
		// echo '<pre>',print_r($penjualan,1),'</pre>';
		// die();
		$response_data['status'] = true;
		$response_data['message'] = 'Berhasil Mengambil Data';
		$response_data['data_cabang'] = $data_cabang;
		$response_data['nama_bulan'] = $nama_bulan;
		$response_data['tahun'] = $tahun;
		$response_data['penjualan'] = $penjualan;
		$response_data['barang_kembali'] = $barang_kembali;
		
		echo json_encode($response_data);
	}

	public function getDataberatTransaksi(){
		$bulan = date('m');
		$tahun = date('Y');
		if ($this->input->get('bulan')) {
			$bulan = $this->input->get('bulan');
		}
		if ($this->input->get('tahun')) {
			$tahun = $this->input->get('tahun');
		}		
		// inisialisasi nama bulan
		if ($bulan == 1) {
			$nama_bulan = 'Januari';
		}elseif ($bulan == 2) {
			$nama_bulan = 'Februari';
		}elseif ($bulan == 3) {
			$nama_bulan = 'Maret';
		}elseif ($bulan == 4) {
			$nama_bulan = 'April';
		}elseif ($bulan == 5) {
			$nama_bulan = 'Mei';
		}elseif ($bulan == 6) {
			$nama_bulan = 'Juni';
		}elseif ($bulan == 7) {
			$nama_bulan = 'Juli';
		}elseif ($bulan == 8) {
			$nama_bulan = 'Agustus';
		}elseif ($bulan == 9) {
			$nama_bulan = 'September';
		}elseif ($bulan == 10) {
			$nama_bulan = 'Oktober';
		}elseif ($bulan == 11) {
			$nama_bulan = 'November';
		}elseif ($bulan == 12) {
			$nama_bulan = 'Desember';
		}
		
		$cabang = $this->cabang_model->getAllById(['cabang.is_deleted' => 0]);
		$data_cabang = [];
		$penjualan = [];
		$barang_kembali = [];
		foreach ($cabang as $key => $value) {
			$data_cabang[] = $value->nama_cabang;
			//penjualan
			$where_pj['MONTH(penjualan_detail.created_at)'] = $bulan;
			$where_pj['YEAR(penjualan_detail.created_at)'] = $tahun;
			$where_pj['penjualan_detail.cabang_penjualan'] = $value->id;
			$where_pj['penjualan_detail.enum_penjualan'] = 2;
			$total_pj = $this->penjualan_detail_model->sum($where_pj);
			// TUKAR PLUS
			$where_tukar['MONTH(tukar_plus_detail.created_at)'] = $bulan;
			$where_tukar['YEAR(tukar_plus_detail.created_at)'] = $tahun;
			$where_tukar['tukar_plus_detail.status'] = 'Tukar Plus';
			$where_tukar['tukar_plus_detail.cabang_tukar'] = $value->id;
			$where_tukar['tukar_plus_detail.enum_tukar'] = 2;
			$total_pj_tukar = $this->tukar_plus_detail_model->sum($where_tukar);
			$total_penjualan = $total_pj->berat + $total_pj_tukar->berat;
			$penjualan[] = (int)$total_penjualan;
			//BK
			$where_bk['MONTH(barang_kembali_detail.created_at)'] = $bulan;
			$where_bk['YEAR(barang_kembali_detail.created_at)'] = $tahun;
			$where_bk['barang_kembali_detail.cabang_id_asal'] = $value->id;
			$where_bk['barang_kembali_detail.enum'] = 1;
			$total_bk = $this->barang_kembali_detail_model->sum($where_bk);
			$barang_kembali[] = (int)$total_bk->berat;
		}
		// echo '<pre>',print_r($penjualan,1),'</pre>';
		// die();
		$response_data['status'] = true;
		$response_data['message'] = 'Berhasil Mengambil Data';
		$response_data['data_cabang'] = $data_cabang;
		$response_data['nama_bulan'] = $nama_bulan;
		$response_data['tahun'] = $tahun;
		$response_data['penjualan'] = $penjualan;
		$response_data['barang_kembali'] = $barang_kembali;
		
		echo json_encode($response_data);
	}

	public function getDataTotalHargaTransaksi(){
		$tahun = date('Y');
		if ($this->input->get('tahun')) {
			$tahun = $this->input->get('tahun');
		}		
		$array_month = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agt', 'Sep', 'Okt', 'Nov', 'Des'];

		// AMBIL DATA PJ SEMUA CABANG PERBULAN
		$penjualan = [];
		$barang_kembali = [];
		for ($i=1; $i <=12 ; $i++) { 
			//penjualan
			$where_pj['MONTH(penjualan_detail.created_at)'] = $i;
			$where_pj['YEAR(penjualan_detail.created_at)'] = $tahun;
			$where_pj['penjualan_detail.enum_penjualan'] = 2;
			$total_pj = $this->penjualan_detail_model->sum($where_pj);
			// TUKAR PLUS
			$where_tukar['MONTH(tukar_plus_detail.created_at)'] = $i;
			$where_tukar['YEAR(tukar_plus_detail.created_at)'] = $tahun;
			$where_tukar['tukar_plus_detail.status'] = 'Tukar Plus';
			$where_tukar['tukar_plus_detail.enum_tukar'] = 2;
			$total_pj_tukar = $this->tukar_plus_detail_model->sum($where_tukar);
			$total_penjualan = $total_pj->harga + $total_pj_tukar->harga;
			$penjualan[] = (int)$total_penjualan;
			// BK
			$where_bk['MONTH(barang_kembali_detail.created_at)'] = $i;
			$where_bk['YEAR(barang_kembali_detail.created_at)'] = $tahun;
			$where_bk['barang_kembali_detail.enum'] = 1;
			$total_bk = $this->barang_kembali_detail_model->sum($where_bk);
			$barang_kembali[] = (int)$total_bk->harga;
		}
		$response_data['status'] = true;
		$response_data['message'] = 'Berhasil Mengambil Data';
		$response_data['tahun'] = $tahun;
		$response_data['array_month'] = $array_month;
		$response_data['penjualan'] = $penjualan;
		$response_data['barang_kembali'] = $barang_kembali;
		
		echo json_encode($response_data);
	}

	public function getDataTotalberatTransaksi(){
        $tahun = date('Y');
        if ($this->input->get('tahun')) {
            $tahun = $this->input->get('tahun');
        }       
        $array_month = ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Agt', 'Sep', 'Okt', 'Nov', 'Des'];

        // AMBIL DATA PJ SEMUA CABANG PERBULAN
        $penjualan = [];
        $barang_kembali = [];
        for ($i=1; $i <=12 ; $i++) { 
            //penjualan
            $where_pj['MONTH(penjualan_detail.created_at)'] = $i;
            $where_pj['YEAR(penjualan_detail.created_at)'] = $tahun;
            $where_pj['penjualan_detail.enum_penjualan'] = 2;
            $total_pj = $this->penjualan_detail_model->sum($where_pj);
            // TUKAR PLUS
            $where_tukar['MONTH(tukar_plus_detail.created_at)'] = $i;
            $where_tukar['YEAR(tukar_plus_detail.created_at)'] = $tahun;
            $where_tukar['tukar_plus_detail.status'] = 'Tukar Plus';
            $where_tukar['tukar_plus_detail.enum_tukar'] = 2;
            $total_pj_tukar = $this->tukar_plus_detail_model->sum($where_tukar);
            $total_penjualan = $total_pj->berat + $total_pj_tukar->berat;
            $penjualan[] = (int)$total_penjualan;
            // BK
            $where_bk['MONTH(barang_kembali_detail.created_at)'] = $i;
            $where_bk['YEAR(barang_kembali_detail.created_at)'] = $tahun;
            $where_bk['barang_kembali_detail.enum'] = 1;
            $total_bk = $this->barang_kembali_detail_model->sum($where_bk);
            $barang_kembali[] = (int)$total_bk->berat;
        }
        $response_data['status'] = true;
        $response_data['message'] = 'Berhasil Mengambil Data';
        $response_data['tahun'] = $tahun;
        $response_data['array_month'] = $array_month;
        $response_data['penjualan'] = $penjualan;
        $response_data['barang_kembali'] = $barang_kembali;
        
        echo json_encode($response_data);
    }

	

}
