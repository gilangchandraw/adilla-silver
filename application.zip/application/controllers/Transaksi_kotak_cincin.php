<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Transaksi_kotak_cincin extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('transaksi_kotak_cincin_model');
		$this->load->model('transaksi_kotak_cincin_detail_model');
		$this->load->model('cabang_model');
		$this->load->model('barang_kotak_cincin_model');
		$this->load->model('stok_kotak_cincin_cabang_model');
	}

	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			if($this->data['users_groups']->id == 4){
				$where['cabang.users_id'] = $this->data['users']->id;
				$this->data['cabang'] = $this->cabang_model->getOneBy($where);
				$where_kc['transaksi_kotak_cincin.cabang_id'] = $this->data['cabang']->id;
			}
			$where_kc['transaksi_kotak_cincin.tanggal'] = date('Y-m-d');
			$cek_insert = $this->transaksi_kotak_cincin_model->getOneBy($where_kc);
			$this->data['cek_insert'] = $cek_insert ? 1 : 0;
			$this->data['data_cabang'] = $this->cabang_model->getAllById();
			$this->data['content'] = 'admin/transaksi_kotak_cincin/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function create()
	{
		$this->form_validation->set_rules('tanggal', "tanggal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
			$where['penjualan.cabang_id'] = $cabang->id;
			$data = array(
				'tanggal' => $this->input->post('tanggal'),
				'users_id' => $this->data['users']->id,
				'cabang_id' => $cabang->id,
				'total_harga_keseluruhan' => $this->input->post('harga'),
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			$insert = $this->transaksi_kotak_cincin_model->insert($data);
			
			$kotak_cincin_id = $this->input->post('kotak_cincin_id');
			$qty = $this->input->post('qty');
			$data_detail = array(
				'transaksi_kotak_cincin_id' => $insert,
				'kotak_cincin_id' => $kotak_cincin_id,
				'qty' => $qty,
				'harga' => $this->input->post('harga'),
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			$insert_detail = $this->transaksi_kotak_cincin_detail_model->insert($data_detail);

			// stok opname stok sepuhan
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
			$where_stok['cabang_id'] = $cabang->id;
			$where_stok['kotak_cincin_id'] = $kotak_cincin_id;
			$stok_sepuhan = $this->stok_kotak_cincin_cabang_model->getOneBy($where_stok);
			$data_update_stok = array('stok' => ($stok_sepuhan->stok - $qty));

			$update_stok = $this->stok_kotak_cincin_cabang_model->update($data_update_stok, $where_stok);

			if ($update_stok) {
				$this->session->set_flashdata('message', "Data Transaksi Kotak Cintin Baru Berhasil Disimpan");
				redirect("transaksi_kotak_cincin/create_more/".$insert);
			} else {
				$this->session->set_flashdata('message_error', "Data Transaksi Kotak Cintin Baru Gagal Disimpan");
				redirect("transaksi_kotak_cincin");
			}
		} else {
			if ($this->data['is_can_create']) {
				$this->data['barang_kotak_cincin'] = $this->barang_kotak_cincin_model->getAllById();
				$this->data['content'] = 'admin/transaksi_kotak_cincin/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function create_more($id)
	{
		$this->form_validation->set_rules('id', "id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {

			$id = $this->input->post('id');
			$kotak_cincin_id = $this->input->post('kotak_cincin_id');
			$qty = $this->input->post('qty');
			$data_detail = array(
				'transaksi_kotak_cincin_id' => $id,
				'kotak_cincin_id' => $kotak_cincin_id,
				'qty' => $qty,
				'harga' => $this->input->post('harga'),
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			$insert_detail = $this->transaksi_kotak_cincin_detail_model->insert($data_detail);

			$count = $this->transaksi_kotak_cincin_detail_model->getAllById(['transaksi_kotak_cincin_id' => $id]);
			if (!empty($count)) {
				$total_harga_keseluruhan = 0;
				foreach ($count as $key => $value) {
					$total_harga_keseluruhan += $value->harga;
				}
				$data_update = array(
					'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
					'updated_by' => $this->data['users']->id

				); 
				$update = $this->transaksi_kotak_cincin_model->update($data_update,array("id" => $id));
			}

			// stok opname stok sepuhan
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
			$where_stok['cabang_id'] = $cabang->id;
			$where_stok['kotak_cincin_id'] = $kotak_cincin_id;
			$stok_sepuhan = $this->stok_kotak_cincin_cabang_model->getOneBy($where_stok);
			$data_update_stok = array('stok' => ($stok_sepuhan->stok - $qty));

			$update_stok = $this->stok_kotak_cincin_cabang_model->update($data_update_stok, $where_stok);

			if ($insert_detail) {
				$this->session->set_flashdata('message', "Data Transaksi Kotak Cintin Baru Berhasil Disimpan");
				redirect("transaksi_kotak_cincin/create_more/".$id);
			} else {
				$this->session->set_flashdata('message_error', "Data Transaksi Kotak Cintin Baru Gagal Disimpan");
				redirect("transaksi_kotak_cincin");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("transaksi_kotak_cincin");
			} else {
				$this->data['id'] = $id;
				$this->data['kc'] = $this->transaksi_kotak_cincin_model->getOneBy(array("id" => $this->data['id']));
				$this->data['data_kc'] = $this->transaksi_kotak_cincin_detail_model->getAllById(['transaksi_kotak_cincin_id' => $id]);
				$this->data['barang_kotak_cincin'] = $this->barang_kotak_cincin_model->getAllById();
				$this->data['content'] = 'admin/transaksi_kotak_cincin/create_more_v';
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function edit()
	{
		$this->form_validation->set_rules('id', "id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$id = $this->input->post('id');
			$transaksi_kotak_cincin_id = $this->input->post('transaksi_kotak_cincin_id');

			$data = array(
				'kotak_cincin_id' => $this->input->post('kotak_cincin_id'),
				'qty' => $this->input->post('qty'),
				'harga' => $this->input->post('harga'),
				'updated_by' => $this->data['users']->id
			);
			$update = $this->transaksi_kotak_cincin_detail_model->update($data, array("id" => $id));
			$count = $this->transaksi_kotak_cincin_detail_model->getAllById(['transaksi_kotak_cincin_id' => $transaksi_kotak_cincin_id]);
			if (!empty($count)) {
				$total_harga_keseluruhan = 0;
				foreach ($count as $key => $value) {
					$total_harga_keseluruhan += $value->harga;
				}
				$data_update = array(
					'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
					'updated_by' => $this->data['users']->id

				); 
				$update = $this->transaksi_kotak_cincin_model->update($data_update,array("id" => $transaksi_kotak_cincin_id));
			}

			if ($update) {
				$this->session->set_flashdata('message', "Data Kotak Cincin Berhasil Diedit");
				redirect("transaksi_kotak_cincin/detail/".$transaksi_kotak_cincin_id);
			} else {
				$this->session->set_flashdata('message_error', "Data Kotak Cincin Gagal Diedit");
				redirect("transaksi_kotak_cincin");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("transaksi_kotak_cincin/edit/" . $id);
			} else {
				if ($this->data['is_can_edit']) {
					$this->data['id'] = $this->uri->segment(3);
					$this->data['barang_kotak_cincin'] = $this->barang_kotak_cincin_model->getAllById();
					$this->data['kc_detail'] = $this->transaksi_kotak_cincin_detail_model->getOneBy(array("transaksi_kotak_cincin_detail.id" => $this->data['id']));
					$this->data['content'] = 'admin/transaksi_kotak_cincin/edit_v';
				} else {
					$this->data['content']  = 'errors/html/restrict';
				}
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function detail()
	{
		$this->data['id'] = $this->uri->segment(3);
		$this->data['data_kc'] = $this->transaksi_kotak_cincin_model->getOneBy(array("transaksi_kotak_cincin.id" => $this->data['id']));
		$this->data['data_kc_detail'] = $this->transaksi_kotak_cincin_detail_model->getAllById(['transaksi_kotak_cincin_id' => $this->data['id']]);
		$this->data['cek_insert'] = $this->data['data_kc']->tanggal == date('Y-m-d') ? 1 : 0;
		$this->data['content'] = 'admin/transaksi_kotak_cincin/detail_v';
		$this->load->view('admin/layouts/page', $this->data);

	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
			1 => 'transaksi_kotak_cincin.tanggal',
			2 => 'transaksi_kotak_cincin.nama_cabang',
			3 => 'transaksi_kotak_cincin.total_harga_keseluruhan',
			4 => 'action'
		);

		$where = array();
		if(!$this->data['is_superadmin']){
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
			$where['transaksi_kotak_cincin.cabang_id'] = $cabang->id;
		}
		

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->transaksi_kotak_cincin_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		$searchColumn = $this->input->post('columns');
        $isSearchColumn = false;

        if(!empty($searchColumn[0]['search']['value'])){
            $value = $searchColumn[0]['search']['value'];
            $isSearchColumn = true;
            $where['transaksi_kotak_cincin.tanggal'] = $value;
        }

        if($isSearchColumn){
			$totalFiltered = $this->transaksi_kotak_cincin_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
			$totalData = $totalFiltered;
        }else{
        	$totalFiltered = $totalData;
        }

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->transaksi_kotak_cincin_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$detail_url = "";
				$add_url = "";

				$detail_url = "<a href='" . base_url() . "transaksi_kotak_cincin/detail/" . $data->id . "' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";
				if ($data->tanggal == date('Y-m-d')) {
					$add_url = "<a href='".base_url()."transaksi_kotak_cincin/create_more/".$data->id."' class='btn btn-sm btn-success' data-toggle='tooltip' title='Tambah Data' data-placement='bottom'><i class='fa fa-plus fa-w-20'></i></a>";
				}
				

				$nestedData['id'] = $start + $key + 1;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['total_harga_keseluruhan'] = number_format($data->total_harga_keseluruhan);
				$nestedData['action'] = $detail_url.' '.$add_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function dataListAdmin()
	{
		$columns = array(
			0 => 'id',
			1 => 'transaksi_kotak_cincin.tanggal',
			2 => 'transaksi_kotak_cincin.nama_cabang',
			3 => 'transaksi_kotak_cincin.total_harga_keseluruhan',
			4 => 'action'
		);

		$where = array();
		
		

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->transaksi_kotak_cincin_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		$searchColumn = $this->input->post('columns');
        $isSearchColumn = false;

        if(!empty($searchColumn[0]['search']['value'])){
            $value = $searchColumn[0]['search']['value'];
            $isSearchColumn = true;
            $where['transaksi_kotak_cincin.tanggal'] = $value;
        }
        if(!empty($searchColumn[1]['search']['value'])){
            $value = $searchColumn[1]['search']['value'];
            $isSearchColumn = true;
            $where['transaksi_kotak_cincin.cabang_id'] = $value;
        }
        if(!empty($searchColumn[2]['search']['value'])){
            $value = $searchColumn[2]['search']['value'];
            $isSearchColumn = true;
            if ($value == 2) {
            	$value = 0;
            }
            $where['transaksi_kotak_cincin.status_audit'] = $value;
        }

        if($isSearchColumn){
			$totalFiltered = $this->transaksi_kotak_cincin_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
			$totalData = $totalFiltered;
        }else{
        	$totalFiltered = $totalData;
        }

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->transaksi_kotak_cincin_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$detail_url = "";
				$audit_url = "";
				$add_url = "";

				$detail_url = "<a href='" . base_url() . "transaksi_kotak_cincin/detail/" . $data->id . "' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";
				if ($this->data['users_groups']->id == 4) {
					$add_url = "<a href='".base_url()."transaksi_kotak_cincin/create_more/".$data->id."' class='btn btn-sm btn-success' data-toggle='tooltip' title='Tambah Data' data-placement='bottom'><i class='fa fa-plus fa-w-20'></i></a>";
				}
				if ($data->status_audit == 0 && $this->data['users_groups']->id == 3) {
            		$audit_url = "<a href='#' 
	        				url='" . base_url() . "transaksi_kotak_cincin/destroy/" . $data->id . "/" . $data->status_audit . "' class='btn btn-sm btn-danger delete' data-toggle='tooltip' title='Data telah Diaudit' data-placement='bottom'><i class='fa fa-check-circle fa-w-20'></i></a>";
            	}
				

				$nestedData['id'] = $start + $key + 1;
				$nestedData['cabang'] = $data->nama_cabang;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['total_harga_keseluruhan'] = number_format($data->total_harga_keseluruhan);
				$nestedData['status_audit'] = $data->status_audit == 0 ? '<b style="color:red;">Belum</b>' : '<b style="color:green;">Selesai</b>';
				$nestedData['action'] = $detail_url.' '.$add_url.' '.$audit_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function destroy()
	{
		$response_data = array();
		$response_data['status'] = false;
		$response_data['msg'] = "";
		$response_data['data'] = array();

		$id = $this->uri->segment(3);
		$status_audit = $this->uri->segment(4);
		if (!empty($id)) {
			$this->load->model("transaksi_kotak_cincin_model");
			$data = array(
				'status_audit' => ($status_audit == 1) ? 0 : 1
			);
			$update = $this->transaksi_kotak_cincin_model->update($data, array("id" => $id));

			$response_data['data'] = $data;
			$response_data['status'] = true;
		} else {
			$response_data['msg'] = "ID Harus Diisi";
		}

		echo json_encode($response_data);
	}

	public function gettransaksi_kotak_cincin()
	{
		$where = array();
		$office_id = $this->input->get('office_id');

		if ($office_id != '') {
			$where['transaksi_kotak_cincin.office_id'] = $office_id;
		}

		$transaksi_kotak_cincin = $this->transaksi_kotak_cincin_model->getAllById($where);

		$data = array();
		if ($transaksi_kotak_cincin) {
			$data['status'] = true;
			$data['data'] = $transaksi_kotak_cincin;
			$data['message'] = "Success get data transaksi_kotak_cincin.";
		} else {
			$data['status'] = false;
			$data['data'] = [];
			$data['message'] = "Failed get data transaksi_kotak_cincin.";
		}

		echo json_encode($data);
	}

	public function delete(){
		$transaksi_kotak_cincin_detail = $this->uri->segment('3');
		
		$get_transaksi = $this->transaksi_kotak_cincin_detail_model->getOneBy(['transaksi_kotak_cincin_detail.id' => $transaksi_kotak_cincin_detail]);
		$get_transaksi_master = $this->transaksi_kotak_cincin_model->getOneBy(['transaksi_kotak_cincin.id' => $get_transaksi->transaksi_kotak_cincin_id]);
		// delete detail
		$this->db->where('transaksi_kotak_cincin_detail.id', $transaksi_kotak_cincin_detail);
   		$this->db->delete('transaksi_kotak_cincin_detail'); 
   		// kembalikan stok
   		$cabang_id = $get_transaksi_master->cabang_id;
   		if (!$this->data['is_superadmin']) {
   			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
   			$cabang_id = $cabang->id;
   		}
   		$where_stok['cabang_id'] = $cabang_id;
		$where_stok['kotak_cincin_id'] = $get_transaksi->kotak_cincin_id;
   		$get_stok = $this->stok_kotak_cincin_cabang_model->getOneBy($where_stok);
   		$data_update_stok = ['stok' => ($get_stok->stok + $get_transaksi->qty)];
   		
   		//update stok
		$update = $this->stok_kotak_cincin_cabang_model->update($data_update_stok, $where_stok);
		//update master
		$cek_detail = $this->transaksi_kotak_cincin_detail_model->getAllById(['transaksi_kotak_cincin_detail.transaksi_kotak_cincin_id' => $get_transaksi->transaksi_kotak_cincin_id]);
		if (!empty($cek_detail)) {
			$total_harga_keseluruhan = 0;
			foreach ($cek_detail as $key => $value) {
				$total_harga_keseluruhan += $value->harga;
			}
		}else{
			$total_harga_keseluruhan = 0;

		}
		$data_update_master = array('total_harga_keseluruhan' => $total_harga_keseluruhan);

		$update = $this->transaksi_kotak_cincin_model->update($data_update_master, ['transaksi_kotak_cincin.id' => $get_transaksi->transaksi_kotak_cincin_id]);


		if ($update) {
			$this->session->set_flashdata('message', "Data Berhasil Dihapus");
			redirect("transaksi_kotak_cincin/detail/".$get_transaksi->transaksi_kotak_cincin_id);
		} else {
			$this->session->set_flashdata('message_error', "Data Gagal Dihapus");
			redirect("transaksi_kotak_cincin/detail/".$get_transaksi->transaksi_kotak_cincin_id);
		}

	}
}
