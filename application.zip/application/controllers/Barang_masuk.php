<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Barang_masuk extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('barang_masuk_model');
		$this->load->model('barang_model');
		$this->load->model('barang_sepuhan_model');
		$this->load->model('barang_kotak_cincin_model');
		$this->load->model('supplier_model');
	}

	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$this->data['content'] = 'admin/barang_masuk/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function create()
	{
		$this->form_validation->set_rules('tanggal', "tanggal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$status_sk = $this->input->post('status_sk');
			$supplier_id = $this->input->post('nama_supplier');
			$barang_id = $this->input->post('barang_id');
			$barang_sepuhan_id = $this->input->post('barang_sepuhan_id');
			$barang_kotak_cincin_id = $this->input->post('barang_kotak_cincin_id');
			$jumlah_barang = $this->input->post('jumlah_barang');
			if ($status_sk == 1) {
				$data = array(
					'tanggal' => $this->input->post('tanggal'),
					'barang_id' => $barang_id,
					'supplier_id' => $supplier_id,
					'jumlah_barang' => $this->input->post('jumlah_barang'),
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$add_stok_perhiasan = $this->barang_model->getOneBy(['id' => $barang_id]);
				// stok opname kantor
				$stok_perhiasan = $add_stok_perhiasan->stok + $jumlah_barang;
				$data_stok_kantor = array('stok' => $stok_perhiasan);
				$update_kantor = $this->barang_model->update($data_stok_kantor, ['barang.id' => $barang_id]);
			} elseif ($status_sk == 2) {
				$data = array(
					'tanggal' => $this->input->post('tanggal'),
					'barang_sepuhan_id' => $barang_sepuhan_id,
					'supplier_id' => $supplier_id,
					'jumlah_barang' => $this->input->post('jumlah_barang'),
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$add_stok_sepuhan = $this->barang_sepuhan_model->getOneBy(['id' => $barang_sepuhan_id]);
				// stok opname kantor
				$stok_perhiasan = $add_stok_sepuhan->stok + $jumlah_barang;
				$data_stok_kantor = array('stok' => $stok_perhiasan);
				$update_kantor = $this->barang_sepuhan_model->update($data_stok_kantor, ['barang_sepuhan.id' => $barang_sepuhan_id]);
			} elseif ($status_sk == 3) {
				$data = array(
					'tanggal' => $this->input->post('tanggal'),
					'barang_kotak_cincin_id' => $barang_kotak_cincin_id,
					'supplier_id' => $supplier_id,
					'jumlah_barang' => $this->input->post('jumlah_barang'),
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$add_stok_kotak_cincin = $this->barang_kotak_cincin_model->getOneBy(['id' => $barang_kotak_cincin_id]);
				// stok opname kantor
				$stok_perhiasan = $add_stok_kotak_cincin->stok + $jumlah_barang;
				$data_stok_kantor = array('stok' => $stok_perhiasan);
				$update_kantor = $this->barang_kotak_cincin_model->update($data_stok_kantor, ['barang_kotak_cincin.id' => $barang_kotak_cincin_id]);
			}
			$insert = $this->barang_masuk_model->insert($data);
			if ($insert) {
				$this->session->set_flashdata('message', "Data Barang Masuk Baru Berhasil Disimpan");
				redirect("barang_masuk");
			} else {
				$this->session->set_flashdata('message_error', "Data Barang Masuk Baru Gagal Disimpan");
				redirect("barang_masuk");
			}
		} else {
			if ($this->data['is_can_create']) {
				$this->data['barang'] = $this->barang_model->getAllById();
				$this->data['supplier'] = $this->supplier_model->getAllById();
				$this->data['barang_sepuhan'] = $this->barang_sepuhan_model->getAllById();
				$this->data['barang_kotak_cincin'] = $this->barang_kotak_cincin_model->getAllById();
				$this->data['content'] = 'admin/barang_masuk/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function edit()
	{
		$this->form_validation->set_rules('tanggal', "tanggal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$id = $this->input->post('id');
			$data = array(
				'tanggal' => $this->input->post('tanggal'),
				'kode_barang' => $this->input->post('kode_barang'),
				'nama_barang' => $this->input->post('nama_barang'),
				'stok' => $this->input->post('stok'),
				'updated_by' => $this->data['users']->id
			);
			$update = $this->barang_masuk_model->update($data, array("id" => $this->input->post('id')));
			if ($update) {
				$this->session->set_flashdata('message', "Data Barang Masuk Berhasil Diedit");
				redirect("barang_masuk");
			} else {
				$this->session->set_flashdata('message_error', "Data Barang Masuk Gagal Diedit");
				redirect("barang_masuk");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("barang_masuk/edit/" . $id);
			} else {
				if ($this->data['is_can_edit']) {
					$this->data['id'] = $this->uri->segment(3);
					$this->data['barang_masuk'] = $this->barang_masuk_model->getOneBy(array("barang_masuk.id" => $this->data['id']));
					$this->data['content'] = 'admin/barang_masuk/edit_v';
				} else {
					$this->data['content']  = 'errors/html/restrict';
				}
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function detail()
	{
		$this->data['id'] = $this->uri->segment(3);
		$this->data['barang_masuk'] = $this->barang_masuk_model->getOneBy(array("barang_masuk.id" => $this->data['id']));

		$this->data['content'] = 'admin/barang_masuk/detail_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
			1 => 'barang_masuk.tanggal',
			2 => 'barang_masuk.supplier_id',
			3 => 'barang_masuk.nama_barang',
			4 => 'barang_masuk.jumlah_barang',
			5 => 'action'
		);

		$where = array();
		// if(!$this->data['is_superadmin']){
		// 	$where['barang_masuk.office_id'] = $this->data['users']->office_id;
		// }
		$where['barang_masuk.is_deleted'] = 0;

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->barang_masuk_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		if (!empty($this->input->post('search')['value'])) {
			$search_value = $this->input->post('search')['value'];
			$search = array(
				"barang_masuk.tanggal" => $search_value,
				"barang_masuk.supplier_id" => $search_value,
				"barang_masuk.nama_barang" => $search_value,
				"barang_masuk.jumlah_barang" => $search_value,
			);
			$totalFiltered = $this->barang_masuk_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->barang_masuk_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$edit_url = "";
				$delete_url = "";
				//	if ($this->data['is_can_edit'] && $data->is_deleted == 0) {
				// $edit_url = "<a href='".base_url()."barang_masuk/edit/".$data->id."' class='btn btn-sm btn-info'>Ubah</a>";
				//		$edit_url = "<a href='" . base_url() . "barang_masuk/edit/" . $data->id . "' class='btn btn-sm btn-warning' data-toggle='tooltip' title='Edit Data' data-placement='bottom'><i class='fa fa-edit fa-w-20'></i></a>"	}
				if ($this->data['is_can_edit']) {
					if ($data->is_deleted == 0) {
						$delete_url = "<a href='#' 
	        				url='" . base_url() . "barang_masuk/destroy/" . $data->id . "/" . $data->is_deleted . "' class='btn btn-sm btn-danger delete' data-toggle='tooltip' title='Non Aktifkan Data' data-placement='bottom'><i class='fa fa-times fa-w-20'></i></a>";
					} else {
						$delete_url = "<a href='#' 
	        				url='" . base_url() . "barang_masuk/destroy/" . $data->id . "/" . $data->is_deleted . "' class='btn btn-sm btn-success delete' data-toggle='tooltip' title='Aktifkan Data' data-placement='bottom'><i class='fa fa-check fa-w-20'></i></a>";
					}
				}

				$nestedData['id'] = $start + $key + 1;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['supplier_id'] = $data->supplier_id;
				if ($data->barang_id == NULL) {
					if ($data->barang_sepuhan_id == NULL) {
						$nestedData['nama_barang'] = $data->nama_barang_kotak_cincin;						
					} else {
						$nestedData['nama_barang'] = $data->nama_barang_sepuhan;						
					}					
				} elseif ($data->barang_sepuhan_id == NULL) {
					if ($data->barang_id == NULL) {
						$nestedData['nama_barang'] = $data->nama_barang_kotak_cincin;						
					} else {
						$nestedData['nama_barang'] = $data->nama_barang_perhiasan;						
					}
				} elseif ($data->barang_kotak_cincin_id == NULL) {
					if ($data->barang_id == NULL) {
						$nestedData['nama_barang'] = $data->nama_barang_sepuhan;						
					} else {
						$nestedData['nama_barang'] = $data->nama_barang_sepuhan;						
					}
				}
				$nestedData['jumlah_barang'] = $data->jumlah_barang;
				$nestedData['action'] = $edit_url . " " . $delete_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function destroy()
	{
		$response_data = array();
		$response_data['status'] = false;
		$response_data['msg'] = "";
		$response_data['data'] = array();

		$id = $this->uri->segment(3);
		$is_deleted = $this->uri->segment(4);
		if (!empty($id)) {
			$data_barang = $this->barang_masuk_model->getOneBy(['barang_masuk.id' => $id]);
			if ($data_barang->barang_id != NULL) {
				$get_stok = $this->barang_model->getOneBy(['id' => $data_barang->barang_id]);
				// stok opname kantor
				$stok_kantor = $get_stok->stok - $data_barang->jumlah_barang;
				$data_stok_kantor = array('stok' => $stok_kantor);

				$update_kantor = $this->barang_model->update($data_stok_kantor, ['barang.id' => $data_barang->barang_id]);
			} elseif ($data_barang->barang_sepuhan_id != NULL) {
				$get_stok_sepuhan = $this->barang_sepuhan_model->getOneBy(['id' => $data_barang->barang_sepuhan_id]);
				// stok opname kantor
				$stok_kantor = $get_stok_sepuhan->stok - $data_barang->jumlah_barang;
				$data_stok_kantor = array('stok' => $stok_kantor);

				$update_kantor = $this->barang_sepuhan_model->update($data_stok_kantor, ['barang_sepuhan.id' => $data_barang->barang_sepuhan_id]);
			} elseif ($data_barang->barang_kotak_cincin_id != NULL) {
				$get_stok_kotak_cincin = $this->barang_kotak_cincin_model->getOneBy(['id' => $data_barang->barang_kotak_cincin_id]);
				// stok opname kantor
				$stok_kantor = $get_stok_kotak_cincin->stok - $data_barang->jumlah_barang;
				$data_stok_kantor = array('stok' => $stok_kantor);

				$update_kantor = $this->barang_kotak_cincin_model->update($data_stok_kantor, ['barang_kotak_cincin.id' => $data_barang->barang_kotak_cincin_id]);
			}

			$data = array(
				'is_deleted' => ($is_deleted == 1) ? 0 : 1
			);
			$update = $this->barang_masuk_model->update($data, array("id" => $id));

			$response_data['data'] = $data;
			$response_data['status'] = true;
		} else {
			$response_data['msg'] = "ID Harus Diisi";
		}

		echo json_encode($response_data);
	}

	public function getbarang_masuk()
	{
		$where = array();
		$office_id = $this->input->get('office_id');

		if ($office_id != '') {
			$where['barang_masuk.office_id'] = $office_id;
		}

		$barang_masuk = $this->barang_masuk_model->getAllById($where);

		$data = array();
		if ($barang_masuk) {
			$data['status'] = true;
			$data['data'] = $barang_masuk;
			$data['message'] = "Success get data barang_masuk.";
		} else {
			$data['status'] = false;
			$data['data'] = [];
			$data['message'] = "Failed get data barang_masuk.";
		}

		echo json_encode($data);
	}
}
