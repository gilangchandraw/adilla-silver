<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Pembukuan_tukar_plus extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('tukar_plus_model');
		$this->load->model('tukar_plus_detail_model');
		$this->load->model('cabang_model');
		$this->load->model('data_karyawan_model');
		$this->load->model('barang_model');
		$this->load->model('enum_transaksi_barang_model');
		$this->load->model('barang_kembali_detail_model');
		$this->load->model('penjualan_detail_model');
		$this->load->model('nota_model');
		$this->load->model('penjualan_model');
	}

	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$this->data['data_cabang'] = $this->cabang_model->getAllById(); 	
			$this->data['content'] = 'admin/pembukuan_tukar_plus/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function cek_nota()
	{
		$this->data['content'] = 'admin/pembukuan_tukar_plus/cek_nota_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function create()
	{
		$this->form_validation->set_rules('tanggal', "tanggal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$tanggal = $this->input->post('tanggal');
			$no_nota_id = $this->input->post('no_nota_id');
			$cabang_id_tukar = $this->input->post('cabang_id_tukar');
			$jenis_tukar = $this->input->post('jenis_tukar');
			$data_tukar_plus = array(
				'users_id' => $this->data['users']->id,
				'tanggal' => $tanggal,
				'total_berat' => 0,
				'jumlah_transaksi' => 1,
				'enum' => 0,
				'cabang_id' => $cabang_id_tukar,
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			$insert_tukar_plus = $this->tukar_plus_model->insert($data_tukar_plus);
			// get no nota
			$no_nota = $this->nota_model->getOneBy(['nota.id' => $no_nota_id]);
			if ($jenis_tukar == 1) {
				$data_tukar_plus_detail = array(
					'tukar_plus_id' => $insert_tukar_plus,
					'no_nota' => $no_nota->no_nota,
					'status' => 'Tukar Plus',
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				//update status nota
				$data_update_nota = array(
						'status' => 4
				);
			} else {
				$data_tukar_plus_detail = array(
					'tukar_plus_id' => $insert_tukar_plus,
					'no_nota' => $no_nota->no_nota,
					'status' => 'Tukar Min',
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				//update status nota
				$data_update_nota = array(
						'status' => 5
				);
			}

			$insert_tukar_plus_detail = $this->tukar_plus_detail_model->insert($data_tukar_plus_detail);
			$update_nota = $this->nota_model->update($data_update_nota, ['nota.id' => $no_nota_id]);
			if ($update_nota) {
				$this->session->set_flashdata('message', "Data Pembukuan Tukar Barang Baru Berhasil Disimpan");
				redirect("pembukuan_tukar_plus/create_more/" . $insert_tukar_plus);
			} else {
				$this->session->set_flashdata('message_error', "Data Pembukuan Tukar Barang Baru Gagal Disimpan");
				redirect("pembukuan_tukar_plus");
			}
			/*
			$value_tambah = $this->input->post('value-btn-tambah');
			$harga = $this->input->post('harga_tp');
			$jenis_tukar = $this->input->post('jenis_tukar');
			$no_nota = $this->input->post('no_nota');
			$no_nota_penjualan = $this->input->post('no_nota_penjualan');

			
			if ($jenis_tukar == 1) {
				$harga = $this->input->post('harga_tp');
				$harga = $harga + $this->input->post('harga_penjualan');
				$data_tukar_plus = array(
					'users_id' => $this->data['users']->id,
					'tanggal' => $this->input->post('tanggal'),
					'total_berat' => $this->input->post('berat_tp')+$this->input->post('berat'),
					'jumlah_transaksi' => 1,
					'enum' => 0,
					'cabang_id' => $this->input->post('cabang_id'),
					'total_harga_keseluruhan' => $harga,
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$insert_tukar_plus = $this->tukar_plus_model->insert($data_tukar_plus);
			} else {
				$data_tukar_plus = array(
					'users_id' => $this->data['users']->id,
					'tanggal' => $this->input->post('tanggal'),
					'total_berat' => $this->input->post('berat_tp'),
					'jumlah_transaksi' => 1,
					'enum' => 0,
					'cabang_id' => $this->input->post('cabang_id'),
					'total_harga_keseluruhan' => $harga,
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$insert_tukar_plus = $this->tukar_plus_model->insert($data_tukar_plus);
			}
			

			if ($jenis_tukar == 1) {

				$harga = $this->input->post('harga_tp');
				$harga = $harga + $this->input->post('harga_penjualan');
				$data_tukar_plus_detail = array(
					'tukar_plus_id' => $insert_tukar_plus,
					'karyawan_id' => $this->input->post('karyawan_id'),
					'no_nota' => $no_nota,
					'barang_id' => $this->input->post('barang_id'),
					'jenis_transaksi_id' => $this->input->post('jenis_transaksi_id'),
					'berat' => $this->input->post('berat_tp')+$this->input->post('berat'),
					'potong' => $this->input->post('potong'),
					'no_nota_penjualan' => $no_nota_penjualan,
					'potongan_rusak' => $this->input->post('potongan_rusak'),
					'harga' => $harga,
					'status' => 'Tukar Plus',
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$insert_tukar_plus_detail = $this->tukar_plus_detail_model->insert($data_tukar_plus_detail);
				//update status nota
				$data_update_nota = array(
						'status' => 4
				);
				//update status nota di tabel nota
				$where_update_nota_penjualan['nota.no_nota'] = $no_nota_penjualan;
				$where_update_nota_penjualan['nota.jenis_nota'] = 0;
				$this->nota_model->update($data_update_nota, $where_update_nota_penjualan);
				$data_update_nota = array(
						'status' => 4
				);
				//update status nota di tabel nota
				$where_update_nota['nota.no_nota'] = $no_nota;
				$where_update_nota['nota.jenis_nota'] = 0;
				$this->nota_model->update($data_update_nota, $where_update_nota);
				$where_penjualan['penjualan_detail.no_nota'] = $no_nota_penjualan;
				$where_penjualan['penjualan_detail.enum'] = 0;
				$penjualan_detail = $this->penjualan_detail_model->getOneBy($where_penjualan);
				//hapus nota di penjualan
				$data_update = array('penjualan_detail.is_deleted' => 1);
				$this->penjualan_detail_model->update($data_update, $where_penjualan);
				$cek_detail = $this->penjualan_detail_model->getAllById(['penjualan_detail.penjualan_id' => $penjualan_detail->penjualan_id, 'penjualan_detail.is_deleted' => 0]);
				if (empty($cek_detail)) {
					$data_update = array('penjualan.is_deleted' => 1);
					$this->penjualan_model->update($data_update,array('penjualan.id' => $penjualan_detail->penjualan_id));
				}
			}else{
				// get enum jenis
				$harga_jenis_barang_kembali = $this->input->post('harga_jenis_barang_kembali');
				$where_enum['enum_transaksi_barang.jenis_transaksi'] = 'barang_kembali';
				$where_enum['enum_transaksi_barang.harga'] = $harga_jenis_barang_kembali;
				$enum_transaksi = $this->enum_transaksi_barang_model->getOneBy($where_enum);
				$data_tukar_plus_detail = array(
					'tukar_plus_id' => $insert_tukar_plus,
					'karyawan_id' => $this->input->post('karyawan_id'),
					'no_nota' => $no_nota,
					'jenis_transaksi_id' => $enum_transaksi->id,
					'barang_id' => $this->input->post('barang_id'),
					'berat' => $this->input->post('berat_tp'),
					'potong' => $this->input->post('potong'),
					'no_nota_penjualan' => $no_nota_penjualan,
					'harga' => $harga,
					'potongan_rusak' => $this->input->post('potongan_rusak'),
					'status' => 'Tukar Min',
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$insert_tukar_plus_detail = $this->tukar_plus_detail_model->insert($data_tukar_plus_detail);
				//update status nota
				$data_update_nota = array(
						'status' => 2
				);
				//update status nota di tabel nota
				$where_update_nota_penjualan['nota.no_nota'] = $no_nota_penjualan;
				$where_update_nota_penjualan['nota.jenis_nota'] = 0;
				$this->nota_model->update($data_update_nota, $where_update_nota_penjualan);
				// $hapus_penjualan = $this->penjualan_detail_model->delete(['penjualan_detail.no_nota' => $no_nota_penjualan]);
				$data_update_nota = array(
						'status' => 5
				);
				//update status nota di tabel nota
				$where_update_nota['nota.no_nota'] = $no_nota;
				$where_update_nota['nota.jenis_nota'] = 0;
				$this->nota_model->update($data_update_nota, $where_update_nota);
				//cek data barang kembali
				$data_bk = $this->barang_kembali_model->getOneBy(['barang_kembali.tanggal' => $tanggal, 'barang_kembali.enum' => 0]);

				$penjualan_detail = $this->penjualan_detail_model->getOneBy(['penjualan_detail.no_nota' => $no_nota_penjualan]);

				// insert ke BK
				$data_barang_kembali_detail = array(
					'barang_kembali_id' => $data_bk->id,
					'karyawan_id' => $this->input->post('karyawan_id'),
					'no_nota' => $penjualan_detail->no_nota,
					'jenis_transaksi_id' => $enum_transaksi->id,
					'barang_id' => $this->input->post('barang_id'),
					'berat' => $this->input->post('selisih_berat'),
					'potong' => $this->input->post('potong'),
					'harga' => $this->input->post('selisih_harga'),
					'potongan' => $this->input->post('potongan'),
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$insert_barang_kembali_detail = $this->barang_kembali_detail_model->insert($data_barang_kembali_detail);

				//hapus nota di penjualan
				$data_update = array('penjualan_detail.is_deleted' => 1);
				$this->penjualan_detail_model->update($data_update,array("penjualan_detail.no_nota" => $no_nota_penjualan));
				$cek_detail = $this->penjualan_detail_model->getAllById(['penjualan_detail.penjualan_id' => $penjualan_detail->penjualan_id, 'penjualan_detail.is_deleted' => 0]);
				if (empty($cek_detail)) {
					$data_update = array('penjualan.is_deleted' => 1);
					$this->penjualan_model->update($data_update,array('penjualan.id' => $penjualan_detail->penjualan_id));
				}
				if (!empty($cek_detail)) {
					$total_berat = 0.0;
					$total_harga_keseluruhan = 0;
					$jumlah_transaksi = count($cek_detail);
					foreach ($cek_detail as $key => $value) {
						$total_berat += $value->berat;
						$total_harga_keseluruhan += $value->harga;
					}
					$data_update_penjualan = array(
						'jumlah_transaksi' 					=> $jumlah_transaksi,
						'total_berat' 					=> $total_berat,
						'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
						'updated_by' => $this->data['users']->id

					); 
					$update_master_penjualan = $this->penjualan_model->update($data_update_penjualan,array("penjualan.id" => $penjualan_detail->penjualan_id));
				}

				$data_bk_detail = $this->barang_kembali_detail_model->getAllById(['barang_kembali_detail.barang_kembali_id' => $data_bk->id, 'barang_kembali_detail.is_deleted' => 0]);
				if (!empty($data_bk_detail)) {
					$total_berat = 0.0;
					$total_harga_keseluruhan = 0;
					$jumlah_transaksi = count($data_bk_detail);
					foreach ($data_bk_detail as $key => $value) {
						$total_berat += $value->berat;
						$total_harga_keseluruhan += $value->harga;
					}
					$data_update_bk = array(
						'jumlah_transaksi' 					=> $jumlah_transaksi,
						'total_berat' 					=> $total_berat,
						'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
						'updated_by' => $this->data['users']->id

					); 
					$update_master_bk = $this->barang_kembali_model->update($data_update_bk,array("barang_kembali.id" => $data_bk->id));
				}

			}

			$cek_detail = $this->penjualan_detail_model->getAllById(['penjualan_detail.penjualan_id' => $penjualan_detail->penjualan_id, 'penjualan_detail.is_deleted' => 0]);
			if (!empty($cek_detail)) {
				$total_berat = 0.0;
				$total_harga_keseluruhan = 0;
				$jumlah_transaksi = count($cek_detail);
				foreach ($cek_detail as $key => $value) {
					$total_berat += $value->berat;
					$total_harga_keseluruhan += $value->harga;
				}
				$data_update_penjualan = array(
					'jumlah_transaksi' 					=> $jumlah_transaksi,
					'total_berat' 					=> $total_berat,
					'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
					'updated_by' => $this->data['users']->id

				); 
				$update_master_penjualan = $this->penjualan_model->update($data_update_penjualan,array("penjualan.id" => $penjualan_detail->penjualan_id));
			}

			if ($insert_tukar_plus_detail) {
				$this->session->set_flashdata('message', "Data Pembukuan Tukar Barang Baru Berhasil Disimpan");
				redirect("pembukuan_tukar_plus/create_more/" . $insert_tukar_plus);
			} else {
				$this->session->set_flashdata('message_error', "Data Pembukuan Tukar Barang Baru Gagal Disimpan");
				redirect("pembukuan_tukar_plus");
			}
			*/
		} else {
			if ($this->data['is_can_create']) {
				$where['data_karyawan.is_deleted'] = 0;
				$this->data['karyawan'] = $this->data_karyawan_model->getAllById($where);
				$this->data['enum_transaksi'] = $this->enum_transaksi_barang_model->getAllById(['jenis_transaksi' => 'tukar_plus']);
				$this->data['barang'] = $this->barang_model->getAllById();
				$this->data['cabang'] = $this->cabang_model->getAllById();
				$this->data['content'] = 'admin/pembukuan_tukar_plus/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function create_more($id)
	{
		$this->form_validation->set_rules('tukar_plus_id', "tukar_plus_id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$tukar_plus_id = $this->input->post('tukar_plus_id');
			$jenis_tukar = $this->input->post('jenis_tukar');
			$no_nota_id = $this->input->post('no_nota_id');

			// get no nota
			$no_nota = $this->nota_model->getOneBy(['nota.id' => $no_nota_id]);
			if ($jenis_tukar == 1) {
				$data_tukar_plus_detail = array(
					'tukar_plus_id' => $tukar_plus_id,
					'no_nota' => $no_nota->no_nota,
					'status' => 'Tukar Plus',
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				//update status nota
				$data_update_nota = array(
						'status' => 4
				);
			} else {
				$data_tukar_plus_detail = array(
					'tukar_plus_id' => $tukar_plus_id,
					'no_nota' => $no_nota->no_nota,
					'status' => 'Tukar Min',
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				//update status nota
				$data_update_nota = array(
						'status' => 5
				);
			}
			$insert_tukar_plus_detail = $this->tukar_plus_detail_model->insert($data_tukar_plus_detail);
			$update_nota = $this->nota_model->update($data_update_nota, ['nota.id' => $no_nota_id]);

			//  ubah master barang_kembali
				$data_tukar = $this->tukar_plus_model->getOneBy(['tukar_plus.id' => $tukar_plus_id]);
				$update_jumlah = $data_tukar->jumlah_transaksi + 1;
				$data_update_tukar = array(
					'jumlah_transaksi' 					=> $update_jumlah,
					'updated_by' => $this->data['users']->id

				);
				$update_master_tukar = $this->tukar_plus_model->update($data_update_tukar, array("tukar_plus.id" => $tukar_plus_id));

			if ($update_master_tukar) {
				$this->session->set_flashdata('message', "Data Pembukuan Tukar Barang Baru Berhasil Disimpan");
				redirect("pembukuan_tukar_plus/create_more/" . $tukar_plus_id);
			} else {
				$this->session->set_flashdata('message_error', "Data Pembukuan Tukar Barang Baru Gagal Disimpan");
				redirect("pembukuan_tukar_plus");
			}		
			/*
			$value_tambah = $this->input->post('value-btn-tambah');
			$harga = $this->input->post('harga_tp');
			$jenis_tukar = $this->input->post('jenis_tukar');
			$no_nota = $this->input->post('no_nota');
			$tanggal = $this->input->post('tanggal');
			$no_nota_penjualan = $this->input->post('no_nota_penjualan');

			if ($jenis_tukar == 1) {
				$harga = $this->input->post('harga_tp');
				$harga = $harga + $this->input->post('harga_penjualan');
				$data_tukar_plus_detail = array(
					'tukar_plus_id' => $tukar_plus_id,
					'karyawan_id' => $this->input->post('karyawan_id'),
					'no_nota' => $no_nota,
					'jenis_transaksi_id' => $this->input->post('jenis_transaksi_id'),
					'barang_id' => $this->input->post('barang_id'),
					'berat' => $this->input->post('berat_tp')+$this->input->post('berat'),
					'potong' => $this->input->post('potong'),
					'no_nota_penjualan' => $no_nota_penjualan,
					'potongan_rusak' => $this->input->post('potongan_rusak'),
					'harga' => $harga,
					'status' => 'Tukar Plus',
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$insert_tukar_plus_detail = $this->tukar_plus_detail_model->insert($data_tukar_plus_detail);
				//update status nota
				$data_update_nota = array(
						'status' => 4
				);
				//update status nota di tabel nota
				$where_update_nota['nota.no_nota'] = $no_nota;
				$where_update_nota['nota.jenis_nota'] = 0;
				$this->nota_model->update($data_update_nota, $where_update_nota);

				//hapus nota di penjualan
				$data_update = array('penjualan_detail.is_deleted' => 1);
				$this->penjualan_detail_model->update($data_update,array("penjualan_detail.no_nota" => $no_nota_penjualan));
				$where_penjualan['penjualan_detail.no_nota'] = $no_nota_penjualan;
				$where_penjualan['penjualan_detail.enum'] = 0;
				$penjualan_detail = $this->penjualan_detail_model->getOneBy(['penjualan_detail.no_nota' => $no_nota_penjualan]);
				$cek_detail = $this->penjualan_detail_model->getAllById(['penjualan_detail.penjualan_id' => $penjualan_detail->penjualan_id, 'penjualan_detail.is_deleted' => 0]);
				if (empty($cek_detail)) {
					$data_update = array('penjualan.is_deleted' => 1);
					$this->penjualan_model->update($data_update,array('penjualan.id' => $penjualan_detail->penjualan_id));		
				}
			}else{
				// get enum jenis
				$harga_jenis_barang_kembali = $this->input->post('harga_jenis_barang_kembali');
				$where_enum['enum_transaksi_barang.jenis_transaksi'] = 'barang_kembali';
				$where_enum['enum_transaksi_barang.harga'] = $harga_jenis_barang_kembali;
				$enum_transaksi = $this->enum_transaksi_barang_model->getOneBy($where_enum);

				$data_tukar_plus_detail = array(
					'tukar_plus_id' => $tukar_plus_id,
					'karyawan_id' => $this->input->post('karyawan_id'),
					'no_nota' => $no_nota,
					'jenis_transaksi_id' => $enum_transaksi->id,
					'barang_id' => $this->input->post('barang_id'),
					'berat' => $this->input->post('berat_tp'),
					'potong' => $this->input->post('potong'),
					'no_nota_penjualan' => $no_nota_penjualan,
					'harga' => $harga,
					'potongan_rusak' => $this->input->post('potongan_rusak'),
					'status' => 'Tukar Min',
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$insert_tukar_plus_detail = $this->tukar_plus_detail_model->insert($data_tukar_plus_detail);
				//update status nota
				$data_update_nota = array(
						'status' => 2
				);
				//update status nota di tabel nota
				$where_update_nota_penjualan['nota.no_nota'] = $no_nota_penjualan;
				$where_update_nota_penjualan['nota.jenis_nota'] = 0;
				$this->nota_model->update($data_update_nota, $where_update_nota_penjualan);
				// $hapus_penjualan = $this->penjualan_detail_model->delete(['penjualan_detail.no_nota' => $no_nota_penjualan]);
				$data_update_nota = array(
						'status' => 5
				);
				//update status nota di tabel nota
				$where_update_nota['nota.no_nota'] = $no_nota;
				$where_update_nota['nota.jenis_nota'] = 0;
				$this->nota_model->update($data_update_nota, $where_update_nota);
				//cek data barang kembali
				$data_bk = $this->barang_kembali_model->getOneBy(['barang_kembali.tanggal' => $tanggal, 'barang_kembali.enum' => 0]);
				$where_penjualan['penjualan_detail.no_nota'] = $no_nota_penjualan;
				$where_penjualan['penjualan_detail.enum'] = 0;
				$penjualan_detail = $this->penjualan_detail_model->getOneBy($where_penjualan);

				// insert ke BK
				$data_barang_kembali_detail = array(
					'barang_kembali_id' => $data_bk->id,
					'karyawan_id' => $this->input->post('karyawan_id'),
					'no_nota' => $penjualan_detail->no_nota,
					'jenis_transaksi_id' => $enum_transaksi->id,
					'barang_id' => $this->input->post('barang_id'),
					'berat' => $this->input->post('selisih_berat'),
					'potong' => $this->input->post('potong'),
					'harga' => $this->input->post('selisih_harga'),
					'potongan' => $this->input->post('potongan'),
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$insert_barang_kembali_detail = $this->barang_kembali_detail_model->insert($data_barang_kembali_detail);

				//hapus nota di penjualan
				$data_update = array('penjualan_detail.is_deleted' => 1);
				$this->penjualan_detail_model->update($data_update, $where_penjualan);
				
				$cek_detail = $this->penjualan_detail_model->getAllById(['penjualan_detail.penjualan_id' => $penjualan_detail->penjualan_id, 'penjualan_detail.is_deleted' => 0]);
				if (empty($cek_detail)) {
					$data_update = array('penjualan.is_deleted' => 1);
					$this->penjualan_model->update($data_update,array('penjualan.id' => $penjualan_detail->penjualan_id));		
				}

				$data_bk_detail = $this->barang_kembali_detail_model->getAllById(['barang_kembali_detail.barang_kembali_id' => $data_bk->id, 'barang_kembali_detail.is_deleted' => 0]);
				if (!empty($data_bk_detail)) {
					$total_berat = 0.0;
					$total_harga_keseluruhan = 0;
					$jumlah_transaksi = count($data_bk_detail);
					foreach ($data_bk_detail as $key => $value) {
						$total_berat += $value->berat;
						$total_harga_keseluruhan += $value->harga;
					}
					$data_update_bk = array(
						'jumlah_transaksi' 					=> $jumlah_transaksi,
						'total_berat' 					=> $total_berat,
						'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
						'updated_by' => $this->data['users']->id

					); 
					$update_master_bk = $this->barang_kembali_model->update($data_update_bk,array("barang_kembali.id" => $data_bk->id));
				}
			}
			// ubah master tukar_plus
			$data_tukar_plus = $this->tukar_plus_model->getOneBy(['tukar_plus.id' => $tukar_plus_id]);
			//update harga
			if ($jenis_tukar == 1) {
				$update_berat = $data_tukar_plus->total_berat + $this->input->post('berat_tp') + $this->input->post('berat');
				$harga = $this->input->post('harga_tp');
				$harga = $harga + $this->input->post('harga_penjualan');
				$update_harga = $harga + $data_tukar_plus->total_harga_keseluruhan;
			} else {
				$update_berat = $data_tukar_plus->total_berat + $this->input->post('berat_tp');
				$update_harga = $harga + $data_tukar_plus->total_harga_keseluruhan;
			}
			
			// update jumlah_transaksi
			$update_jumlah = $data_tukar_plus->jumlah_transaksi + 1;
			// update berat
			$data_update_tukar_plus = array(
				'jumlah_transaksi' 					=> $update_jumlah,
				'total_harga_keseluruhan'			=> $update_harga,
				'total_berat' 					=> $update_berat,
				'updated_by' => $this->data['users']->id

			);
			$update_master_tukar_plus = $this->tukar_plus_model->update($data_update_tukar_plus, array("tukar_plus.id" => $tukar_plus_id));
			//update master
			$cek_detail = $this->penjualan_detail_model->getAllById(['penjualan_detail.penjualan_id' => $penjualan_detail->penjualan_id, 'penjualan_detail.is_deleted' => 0]);
			if (!empty($cek_detail)) {
				$total_berat = 0.0;
				$total_harga_keseluruhan = 0;
				$jumlah_transaksi = count($cek_detail);
				foreach ($cek_detail as $key => $value) {
					$total_berat += $value->berat;
					$total_harga_keseluruhan += $value->harga;
				}
				$data_update_penjualan = array(
					'jumlah_transaksi' 					=> $jumlah_transaksi,
					'total_berat' 					=> $total_berat,
					'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
					'updated_by' => $this->data['users']->id

				); 
				$update_master_penjualan = $this->penjualan_model->update($data_update_penjualan,array("penjualan.id" => $penjualan_detail->penjualan_id));
			}
			
			if ($update_master_tukar_plus) {
				$this->session->set_flashdata('message', "Data transaksi Tukar Barang Baru Berhasil Disimpan");
				redirect("pembukuan_tukar_plus/create_more/" . $tukar_plus_id);
			} else {
				$this->session->set_flashdata('message_error', "Data transaksi Tukar Barang Baru Gagal Disimpan");
				redirect("pembukuan_tukar_plus");
			}
			*/

		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("tukar_plus/create_more/" . $id);
			} else {
				$this->data['id'] = $id;
				$this->data['tukar_plus'] = $this->tukar_plus_model->getOneBy(array("tukar_plus.id" => $this->data['id']));
				//nota
				$where_nota['cabang_id'] = $this->data['tukar_plus']->cabang_id;
				$where_nota['jenis_nota'] = 0;
				$where_nota['huruf_nota'] = 'G';
				$where_nota['status'] = 1;
				$this->data['no_nota'] = $this->nota_model->getAllById($where_nota);
				//data histori
				$this->data['data_tukar_plus_detail'] = $this->tukar_plus_detail_model->getAllById(['tukar_plus_id' => $id, 'tukar_plus_detail.is_deleted' => 0]);

				$this->data['cabang'] = $this->cabang_model->getAllById();
				$this->data['content'] = 'admin/pembukuan_tukar_plus/create_more_v';
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function detail()
	{
		$this->data['id'] = $this->uri->segment(3);
		$this->data['tukar_plus'] = $this->tukar_plus_model->getOneBy(array("tukar_plus.id" => $this->data['id']));
		$this->data['data_tukar_plus_detail'] = $this->tukar_plus_detail_model->getAllById(['tukar_plus_id' => $this->data['id']]);
		$this->data['content'] = 'admin/pembukuan_tukar_plus/detail_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
		);

		$where['tukar_plus.enum'] = 0;
		$where['tukar_plus.is_deleted'] = 0;
		

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->tukar_plus_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);


		$searchColumn = $this->input->post('columns');
        $isSearchColumn = false;

        if(!empty($searchColumn[0]['search']['value'])){
            $value = $searchColumn[0]['search']['value'];
            $isSearchColumn = true;
            $where['tukar_plus.tanggal'] = $value;
        }

        if(!empty($searchColumn[1]['search']['value'])){
            $value = $searchColumn[1]['search']['value'];
            $isSearchColumn = true;
            $where['tukar_plus.cabang_id'] = $value;
        }

        if($isSearchColumn){
			$totalFiltered = $this->tukar_plus_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
			$totalData = $totalFiltered;
        }else{
        	$totalFiltered = $totalData;
        }

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->tukar_plus_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$detail_url = "";
				$add_url = "";

				$detail_url = "<a href='" . base_url() . "pembukuan_tukar_plus/detail/" . $data->id . "' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";
				$add_url = "<a href='".base_url()."pembukuan_tukar_plus/create_more/".$data->id."' class='btn btn-sm btn-success' data-toggle='tooltip' title='Tambah Data' data-placement='bottom'><i class='fa fa-plus fa-w-20'></i></a>";
				$nestedData['id'] = $start + $key + 1;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['jumlah_transaksi'] = $data->jumlah_transaksi;
				$nestedData['cabang'] = $data->nama_cabang;				
				$nestedData['action'] = $detail_url.' '.$add_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function destroy()
	{
		$response_data = array();
		$response_data['status'] = false;
		$response_data['msg'] = "";
		$response_data['data'] = array();

		$id = $this->uri->segment(3);
		$is_deleted = $this->uri->segment(4);
		if (!empty($id)) {
			$this->load->model("tukar_plus_model");
			$data = array(
				'is_deleted' => ($is_deleted == 1) ? 0 : 1
			);
			$update = $this->tukar_plus_model->update($data, array("id" => $id));

			$response_data['data'] = $data;
			$response_data['status'] = true;
		} else {
			$response_data['msg'] = "ID Harus Diisi";
		}

		echo json_encode($response_data);
	}

	public function hasil_nota(){
		$no_nota = $this->input->get('no_nota');
		$where['no_nota'] = $no_nota;
		$cek = $this->tukar_plus_detail_model->getOneBy($where);
		
		if($cek){
			$data['status'] = true;
			// $data['harga'] = $jenis->harga;
		}else{
			$data['status'] = false;
			// $data['harga'] = '';
		}
		echo json_encode($data);
	}


}
