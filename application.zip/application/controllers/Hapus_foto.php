<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Hapus_foto extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('penjualan_detail_model');
		$this->load->model('tukar_plus_detail_model');
		$this->load->model('barang_kembali_detail_model');
	}

	public function index()
	{
		// $where['MONTH(tukar_plus_detail.created_at)'] = '09';
		// $where['tukar_plus_detail.status'] = 'Tukar Min';
		// $where['tukar_plus_detail.cabang_tukar'] = 12;
		// $tukar = $this->tukar_plus_detail_model->getAllById($where);

		// $where_bk['barang_kembali_detail.cabang_id_asal'] = 12;
		// $where_bk['MONTH(barang_kembali_detail.created_at)'] = '09';
		// $bk = $this->barang_kembali_detail_model->getAllById($where_bk);
		// $no = 1;
		// // foreach ($bk as $key => $value) {
		// // 	if ($value->cabang_bk == 0) {
		// // 		echo $value->no_nota.'<br>';
		// // 	}
		// // }
		// foreach ($tukar as $key_t => $value_t) {
		// 	foreach ($bk as $key => $value) {
		// 		if ($value_t->no_nota_penjualan == $value->no_nota) {
		// 			$data = array('jenis_bk' => 1);
		// 			$this->barang_kembali_detail_model->update($data, ['barang_kembali_detail.id' => $value->id]);
		// 		}				
		// 	}
		// }
		// // echo '<pre>',print_r($bk,1),'</pre>';
		// die();
		// CARA 1
		// HAPUS FOTO
		// PENJUALAN
		$pj_detail = $this->penjualan_detail_model->getAllById(['status_print' => 1]);
		if (!empty($pj_detail)) {
			foreach ($pj_detail as $key => $value) {
				if ($value->foto != NULL) {
					if (file_exists('uploads/foto-barang-penjualan/'.$value->foto)) {   
						// DELETE FOTO
						unlink('uploads/foto-barang-penjualan/'.$value->foto);
						$data_update_foto = array(
							'foto' => NULL,
							'updated_by' => $this->data['users']->id
						);
						$this->penjualan_detail_model->update($data_update_foto, array("penjualan_detail.id" => $value->id));
					}else{
						$data_update_foto = array(
							'foto' => NULL,
							'updated_by' => $this->data['users']->id
						);
						$this->penjualan_detail_model->update($data_update_foto, array("penjualan_detail.id" => $value->id));
					}
				}
			}
		}
		// TUKAR
		$tukar = $this->tukar_plus_detail_model->getAllById(['status_print' => 1]);
		if (!empty($tukar)) {
			foreach ($tukar as $key => $value) {
				if ($value->foto != NULL) {
					if (file_exists('uploads/foto-barang-tukar/'.$value->foto)) {   
						// DELETE FOTO
						unlink('uploads/foto-barang-tukar/'.$value->foto);
						$data_update_foto = array(
							'foto' => NULL,
							'updated_by' => $this->data['users']->id
						);
						$this->tukar_plus_detail_model->update($data_update_foto, array("tukar_plus_detail.id" => $value->id));
					}else{
						$data_update_foto = array(
							'foto' => NULL,
							'updated_by' => $this->data['users']->id
						);
						$this->tukar_plus_detail_model->update($data_update_foto, array("tukar_plus_detail.id" => $value->id));
					}
				}
			}
		}
		$this->session->set_flashdata('message', "Foto Berhasil Dihapus");
		redirect("dashboard");
	}
}
