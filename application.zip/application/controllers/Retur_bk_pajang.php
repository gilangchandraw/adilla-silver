<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Retur_bk_pajang extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('retur_bk_pajang_model');
		$this->load->model('user_model');
		$this->load->model('cabang_model');
	}

	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$date = date('Y-m-d');
			$nama_hari = date('D', strtotime($date));
			$status_nama_hari = 0;
			if ($nama_hari == 'Sat') {
				$status_nama_hari = 1;
			}
			if ($this->data['users_groups']->id == 4) {
				$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
				$where['cabang_id'] = $cabang->id;
			}
			$where['tanggal'] = $date;
			$data_cek = $this->retur_bk_pajang_model->getOneBy($where);
			$this->data['cek_insert'] = $data_cek ? 1 : 0;
			$this->data['cek_hari'] = $status_nama_hari;
			$this->data['content'] = 'admin/retur_bk_pajang/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function create()
	{
		$this->form_validation->set_rules('tanggal', "tanggal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			// get data cabang
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);

			$tanggal = $this->input->post('tanggal');
			$stok_retur_bk_925 = $this->input->post('stok_retur_bk_925');
			$stok_retur_pajang_925 = $this->input->post('stok_retur_pajang_925');
			$stok_retur_bk_sp = $this->input->post('stok_retur_bk_sp');
			$stok_retur_pajang_sp = $this->input->post('stok_retur_pajang_sp');
			$data = array(
				'users_id' => $cabang->users_id,
				'cabang_id' => $cabang->id,
				'tanggal' => $tanggal,
				'stok_retur_bk_925' => $stok_retur_bk_925,
				'stok_retur_pajang_925' => $stok_retur_pajang_925,
				'stok_retur_bk_sp' => $stok_retur_bk_sp,
				'stok_retur_pajang_sp' => $stok_retur_pajang_sp,
				'created_by' => $this->data['users']->id,
			);
			$insert = $this->retur_bk_pajang_model->insert($data);
			// ngurangin stok
			// 925
			$update_stok_925 = $cabang->stok_925 - $stok_retur_bk_925;
			$update_stok_925 = $update_stok_925 - $stok_retur_pajang_925;
			// sp
			$update_stok_sp = $cabang->stok_sp - $stok_retur_bk_sp;
			$update_stok_sp = $update_stok_sp - $stok_retur_pajang_sp;

			//nambahin ke cabang
			// 925
			$update_retur_bk_925 = $cabang->stok_retur_bk_925 + $stok_retur_bk_925;
			$update_retur_pajang_925 = $cabang->stok_retur_pajang_925 + $stok_retur_pajang_925;
			// sp
			$update_retur_bk_sp = $cabang->stok_retur_bk_sp + $stok_retur_bk_sp;
			$update_retur_pajang_sp = $cabang->stok_retur_pajang_sp + $stok_retur_pajang_sp;

			$data_update = array(
				'stok_925' => $update_stok_925,
				'stok_sp' => $update_stok_sp,
				'stok_retur_bk_925' => $update_retur_bk_925,
				'stok_retur_pajang_925' => $update_retur_pajang_925,
				'stok_retur_bk_sp' => $update_retur_bk_sp,
				'stok_retur_pajang_sp' => $update_retur_pajang_sp,
			);
			$update = $this->cabang_model->update($data_update, array("id" => $cabang->id));
			
			if ($update) {
				$this->session->set_flashdata('message', "Data retur bk pajang Baru Berhasil Disimpan");
				redirect("retur_bk_pajang");
			} else {
				$this->session->set_flashdata('message_error', "Data retur bk pajang Baru Gagal Disimpan");
				redirect("retur_bk_pajang");
			}
		} else {
			if ($this->data['is_can_create']) {
				$this->data['content'] = 'admin/retur_bk_pajang/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function edit()
	{
		$this->form_validation->set_rules('tanggal', "tanggal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$id = $this->input->post('id');
			// get data cabang
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
			$stok_retur_bk_925 = $this->input->post('stok_retur_bk_925');
			$stok_retur_pajang_925 = $this->input->post('stok_retur_pajang_925');
			$stok_retur_bk_sp = $this->input->post('stok_retur_bk_sp');
			$stok_retur_pajang_sp = $this->input->post('stok_retur_pajang_sp');
			//kembali dulu data sebelumnya 
			$data_sebelum = $this->retur_bk_pajang_model->getOneBy(['id' => $id]);
			
			$data = array(
				'stok_retur_bk_925' => $stok_retur_bk_925,
				'stok_retur_pajang_925' => $stok_retur_pajang_925,
				'stok_retur_bk_sp' => $stok_retur_bk_sp,
				'stok_retur_pajang_sp' => $stok_retur_pajang_sp,
				'updated_by' => $this->data['users']->id,
			);
			$update = $this->retur_bk_pajang_model->update($data, array("id" => $id));

			//update ke cabang
			//925
			$update_stok_925 = $cabang->stok_925 + $data_sebelum->stok_retur_bk_925 + $data_sebelum->stok_retur_pajang_925;
			$update_stok_925 = $update_stok_925 - $stok_retur_bk_925 - $stok_retur_pajang_925;
			// sp
			$update_stok_sp = $cabang->stok_sp + $data_sebelum->stok_retur_bk_sp + $data_sebelum->stok_retur_pajang_sp;
			$update_stok_sp = $update_stok_sp - $stok_retur_bk_sp - $stok_retur_pajang_sp;
			// 925
			$update_retur_bk_925 = $cabang->stok_retur_bk_925 - $data_sebelum->stok_retur_bk_925 + $stok_retur_bk_925;
			$update_retur_pajang_925 = $cabang->stok_retur_pajang_925 - $data_sebelum->stok_retur_pajang_925 + $stok_retur_pajang_925;
			// sp
			$update_retur_bk_sp = $cabang->stok_retur_bk_sp - $data_sebelum->stok_retur_bk_sp + $stok_retur_bk_sp;
			$update_retur_pajang_sp = $cabang->stok_retur_pajang_sp - $data_sebelum->stok_retur_pajang_sp + $stok_retur_pajang_sp;
			$data_update = array(
				'stok_925' => $update_stok_925,
				'stok_sp' => $update_stok_sp,
				'stok_retur_bk_925' => $update_retur_bk_925,
				'stok_retur_pajang_925' => $update_retur_pajang_925,
				'stok_retur_bk_sp' => $update_retur_bk_sp,
				'stok_retur_pajang_sp' => $update_retur_pajang_sp,
			);
			$update = $this->cabang_model->update($data_update, array("id" => $cabang->id));
			if ($update) {
				$this->session->set_flashdata('message', "Data retur bk pajang Baru Berhasil Diedit");
				redirect("retur_bk_pajang");
			} else {
				$this->session->set_flashdata('message_error', "Data retur bk pajang Baru Gagal Diedit");
				redirect("retur_bk_pajang");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("retur_bk_pajang/edit/" . $id);
			} else {
				if ($this->data['is_can_edit']) {
					$this->data['id'] = $this->uri->segment(3);
					$this->data['retur_bk_pajang'] = $this->retur_bk_pajang_model->getOneBy(array("retur_bk_pajang.id" => $this->data['id']));
					$this->data['content'] = 'admin/retur_bk_pajang/edit_v';
				} else {
					$this->data['content']  = 'errors/html/restrict';
				}
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
			1 => 'retur_bk_pajang.kode_retur_bk_pajang',
			2 => 'retur_bk_pajang.nama_retur_bk_pajang',
			3 => 'retur_bk_pajang.alamat',
			4 => 'action'
		);

		$where = array();
		$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
		$where['retur_bk_pajang.cabang_id'] = $cabang->id;
		$where['retur_bk_pajang.users_id'] = $this->data['users']->id;

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->retur_bk_pajang_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		if (!empty($this->input->post('search')['value'])) {
			$search_value = $this->input->post('search')['value'];
			$search = array(
				"retur_bk_pajang.kode_retur_bk_pajang" => $search_value,
				"retur_bk_pajang.nama_retur_bk_pajang" => $search_value,
				"retur_bk_pajang.alamat" => $search_value,
			);
			$totalFiltered = $this->retur_bk_pajang_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->retur_bk_pajang_model->getAllBy($limit, $start, $search, $order, $dir, $where);
		$date_lagi = date('Y-m-d');
		$nama_hari_lagi = date('D', strtotime($date_lagi));
		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {
				$date = $data->tanggal;
				$nama_hari = date('D', strtotime($date));

				$edit_url = "";
				if ($this->data['is_can_edit'] && $data->is_deleted == 0 && $nama_hari == 'Sat' && $this->data['users_groups']->id == 4) {
					if ($nama_hari_lagi == 'Sat') {
						$edit_url = "<a href='" . base_url() . "retur_bk_pajang/edit/" . $data->id . "' class='btn btn-sm btn-warning' data-toggle='tooltip' title='Edit Data' data-placement='bottom'><i class='fa fa-edit fa-w-20'></i></a>";
					}
						
				}

				$nestedData['id'] = $start + $key + 1;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['stok_retur_bk_925'] = $data->stok_retur_bk_925;
				$nestedData['stok_retur_pajang_925'] = $data->stok_retur_pajang_925;
				$nestedData['stok_retur_bk_sp'] = $data->stok_retur_bk_sp;
				$nestedData['stok_retur_pajang_sp'] = $data->stok_retur_pajang_sp;
				$nestedData['action'] = $edit_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function dataListAdmin()
	{
		$columns = array(
			0 => 'id',
			1 => 'retur_bk_pajang.kode_retur_bk_pajang',
			2 => 'retur_bk_pajang.nama_retur_bk_pajang',
			3 => 'retur_bk_pajang.alamat',
			4 => 'action'
		);

		$where = array();
		
		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->retur_bk_pajang_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		if (!empty($this->input->post('search')['value'])) {
			$search_value = $this->input->post('search')['value'];
			$search = array(
				"retur_bk_pajang.kode_retur_bk_pajang" => $search_value,
				"retur_bk_pajang.nama_retur_bk_pajang" => $search_value,
				"retur_bk_pajang.alamat" => $search_value,
			);
			$totalFiltered = $this->retur_bk_pajang_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->retur_bk_pajang_model->getAllBy($limit, $start, $search, $order, $dir, $where);
		$date_lagi = date('Y-m-d');
		$nama_hari_lagi = date('D', strtotime($date_lagi));
		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {
				$date = $data->tanggal;
				$nama_hari = date('D', strtotime($date));

				$edit_url = "";
				if ($this->data['is_can_edit'] && $data->is_deleted == 0 && $nama_hari == 'Sat' && $this->data['users_groups']->id == 4) {
					if ($nama_hari_lagi == 'Sat') {
						$edit_url = "<a href='" . base_url() . "retur_bk_pajang/edit/" . $data->id . "' class='btn btn-sm btn-warning' data-toggle='tooltip' title='Edit Data' data-placement='bottom'><i class='fa fa-edit fa-w-20'></i></a>";
					}
						
				}

				$nestedData['id'] = $start + $key + 1;
				$nestedData['nama_cabang'] = $data->nama_cabang;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['stok_retur_bk_925'] = $data->stok_retur_bk_925;
				$nestedData['stok_retur_pajang_925'] = $data->stok_retur_pajang_925;
				$nestedData['stok_retur_bk_sp'] = $data->stok_retur_bk_sp;
				$nestedData['stok_retur_pajang_sp'] = $data->stok_retur_pajang_sp;
				$nestedData['action'] = $edit_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function destroy()
	{
		$response_data = array();
		$response_data['status'] = false;
		$response_data['msg'] = "";
		$response_data['data'] = array();

		$id = $this->uri->segment(3);
		$is_deleted = $this->uri->segment(4);
		if (!empty($id)) {
			$this->load->model("retur_bk_pajang_model");
			$data = array(
				'is_deleted' => ($is_deleted == 1) ? 0 : 1
			);
			$update = $this->retur_bk_pajang_model->update($data, array("id" => $id));

			$response_data['data'] = $data;
			$response_data['status'] = true;
		} else {
			$response_data['msg'] = "ID Harus Diisi";
		}

		echo json_encode($response_data);
	}

	public function getretur_bk_pajang()
	{
		$where = array();
		$office_id = $this->input->get('office_id');

		if ($office_id != '') {
			$where['retur_bk_pajang.office_id'] = $office_id;
		}

		$retur_bk_pajang = $this->retur_bk_pajang_model->getAllById($where);

		$data = array();
		if ($retur_bk_pajang) {
			$data['status'] = true;
			$data['data'] = $retur_bk_pajang;
			$data['message'] = "Success get data retur_bk_pajang.";
		} else {
			$data['status'] = false;
			$data['data'] = [];
			$data['message'] = "Failed get data retur_bk_pajang.";
		}

		echo json_encode($data);
	}
}
