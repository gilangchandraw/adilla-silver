<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Transaksi_sepuhan extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('transaksi_sepuhan_model');
		$this->load->model('transaksi_sepuhan_detail_model');
		$this->load->model('cabang_model');
		$this->load->model('barang_sepuhan_model');
		$this->load->model('stok_sepuhan_cabang_model');
	}

	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			if($this->data['users_groups']->id == 4){
				$where['cabang.users_id'] = $this->data['users']->id;
				$this->data['cabang'] = $this->cabang_model->getOneBy($where);
				$where_sepuhan['transaksi_sepuhan.cabang_id'] = $this->data['cabang']->id;
			}
			$where_sepuhan['transaksi_sepuhan.tanggal'] = date('Y-m-d');
			$cek_insert = $this->transaksi_sepuhan_model->getOneBy($where_sepuhan);
			$this->data['cek_insert'] = $cek_insert ? 1 : 0;
			$this->data['data_cabang'] = $this->cabang_model->getAllById();
			$this->data['content'] = 'admin/transaksi_sepuhan/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function create()
	{
		$this->form_validation->set_rules('tanggal', "tanggal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);

			// inisialisasi
			$tanggal = $this->input->post('tanggal');
			$nama_pemasukan = $this->input->post('nama_pemasukan');
			$harga_pemasukan = $this->input->post('harga_pemasukan');
			$nama_pengeluaran = $this->input->post('nama_pengeluaran');
			$harga_pengeluaran = $this->input->post('harga_pengeluaran');
			$where_kas['id'] = $cabang->id;

			$total_harga = $harga_pemasukan - $harga_pengeluaran;
			$cek_kas_sepuhan_akhir = $cabang->kas_sepuhan + $total_harga;
			if ($cabang->kas_sepuhan == 0) {
				$kas_sepuhan_akhir = $cek_kas_sepuhan_akhir;
				$data_kas = $cabang->kas + $kas_sepuhan_akhir;
				$data_update_ks = array('kas' => $data_kas);
				$update_kas_sepuhan = $this->cabang_model->update($data_update_ks, $where_kas);
				$keterangan = $nama_pengeluaran.' - '.$harga_pengeluaran;
			} else {
				if ($cek_kas_sepuhan_akhir >= 0 ) {
					$kas_sepuhan_akhir = $cek_kas_sepuhan_akhir;
				} else {
					$kas_sepuhan_akhir = $cek_kas_sepuhan_akhir;
					$data_kas = $cabang->kas + $kas_sepuhan_akhir;
					$data_update_ks = array('kas' => $data_kas);
					$update_kas_sepuhan = $this->cabang_model->update($data_update_ks, $where_kas);
					$keterangan = $nama_pengeluaran.' - '.$harga_pengeluaran;
				}
			}			
			
			$data = array(
				'tanggal' => $tanggal,
				'users_id' => $this->data['users']->id,
				'cabang_id' => $cabang->id,
				'created_by' => $this->data['users']->id,
			);
			$insert = $this->transaksi_sepuhan_model->insert($data);

			if ($cek_kas_sepuhan_akhir >= 0) {
				$data_detail = array(
					'transaksi_sepuhan_id' => $insert,
					'nama_pemasukan' => $nama_pemasukan,
					'harga_pemasukan' => $harga_pemasukan,
					'nama_pengeluaran' => $nama_pengeluaran,
					'harga_pengeluaran' => $harga_pengeluaran,
					'total_harga' => $total_harga,
					'kas_sepuhan_akhir' => $kas_sepuhan_akhir,
					'created_by' => $this->data['users']->id,
				);
			} else {
				$data_detail = array(
					'transaksi_sepuhan_id' => $insert,
					'nama_pemasukan' => $nama_pemasukan,
					'harga_pemasukan' => $harga_pemasukan,
					'nama_pengeluaran' => $nama_pengeluaran,
					'harga_pengeluaran' => $harga_pengeluaran,
					'total_harga' => $total_harga,
					'keterangan' => $keterangan,
					'kas_sepuhan_akhir' => $kas_sepuhan_akhir,
					'created_by' => $this->data['users']->id,
				);
			}
			
				
			$insert_detail = $this->transaksi_sepuhan_detail_model->insert($data_detail);

			// update kas sepuhan
			if ($cek_kas_sepuhan_akhir >= 0 ) {
				$kas_sepuhan_akhir = $cek_kas_sepuhan_akhir;
			} else {
				$kas_sepuhan_akhir = 0;
			}
			$data_update_ks = array('kas_sepuhan' => $kas_sepuhan_akhir);
			$update_kas_sepuhan = $this->cabang_model->update($data_update_ks, $where_kas);
			

			if ($update_kas_sepuhan) {
				$this->session->set_flashdata('message', "Data Transaksi Sepuhan Baru Berhasil Disimpan");
				redirect("transaksi_sepuhan/create_more/" . $insert);
			} else {
				$this->session->set_flashdata('message_error', "Data Transaksi Sepuhan Baru Gagal Disimpan");
				redirect("transaksi_sepuhan");
			}
		} else {
			if ($this->data['is_can_create']) {
				$this->data['barang_sepuhan'] = $this->barang_sepuhan_model->getAllById();
				$this->data['content'] = 'admin/transaksi_sepuhan/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function create_old()
	{
		$this->form_validation->set_rules('tanggal', "tanggal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);

			// inisialisasi
			$tanggal = $this->input->post('tanggal');
			$nama_pemasukan = $this->input->post('nama_pemasukan');
			$harga_pemasukan = $this->input->post('harga_pemasukan');
			$barang_sepuhan_id = $this->input->post('barang_sepuhan_id');
			$qty = $this->input->post('qty');
			$harga_pengeluaran = $this->input->post('harga_pengeluaran');
			$keterangan = $this->input->post('keterangan');
			$harga_pengeluaran_lain = $this->input->post('harga_pengeluaran_lain');
			if ($barang_sepuhan_id == 50) {
				$harga = $harga_pengeluaran_lain;
			} else {
				$harga = $harga_pengeluaran;
			}
			$total_harga = $harga_pemasukan - $harga;
			$kas_sepuhan_akhir = $cabang->kas_sepuhan + $total_harga;
			
			$data = array(
				'tanggal' => $tanggal,
				'users_id' => $this->data['users']->id,
				'cabang_id' => $cabang->id,
				'total_harga_keseluruhan' => $harga,
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			$insert = $this->transaksi_sepuhan_model->insert($data);

			if ($barang_sepuhan_id == 50) {
				$data_detail = array(
					'transaksi_sepuhan_id' => $insert,
					'nama_pemasukan' => $nama_pemasukan,
					'harga_pemasukan' => $harga_pemasukan,
					'barang_sepuhan_id' => $barang_sepuhan_id,
					'qty' => $qty,
					'harga_pengeluaran' => $harga,
					'total_harga' => $total_harga,
					'keterangan' => $keterangan,
					'kas_sepuhan_akhir' => $kas_sepuhan_akhir,
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
			} else {
				$data_detail = array(
					'transaksi_sepuhan_id' => $insert,
					'nama_pemasukan' => $nama_pemasukan,
					'harga_pemasukan' => $harga_pemasukan,
					'barang_sepuhan_id' => $barang_sepuhan_id,
					'qty' => $qty,
					'harga_pengeluaran' => $harga,
					'total_harga' => $total_harga,
					'kas_sepuhan_akhir' => $kas_sepuhan_akhir,
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
			}
			
				
			$insert_detail = $this->transaksi_sepuhan_detail_model->insert($data_detail);

			// stok opname stok sepuhan
			$where_stok['cabang_id'] = $cabang->id;
			$where_stok['sepuhan_id'] = $barang_sepuhan_id;
			$stok_sepuhan = $this->stok_sepuhan_cabang_model->getOneBy($where_stok);
			$data_update_stok = array('stok' => ($stok_sepuhan->stok - $qty));

			$update_stok = $this->stok_sepuhan_cabang_model->update($data_update_stok, $where_stok);

			// update kas sepuhan
			$where_kas['id'] = $cabang->id;
			$data_update_ks = array('kas_sepuhan' => $kas_sepuhan_akhir);
			$update_kas_sepuhan = $this->cabang_model->update($data_update_ks, $where_kas);
			

			if ($update_kas_sepuhan) {
				$this->session->set_flashdata('message', "Data Transaksi Sepuhan Baru Berhasil Disimpan");
				redirect("transaksi_sepuhan/create_more/" . $insert);
			} else {
				$this->session->set_flashdata('message_error', "Data Transaksi Sepuhan Baru Gagal Disimpan");
				redirect("transaksi_sepuhan");
			}
		} else {
			if ($this->data['is_can_create']) {
				$this->data['barang_sepuhan'] = $this->barang_sepuhan_model->getAllById();
				$this->data['content'] = 'admin/transaksi_sepuhan/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function create_more($id)
	{
		$this->form_validation->set_rules('id', "id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {

			$id = $this->input->post('id');
			if ($this->data['is_superadmin']) {
				$get = $this->transaksi_sepuhan_model->getOneBy(['transaksi_sepuhan.id' => $id]);
				$cabang = $this->cabang_model->getOneBy(['cabang.id' => $get->cabang_id]);
				
			}else{
				$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
			}
			// inisialisasi
			$nama_pemasukan = $this->input->post('nama_pemasukan');
			$harga_pemasukan = $this->input->post('harga_pemasukan');
			$nama_pengeluaran = $this->input->post('nama_pengeluaran');
			$harga_pengeluaran = $this->input->post('harga_pengeluaran');
			
			$total_harga = $harga_pemasukan - $harga_pengeluaran;
			$cek_kas_sepuhan_akhir = $cabang->kas_sepuhan + $total_harga;
			if ($cabang->kas_sepuhan == 0) {
				$kas_sepuhan_akhir = $cek_kas_sepuhan_akhir;
				$data_kas = $cabang->kas + $kas_sepuhan_akhir;
				$data_update_ks = array('kas' => $data_kas);
				$update_kas_sepuhan = $this->cabang_model->update($data_update_ks, $where_kas);
				$keterangan = $nama_pengeluaran.' - '.$harga_pengeluaran;
			} else {
				if ($cek_kas_sepuhan_akhir >= 0 ) {
					$kas_sepuhan_akhir = $cek_kas_sepuhan_akhir;
				} else {
					$kas_sepuhan_akhir = $cek_kas_sepuhan_akhir;
					$data_kas = $cabang->kas + $kas_sepuhan_akhir;
					$data_update_ks = array('kas' => $data_kas);
					$update_kas_sepuhan = $this->cabang_model->update($data_update_ks, $where_kas);
					$keterangan = $nama_pengeluaran.' - '.$harga_pengeluaran;
				}
			}

			if ($cek_kas_sepuhan_akhir >= 0) {
				$data_detail = array(
					'transaksi_sepuhan_id' => $id,
					'nama_pemasukan' => $nama_pemasukan,
					'harga_pemasukan' => $harga_pemasukan,
					'nama_pengeluaran' => $nama_pengeluaran,
					'harga_pengeluaran' => $harga_pengeluaran,
					'total_harga' => $total_harga,
					'kas_sepuhan_akhir' => $kas_sepuhan_akhir,
					'created_by' => $this->data['users']->id,
				);
			} else {
				$data_detail = array(
					'transaksi_sepuhan_id' => $id,
					'nama_pemasukan' => $nama_pemasukan,
					'harga_pemasukan' => $harga_pemasukan,
					'nama_pengeluaran' => $nama_pengeluaran,
					'harga_pengeluaran' => $harga_pengeluaran,
					'total_harga' => $total_harga,
					'keterangan' => $keterangan,
					'kas_sepuhan_akhir' => $kas_sepuhan_akhir,
					'created_by' => $this->data['users']->id,
				);
			}
			
				
			$insert_detail = $this->transaksi_sepuhan_detail_model->insert($data_detail);

			// update kas sepuhan
			$where_kas['id'] = $cabang->id;
			$data_update_ks = array('kas_sepuhan' => $kas_sepuhan_akhir);
			$update_kas_sepuhan = $this->cabang_model->update($data_update_ks, $where_kas);

			if ($update_kas_sepuhan) {
				$this->session->set_flashdata('message', "Data Transaksi Sepuhan Baru Berhasil Disimpan");
				redirect("transaksi_sepuhan/create_more/" . $id);
			} else {
				$this->session->set_flashdata('message_error', "Data Transaksi Sepuhan Baru Gagal Disimpan");
				redirect("transaksi_sepuhan");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("transaksi_sepuhan");
			} else {
				$this->data['id'] = $id;
				$this->data['sepuh'] = $this->transaksi_sepuhan_model->getOneBy(array("id" => $this->data['id']));
				$this->data['data_sepuh'] = $this->transaksi_sepuhan_detail_model->getAllById(['transaksi_sepuhan_id' => $id]);
				$this->data['content'] = 'admin/transaksi_sepuhan/create_more_v';
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function create_more_old($id)
	{
		$this->form_validation->set_rules('id', "id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {

			$id = $this->input->post('id');
			if ($this->data['is_superadmin']) {
				$get = $this->transaksi_sepuhan_model->getOneBy(['transaksi_sepuhan.id' => $id]);
				$cabang = $this->cabang_model->getOneBy(['cabang.id' => $get->cabang_id]);
				
			}else{
				$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
			}
			// inisialisasi
			$nama_pemasukan = $this->input->post('nama_pemasukan');
			$harga_pemasukan = $this->input->post('harga_pemasukan');
			$barang_sepuhan_id = $this->input->post('barang_sepuhan_id');
			$qty = $this->input->post('qty');
			$harga_pengeluaran = $this->input->post('harga_pengeluaran');
			$keterangan = $this->input->post('keterangan');
			$harga_pengeluaran_lain = $this->input->post('harga_pengeluaran_lain');
			if ($barang_sepuhan_id == 50) {
				$harga = $harga_pengeluaran_lain;
			} else {
				$harga = $harga_pengeluaran;
			}
			$total_harga = $harga_pemasukan - $harga;
			// perhitungan buat di cabang
			$where_before['transaksi_sepuhan_detail.transaksi_sepuhan_id'] = $id;
			$data_sebelum = $this->transaksi_sepuhan_detail_model->getOneByLast($where_before);
			$kas_sepuhan_akhir = $data_sebelum->kas_sepuhan_akhir + $total_harga;
			$kas_sepuhan_akhir_master = $cabang->kas_sepuhan + $total_harga;
			if ($barang_sepuhan_id == 50) {
				$data_detail = array(
					'transaksi_sepuhan_id' => $id,
					'nama_pemasukan' => $nama_pemasukan,
					'harga_pemasukan' => $harga_pemasukan,
					'barang_sepuhan_id' => $barang_sepuhan_id,
					'qty' => $qty,
					'harga_pengeluaran' => $harga,
					'total_harga' => $total_harga,
					'keterangan' => $keterangan,
					'kas_sepuhan_akhir' => $kas_sepuhan_akhir,
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
			} else {
				$data_detail = array(
					'transaksi_sepuhan_id' => $id,
					'nama_pemasukan' => $nama_pemasukan,
					'harga_pemasukan' => $harga_pemasukan,
					'barang_sepuhan_id' => $barang_sepuhan_id,
					'qty' => $qty,
					'harga_pengeluaran' => $harga,
					'total_harga' => $total_harga,
					'kas_sepuhan_akhir' => $kas_sepuhan_akhir,
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
			}
				
			$insert_detail = $this->transaksi_sepuhan_detail_model->insert($data_detail);

			// $count = $this->transaksi_sepuhan_detail_model->getAllById(['transaksi_sepuhan_id' => $id]);
			// if (!empty($count)) {
			// 	$total_harga_keseluruhan = 0;
			// 	foreach ($count as $key => $value) {
			// 		$total_harga_keseluruhan += $value->harga;
			// 	}
			// 	$data_update = array(
			// 		'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
			// 		'updated_by' => $this->data['users']->id

			// 	);
			// 	$update = $this->transaksi_sepuhan_model->update($data_update, array("id" => $id));
			// }

			// stok opname stok sepuhan
			$where_stok['cabang_id'] = $cabang->id;
			$where_stok['sepuhan_id'] = $barang_sepuhan_id;
			$stok_sepuhan = $this->stok_sepuhan_cabang_model->getOneBy($where_stok);
			$data_update_stok = array('stok' => ($stok_sepuhan->stok - $qty));

			$update_stok = $this->stok_sepuhan_cabang_model->update($data_update_stok, $where_stok);

			// update kas sepuhan
			$where_kas['id'] = $cabang->id;
			$data_update_ks = array('kas_sepuhan' => $kas_sepuhan_akhir_master);
			$update_kas_sepuhan = $this->cabang_model->update($data_update_ks, $where_kas);

			if ($update_kas_sepuhan) {
				$this->session->set_flashdata('message', "Data Transaksi Sepuhan Baru Berhasil Disimpan");
				redirect("transaksi_sepuhan/create_more/" . $id);
			} else {
				$this->session->set_flashdata('message_error', "Data Transaksi Sepuhan Baru Gagal Disimpan");
				redirect("transaksi_sepuhan");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("transaksi_sepuhan");
			} else {
				$this->data['id'] = $id;
				$this->data['sepuh'] = $this->transaksi_sepuhan_model->getOneBy(array("id" => $this->data['id']));
				$this->data['data_sepuh'] = $this->transaksi_sepuhan_detail_model->getAllById(['transaksi_sepuhan_id' => $id]);
				$this->data['barang_sepuhan'] = $this->barang_sepuhan_model->getAllById();
				$this->data['content'] = 'admin/transaksi_sepuhan/create_more_v';
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function edit()
	{
		$this->form_validation->set_rules('id', "id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$id = $this->input->post('id');
			$transaksi_sepuhan_id = $this->input->post('transaksi_sepuhan_id');

			$data = array(
				'barang_sepuhan_id' => $this->input->post('barang_sepuhan_id'),
				'qty' => $this->input->post('qty'),
				'harga' => $this->input->post('harga'),
				'updated_by' => $this->data['users']->id
			);
			$update = $this->transaksi_sepuhan_detail_model->update($data, array("id" => $id));
			$count = $this->transaksi_sepuhan_detail_model->getAllById(['transaksi_sepuhan_id' => $transaksi_sepuhan_id]);
			if (!empty($count)) {
				$total_harga_keseluruhan = 0;
				foreach ($count as $key => $value) {
					$total_harga_keseluruhan += $value->harga;
				}
				$data_update = array(
					'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
					'updated_by' => $this->data['users']->id

				);
				$update = $this->transaksi_sepuhan_model->update($data_update, array("id" => $transaksi_sepuhan_id));
			}

			if ($update) {
				$this->session->set_flashdata('message', "Data Sepuhan Berhasil Diedit");
				redirect("transaksi_sepuhan/detail/" . $transaksi_sepuhan_id);
			} else {
				$this->session->set_flashdata('message_error', "Data Sepuhan Gagal Diedit");
				redirect("transaksi_sepuhan");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("transaksi_sepuhan/edit/" . $id);
			} else {
				if ($this->data['is_can_edit']) {
					$this->data['id'] = $this->uri->segment(3);
					$this->data['barang_sepuhan'] = $this->barang_sepuhan_model->getAllById();
					$this->data['sepuh_detail'] = $this->transaksi_sepuhan_detail_model->getOneBy(array("transaksi_sepuhan_detail.id" => $this->data['id']));
					$this->data['content'] = 'admin/transaksi_sepuhan/edit_v';
				} else {
					$this->data['content']  = 'errors/html/restrict';
				}
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function detail()
	{
		$this->data['id'] = $this->uri->segment(3);
		$this->data['data_sepuh'] = $this->transaksi_sepuhan_model->getOneBy(array("transaksi_sepuhan.id" => $this->data['id']));
		$this->data['data_sepuh_detail'] = $this->transaksi_sepuhan_detail_model->getAllById(['transaksi_sepuhan_id' => $this->data['id']]);
		$this->data['cek_insert'] = $this->data['data_sepuh']->tanggal == date('Y-m-d') ? 1 : 0;
		$this->data['content'] = 'admin/transaksi_sepuhan/detail_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
			1 => 'transaksi_sepuhan.tanggal',
			2 => 'transaksi_sepuhan.total_harga_keseluruhan',
			3 => 'action'
		);

		$where = array();
		if (!$this->data['is_superadmin']) {
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
			$where['transaksi_sepuhan.cabang_id'] = $cabang->id;
		}


		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->transaksi_sepuhan_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		$searchColumn = $this->input->post('columns');
		$isSearchColumn = false;

		if (!empty($searchColumn[0]['search']['value'])) {
			$value = $searchColumn[0]['search']['value'];
			$isSearchColumn = true;
			$where['transaksi_sepuhan.tanggal'] = $value;
		}

		if ($isSearchColumn) {
			$totalFiltered = $this->transaksi_sepuhan_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
			$totalData = $totalFiltered;
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->transaksi_sepuhan_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$detail_url = "";
				$add_url = "";

				$detail_url = "<a href='" . base_url() . "transaksi_sepuhan/detail/" . $data->id . "' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";
				if ($data->tanggal == date('Y-m-d')) {
					$add_url = "<a href='" . base_url() . "transaksi_sepuhan/create_more/" . $data->id . "' class='btn btn-sm btn-success' data-toggle='tooltip' title='Tambah Data' data-placement='bottom'><i class='fa fa-plus fa-w-20'></i></a>";
				}


				$nestedData['id'] = $start + $key + 1;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['total_harga_keseluruhan'] = number_format($data->total_harga_keseluruhan);
				$nestedData['action'] = $detail_url . ' ' . $add_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function dataListAdmin()
	{
		$columns = array(
			0 => 'id',
			1 => 'transaksi_sepuhan.tanggal',
			2 => 'transaksi_kotak_cincin.nama_cabang',
			3 => 'transaksi_sepuhan.total_harga_keseluruhan',
			4 => 'action'
		);

		$where = array();



		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->transaksi_sepuhan_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		$searchColumn = $this->input->post('columns');
		$isSearchColumn = false;

		if (!empty($searchColumn[0]['search']['value'])) {
			$value = $searchColumn[0]['search']['value'];
			$isSearchColumn = true;
			$where['transaksi_sepuhan.tanggal'] = $value;
		}
		if (!empty($searchColumn[1]['search']['value'])) {
			$value = $searchColumn[1]['search']['value'];
			$isSearchColumn = true;
			$where['transaksi_sepuhan.cabang_id'] = $value;
		}
		if(!empty($searchColumn[2]['search']['value'])){
            $value = $searchColumn[2]['search']['value'];
            $isSearchColumn = true;
            if ($value == 2) {
            	$value = 0;
            }
            $where['transaksi_sepuhan.status_audit'] = $value;
        }

		if ($isSearchColumn) {
			$totalFiltered = $this->transaksi_sepuhan_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
			$totalData = $totalFiltered;
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->transaksi_sepuhan_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$detail_url = "";
				$add_url = "";
				$audit_url = "";

				$detail_url = "<a href='" . base_url() . "transaksi_sepuhan/detail/" . $data->id . "' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";
				if ($this->data['is_superadmin']) {
					$add_url = "<a href='" . base_url() . "transaksi_sepuhan/create_more/" . $data->id . "' class='btn btn-sm btn-success' data-toggle='tooltip' title='Tambah Data' data-placement='bottom'><i class='fa fa-plus fa-w-20'></i></a>";
				}
				if ($data->status_audit == 0 && $this->data['users_groups']->id == 3) {
            		$audit_url = "<a href='#' 
	        				url='" . base_url() . "transaksi_sepuhan/destroy/" . $data->id . "/" . $data->status_audit . "' class='btn btn-sm btn-danger delete' data-toggle='tooltip' title='Data telah Diaudit' data-placement='bottom'><i class='fa fa-check-circle fa-w-20'></i></a>";
            	}


				$nestedData['id'] = $start + $key + 1;
				$nestedData['cabang'] = $data->nama_cabang;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['total_harga_keseluruhan'] = number_format($data->total_harga_keseluruhan);
				$nestedData['status_audit'] = $data->status_audit == 0 ? '<b style="color:red;">Belum</b>' : '<b style="color:green;">Selesai</b>';
				$nestedData['action'] = $detail_url . ' ' . $add_url.' '.$audit_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function destroy()
	{
		$response_data = array();
		$response_data['status'] = false;
		$response_data['msg'] = "";
		$response_data['data'] = array();

		$id = $this->uri->segment(3);
		$status_audit = $this->uri->segment(4);
		if (!empty($id)) {
			$this->load->model("transaksi_sepuhan_model");
			$data = array(
				'status_audit' => ($status_audit == 1) ? 0 : 1
			);
			$update = $this->transaksi_sepuhan_model->update($data, array("id" => $id));

			$response_data['data'] = $data;
			$response_data['status'] = true;
		} else {
			$response_data['msg'] = "ID Harus Diisi";
		}

		echo json_encode($response_data);
	}

	public function gettransaksi_sepuhan()
	{
		$where = array();
		$office_id = $this->input->get('office_id');

		if ($office_id != '') {
			$where['transaksi_sepuhan.office_id'] = $office_id;
		}

		$transaksi_sepuhan = $this->transaksi_sepuhan_model->getAllById($where);

		$data = array();
		if ($transaksi_sepuhan) {
			$data['status'] = true;
			$data['data'] = $transaksi_sepuhan;
			$data['message'] = "Success get data transaksi_sepuhan.";
		} else {
			$data['status'] = false;
			$data['data'] = [];
			$data['message'] = "Failed get data transaksi_sepuhan.";
		}

		echo json_encode($data);
	}

	public function delete(){
		$transaksi_sepuhan_detail = $this->uri->segment('3');
		
		$get_transaksi = $this->transaksi_sepuhan_detail_model->getOneBy(['transaksi_sepuhan_detail.id' => $transaksi_sepuhan_detail]);
		$get_transaksi_master = $this->transaksi_sepuhan_model->getOneBy(['transaksi_sepuhan.id' => $get_transaksi->transaksi_sepuhan_id]);
		$where_detail['transaksi_sepuhan_detail.transaksi_sepuhan_id'] = $get_transaksi_master->id;
		$where_detail['transaksi_sepuhan_detail.id >'] = $get_transaksi->id;
		$data_detail = $this->transaksi_sepuhan_detail_model->getAllById($where_detail);
		// ubah data kas sepuhan akhir
		if (!empty($data_detail)) {
			foreach ($data_detail as $key => $value) {
				$get = $this->transaksi_sepuhan_detail_model->getOneBy(['transaksi_sepuhan_detail.id' => $value->id]);
				$kas_update = $get->kas_sepuhan_akhir - $get_transaksi->total_harga;
				$data_ks = array('kas_sepuhan_akhir' => $kas_update);
				$this->transaksi_sepuhan_detail_model->update($data_ks, ['transaksi_sepuhan_detail.id' => $value->id]);
			}
		}
		// ubah data di cabang
		if ($this->data['is_superadmin']) {
			$cabang = $this->cabang_model->getOneBy(['cabang.id' => $get_transaksi_master->cabang_id]);
		}else{
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
		}
		$update_total_kas = $cabang->kas_sepuhan - $get_transaksi->total_harga;
		$data_kas_sepuhan_cabang = array('kas_sepuhan' => $update_total_kas);
		$update_cabang = $this->cabang_model->update($data_kas_sepuhan_cabang, ['cabang.id' => $cabang->id]);
		
		// delete detail
		$this->db->where('transaksi_sepuhan_detail.id', $transaksi_sepuhan_detail);
   		$this->db->delete('transaksi_sepuhan_detail'); 
   		
   		if ($update_cabang) {
			$this->session->set_flashdata('message', "Data Berhasil Dihapus");
			redirect("transaksi_sepuhan/detail/".$get_transaksi->transaksi_sepuhan_id);
		} else {
			$this->session->set_flashdata('message_error', "Data Gagal Dihapus");
			redirect("transaksi_sepuhan/detail/".$get_transaksi->transaksi_sepuhan_id);
		}

	}

	public function delete_old(){
		$transaksi_sepuhan_detail = $this->uri->segment('3');
		
		$get_transaksi = $this->transaksi_sepuhan_detail_model->getOneBy(['transaksi_sepuhan_detail.id' => $transaksi_sepuhan_detail]);
		$get_transaksi_master = $this->transaksi_sepuhan_model->getOneBy(['transaksi_sepuhan.id' => $get_transaksi->transaksi_sepuhan_id]);
		$where_detail['transaksi_sepuhan_detail.transaksi_sepuhan_id'] = $get_transaksi_master->id;
		$where_detail['transaksi_sepuhan_detail.id >'] = $get_transaksi->id;
		$data_detail = $this->transaksi_sepuhan_detail_model->getAllById($where_detail);
		// ubah data kas sepuhan akhir
		if (!empty($data_detail)) {
			foreach ($data_detail as $key => $value) {
				$get = $this->transaksi_sepuhan_detail_model->getOneBy(['transaksi_sepuhan_detail.id' => $value->id]);
				$kas_update = $get->kas_sepuhan_akhir - $get_transaksi->total_harga;
				$data_ks = array('kas_sepuhan_akhir' => $kas_update);
				$this->transaksi_sepuhan_detail_model->update($data_ks, ['transaksi_sepuhan_detail.id' => $value->id]);
			}
		}
		// ubah data di cabang
		if ($this->data['is_superadmin']) {
			$cabang = $this->cabang_model->getOneBy(['cabang.id' => $get_transaksi_master->cabang_id]);
		}else{
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
		}
		$update_total_kas = $cabang->kas_sepuhan - $get_transaksi->total_harga;
		$data_kas_sepuhan_cabang = array('kas_sepuhan' => $update_total_kas);
		$update_cabang = $this->cabang_model->update($data_kas_sepuhan_cabang, ['cabang.id' => $cabang->id]);
		
		// delete detail
		$this->db->where('transaksi_sepuhan_detail.id', $transaksi_sepuhan_detail);
   		$this->db->delete('transaksi_sepuhan_detail'); 
   		// kembalikan stok
   		$cabang_id = $get_transaksi_master->cabang_id;
   		if (!$this->data['is_superadmin']) {
   			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
   			$cabang_id = $cabang->id;
   		}
   		if ($get_transaksi->barang_sepuhan_id != 50) {
   			$where_stok['cabang_id'] = $cabang_id;
			$where_stok['sepuhan_id'] = $get_transaksi->barang_sepuhan_id;
	   		$get_stok = $this->stok_sepuhan_cabang_model->getOneBy($where_stok);
	   		$data_update_stok = ['stok' => ($get_stok->stok + $get_transaksi->qty)];
	   		//update stok
			$update = $this->stok_sepuhan_cabang_model->update($data_update_stok, $where_stok);
   		}
		// //update master
		// $cek_detail = $this->transaksi_sepuhan_detail_model->getAllById(['transaksi_sepuhan_detail.transaksi_sepuhan_id' => $get_transaksi->transaksi_sepuhan_id]);
		// if (!empty($cek_detail)) {
		// 	$total_harga_keseluruhan = 0;
		// 	foreach ($cek_detail as $key => $value) {
		// 		$total_harga_keseluruhan += $value->harga;
		// 	}
		// }else{
		// 	$total_harga_keseluruhan = 0;

		// }
		// $data_update_master = array('total_harga_keseluruhan' => $total_harga_keseluruhan);
		// $update = $this->transaksi_sepuhan_model->update($data_update_master, ['transaksi_sepuhan.id' => $get_transaksi->transaksi_sepuhan_id]);


		if ($update_cabang) {
			$this->session->set_flashdata('message', "Data Berhasil Dihapus");
			redirect("transaksi_sepuhan/detail/".$get_transaksi->transaksi_sepuhan_id);
		} else {
			$this->session->set_flashdata('message_error', "Data Gagal Dihapus");
			redirect("transaksi_sepuhan/detail/".$get_transaksi->transaksi_sepuhan_id);
		}

	}
}
