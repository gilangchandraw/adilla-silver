<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH.'core/Admin_Controller.php';
class Pembukuan_penjualan extends Admin_Controller {
 	public function __construct()
	{
		parent::__construct(); 
	 	$this->load->model('penjualan_model');
	 	$this->load->model('penjualan_detail_model');
	 	$this->load->model('cabang_model');
	 	$this->load->model('data_karyawan_model');
	 	$this->load->model('barang_model');
	 	$this->load->model('enum_transaksi_barang_model');
	 	$this->load->model('nota_model');
	 	$this->load->model('barang_kembali_detail_model');
	 	$this->load->model('tukar_plus_detail_model');
	}

	public function index()
	{
		$this->load->helper('url');
		if($this->data['is_can_read']){
			$this->data['data_cabang'] = $this->cabang_model->getAllById(); 	
			$this->data['content'] = 'admin/pembukuan_penjualan/list_v'; 	
		}else{
			$this->data['content'] = 'errors/html/restrict'; 
		}
		
		$this->load->view('admin/layouts/page',$this->data);  
	}

	public function create()
	{ 
		$this->form_validation->set_rules('tanggal',"tanggal Is Required", 'trim|required');
		 
		if ($this->form_validation->run() === TRUE)
		{ 
			$value_tambah = $this->input->post('value-btn-tambah');
			$harga = $this->input->post('harga');
			
			$no_nota_id = $this->input->post('no_nota');
			// get no nota
			$no_nota = $this->nota_model->getOneBy(['nota.id' => $no_nota_id]);
			$no_nota = $no_nota->no_nota;
			
			$status_nota = $this->input->post('status_nota');
			if ($status_nota == 2 || $status_nota == 3 || $status_nota == 5) {

				$data_penjualan = array(
					'users_id' => $this->data['users']->id,
					'tanggal' => $this->input->post('tanggal'),
					'cabang_id' => $this->input->post('cabang_id'),
					'jumlah_transaksi' => 0,
					'enum' => 0,
					'total_berat' => 0,
					'total_harga_keseluruhan' => 0,
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				); 
				$insert_penjualan = $this->penjualan_model->insert($data_penjualan);
				if ($status_nota == 2) {
					$data_penjualan_detail = array(
						'penjualan_id' => $insert_penjualan,
						'karyawan_id' => 1,
						'no_nota' => $no_nota,
						'jenis_transaksi_id' => 0,
						'barang_id' => 0,
						'berat' => 0,
						'enum_penjualan' => 1,
						'enum' => 1,
						'potong' => 0,
						'harga' => 0,
						'status' => 'Nota Batal',
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
					$data_update_nota = array(
							'status' => 3
					);
				}elseif($status_nota == 5){
					$data_penjualan_detail = array(
						'penjualan_id' => $insert_penjualan,
						'karyawan_id' => 1,
						'no_nota' => $no_nota,
						'jenis_transaksi_id' => 0,
						'barang_id' => 0,
						'berat' => 0,
						'enum_penjualan' => 1,
						'enum' => 1,
						'potong' => 0,
						'harga' => 0,
						'status' => 'Nota Pembukuan Penjualan',
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
					$data_update_nota = array(
							'status' => 8
					);
				}else{
					$data_penjualan_detail = array(
						'penjualan_id' => $insert_penjualan,
						'karyawan_id' => 1,
						'no_nota' => $no_nota,
						'jenis_transaksi_id' => 0,
						'barang_id' => 0,
						'berat' => 0,
						'enum_penjualan' => 1,
						'enum' => 1,
						'potong' => 0,
						'harga' => 0,
						'status' => 'Nota Hilang 3R',
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
					$data_update_nota = array(
							'status' => 7
					);
				}
				//update status nota di tabel nota
				$where_update_nota['nota.no_nota'] = $no_nota;
				$where_update_nota['nota.jenis_nota'] = 0;
				$this->nota_model->update($data_update_nota, $where_update_nota);
				$insert_penjualan_detail = $this->penjualan_detail_model->insert($data_penjualan_detail);

				if ($insert_penjualan_detail)
				{ 
					$this->session->set_flashdata('message', "Data transaksi Baru Berhasil Disimpan");
					redirect("pembukuan_penjualan/create_more/".$insert_penjualan);
				}
				else
				{
					$this->session->set_flashdata('message_error',"Data transaksi Baru Gagal Disimpan");
					redirect("pembukuan_penjualan");
				}
			}

			$data_penjualan = array(
				'users_id' => $this->data['users']->id,
				'tanggal' => $this->input->post('tanggal'),
				'cabang_id' => $this->input->post('cabang_id'),
				'jumlah_transaksi' => 1,
				'enum' => 0,
				'total_berat' => $this->input->post('berat'),
				'total_harga_keseluruhan' => $harga,
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			); 
			$insert_penjualan = $this->penjualan_model->insert($data_penjualan);
			if ($status_nota == 1) {
				$data_penjualan_detail = array(
					'penjualan_id' => $insert_penjualan,
					'karyawan_id' => 1,
					'no_nota' => $no_nota,
					'jenis_transaksi_id' => $this->input->post('jenis_transaksi_id'),
					'barang_id' => $this->input->post('barang_id'),
					'berat' => $this->input->post('berat'),
					'potong' => $this->input->post('potong'),
					'potongan' => $this->input->post('potongan'),
					'harga' => $harga,
					'enum_penjualan' => 1,
					'enum' => 1,
					'status' => 'Nota Terjual',
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$data_update_nota = array(
						'status' => 1
				);
			}elseif ($status_nota == 4) {
				$data_penjualan_detail = array(
					'penjualan_id' => $insert_penjualan,
					'karyawan_id' => 1,
					'no_nota' => $no_nota,
					'jenis_transaksi_id' => $this->input->post('jenis_transaksi_id'),
					'barang_id' => $this->input->post('barang_id'),
					'berat' => $this->input->post('berat'),
					'potong' => $this->input->post('potong'),
					'potongan' => $this->input->post('potongan'),
					'harga' => $harga,
					'enum_penjualan' => 1,
					'enum' => 1,
					'status' => 'Nota Hilang 2R',
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$data_update_nota = array(
						'status' => 6
				);
			}elseif ($status_nota == 6) {
				$data_penjualan_detail = array(
					'penjualan_id' => $insert_penjualan,
					'karyawan_id' => 1,
					'no_nota' => $no_nota,
					'jenis_transaksi_id' => $this->input->post('jenis_transaksi_id'),
					'barang_id' => $this->input->post('barang_id'),
					'berat' => $this->input->post('berat'),
					'potong' => $this->input->post('potong'),
					'potongan' => $this->input->post('potongan'),
					'harga' => $harga,
					'enum_penjualan' => 1,
					'enum' => 1,
					'status' => 'Tukar Plus',
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$data_update_nota = array(
						'status' => 4
				);
			}elseif ($status_nota == 7) {
				$data_penjualan_detail = array(
					'penjualan_id' => $insert_penjualan,
					'karyawan_id' => 1,
					'no_nota' => $no_nota,
					'jenis_transaksi_id' => $this->input->post('jenis_transaksi_id'),
					'barang_id' => $this->input->post('barang_id'),
					'berat' => $this->input->post('berat'),
					'potong' => $this->input->post('potong'),
					'potongan' => $this->input->post('potongan'),
					'harga' => $harga,
					'enum_penjualan' => 1,
					'enum' => 1,
					'status' => 'Tukar Min',
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$data_update_nota = array(
						'status' => 5
				);
			}
			//update status nota di tabel nota
			$where_update_nota['nota.no_nota'] = $no_nota;
			$where_update_nota['nota.jenis_nota'] = 0;
			$this->nota_model->update($data_update_nota, $where_update_nota);
			$insert_penjualan_detail = $this->penjualan_detail_model->insert($data_penjualan_detail);
			if ($insert_penjualan_detail)
			{ 
				$this->session->set_flashdata('message', "Data transaksi Baru Berhasil Disimpan");
				redirect("pembukuan_penjualan/create_more/".$insert_penjualan);
			}
			else
			{
				$this->session->set_flashdata('message_error',"Data transaksi Baru Gagal Disimpan");
				redirect("pembukuan_penjualan");
			}
		}else{  
			if($this->data['is_can_create']){  
				
				$this->data['enum_transaksi'] = $this->enum_transaksi_barang_model->getAllById(['jenis_transaksi' => 'penjualan']); 
				$this->data['barang'] = $this->barang_model->getAllById(); 
				$this->data['cabang'] = $this->cabang_model->getAllById();
				$this->data['content'] = 'admin/pembukuan_penjualan/create_v'; 
	        }else{
	            $this->data['content']  = 'errors/html/restrict'; 
	        } 
	        $this->load->view('admin/layouts/page',$this->data);
		}
	} 

	public function create_more($id)
	{ 
		$this->form_validation->set_rules('penjualan_id', "penjualan_id Is Required", 'trim|required'); 
		   
		if ($this->form_validation->run() === TRUE)
		{
		 	$penjualan_id = $this->input->post('penjualan_id');
		 	$value_tambah = $this->input->post('value-btn-tambah');
			$harga = $this->input->post('harga');
			
			$no_nota_id = $this->input->post('no_nota');
			// get no nota
			$no_nota = $this->nota_model->getOneBy(['nota.id' => $no_nota_id]);
			$no_nota = $no_nota->no_nota;

			$status_nota = $this->input->post('status_nota');
			if ($status_nota == 2 || $status_nota == 3 || $status_nota == 5) {
				if ($status_nota == 2) {
					$data_update_nota = array(
							'status' => 3
					);
					$data_penjualan_detail = array(
						'penjualan_id' => $penjualan_id,
						'karyawan_id' => 1,
						'no_nota' => $no_nota,
						'jenis_transaksi_id' => 0,
						'barang_id' => 0,
						'berat' => 0,
						'enum_penjualan' => 1,
						'enum' => 1,
						'potong' => 0,
						'harga' => 0,
						'status' => 'Nota Batal',
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
				}elseif($status_nota == 5){
					$data_penjualan_detail = array(
						'penjualan_id' => $penjualan_id,
						'karyawan_id' => 1,
						'no_nota' => $no_nota,
						'jenis_transaksi_id' => 0,
						'barang_id' => 0,
						'berat' => 0,
						'enum_penjualan' => 1,
						'enum' => 1,
						'potong' => 0,
						'harga' => 0,
						'status' => 'Nota Pembukuan Penjualan',
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
					$data_update_nota = array(
							'status' => 8
					);
				}else{
					$data_update_nota = array(
							'status' => 3
					);
					$data_penjualan_detail = array(
						'penjualan_id' => $penjualan_id,
						'karyawan_id' => 1,
						'no_nota' => $no_nota,
						'jenis_transaksi_id' => 0,
						'barang_id' => 0,
						'berat' => 0,
						'enum_penjualan' => 1,
						'enum' => 1,
						'potong' => 0,
						'harga' => 0,
						'status' => 'Nota Hilang 3R',
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
				}
				//update status nota di tabel nota
				$where_update_nota['nota.no_nota'] = $no_nota;
				$where_update_nota['nota.jenis_nota'] = 0;
				$this->nota_model->update($data_update_nota, $where_update_nota);

				$insert_penjualan_detail = $this->penjualan_detail_model->insert($data_penjualan_detail);
				$cek_detail = $this->penjualan_detail_model->getAllById(['penjualan_detail.penjualan_id' => $penjualan_id, 'penjualan_detail.is_deleted' => 0]);
				//ubah di penjualan
				if (!empty($cek_detail)) {
					$total_berat = 0.0;
					$total_harga_keseluruhan = 0;
					$jumlah_transaksi = count($cek_detail);
					foreach ($cek_detail as $key => $value) {
						$total_berat += $value->berat;
						$total_harga_keseluruhan += $value->harga;
					}
					$data_update_penjualan = array(
						'jumlah_transaksi' 					=> $jumlah_transaksi,
						'total_berat' 					=> $total_berat,
						'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
						'updated_by' => $this->data['users']->id

					); 
					$update_master_penjualan = $this->penjualan_model->update($data_update_penjualan,array("penjualan.id" => $penjualan_detail->penjualan_id));
				}

				if ($insert_penjualan_detail)
				{ 
					$this->session->set_flashdata('message', "Data transaksi Baru Berhasil Disimpan");
					redirect("pembukuan_penjualan/create_more/".$penjualan_id);
				}
				else
				{
					$this->session->set_flashdata('message_error',"Data transaksi Baru Gagal Disimpan");
					redirect("pembukuan_penjualan");
				}
			}
			$berat = $this->input->post('berat');
			//value tambah
			if ($value_tambah == 1) {
				if ($status_nota == 1) {
					$data_update_nota = array(
							'status' => 1
					);
					$data_penjualan_detail = array(
						'penjualan_id' => $penjualan_id,
						'karyawan_id' => 1,
						'no_nota' => $no_nota,
						'jenis_transaksi_id' => $this->input->post('jenis_transaksi_id'),
						'barang_id' => $this->input->post('barang_id'),
						'berat' => $berat,
						'enum_penjualan' => 1,
						'enum' => 1,
						'potong' => $this->input->post('potong'),
						'potongan' => $this->input->post('potongan'),
						'harga' => $harga,
						'status' => 'Nota Terjual',
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
				}elseif ($status_nota == 4) {
					$data_update_nota = array(
							'status' => 6
					);
					$data_penjualan_detail = array(
						'penjualan_id' => $penjualan_id,
						'karyawan_id' => 1,
						'no_nota' => $no_nota,
						'enum_penjualan' => 1,
						'enum' => 1,
						'jenis_transaksi_id' => $this->input->post('jenis_transaksi_id'),
						'barang_id' => $this->input->post('barang_id'),
						'berat' => $berat,
						'potong' => $this->input->post('potong'),
						'potongan' => $this->input->post('potongan'),
						'harga' => $harga,
						'status' => 'Nota Hilang 2R',
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
				}elseif ($status_nota == 6) {
				$data_penjualan_detail = array(
					'penjualan_id' => $penjualan_id,
					'karyawan_id' => 1,
					'no_nota' => $no_nota,
					'jenis_transaksi_id' => $this->input->post('jenis_transaksi_id'),
					'barang_id' => $this->input->post('barang_id'),
					'berat' => $this->input->post('berat'),
					'potong' => $this->input->post('potong'),
					'potongan' => $this->input->post('potongan'),
					'harga' => $harga,
					'enum_penjualan' => 1,
					'enum' => 1,
					'status' => 'Tukar Plus',
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$data_update_nota = array(
						'status' => 4
				);
			}elseif ($status_nota == 7) {
				$data_penjualan_detail = array(
					'penjualan_id' => $penjualan_id,
					'karyawan_id' => 1,
					'no_nota' => $no_nota,
					'jenis_transaksi_id' => $this->input->post('jenis_transaksi_id'),
					'barang_id' => $this->input->post('barang_id'),
					'berat' => $this->input->post('berat'),
					'potong' => $this->input->post('potong'),
					'potongan' => $this->input->post('potongan'),
					'harga' => $harga,
					'enum_penjualan' => 1,
					'enum' => 1,
					'status' => 'Tukar Min',
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$data_update_nota = array(
						'status' => 5
				);
			}
				//update status nota di tabel nota
				$where_update_nota['nota.no_nota'] = $no_nota;
				$where_update_nota['nota.jenis_nota'] = 0;
				$this->nota_model->update($data_update_nota, $where_update_nota);
				$insert_penjualan_detail = $this->penjualan_detail_model->insert($data_penjualan_detail);
				// ubah master penjualan
				$data_penjualan = $this->penjualan_model->getOneBy(['penjualan.id' => $penjualan_id]);
				//update harga
				$update_harga = $harga + $data_penjualan->total_harga_keseluruhan;
				// update jumlah_transaksi
				$update_jumlah = $data_penjualan->jumlah_transaksi + 1;
				// update berat
				$update_berat = $data_penjualan->total_berat + $berat;
				$data_update_penjualan = array(
					'jumlah_transaksi' 					=> $update_jumlah,
					'total_berat' 					=> $update_berat,
					'total_harga_keseluruhan'			=> $update_harga,
					'updated_by' => $this->data['users']->id

				); 
				$update_master_penjualan = $this->penjualan_model->update($data_update_penjualan,array("penjualan.id" => $penjualan_id));
				if ($update_master_penjualan)
				{ 
					$this->session->set_flashdata('message', "Data penjualan baru Berhasil Disimpan");
					redirect("pembukuan_penjualan/create_more/".$penjualan_id);
				}
				else
				{
					$this->session->set_flashdata('message_error',"Data penjualan baru Gagal Disimpan");
					redirect("pembukuan_penjualan");
				}
			}
				
		} 
		else
		{
			if(!empty($_POST)){ 
				$this->session->set_flashdata('message_error',validation_errors());
				return redirect("pembukuan_penjualan/create_more/".$id);	
			}else{
				$this->data['id']= $id;
				$this->data['penjualan'] = $this->penjualan_model->getOneBy(array("penjualan.id"=>$this->data['id']));
				$this->data['data_penjualan_detail'] = $this->penjualan_detail_model->getAllById(['penjualan_id' => $id, 'penjualan_detail.is_deleted' => 0]);
				$where['data_karyawan.is_deleted'] = 0;

				//
				$this->data['karyawan'] = $this->data_karyawan_model->getAllById($where); 
				$this->data['enum_transaksi'] = $this->enum_transaksi_barang_model->getAllById(['jenis_transaksi' => 'penjualan']); 
				$this->data['barang'] = $this->barang_model->getAllById(); 
				$this->data['cabang'] = $this->cabang_model->getAllById();
				$this->data['content'] = 'admin/pembukuan_penjualan/create_more_v';
				$this->load->view('admin/layouts/page',$this->data);
				
			}  
		}    
		
	}

	public function detail()
	{ 
		$this->data['id']= $this->uri->segment(3);
		$this->data['penjualan'] = $this->penjualan_model->getOneBy(array("penjualan.id"=>$this->data['id']));
		$this->data['data_penjualan_detail'] = $this->penjualan_detail_model->getAllById(['penjualan_id' => $this->data['id'], 'penjualan_detail.is_deleted' => 0]);
		$this->data['content'] = 'admin/pembukuan_penjualan/detail_v'; 
		$this->load->view('admin/layouts/page',$this->data); 		
	} 

	public function dataList()
	{
		$columns = array( 
            0 =>'id',
        );

		$where['penjualan.enum'] = 0;
		$where['penjualan.is_deleted'] = 0;
		
		$order = $columns[$this->input->post('order')[0]['column']];
        $dir = $this->input->post('order')[0]['dir'];
  		$search = array();
  		$limit = 0;
  		$start = 0;
        $totalData = $this->penjualan_model->getCountAllBy($limit,$start,$search,$order,$dir,$where); 
        

        $searchColumn = $this->input->post('columns');
        $isSearchColumn = false;

        if(!empty($searchColumn[0]['search']['value'])){
            $value = $searchColumn[0]['search']['value'];
            $isSearchColumn = true;
            $where['penjualan.tanggal'] = $value;
        }
        if(!empty($searchColumn[1]['search']['value'])){
            $value = $searchColumn[1]['search']['value'];
            $isSearchColumn = true;
            $where['penjualan.cabang_id'] = $value;
        }

        if($isSearchColumn){
			$totalFiltered = $this->penjualan_model->getCountAllBy($limit,$start,$search,$order,$dir,$where); 
			$totalData = $totalFiltered;
        }else{
        	$totalFiltered = $totalData;
        }
       
        $limit = $this->input->post('length');
        $start = $this->input->post('start');
     	$datas = $this->penjualan_model->getAllBy($limit,$start,$search,$order,$dir,$where);
     	
        $new_data = array();
        if(!empty($datas))
        { 
            foreach ($datas as $key => $data)
            {  

            	$detail_url = "";
            	$add_url = "";
     			
            	$detail_url = "<a href='".base_url()."pembukuan_penjualan/detail/".$data->id."' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";
            	$add_url = "<a href='".base_url()."pembukuan_penjualan/create_more/".$data->id."' class='btn btn-sm btn-success' data-toggle='tooltip' title='Tambah Data' data-placement='bottom'><i class='fa fa-plus fa-w-20'></i></a>";
            	$delete_url = "<a href='#' url='" . base_url() . "pembukuan_penjualan/destroy/" . $data->id . "/" . $data->is_deleted . "' class='btn btn-sm btn-danger delete' data-toggle='tooltip' title='Non Aktifkan Data' data-placement='bottom'><i class='fa fa-times fa-w-20'></i></a>";

                $nestedData['id'] = $start+$key+1;
                $nestedData['cabang'] = $data->kode_cabang.' - '.$data->nama_cabang;
                $nestedData['tanggal'] = $data->tanggal;
                $nestedData['jumlah_transaksi'] = $data->jumlah_transaksi;
                $nestedData['total_berat'] = $data->total_berat;
                $nestedData['total_harga_keseluruhan'] = 'Rp. '.number_format($data->total_harga_keseluruhan);
           		$nestedData['action'] = $detail_url.' '.$add_url.' '.$delete_url;   
                $new_data[] = $nestedData; 
            }
        }
          
        $json_data = array(
                    "draw"            => intval($this->input->post('draw')),  
                    "recordsTotal"    => intval($totalData),  
                    "recordsFiltered" => intval($totalFiltered), 
                    "data"            => $new_data   
                    );
            
        echo json_encode($json_data); 
	}

	public function destroy(){
		$response_data = array();
        $response_data['status'] = false;
        $response_data['msg'] = "";
        $response_data['data'] = array();   

		$id =$this->uri->segment(3);
		$is_deleted = $this->uri->segment(4);
 		if(!empty($id)){
 			$this->load->model("penjualan_model");
			$data = array(
				'is_deleted' => ($is_deleted == 1)?0:1
			); 
			$update = $this->penjualan_model->update($data,array("id"=>$id));

        	$response_data['data'] = $data; 
         	$response_data['status'] = true;
 		}else{
 		 	$response_data['msg'] = "ID Harus Diisi";
 		}
		
        echo json_encode($response_data); 
	}

	public function get_data_nota(){
		$no_nota_tambah = $this->input->get('no_nota_tambah');
		$where['no_nota'] = $no_nota_tambah;
		$get = $this->penjualan_detail_model->getOneBy($where);
		
		if($get){
			$penjualan = $this->penjualan_model->getOneBy(['penjualan.id' => $get->penjualan_id]);
			$data['status'] = true;
			$data['tanggal'] = $penjualan->tanggal;
			$data['penjualan_id'] = $get->penjualan_id;
			$data['nama_karyawan'] = $get->nama_karyawan;
			$data['no_nota'] = $get->no_nota;
			$data['nama_jenis'] = $get->nama_jenis;
			$data['harga_jenis'] = $get->harga_jenis;
			$data['nama_barang'] = $get->nama_barang;
			$data['jenis_transaksi_id'] = $get->jenis_transaksi_id;
			$data['potong'] = $get->potong;
			$data['berat'] = $get->berat;
			$data['harga'] = $get->harga;
		}else{
			$data['status'] = false;
			$data['penjualan'] = '';
			$data['nama_karyawan'] = '';
			$data['no_nota'] = '';
			$data['harga_jenis'] = '';
			$data['nama_jenis'] = '';
			$data['nama_barang'] = '';
			$data['potong'] = '';
			$data['berat'] = '';
			$data['harga'] = '';
		}
		echo json_encode($data);
	}

	public function edit($penjualan_detail_id)
	{
		$this->form_validation->set_rules('penjualan_detail_id', "penjualan_detail_id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$penjualan_detail_id = $this->input->post('penjualan_detail_id');
			$no_nota = $this->input->post('no_nota');
			
			$harga = $this->input->post('harga');

			$status_nota = $this->input->post('status_nota');
			
			if ($status_nota == 1 || $status_nota == 4 || $status_nota == 6 || $status_nota == 7) {
				if ($status_nota == 1) {
					$data_penjualan_detail = array(
						'jenis_transaksi_id' => $this->input->post('jenis_transaksi_id'),
						'barang_id' => $this->input->post('barang_id'),
						'berat' => $this->input->post('berat_edit'),
						'potong' => $this->input->post('potong'),
						'potongan' => $this->input->post('potongan'),
						'harga' => $harga,
						'status' => 'Nota Terjual',
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
					$data_update_nota = array(
							'status' => 1
					);
				}elseif ($status_nota == 4) {
					$data_penjualan_detail = array(
						'jenis_transaksi_id' => $this->input->post('jenis_transaksi_id'),
						'barang_id' => $this->input->post('barang_id'),
						'berat' => $this->input->post('berat_edit'),
						'potong' => $this->input->post('potong'),
						'potongan' => $this->input->post('potongan'),
						'harga' => $harga,
						'status' => 'Nota Hilang 2R',
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
					$data_update_nota = array(
							'status' => 6
					);
				}elseif ($status_nota == 6) {
					$data_penjualan_detail = array(
						'jenis_transaksi_id' => $this->input->post('jenis_transaksi_id'),
						'barang_id' => $this->input->post('barang_id'),
						'berat' => $this->input->post('berat_edit'),
						'potong' => $this->input->post('potong'),
						'potongan' => $this->input->post('potongan'),
						'harga' => $harga,
						'status' => 'Tukar Plus',
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
					$data_update_nota = array(
							'status' => 4
					);
				}elseif ($status_nota == 7) {
					$data_penjualan_detail = array(
						'jenis_transaksi_id' => $this->input->post('jenis_transaksi_id'),
						'barang_id' => $this->input->post('barang_id'),
						'berat' => $this->input->post('berat_edit'),
						'potong' => $this->input->post('potong'),
						'potongan' => $this->input->post('potongan'),
						'harga' => $harga,
						'status' => 'Tukar Min',
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
					$data_update_nota = array(
							'status' => 5
					);
				}
			}
			
			if ($status_nota == 2 || $status_nota == 3) {
				if ($status_nota == 2) {
					$data_penjualan_detail = array(
						'jenis_transaksi_id' => 0,
						'barang_id' => 0,
						'berat' => 0,
						'potong' => 0,
						'harga' => 0,
						'status' => 'Nota Batal',
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
					$data_update_nota = array(
							'status' => 3
					);
				}else{
					$data_penjualan_detail = array(
						'jenis_transaksi_id' => 0,
						'barang_id' => 0,
						'berat' => 0,
						'potong' => 0,
						'harga' => 0,
						'status' => 'Nota Hilang 3R',
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
					$data_update_nota = array(
							'status' => 7
					);
				}
			}
			//update status nota di tabel nota
			$where_update_nota['nota.no_nota'] = $no_nota;
			$where_update_nota['nota.jenis_nota'] = 0;
			$this->nota_model->update($data_update_nota, $where_update_nota);
			
			$update = $this->penjualan_detail_model->update($data_penjualan_detail, array("id" => $penjualan_detail_id));

			//get id penjualan
			$get_id = $this->penjualan_detail_model->getOneBy(['penjualan_detail.id' => $penjualan_detail_id]);
			$penjualan = $this->penjualan_detail_model->getAllById(['penjualan_detail.penjualan_id' => $get_id->penjualan_id]);
			$jumlah_transaksi = count($penjualan);
			$update_total_berat = 0.0;
			$update_total_harga = 0;
			foreach ($penjualan as $key => $value) {
				$update_total_berat += $value->berat;
				$update_total_harga += $value->harga;
			}
			//update data penjualan
			$data_penjualan = array('jumlah_transaksi' => $jumlah_transaksi, 'total_berat' => $update_total_berat, 'total_harga_keseluruhan' => $update_total_harga); 
			$update = $this->penjualan_model->update($data_penjualan, array("penjualan.id" => $get_id->penjualan_id));
			
			if ($update) {
				$this->session->set_flashdata('message', "Data Penjualan Berhasil Diedit");
				redirect("pembukuan_penjualan/detail/".$get_id->penjualan_id);
			} else {
				$this->session->set_flashdata('message_error', "Data Penjualan Gagal Diedit");
				redirect("pembukuan_penjualan/detail/".$get_id->penjualan_id);
			}
		} else {
			if ($this->data['is_can_edit']) {
				$this->data['penjualan_detail_id'] = $penjualan_detail_id;
				$this->data['detail'] = $this->penjualan_detail_model->getOneBy(array("penjualan_detail.id" => $penjualan_detail_id));
				$this->data['barang'] = $this->barang_model->getAllById(); 
				$this->data['enum_transaksi'] = $this->enum_transaksi_barang_model->getAllById(['jenis_transaksi' => 'penjualan']);

				$this->data['content'] = 'admin/pembukuan_penjualan/edit_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function delete(){
		$penjualan_detail_id = $this->uri->segment('3');
		
		
		$pj_detail = $this->penjualan_detail_model->getOneBy(['penjualan_detail.id' => $penjualan_detail_id]);
		// delete detail
		$this->db->where('penjualan_detail.id', $penjualan_detail_id);
   		$this->db->delete('penjualan_detail'); 
		$no_nota = $pj_detail->no_nota;		
		$nota = $this->nota_model->getOneBy(['no_nota' => $no_nota]);
		$data_update_nota = array('status' => 0);
		//update nota
		$update = $this->nota_model->update($data_update_nota, ['nota.id' => $nota->id]);
		//update master
		$penjualan_detail = $this->penjualan_detail_model->getAllById(['penjualan_detail.penjualan_id' => $pj_detail->penjualan_id, 'penjualan_detail.is_deleted' => 0]);
		
		$update_total_berat = 0.0;
		$update_total_harga = 0;
		$jumlah_transaksi = 0;
		if (!empty($penjualan_detail)) {
			$jumlah_transaksi = count($penjualan_detail);
			foreach ($penjualan_detail as $key => $value) {
				$update_total_berat += $value->berat;
				$update_total_harga += $value->harga;
			}
		}
		//update data penjualan
		$data_penjualan = array('jumlah_transaksi' => $jumlah_transaksi, 'total_berat' => $update_total_berat, 'total_harga_keseluruhan' => $update_total_harga); 
		$update = $this->penjualan_model->update($data_penjualan, array("penjualan.id" => $pj_detail->penjualan_id));

		if ($update) {
			$this->session->set_flashdata('message', "Data Berhasil Dihapus");
			redirect("pembukuan_penjualan/detail/".$pj_detail->penjualan_id);
		} else {
			$this->session->set_flashdata('message_error', "Data Gagal Dihapus");
			redirect("pembukuan_penjualan/detail/".$pj_detail->penjualan_id);
		}

	}

	public function cek_no_nota()
	{
		$this->data['cabang'] = $this->cabang_model->getAllById();
		$this->data['content'] = 'admin/pembukuan_penjualan/cek_nota_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function hasil_nota(){
		$no_nota = $this->input->get('no_nota');
		$kode_cabang = $this->input->get('kode_cabang');
		$no_nota = $no_nota.'~'.$kode_cabang;
		$where_penjualan['penjualan_detail.no_nota LIKE'] = '%'.$no_nota.'%';
		$penjualan = $this->penjualan_detail_model->getOneBy($where_penjualan);
		if($penjualan != false){
			$master = $this->penjualan_model->getOneBy(['penjualan.id' => $penjualan->penjualan_id]);
			$data['tanggal'] = $master->tanggal;
			$data['nama_karyawan'] = $penjualan->nama_karyawan;
			$no_nota = explode('~', $penjualan->no_nota);
			$data['no_nota'] = $no_nota[0];
			$data['harga_jenis'] = $penjualan->harga_jenis;
			$data['nama_barang'] = $penjualan->nama_barang;
			$data['potong'] = $penjualan->potong;
			$data['potongan'] = $penjualan->potongan == NULL ? '' : $penjualan->potongan;
			$data['berat'] = $penjualan->berat;
			$data['harga'] = number_format($penjualan->harga);
			$data['status_'] = $penjualan->is_deleted == 0 ? 'Nota Terjual' : 'Nota Sudah Kembali';
			if ($penjualan->status_print == 0) {
				$status_print = 'Belum';
			}elseif ($penjualan->status_print == 1) {
				$status_print = 'Sudah';
			}elseif ($penjualan->status_print == 2) {
				$status_print = 'Batal';
			}
			$data['status_print'] = $status_print;
			
			$data['status'] = true;
		}else{
			$where_tukar['tukar_plus_detail.no_nota LIKE'] = '%'.$no_nota.'%';
			$tukar = $this->tukar_plus_detail_model->getOneBy($where_tukar);
			if ($tukar != false) {
				$data['status'] = true;
			} else {
				$data['status'] = false;
			}
			
		}
		echo json_encode($data);
	}

}
