<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Barang_kembali extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('barang_kembali_model');
		$this->load->model('barang_kembali_detail_model');
		$this->load->model('cabang_model');
		$this->load->model('data_karyawan_model');
		$this->load->model('barang_model');
		$this->load->model('enum_transaksi_barang_model');
		$this->load->model('penjualan_detail_model');
		$this->load->model('nota_model');
		$this->load->model('barang_rusak_model');
		$this->load->model('barang_hilang_model');
		$this->load->model('penjualan_model');
		$this->load->model('histori_kas_model');
		$this->load->model('histori_stok_barang_model');
		$this->load->model('tukar_plus_detail_model');
		$this->load->model('tukar_plus_model');

	}

	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$cek_insert = true;
			$this->data['data_cabang'] = $this->cabang_model->getAllById();
			if($this->data['users_groups']->id == 4){
				$where['cabang.users_id'] = $this->data['users']->id;
				$this->data['cabang'] = $this->cabang_model->getOneBy($where); 	
				$where_cek['barang_kembali.tanggal'] = date('Y-m-d');
				$where_cek['barang_kembali.enum'] = 1;
				$where_cek['barang_kembali.cabang_id'] = $this->data['cabang']->id;
				$cek_insert = $this->barang_kembali_model->getOneBy($where_cek);
			}
			$this->data['cek_insert'] = $cek_insert ? 1 : 0;
			$this->data['content'] = 'admin/barang_kembali/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function cek_nota()
	{
		$this->data['cabang'] = $this->cabang_model->getAllById();
		$this->data['content'] = 'admin/barang_kembali/cek_nota_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function create()
	{
		$this->form_validation->set_rules('tanggal', "tanggal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$value_tambah = $this->input->post('value-btn-tambah');
			$harga = $this->input->post('harga_barang_kembali');
			$no_nota = $this->input->post('no_nota');
			$potongan = $this->input->post('potongan');
			//cek kualitas
			$kualitas = $this->input->post('kualitas');
			$harga_jenis_barang_kembali = $this->input->post('harga_jenis_barang_kembali');
			//get enum transaksi
			$where_enum['enum_transaksi_barang.jenis_transaksi'] = 'barang_kembali';
			$where_enum['enum_transaksi_barang.harga'] = $harga_jenis_barang_kembali;
			$enum_transaksi = $this->enum_transaksi_barang_model->getOneBy($where_enum);

			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
			$where_penjualan['penjualan_detail.no_nota LIKE'] = '%'.$no_nota.'%';
			// $where_penjualan['penjualan_detail.enum'] = 1;
			//get data penjualan
			$penjualan_detail_cek = $this->penjualan_detail_model->getOneBy($where_penjualan);
			if ($penjualan_detail_cek != false) {
				$penjualan_detail = $this->penjualan_detail_model->getOneBy($where_penjualan);
				$penjualan = $this->penjualan_model->getOneBy(['penjualan.id' => $penjualan_detail->penjualan_id]);
				if ($penjualan_detail->foto != NULL) {
					// DELETE FOTO
					unlink('uploads/foto-barang-penjualan/'.$penjualan_detail->foto);
				}
			} else {
				$where_tukar['tukar_plus_detail.no_nota LIKE'] = '%'.$no_nota.'%';
				$where_tukar['tukar_plus_detail.is_deleted'] = 0;
				$penjualan_detail = $this->tukar_plus_detail_model->getOneBy($where_tukar);
				$penjualan = $this->tukar_plus_model->getOneBy(['tukar_plus.id' => $penjualan_detail->tukar_plus_id]);
				// DELETE FOTO
				if ($penjualan_detail->foto != NULL) {
					unlink('uploads/foto-barang-tukar/'.$penjualan_detail->foto);
				}
			}

			$no_nota = $penjualan_detail->no_nota;
			$tanggal = $this->input->post('tanggal');
			$hasil_before_pengurangan = $this->input->post('hasil_before_pengurangan');
			if ($kualitas != 1) {
				// insert data
				$data_barang_kembali = array(
					'users_id' => $this->data['users']->id,
					'tanggal' => $tanggal,
					'cabang_id' => $cabang->id,
					'total_berat' => $penjualan_detail->berat,
					'jumlah_transaksi' => 1,
					'enum' => 1,
					'total_harga_keseluruhan' => $hasil_before_pengurangan,
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$insert_barang_kembali = $this->barang_kembali_model->insert($data_barang_kembali);

				$data_barang_kembali_detail = array(
					'enum' => 1,
					'barang_kembali_id' => $insert_barang_kembali,
					'karyawan_id' => $penjualan_detail->karyawan_id,
					'no_nota' => $penjualan_detail->no_nota,
					'jenis_transaksi_id' => $enum_transaksi->id,
					'barang_id' => $penjualan_detail->barang_id,
					'berat' => $penjualan_detail->berat,
					'potong' => $penjualan_detail->potong,
					'harga' => $hasil_before_pengurangan,
					'potongan' => $potongan,
					'cabang_id_asal' => $penjualan->cabang_id,
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
			}else{

				$data_barang_kembali = array(
					'users_id' => $this->data['users']->id,
					'tanggal' => $tanggal,
					'cabang_id' => $cabang->id,
					'total_berat' => $penjualan_detail->berat,
					'jumlah_transaksi' => 1,
					'enum' => 1,
					'total_harga_keseluruhan' => $harga,
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$insert_barang_kembali = $this->barang_kembali_model->insert($data_barang_kembali);
				
				$data_barang_kembali_detail = array(
					'enum' => 1,
					'barang_kembali_id' => $insert_barang_kembali,
					'karyawan_id' => $penjualan_detail->karyawan_id,
					'no_nota' => $penjualan_detail->no_nota,
					'jenis_transaksi_id' => $enum_transaksi->id,
					'barang_id' => $penjualan_detail->barang_id,
					'berat' => $penjualan_detail->berat,
					'potong' => $penjualan_detail->potong,
					'harga' => $harga,
					'potongan' => $potongan,
					'cabang_id_asal' => $penjualan->cabang_id,
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				// perhitungan stok opname
				$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
				$cek_jenis_barang = $this->barang_model->getOneBy(['id' => $penjualan_detail->barang_id]);
				// get histori barang
				$cek_histori = $this->histori_stok_barang_model->getOneBy(['cabang_id' => $cabang->id, 'tanggal' => date('Y-m-d')]);
				if($cek_jenis_barang->jenis == '925'){
				    $stok_akhir = $cabang->stok_925 + $penjualan_detail->berat;
				    $data_stok_opname = array('stok_925' => $stok_akhir);
				    //histori stok
				    $total_stok_925 = $cek_histori->total_stok_925 - $penjualan_detail->berat;
				    $data_histori = array(
				    	'total_stok_925' => $total_stok_925,
				    	'stok_925_kembali' => $penjualan_detail->berat,
				    	'stok_925_akhir' => $stok_akhir,
				    );
				}else{
					$stok_akhir = $cabang->stok_sp + $penjualan_detail->berat;
				    $data_stok_opname = array('stok_sp' => $stok_akhir);
				    //histori stok
				    $total_stok_sp = $cek_histori->total_stok_sp - $penjualan_detail->berat;
				    $data_histori = array(
				    	'total_stok_sp' => $total_stok_sp,
				    	'stok_sp_kembali' => $penjualan_detail->berat,
				    	'stok_sp_akhir' => $stok_akhir,
				    );
				}
				// edit di histori
				$where_update_stok['cabang_id'] = $cabang->id;
				$where_update_stok['tanggal'] = date('Y-m-d');
				$update_stok_histori = $this->histori_stok_barang_model->update($data_histori, $where_update_stok);
				// edit di cabang
				$update_stok_opname = $this->cabang_model->update($data_stok_opname, ['id' => $cabang->id]);
			}
			
			$insert_barang_kembali_detail = $this->barang_kembali_detail_model->insert($data_barang_kembali_detail);
			//barang rusak
			if ($kualitas == 2) {
				$data_barang_kembali_detail = array(
					'cabang_id_asal' => $penjualan->cabang_id,
					'enum' => 1,
					'barang_kembali_id' => $insert_barang_kembali,
					'karyawan_id' => $penjualan_detail->karyawan_id,
					'no_nota' => $penjualan_detail->no_nota,
					'jenis_transaksi_id' => $enum_transaksi->id,
					'barang_id' => $penjualan_detail->barang_id,
					'berat' => $this->input->post('berat_barang_rusak'),
					'potong' => $penjualan_detail->potong,
					'potongan_rusak' => $this->input->post('potongan_rusak'),
					'harga' => $harga,
					'potongan' => $potongan,
					'cabang_id' => $cabang->id,
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$insert_barang_kembali_detail = $this->barang_rusak_model->insert($data_barang_kembali_detail);
				// perhitungan stok opname
				$berat_barang_rusak = $this->input->post('berat_barang_rusak');
				
				$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
				$cek_jenis_barang = $this->barang_model->getOneBy(['id' => $penjualan_detail->barang_id]);
				// get histori barang
				$cek_histori = $this->histori_stok_barang_model->getOneBy(['cabang_id' => $cabang->id, 'tanggal' => date('Y-m-d')]);
				if($cek_jenis_barang->jenis == '925'){
					//selisih barang rusak
					$selisih_barang_rusak = $penjualan_detail->berat - $berat_barang_rusak;
					//update
					$stok_akhir = $cabang->stok_925 + $selisih_barang_rusak;
				    $data_stok_opname = array('stok_925' => $stok_akhir);
				    //histori stok
				    $total_stok_925 = $cek_histori->total_stok_925 - $selisih_barang_rusak;
				    $stok_925_kembali = $cek_histori->stok_925_kembali + $selisih_barang_rusak;
				    //histori stok reparasi
				    $stok_925_reparasi = $cek_histori->stok_925_reparasi + $berat_barang_rusak;
				    $data_histori = array(
				    	'total_stok_925' => $total_stok_925,
				    	'stok_925_kembali' => $stok_925_kembali,
				    	'stok_925_akhir' => $stok_akhir,
				    	'stok_925_reparasi' => $stok_925_reparasi
				    );
				}else{
					//selisih barang rusak
					$selisih_barang_rusak = $penjualan_detail->berat - $berat_barang_rusak;
					//update
					$stok_akhir = $cabang->stok_sp + $selisih_barang_rusak;
				    $data_stok_opname = array('stok_sp' => $stok_akhir);
				    //histori stok
				    $total_stok_sp = $cek_histori->total_stok_sp - $selisih_barang_rusak;
				    $stok_sp_kembali = $cek_histori->stok_sp_kembali + $selisih_barang_rusak;
				    //histori stok reparasi
				    $stok_sp_reparasi = $cek_histori->stok_sp_reparasi + $berat_barang_rusak;
				    $data_histori = array(
				    	'total_stok_sp' => $total_stok_sp,
				    	'stok_sp_kembali' => $stok_sp_kembali,
				    	'stok_sp_akhir' => $stok_akhir,
				    	'stok_sp_reparasi' => $stok_sp_reparasi
				    );
				}
				// edit di histori
				$where_update_stok['cabang_id'] = $cabang->id;
				$where_update_stok['tanggal'] = date('Y-m-d');
				$update_stok_histori = $this->histori_stok_barang_model->update($data_histori, $where_update_stok);
			    //edit di cabang
				$update_stok_opname = $this->cabang_model->update($data_stok_opname, ['id' => $cabang->id]);
			//barang hilang
			} elseif ($kualitas == 3) {
				$data_barang_kembali_detail = array(
					'gram_awal' => $penjualan_detail->berat,
					'cabang_id_asal' => $penjualan->cabang_id,
					'enum' => 1,
					'barang_kembali_id' => $insert_barang_kembali,
					'karyawan_id' => $penjualan_detail->karyawan_id,
					'no_nota' => $penjualan_detail->no_nota,
					'jenis_transaksi_id' => $enum_transaksi->id,
					'barang_id' => $penjualan_detail->barang_id,
					'berat' => $this->input->post('berat_barang_hilang'),
					'potong' => $penjualan_detail->potong,
					'potongan_hilang' => $this->input->post('potongan_hilang'),
					'harga' => $harga,
					'potongan' => $potongan,
					'cabang_id' => $cabang->id,
					'created_by' => $this->data['users']->id,
					'updated_by' => $this->data['users']->id
				);
				$insert_barang_kembali_detail = $this->barang_hilang_model->insert($data_barang_kembali_detail);
				// perhitungan stok opname
				$berat_barang_hilang = $this->input->post('berat_barang_hilang');
				
				$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
				$cek_jenis_barang = $this->barang_model->getOneBy(['id' => $penjualan_detail->barang_id]);
				// get histori barang
				$cek_histori = $this->histori_stok_barang_model->getOneBy(['cabang_id' => $cabang->id, 'tanggal' => date('Y-m-d')]);
				if($cek_jenis_barang->jenis == '925'){
					//selisih barang hilang
					$selisih_barang_hilang = $penjualan_detail->berat - $berat_barang_hilang;
					//update
					$stok_akhir = $cabang->stok_925 + $selisih_barang_hilang;
				    $data_stok_opname = array('stok_925' => $stok_akhir);
				    //histori stok
				    $total_stok_925 = $cek_histori->total_stok_925 - $selisih_barang_hilang;
				    $stok_925_kembali = $cek_histori->stok_925_kembali + $selisih_barang_hilang;
				    //histori stok retur
				    $stok_925_retur = $cek_histori->stok_925_retur + $berat_barang_hilang;
				    $data_histori = array(
				    	'total_stok_925' => $total_stok_925,
				    	'stok_925_kembali' => $stok_925_kembali,
				    	'stok_925_akhir' => $stok_akhir,
				    	'stok_925_retur' => $stok_925_retur
				    );
				}else{
					//selisih barang hilang
					$selisih_barang_hilang = $penjualan_detail->berat - $berat_barang_hilang;
					//update
					$stok_akhir = $cabang->stok_sp + $selisih_barang_hilang;
				    $data_stok_opname = array('stok_sp' => $stok_akhir);
				    //histori stok
				    $total_stok_sp = $cek_histori->total_stok_sp - $selisih_barang_hilang;
				    $stok_sp_kembali = $cek_histori->stok_sp_kembali + $selisih_barang_hilang;
				    //histori stok retur
				    $stok_sp_retur = $cek_histori->stok_sp_retur + $berat_barang_hilang;
				    $data_histori = array(
				    	'total_stok_sp' => $total_stok_sp,
				    	'stok_sp_kembali' => $stok_sp_kembali,
				    	'stok_sp_akhir' => $stok_akhir,
				    	'stok_sp_retur' => $stok_sp_retur
				    );
				}
				// edit di histori
				$where_update_stok['cabang_id'] = $cabang->id;
				$where_update_stok['tanggal'] = date('Y-m-d');
				$update_stok_histori = $this->histori_stok_barang_model->update($data_histori, $where_update_stok);
			    //edit di cabang
				$update_stok_opname = $this->cabang_model->update($data_stok_opname, ['id' => $cabang->id]);
			}
			
			if ($penjualan_detail_cek != false) {
				//hapus nota di penjualan setelah barang kembali
				$data_update = array('penjualan_detail.is_deleted' => 1);
				//update is deleted penjualan transaksi
				$where_deleted_penjualan['penjualan_detail.no_nota'] = $no_nota;
				$where_deleted_penjualan['penjualan_detail.enum'] = 1;
				$this->penjualan_detail_model->update($data_update, $where_deleted_penjualan);
				//where cek detail
				$where_cek_detail['penjualan_detail.penjualan_id'] = $penjualan_detail->penjualan_id;
				// $where_cek_detail['penjualan_detail.is_deleted'] = 0;
				$where_cek_detail['penjualan_detail.enum'] = 1;
				$cek_detail = $this->penjualan_detail_model->getAllById($where_cek_detail);
				//ubah di penjualan
				if (!empty($cek_detail)) {
					$total_berat = 0.0;
					$total_harga_keseluruhan = 0;
					$jumlah_transaksi = count($cek_detail);
					foreach ($cek_detail as $key => $value) {
						$total_berat += $value->berat;
						$total_harga_keseluruhan += $value->harga;
					}
					$data_update_penjualan = array(
						'jumlah_transaksi' 					=> $jumlah_transaksi,
						'total_berat' 					=> $total_berat,
						'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
						'updated_by' => $this->data['users']->id

					); 
					$update_master_penjualan = $this->penjualan_model->update($data_update_penjualan,array("penjualan.id" => $penjualan_detail->penjualan_id));
				}
				if (empty($cek_detail)) {
					$data_update = array('penjualan.is_deleted' => 1);
					$this->penjualan_model->update($data_update,array('penjualan.id' => $penjualan_detail->penjualan_id));		
				}
			} else {
				//hapus nota di penjualan setelah barang kembali
				$data_update = array('tukar_plus_detail.is_deleted' => 1);
				//update is deleted penjualan transaksi
				$where_deleted_tukar['tukar_plus_detail.no_nota'] = $no_nota;
				$where_deleted_tukar['tukar_plus_detail.enum'] = 1;
				$this->tukar_plus_detail_model->update($data_update, $where_deleted_tukar);
				//where cek detail
				$where_cek_detail['tukar_plus_detail.tukar_plus_id'] = $penjualan_detail->tukar_plus_id;
				// $where_cek_detail['tukar_plus_detail.is_deleted'] = 0;
				$where_cek_detail['tukar_plus_detail.enum'] = 1;
				$cek_detail = $this->tukar_plus_detail_model->getAllById($where_cek_detail);
				//ubah di penjualan
				if (!empty($cek_detail)) {
					$total_berat = 0.0;
					$total_harga_keseluruhan = 0;
					$jumlah_transaksi = count($cek_detail);
					foreach ($cek_detail as $key => $value) {
						$total_berat += $value->berat;
						$total_harga_keseluruhan += $value->harga;
					}
					$data_update_penjualan = array(
						'jumlah_transaksi' 					=> $jumlah_transaksi,
						'total_berat' 					=> $total_berat,
						'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
						'updated_by' => $this->data['users']->id

					); 
					$update_master_penjualan = $this->tukar_plus_model->update($data_update_penjualan,array("tukar_plus.id" => $penjualan_detail->tukar_plus_id));
				}
				if (empty($cek_detail)) {
					$data_update = array('tukar_plus.is_deleted' => 1);
					$this->tukar_plus_model->update($data_update,array('tukar_plus.id' => $penjualan_detail->tukar_plus_id));		
				}
			}
			
			$data_update_nota = array(
					'status' => 2
			);
			//update status nota di tabel nota
			$where_update_nota['nota.no_nota'] = $no_nota;
			// $where_update_nota['nota.jenis_nota'] = 1;
			$where_update_nota['nota.status_stok_nota'] = 1;
			if ($penjualan_detail->enum_penjualan != NULL) {
				$where_update_nota['nota.status_stok_nota'] = 0;
			}
			$this->nota_model->update($data_update_nota, $where_update_nota);

			// // UPDATE DATA KAS
			// $where_kas['histori_kas.tanggal'] = $tanggal;
			// $where_kas['histori_kas.users_id'] = $this->data['users']->id;
			// $where_kas['histori_kas.cabang_id'] = $cabang->id;
			// $cek_kas = $this->histori_kas_model->getOneBy($where_kas);
			// if ($cek_kas) {

			// 	if ($kualitas != 1) {
			// 		$kas = $cabang->kas - $hasil_before_pengurangan;
			// 	}else{
			// 		$kas = $cabang->kas - $harga;
			// 	}
			// 	//update kas di cabang
			// 	$data_update_kas = array(
			// 			'kas' => $kas
			// 	);
			// 	$update_kas = $this->cabang_model->update($data_update_kas,['cabang.id' => $cabang->id]);
			// 	//update kas di histori kas
			// 	$update_kas = $this->histori_kas_model->update($data_update_kas,$where_kas);
			// } else {
			// 	if ($kualitas != 1) {
			// 		$kas = $cabang->kas - $hasil_before_pengurangan;
			// 	}else{
			// 		$kas = $cabang->kas - $harga;
			// 	}
			// 	$data_update_kas = array(
			// 			'kas' => $kas
			// 	);
			// 	$update_kas = $this->cabang_model->update($data_update_kas,['cabang.id' => $cabang->id]);

			// 	$data_kas = array(
			// 			'users_id' => $this->data['users']->id,
			// 			'cabang_id' => $cabang->id,
			// 			'tanggal' => $tanggal,
			// 			'kas' => $kas,
			// 			'created_by' => $this->data['users']->id,
			// 			'updated_by' => $this->data['users']->id
			// 	);
			// 	$insert_kas = $this->histori_kas_model->insert($data_kas);
			// }
			

			if ($value_tambah == 1) {
				if ($insert_barang_kembali_detail) {
					$this->session->set_flashdata('message', "Data transaksi Baru Berhasil Disimpan");
					redirect("barang_kembali/create_more/" . $insert_barang_kembali);
				} else {
					$this->session->set_flashdata('message_error', "Data transaksi Baru Gagal Disimpan");
					redirect("barang_kembali");
				}
			}
		} else {
			if ($this->data['is_can_create']) {
				$where['data_karyawan.is_deleted'] = 0;
				$where['data_karyawan.users_id'] = $this->data['users']->id;
				$this->data['karyawan'] = $this->data_karyawan_model->getAllById($where);
				$this->data['enum_transaksi'] = $this->enum_transaksi_barang_model->getAllById(['jenis_transaksi' => 'barang_kembali']);
				$this->data['barang'] = $this->barang_model->getAllById();
				$this->data['cabang'] = $this->cabang_model->getAllById();
				$this->data['content'] = 'admin/barang_kembali/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function create_more($id)
	{
		$this->form_validation->set_rules('barang_kembali_id', "barang_kembali_id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$barang_kembali_id = $this->input->post('barang_kembali_id');
			
			$value_tambah = $this->input->post('value-btn-tambah');
			$harga = $this->input->post('harga_barang_kembali');
			$no_nota = $this->input->post('no_nota');
			$harga_jenis_barang_kembali = $this->input->post('harga_jenis_barang_kembali');
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
			//cek kualitas
			$kualitas = $this->input->post('kualitas');
			//get enum transaksi
			$where_enum['enum_transaksi_barang.jenis_transaksi'] = 'barang_kembali';
			$where_enum['enum_transaksi_barang.harga'] = $harga_jenis_barang_kembali;
			$enum_transaksi = $this->enum_transaksi_barang_model->getOneBy($where_enum);
			//get no nota
			$where_penjualan['penjualan_detail.no_nota LIKE'] = '%'.$no_nota.'%';
			// $where_penjualan['penjualan_detail.enum'] = 1;
			
			//get data penjualan
			$penjualan_detail_cek = $this->penjualan_detail_model->getOneBy($where_penjualan);
			if ($penjualan_detail_cek != false) {
				$penjualan_detail = $this->penjualan_detail_model->getOneBy($where_penjualan);
				$penjualan = $this->penjualan_model->getOneBy(['penjualan.id' => $penjualan_detail->penjualan_id]);
				// DELETE FOTO
				if ($penjualan_detail->foto != NULL) {
					unlink('uploads/foto-barang-penjualan/'.$penjualan_detail->foto);
				}
			} else {
				$where_tukar['tukar_plus_detail.no_nota LIKE'] = '%'.$no_nota.'%';
				$where_tukar['tukar_plus_detail.is_deleted'] = 0;
				$penjualan_detail = $this->tukar_plus_detail_model->getOneBy($where_tukar);
				$penjualan = $this->tukar_plus_model->getOneBy(['tukar_plus.id' => $penjualan_detail->tukar_plus_id]);
				// DELETE FOTO
				if ($penjualan_detail->foto != NULL) {
					unlink('uploads/foto-barang-tukar/'.$penjualan_detail->foto);
				}
			}
			

			$no_nota = $penjualan_detail->no_nota;
			$potongan = $this->input->post('potongan');
			$hasil_before_pengurangan = $this->input->post('hasil_before_pengurangan');
			//value tambah
			if ($value_tambah == 1) {
				if ($kualitas != 1) {
					$data_barang_kembali_detail = array(
						'cabang_id_asal' => $penjualan->cabang_id,
						'enum' => 1,
						'barang_kembali_id' => $barang_kembali_id,
						'karyawan_id' => $penjualan_detail->karyawan_id,
						'no_nota' => $penjualan_detail->no_nota,
						'jenis_transaksi_id' => $enum_transaksi->id,
						'barang_id' => $penjualan_detail->barang_id,
						'berat' => $penjualan_detail->berat,
						'potong' => $penjualan_detail->potong,
						'potongan' => $potongan,
						'harga' => $hasil_before_pengurangan,
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
				}else{
					$data_barang_kembali_detail = array(
						'cabang_id_asal' => $penjualan->cabang_id,
						'enum' => 1,
						'barang_kembali_id' => $barang_kembali_id,
						'karyawan_id' => $penjualan_detail->karyawan_id,
						'no_nota' => $penjualan_detail->no_nota,
						'jenis_transaksi_id' => $enum_transaksi->id,
						'barang_id' => $penjualan_detail->barang_id,
						'berat' => $penjualan_detail->berat,
						'potong' => $penjualan_detail->potong,
						'potongan' => $potongan,
						'harga' => $harga,
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
					// perhitungan stok opname
					
					$cek_jenis_barang = $this->barang_model->getOneBy(['id' => $penjualan_detail->barang_id]);
					// get histori barang
					$cek_histori = $this->histori_stok_barang_model->getOneBy(['cabang_id' => $cabang->id, 'tanggal' => date('Y-m-d')]);
					if($cek_jenis_barang->jenis == '925'){
					    $stok_akhir = $cabang->stok_925 + $penjualan_detail->berat;
					    $data_stok_opname = array('stok_925' => $stok_akhir);
					    //histori stok
					    $total_stok_925 = $cek_histori->total_stok_925 - $penjualan_detail->berat;
					    $stok_925_kembali = $cek_histori->stok_925_kembali + $penjualan_detail->berat;
					    $data_histori = array(
					    	'total_stok_925' => $total_stok_925,
					    	'stok_925_kembali' => $stok_925_kembali,
					    	'stok_925_akhir' => $stok_akhir,
					    );
					}else{
						$stok_akhir = $cabang->stok_sp + $penjualan_detail->berat;
					    $data_stok_opname = array('stok_sp' => $stok_akhir);
					    //histori stok
					    $total_stok_sp = $cek_histori->total_stok_sp - $penjualan_detail->berat;
					    $stok_sp_kembali = $cek_histori->stok_sp_kembali + $penjualan_detail->berat;
					    $data_histori = array(
					    	'total_stok_sp' => $total_stok_sp,
					    	'stok_sp_kembali' => $stok_sp_kembali,
					    	'stok_sp_akhir' => $stok_akhir,
					    );
					}
					// edit di histori
					$where_update_stok['cabang_id'] = $cabang->id;
					$where_update_stok['tanggal'] = date('Y-m-d');
					$update_stok_histori = $this->histori_stok_barang_model->update($data_histori, $where_update_stok);
					// edit di cabang
					$update_stok_opname = $this->cabang_model->update($data_stok_opname, ['id' => $cabang->id]);
				}
				$insert_barang_kembali_detail = $this->barang_kembali_detail_model->insert($data_barang_kembali_detail);
				//barang rusak
				if ($kualitas == 2) {
					$data_barang_kembali_detail = array(
						'cabang_id_asal' => $penjualan->cabang_id,
						'enum' => 1,
						'barang_kembali_id' => $barang_kembali_id,
						'karyawan_id' => $penjualan_detail->karyawan_id,
						'no_nota' => $penjualan_detail->no_nota,
						'jenis_transaksi_id' => $enum_transaksi->id,
						'barang_id' => $penjualan_detail->barang_id,
						'berat' => $this->input->post('berat_barang_rusak'),
						'potong' => $penjualan_detail->potong,
						'potongan_rusak' => $this->input->post('potongan_rusak'),
						'harga' => $harga,
						'cabang_id' => $cabang->id,
						'potongan' => $potongan,
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
					$insert_barang_kembali_detail = $this->barang_rusak_model->insert($data_barang_kembali_detail);
					// perhitungan stok opname
					$berat_barang_rusak = $this->input->post('berat_barang_rusak');
					
					$cek_jenis_barang = $this->barang_model->getOneBy(['id' => $penjualan_detail->barang_id]);
					// get histori barang
					$cek_histori = $this->histori_stok_barang_model->getOneBy(['cabang_id' => $cabang->id, 'tanggal' => date('Y-m-d')]);
					if($cek_jenis_barang->jenis == '925'){
						//selisih barang rusak
						$selisih_barang_rusak = $penjualan_detail->berat - $berat_barang_rusak;
						//update
						$stok_akhir = $cabang->stok_925 + $selisih_barang_rusak;
					    $data_stok_opname = array('stok_925' => $stok_akhir);
					    //histori stok
					    $total_stok_925 = $cek_histori->total_stok_925 - $selisih_barang_rusak;
					    $stok_925_kembali = $cek_histori->stok_925_kembali + $selisih_barang_rusak;
					    //histori stok reparasi
					    $stok_925_reparasi = $cek_histori->stok_925_reparasi + $berat_barang_rusak;
					    $data_histori = array(
					    	'total_stok_925' => $total_stok_925,
					    	'stok_925_kembali' => $stok_925_kembali,
					    	'stok_925_akhir' => $stok_akhir,
					    	'stok_925_reparasi' => $stok_925_reparasi
					    );
					}else{
						//selisih barang rusak
						$selisih_barang_rusak = $penjualan_detail->berat - $berat_barang_rusak;
						//update
						$stok_akhir = $cabang->stok_sp + $selisih_barang_rusak;
					    $data_stok_opname = array('stok_sp' => $stok_akhir);
					    //histori stok
					    $total_stok_sp = $cek_histori->total_stok_sp - $selisih_barang_rusak;
					    $stok_sp_kembali = $cek_histori->stok_sp_kembali + $selisih_barang_rusak;
					    //histori stok reparasi
					    $stok_sp_reparasi = $cek_histori->stok_sp_reparasi + $berat_barang_rusak;
					    $data_histori = array(
					    	'total_stok_sp' => $total_stok_sp,
					    	'stok_sp_kembali' => $stok_sp_kembali,
					    	'stok_sp_akhir' => $stok_akhir,
					    	'stok_sp_reparasi' => $stok_sp_reparasi
					    );
					}
					// edit di histori
					$where_update_stok['cabang_id'] = $cabang->id;
					$where_update_stok['tanggal'] = date('Y-m-d');
					$update_stok_histori = $this->histori_stok_barang_model->update($data_histori, $where_update_stok);
				    //edit di cabang
					$update_stok_opname = $this->cabang_model->update($data_stok_opname, ['id' => $cabang->id]);
				//barang hilang
				} elseif ($kualitas == 3) {
					$data_barang_kembali_detail = array(
						'gram_awal' => $penjualan_detail->berat,
						'cabang_id_asal' => $penjualan->cabang_id,
						'enum' => 1,
						'barang_kembali_id' => $barang_kembali_id,
						'karyawan_id' => $penjualan_detail->karyawan_id,
						'no_nota' => $penjualan_detail->no_nota,
						'jenis_transaksi_id' => $enum_transaksi->id,
						'barang_id' => $penjualan_detail->barang_id,
						'berat' => $this->input->post('berat_barang_hilang'),
						'potong' => $penjualan_detail->potong,
						'potongan_hilang' => $this->input->post('potongan_hilang'),
						'harga' => $harga,
						'cabang_id' => $cabang->id,
						'potongan' => $potongan,
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					);
					$insert_barang_kembali_detail = $this->barang_hilang_model->insert($data_barang_kembali_detail);
					// perhitungan stok opname
					$berat_barang_hilang = $this->input->post('berat_barang_hilang');
					
					$cek_jenis_barang = $this->barang_model->getOneBy(['id' => $penjualan_detail->barang_id]);
					// get histori barang
					$cek_histori = $this->histori_stok_barang_model->getOneBy(['cabang_id' => $cabang->id, 'tanggal' => date('Y-m-d')]);
					if($cek_jenis_barang->jenis == '925'){
						//selisih barang hilang
						$selisih_barang_hilang = $penjualan_detail->berat - $berat_barang_hilang;
						//update
						$stok_akhir = $cabang->stok_925 + $selisih_barang_hilang;
					    $data_stok_opname = array('stok_925' => $stok_akhir);
					    //histori stok
					    $total_stok_925 = $cek_histori->total_stok_925 - $selisih_barang_hilang;
					    $stok_925_kembali = $cek_histori->stok_925_kembali + $selisih_barang_hilang;
					    //histori stok retur
					    $stok_925_retur = $cek_histori->stok_925_retur + $berat_barang_hilang;
					    $data_histori = array(
					    	'total_stok_925' => $total_stok_925,
					    	'stok_925_kembali' => $stok_925_kembali,
					    	'stok_925_akhir' => $stok_akhir,
					    	'stok_925_retur' => $stok_925_retur
					    );
					}else{
						//selisih barang hilang
						$selisih_barang_hilang = $penjualan_detail->berat - $berat_barang_hilang;
						//update
						$stok_akhir = $cabang->stok_sp + $selisih_barang_hilang;
					    $data_stok_opname = array('stok_sp' => $stok_akhir);
					    //histori stok
					    $total_stok_sp = $cek_histori->total_stok_sp - $selisih_barang_hilang;
					    $stok_sp_kembali = $cek_histori->stok_sp_kembali + $selisih_barang_hilang;
					    //histori stok retur
					    $stok_sp_retur = $cek_histori->stok_sp_retur + $berat_barang_hilang;
					    $data_histori = array(
					    	'total_stok_sp' => $total_stok_sp,
					    	'stok_sp_kembali' => $stok_sp_kembali,
					    	'stok_sp_akhir' => $stok_akhir,
					    	'stok_sp_retur' => $stok_sp_retur
					    );
					}
					// edit di histori
					$where_update_stok['cabang_id'] = $cabang->id;
					$where_update_stok['tanggal'] = date('Y-m-d');
					$update_stok_histori = $this->histori_stok_barang_model->update($data_histori, $where_update_stok);
				    //edit di cabang
					$update_stok_opname = $this->cabang_model->update($data_stok_opname, ['id' => $cabang->id]);
				}
				// ubah master barang_kembali
				$data_barang_kembali = $this->barang_kembali_model->getOneBy(['barang_kembali.id' => $barang_kembali_id]);
				//update harga
				if ($kualitas != 1) {
					$update_harga = $hasil_before_pengurangan + $data_barang_kembali->total_harga_keseluruhan;
				} else {
					$update_harga = $harga + $data_barang_kembali->total_harga_keseluruhan;
				}
				
				// update jumlah_transaksi
				$update_jumlah = $data_barang_kembali->jumlah_transaksi + 1;
				// update berat
				$update_berat = $data_barang_kembali->total_berat + $penjualan_detail->berat;
				$data_update_barang_kembali = array(
					'jumlah_transaksi' 					=> $update_jumlah,
					'total_harga_keseluruhan'			=> $update_harga,
					'total_berat' 					=> $update_berat,
					'updated_by' => $this->data['users']->id

				);
				$update_master_barang_kembali = $this->barang_kembali_model->update($data_update_barang_kembali, array("barang_kembali.id" => $barang_kembali_id));
				//hapus nota di penjualan setelah barang kembali
				$data_update = array('penjualan_detail.is_deleted' => 1);
				//update is deleted penjualan transaksi
				$where_deleted_penjualan['penjualan_detail.no_nota'] = $no_nota;
				// $where_deleted_penjualan['penjualan_detail.enum'] = 1;
				$this->penjualan_detail_model->update($data_update, $where_deleted_penjualan);
				//where cek detail
				$where_cek_detail['penjualan_detail.penjualan_id'] = $penjualan_detail->penjualan_id;
				// $where_cek_detail['penjualan_detail.is_deleted'] = 0;
				$where_cek_detail['penjualan_detail.enum'] = 1;
				$cek_detail = $this->penjualan_detail_model->getAllById($where_cek_detail);
				if (empty($cek_detail)) {
					$data_update = array('penjualan.is_deleted' => 1);
					$this->penjualan_model->update($data_update,array('penjualan.id' => $penjualan_detail->penjualan_id));		
				}
				if (!empty($cek_detail)) {
					$total_berat = 0.0;
					$total_harga_keseluruhan = 0;
					$jumlah_transaksi = count($cek_detail);
					foreach ($cek_detail as $key => $value) {
						$total_berat += $value->berat;
						$total_harga_keseluruhan += $value->harga;
					}
					$data_update_penjualan = array(
						'jumlah_transaksi' 					=> $jumlah_transaksi,
						'total_berat' 					=> $total_berat,
						'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
						'updated_by' => $this->data['users']->id

					); 
					$update_master_penjualan = $this->penjualan_model->update($data_update_penjualan,array("penjualan.id" => $penjualan_detail->penjualan_id));
				}
				$data_update_nota = array(
						'status' => 2
				);
				//update status nota di tabel nota
				$where_update_nota['nota.no_nota'] = $no_nota;
				// $where_update_nota['nota.jenis_nota'] = 1;
				$where_update_nota['nota.status_stok_nota'] = 1;
				if ($penjualan_detail->enum_penjualan != NULL) {
					$where_update_nota['nota.status_stok_nota'] = 0;
				}
				$this->nota_model->update($data_update_nota, $where_update_nota);
				// // UPDATE DATA KAS
				// $bk = $this->barang_kembali_model->getOneBy(['barang_kembali.id' => $barang_kembali_id]);
				// $cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
				// $where_kas['histori_kas.tanggal'] = $bk->tanggal;
				// $where_kas['histori_kas.users_id'] = $this->data['users']->id;
				// $where_kas['histori_kas.cabang_id'] = $cabang->id;
				// if ($kualitas != 1) {
				// 	$kas = $cabang->kas - $hasil_before_pengurangan;
				// }else{
				// 	$kas = $cabang->kas - $harga;
				// }
				// //update kas di cabang
				// $data_update_kas = array(
				// 		'kas' => $kas
				// );
				// $update_kas = $this->cabang_model->update($data_update_kas,['cabang.id' => $cabang->id]);
				// //update kas di histori kas
				// $update_kas = $this->histori_kas_model->update($data_update_kas,$where_kas);

				if ($update_master_barang_kembali) {
					$this->session->set_flashdata('message', "Data barang_kembali baru Berhasil Disimpan");
					redirect("barang_kembali/create_more/" . $barang_kembali_id);
				} else {
					$this->session->set_flashdata('message_error', "Data barang_kembali baru Gagal Disimpan");
					redirect("barang_kembali");
				}
			}

		} else {
			if (!empty($_POST)) {
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("barang_kembali/create_more/" . $id);
			} else {
				$this->data['id'] = $id;
				$this->data['barang_kembali'] = $this->barang_kembali_model->getOneBy(array("barang_kembali.id" => $this->data['id']));
				$where['data_karyawan.is_deleted'] = 0;
				$where['data_karyawan.users_id'] = $this->data['users']->id;
				$this->data['karyawan'] = $this->data_karyawan_model->getAllById($where);
				$this->data['enum_transaksi'] = $this->enum_transaksi_barang_model->getAllById(['jenis_transaksi' => 'barang_kembali']);
				$this->data['barang'] = $this->barang_model->getAllById();
				$this->data['data_barang_kembali_detail'] = $this->barang_kembali_detail_model->getAllById(['barang_kembali_id' => $id]);
				$this->data['data_barang_rusak'] = $this->barang_rusak_model->getAllById(['barang_kembali_id' => $id]);
				$this->data['data_barang_hilang'] = $this->barang_hilang_model->getAllById(['barang_kembali_id' => $id]);
				$this->data['cabang'] = $this->cabang_model->getAllById();

				$this->data['content'] = 'admin/barang_kembali/create_more_v';
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function detail()
	{
		$this->data['id'] = $this->uri->segment(3);
		$this->data['barang_kembali'] = $this->barang_kembali_model->getOneBy(array("barang_kembali.id" => $this->data['id']));
		$this->data['cek_insert'] = $this->data['barang_kembali']->tanggal == date('Y-m-d') ? 1 : 0;
		$where_detail['barang_kembali_detail.barang_kembali_id'] = $this->data['id'];
		$where_detail['barang_kembali_detail.is_deleted'] = 0;
		$this->data['data_barang_kembali_detail'] = $this->barang_kembali_detail_model->getAllById($where_detail);
		$this->data['data_barang_rusak'] = $this->barang_rusak_model->getAllById(['barang_kembali_id' => $this->data['id']]);
		$this->data['data_barang_hilang'] = $this->barang_hilang_model->getAllById(['barang_kembali_id' => $this->data['id']]);
		$this->data['not_edit'] = [];
		if (!empty($this->data['data_barang_rusak'])) {
			foreach ($this->data['data_barang_rusak'] as $key => $value) {
				$object =  new stdClass();
	            $object->no_nota = $value->no_nota;
				array_push($this->data['not_edit'], $object);
			}
		}
		
		if (!empty($this->data['data_barang_hilang'])) {
			foreach ($this->data['data_barang_hilang'] as $key => $value) {
	   			$object1 =  new stdClass();
	            $object1->no_nota = $value->no_nota;
				array_push($this->data['not_edit'], $object1);
			}
		}
		
		$this->data['content'] = 'admin/barang_kembali/detail_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
		);
		if($this->data['users_groups']->id == 4){
			$cabang = $this->cabang_model->getOneBy(['cabang.users_id' => $this->data['users']->id]);
			$where['barang_kembali.cabang_id'] = $cabang->id;
		}
		$where['barang_kembali.enum'] = 1;
		$where['barang_kembali.is_deleted'] = 0;
		
		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->barang_kembali_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);

		$searchColumn = $this->input->post('columns');
        $isSearchColumn = false;

        if(!empty($searchColumn[0]['search']['value'])){
            $value = $searchColumn[0]['search']['value'];
            $isSearchColumn = true;
            $where['barang_kembali.tanggal'] = $value;
        }
        

        if($isSearchColumn){
			$totalFiltered = $this->barang_kembali_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
			$totalData = $totalFiltered;
        }else{
        	$totalFiltered = $totalData;
        }

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->barang_kembali_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$detail_url = "";
				$add_url = "";

				$detail_url = "<a href='" . base_url() . "barang_kembali/detail/" . $data->id . "' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";
				if($this->data['users_groups']->id == 4){
					if ($data->tanggal == date('Y-m-d')) {
						$add_url = "<a href='".base_url()."barang_kembali/create_more/".$data->id."' class='btn btn-sm btn-success' data-toggle='tooltip' title='Tambah Data' data-placement='bottom'><i class='fa fa-plus fa-w-20'></i></a>";
					}
				}

				$nestedData['id'] = $start + $key + 1;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['jumlah_transaksi'] = $data->jumlah_transaksi;
				$nestedData['total_berat'] = $data->total_berat;
				$nestedData['total_harga_keseluruhan'] = 'Rp. ' . number_format($data->total_harga_keseluruhan);
				$nestedData['action'] = $detail_url.' '.$add_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function dataListAdmin()
	{
		$columns = array(
			0 => 'id',
		);
		$where['barang_kembali.enum'] = 1;
		$where['barang_kembali.is_deleted'] = 0;
		
		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->barang_kembali_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);

		$searchColumn = $this->input->post('columns');
        $isSearchColumn = false;

        if(!empty($searchColumn[0]['search']['value'])){
            $value = $searchColumn[0]['search']['value'];
            $isSearchColumn = true;
            $where['barang_kembali.tanggal'] = $value;
        }
        if(!empty($searchColumn[1]['search']['value'])){
            $value = $searchColumn[1]['search']['value'];
            $isSearchColumn = true;
            $where['barang_kembali.cabang_id'] = $value;
        }
        if(!empty($searchColumn[2]['search']['value'])){
            $value = $searchColumn[2]['search']['value'];
            $isSearchColumn = true;
            if ($value == 2) {
            	$value = 0;
            }
            $where['barang_kembali.status_audit'] = $value;
        }

        if($isSearchColumn){
			$totalFiltered = $this->barang_kembali_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
			$totalData = $totalFiltered;
        }else{
        	$totalFiltered = $totalData;
        }

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->barang_kembali_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$detail_url = "";
				$add_url = "";
				$audit_url = "";

				$detail_url = "<a href='" . base_url() . "barang_kembali/detail/" . $data->id . "' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";
				if ($data->status_audit == 0 && $this->data['users_groups']->id == 3) {
            		$audit_url = "<a href='#' 
	        				url='" . base_url() . "barang_kembali/destroy/" . $data->id . "/" . $data->status_audit . "' class='btn btn-sm btn-danger delete' data-toggle='tooltip' title='Data telah Diaudit' data-placement='bottom'><i class='fa fa-check-circle fa-w-20'></i></a>";
            	}
				// $add_url = "<a href='".base_url()."barang_kembali/create_more/".$data->id."' class='btn btn-sm btn-success' data-toggle='tooltip' title='Tambah Data' data-placement='bottom'><i class='fa fa-plus fa-w-20'></i></a>";

				$nestedData['id'] = $start + $key + 1;
				$nestedData['cabang'] = $data->nama_cabang;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['jumlah_transaksi'] = $data->jumlah_transaksi;
				$nestedData['total_berat'] = $data->total_berat;
				$nestedData['total_harga_keseluruhan'] = 'Rp. ' . number_format($data->total_harga_keseluruhan);
				$nestedData['status_audit'] = $data->status_audit == 0 ? '<b style="color:red;">Belum</b>' : '<b style="color:green;">Selesai</b>';
           		$nestedData['action'] = $detail_url.' '.$add_url.' '.$audit_url;   
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function destroy()
	{
		$response_data = array();
		$response_data['status'] = false;
		$response_data['msg'] = "";
		$response_data['data'] = array();

		$id = $this->uri->segment(3);
		$status_audit = $this->uri->segment(4);
		if (!empty($id)) {
			$this->load->model("barang_kembali_model");
			$data = array(
				'status_audit' => ($status_audit == 1) ? 0 : 1
			);
			$update = $this->barang_kembali_model->update($data, array("id" => $id));

			$response_data['data'] = $data;
			$response_data['status'] = true;
		} else {
			$response_data['msg'] = "ID Harus Diisi";
		}

		echo json_encode($response_data);
	}

	public function hasil_nota(){
		$no_nota = $this->input->get('no_nota');
		$kode_cabang = $this->input->get('kode_cabang');
		$no_nota = $no_nota.'~'.$kode_cabang;
		$where_bk['barang_kembali_detail.no_nota LIKE'] = '%'.$no_nota.'%';
		$bk = $this->barang_kembali_detail_model->getOneBy($where_bk);
		$cabang = $this->cabang_model->getOneBy(['cabang.kode_cabang' => $kode_cabang]);
		if($bk == false){
			$where_penjualan['penjualan_detail.no_nota LIKE'] = '%'.$no_nota.'%';
			$where_penjualan['penjualan_detail.is_deleted'] = 0;
			$penjualan = $this->penjualan_detail_model->getOneBy($where_penjualan);
			if($penjualan != false){
				$data['cabang'] = $cabang->nama_cabang;
				$data['status'] = true;
			}else{
				$where_tukar['tukar_plus_detail.no_nota LIKE'] = '%'.$no_nota.'%';
				$where_tukar['tukar_plus_detail.is_deleted'] = 0;
				$tukar = $this->tukar_plus_detail_model->getOneBy($where_tukar);
				if ($tukar != false) {
					$data['cabang'] = $cabang->nama_cabang;
					$data['status'] = true;
				} else {
					$data['cabang'] = $cabang->nama_cabang;
					$data['status'] = false;
				}
				
			}
				
		}else{
			$data['cabang'] = $cabang->nama_cabang;
			$data['status'] = false;
		}
		echo json_encode($data);
	}

	public function edit_barang_rusak($barang_rusak_id)
	{
		$this->form_validation->set_rules('barang_rusak_id', "barang_rusak_id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$barang_rusak_id = $this->input->post('barang_rusak_id');
			$harga = $this->input->post('harga_barang_kembali');
			
			$get_id = $this->barang_rusak_model->getOneBy(['barang_rusak.id' => $barang_rusak_id]);
			//
			$barang_kembali = $this->barang_kembali_model->getOneBy(['barang_kembali.id' => $get_id->barang_kembali_id]);
			$cabang_id = $barang_kembali->cabang_id;
			//stok opname dulu daks
			// get tukar plus id
			$data_stok = $this->histori_stok_barang_model->getAllById(['cabang_id' => $cabang_id]);
			$cek_jenis_barang = $this->barang_model->getOneBy(['id' => $get_id->barang_id]);
			/*
				kembaliin dulu data sebelumnya
			*/
			// perhitungan stok opname
			$berat_lama = $get_id->berat;
			$berat_baru = $this->input->post('berat');
			// get histori barang
			$cek_histori = $this->histori_stok_barang_model->getOneBy(['cabang_id' => $cabang_id, 'tanggal' => $barang_kembali->tanggal]);
			if($cek_jenis_barang->jenis == '925'){
				//histori stok kembaliin data sebelumnya
				$stok_925_reparasi = $cek_histori->stok_925_reparasi - $berat_lama;
			    $data_histori = array(
			    	'stok_925_reparasi' => $stok_925_reparasi,
			    );
			    //berat baru
			    $stok_925_reparasi_edit = $stok_925_reparasi + $berat_baru;
			    $data_histori_edit = array(
			    	'stok_925_reparasi' => $stok_925_reparasi_edit,
			    );
			}else{
				//histori stok kembaliin data sebelumnya
				$stok_sp_reparasi = $cek_histori->stok_sp_reparasi - $berat_lama;
			    $data_histori = array(
			    	'stok_sp_reparasi' => $stok_sp_reparasi,
			    );
			    //berat baru
			    $stok_sp_reparasi_edit = $stok_sp_reparasi + $berat_baru;
			    $data_histori_edit = array(
			    	'stok_sp_reparasi' => $stok_sp_reparasi_edit,
			    );
			}
			$where_update_stok['cabang_id'] = $cabang_id;
			$where_update_stok['tanggal'] = $barang_kembali->tanggal;
			$update_stok_histori = $this->histori_stok_barang_model->update($data_histori, $where_update_stok);
			$update_stok_histori_edit = $this->histori_stok_barang_model->update($data_histori_edit, $where_update_stok);

			// edit di tukar plus
			$data_rusak = array(
				'berat' => $this->input->post('berat'),
				'potongan_rusak' => $this->input->post('potongan_rusak'),
				'harga' => $harga,
				'updated_by' => $this->data['users']->id
			);
			$update = $this->barang_rusak_model->update($data_rusak, array("id" => $barang_rusak_id));
			
			if ($update) {
				$this->session->set_flashdata('message', "Data Barang Rusak Berhasil Diedit");
				redirect("barang_kembali/detail/".$get_id->barang_kembali_id);
			} else {
				$this->session->set_flashdata('message_error', "Data Barang Rusak Gagal Diedit");
				redirect("barang_kembali/detail/".$get_id->barang_kembali_id);
			}
		} else {
			if ($this->data['is_can_edit']) {
				$this->data['barang_rusak_id'] = $barang_rusak_id;
				$this->data['data'] = $this->barang_rusak_model->getOneBy(array("barang_rusak.id" => $barang_rusak_id));
				$this->data['bk'] = $this->barang_kembali_detail_model->getOneBy(array("barang_kembali_detail.no_nota" => $this->data['data']->no_nota));

				$this->data['barang'] = $this->barang_model->getAllById(); 
				$this->data['enum_transaksi'] = $this->enum_transaksi_barang_model->getAllById(['jenis_transaksi' => 'barang_kembali']); 
				$this->data['content'] = 'admin/barang_kembali/edit_barang_rusak_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function edit_barang_hilang($barang_hilang_id)
	{
		$this->form_validation->set_rules('barang_hilang_id', "barang_hilang_id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$barang_hilang_id = $this->input->post('barang_hilang_id');
			$harga = $this->input->post('harga_barang_kembali');
			
			$get_id = $this->barang_hilang_model->getOneBy(['barang_hilang.id' => $barang_hilang_id]);
			//
			$barang_kembali = $this->barang_kembali_model->getOneBy(['barang_kembali.id' => $get_id->barang_kembali_id]);
			$cabang_id = $barang_kembali->cabang_id;
			//stok opname dulu daks
			// get tukar plus id
			$data_stok = $this->histori_stok_barang_model->getAllById(['cabang_id' => $cabang_id]);
			$cek_jenis_barang = $this->barang_model->getOneBy(['id' => $get_id->barang_id]);
			/*
				kembaliin dulu data sebelumnya
			*/
			// perhitungan stok opname
			$berat_lama = $get_id->berat;
			$berat_baru = $this->input->post('berat_barang_hilang');
			// get histori barang
			$cek_histori = $this->histori_stok_barang_model->getOneBy(['cabang_id' => $cabang_id, 'tanggal' => $barang_kembali->tanggal]);
			if($cek_jenis_barang->jenis == '925'){
				//histori stok kembaliin data sebelumnya
				$stok_925_retur = $cek_histori->stok_925_retur - $berat_lama;
			    $data_histori = array(
			    	'stok_925_retur' => $stok_925_retur,
			    );
			    //berat baru
			    $stok_925_retur_edit = $stok_925_retur + $berat_baru;
			    $data_histori_edit = array(
			    	'stok_925_retur' => $stok_925_retur_edit,
			    );
			}else{
				//histori stok kembaliin data sebelumnya
				$stok_sp_retur = $cek_histori->stok_sp_retur - $berat_lama;
			    $data_histori = array(
			    	'stok_sp_retur' => $stok_sp_retur,
			    );
			    //berat baru
			    $stok_sp_retur_edit = $stok_sp_retur + $berat_baru;
			    $data_histori_edit = array(
			    	'stok_sp_retur' => $stok_sp_retur_edit,
			    );
			}
			$where_update_stok['cabang_id'] = $cabang_id;
			$where_update_stok['tanggal'] = $barang_kembali->tanggal;
			$update_stok_histori = $this->histori_stok_barang_model->update($data_histori, $where_update_stok);
			$update_stok_histori_edit = $this->histori_stok_barang_model->update($data_histori_edit, $where_update_stok);
			//
			$data_hilang = array(
				'potongan_hilang' => $this->input->post('potongan_hilang'),
				'berat' => $this->input->post('berat_barang_hilang'),
				'harga' => $harga,
				'updated_by' => $this->data['users']->id
			);
			$update = $this->barang_hilang_model->update($data_hilang, array("id" => $barang_hilang_id));
			
			if ($update) {
				$this->session->set_flashdata('message', "Data Barang Rusak Berhasil Diedit");
				redirect("barang_kembali/detail/".$get_id->barang_kembali_id);
			} else {
				$this->session->set_flashdata('message_error', "Data Barang Rusak Gagal Diedit");
				redirect("barang_kembali/detail/".$get_id->barang_kembali_id);
			}
		} else {
			if ($this->data['is_can_edit']) {
				$this->data['barang_hilang_id'] = $barang_hilang_id;
				$this->data['data'] = $this->barang_hilang_model->getOneBy(array("barang_hilang.id" => $barang_hilang_id));
				$this->data['bk'] = $this->barang_kembali_detail_model->getOneBy(array("barang_kembali_detail.no_nota" => $this->data['data']->no_nota));

				$this->data['barang'] = $this->barang_model->getAllById(); 
				$this->data['enum_transaksi'] = $this->enum_transaksi_barang_model->getAllById(['jenis_transaksi' => 'barang_kembali']); 
				$this->data['content'] = 'admin/barang_kembali/edit_barang_hilang_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function edit($barang_kembali_detail_id)
	{
		$this->form_validation->set_rules('barang_kembali_detail_id', "barang_kembali_detail_id Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$barang_kembali_detail_id = $this->input->post('barang_kembali_detail_id');
			$harga_jenis = $this->input->post('harga_jenis');
			$potongan = $this->input->post('potongan');
			$harga_enum = $harga_jenis - $potongan;
			// penentuan jenis transaksi
			$enum_transaksi = $this->enum_transaksi_barang_model->getOneBy(['harga' => $harga_enum, 'jenis_transaksi' => 'barang_kembali']);
			// get data
			$bk = $this->barang_kembali_detail_model->getOneBy(['barang_kembali_detail.id' => $barang_kembali_detail_id]);

			$update_bk = array(
				'jenis_transaksi_id' => $enum_transaksi->id,
				'potongan' => $this->input->post('potongan'),
				'harga' => $this->input->post('harga_barang_kembali'),
			);
			// $harga = $this->input->post('harga_barang_kembali');
			$update = $this->barang_kembali_detail_model->update($update_bk,array("barang_kembali_detail.id" => $barang_kembali_detail_id));
			
			$cek_detail = $this->barang_kembali_detail_model->getAllById(['barang_kembali_detail.barang_kembali_id' => $barang_kembali_detail_id]);
			
			// penjualan 
			// $penjualan = $this->barang_kembali_detail_model->getAllById(array("barang_kembali_detail.id" => $barang_kembali_detail_id));
			if (!empty($cek_detail)) {
				$total_berat = 0.0;
				$total_harga_keseluruhan = 0;
				$jumlah_transaksi = count($cek_detail);
				foreach ($cek_detail as $key => $value) {
					$total_berat += $value->berat;
					$total_harga_keseluruhan += $value->harga;
				}
				$data_update = array(
					'jumlah_transaksi' 					=> $jumlah_transaksi,
					'total_berat' 					=> $total_berat,
					'total_harga_keseluruhan'			=> $total_harga_keseluruhan,
					'updated_by' => $this->data['users']->id

				); 
				$update = $this->barang_kembali_model->update($data_update,array("barang_kembali.id" => $bk->barang_kembali_id));
			}
			
			if ($update) {
				$this->session->set_flashdata('message', "Data Barang Rusak Berhasil Diedit");
				redirect("barang_kembali/detail/".$bk->barang_kembali_id);
			} else {
				$this->session->set_flashdata('message_error', "Data Barang Rusak Gagal Diedit");
				redirect("barang_kembali/detail/".$bk->barang_kembali_id);
			}
		} else {
			if ($this->data['is_can_edit']) {
				$this->data['barang_kembali_detail_id'] = $barang_kembali_detail_id;
				$this->data['bk'] = $this->barang_kembali_detail_model->getOneBy(array("barang_kembali_detail.id" => $barang_kembali_detail_id));

				$this->data['barang'] = $this->barang_model->getAllById(); 
				$this->data['penjualan'] = $this->penjualan_detail_model->getOneBy(array("penjualan_detail.no_nota" => $this->data['bk']->no_nota));
				$this->data['enum_transaksi'] = $this->enum_transaksi_barang_model->getOneBy(['id' => $this->data['penjualan']->jenis_transaksi_id]);
				//penjualan
				// print_r($this->data['enum_transaksi']);
				// die();
				$this->data['content'] = 'admin/barang_kembali/edit_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}


}
