<?php
defined('BASEPATH') OR exit('No direct script access allowed');
require_once APPPATH.'core/Admin_Controller.php';
class Nota_kantor extends Admin_Controller {
 	public function __construct()
	{
		parent::__construct(); 
	 	$this->load->model('nota_model');
	 	$this->load->model('cabang_model');
	 	$this->load->model('pemesanan_nota_model');
	 	$this->load->model('pemesanan_nota_detail_model');
	}

	public function index()
	{
		$this->load->helper('url');
		if($this->data['is_can_read']){
			$this->data['content'] = 'admin/nota_kantor/list_v'; 	
		}else{
			$this->data['content'] = 'errors/html/restrict'; 
		}
		
		$this->load->view('admin/layouts/page',$this->data);  
	}

	

	public function edit()
	{ 
		$this->form_validation->set_rules('kode_nota', "kode_nota Is Required", 'trim|required'); 
		   
		if ($this->form_validation->run() === TRUE)
		{
		 	$id = $this->input->post('id');
			$data = array(
				'kode_nota' => $this->input->post('kode_nota'),
				'nama_nota' => $this->input->post('nama_nota'),
				'stok' => $this->input->post('stok'),
				'updated_by' => $this->data['users']->id
			); 
			$update = $this->nota_model->update($data,array("id"=>$this->input->post('id')));
			if ($update)
			{ 
				$this->session->set_flashdata('message', "Data nota Berhasil Diedit");
				redirect("nota");
			}
			else
			{
				$this->session->set_flashdata('message_error',"Data nota Gagal Diedit");
				redirect("nota");
			}
		} 
		else
		{
			if(!empty($_POST)){ 
				$id = $this->input->post('id'); 
				$this->session->set_flashdata('message_error',validation_errors());
				return redirect("nota_kantor/edit/".$id);	
			}else{
				if($this->data['is_can_edit']){    
					$this->data['id']= $this->uri->segment(3);
					$this->data['nota'] = $this->nota_model->getOneBy(array("nota.id"=>$this->data['id']));
					$this->data['content'] = 'admin/nota_kantor/edit_v';
		        }else{
		            $this->data['content']  = 'errors/html/restrict'; 
		        } 
		        $this->load->view('admin/layouts/page',$this->data);
			}  
		}    
		
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
			1 => 'cabang.kode_cabang',
			2 => 'cabang.nama_cabang',
			3 => 'cabang.alamat',
			4 => 'action'
		);

		$where = array();
		// if(!$this->data['is_superadmin']){
		// 	$where['cabang.office_id'] = $this->data['users']->office_id;
		// }

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->cabang_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		if (!empty($this->input->post('search')['value'])) {
			$search_value = $this->input->post('search')['value'];
			$search = array(
				"cabang.kode_cabang" => $search_value,
				"cabang.nama_cabang" => $search_value,
				"cabang.alamat" => $search_value,
			);
			$totalFiltered = $this->cabang_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->cabang_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$tambah_url = "";
				if ($this->data['is_can_edit'] && $data->is_deleted == 0) {
					$tambah_url = "<a href='" . base_url() . "nota_kantor/pemesanan/" . $data->id . "' class='btn btn-sm btn-primary' data-toggle='tooltip' title='Tambah Pemesanan Nota' data-placement='bottom'><i class='fa fa-plus fa-w-20'></i></a>";
				}
				$nestedData['id'] = $start + $key + 1;
				$nestedData['kode_cabang'] = $data->kode_cabang;
				$nestedData['nama_cabang'] = $data->nama_cabang;
				$nestedData['action'] = $tambah_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function pemesanan($id)
	{
		$this->load->helper('url');
		if($this->data['is_can_read']){
			$this->data['cabang_id'] = $id;
			$where['cabang.id'] = $id;
			$this->data['cabang'] = $this->cabang_model->getOneBy($where); 	
			$this->data['content'] = 'admin/nota_kantor/list_pemesanan_v'; 	
		}else{
			$this->data['content'] = 'errors/html/restrict'; 
		}
		
		$this->load->view('admin/layouts/page',$this->data);  
	}

	public function pemesanan_create($cabang_id)
	{ 
		$this->form_validation->set_rules('cabang_id',"cabang_id Is Required", 'trim|required');
		 
		if ($this->form_validation->run() === TRUE)
		{ 
			$cabang_id = $this->input->post('cabang_id');
			$tanggal = $this->input->post('tanggal');
			$angka_awal = $this->input->post('angka_awal');
			$angka_akhir = $this->input->post('angka_akhir');
			$huruf_nota = $this->input->post('huruf_nota');
			$jenis_nota = $this->input->post('jenis_nota');

			// insert pemesanan nota
			$data = array(
				'tanggal' => $tanggal,
				'cabang_id' => $cabang_id,
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			); 
			$insert_pemesanan = $this->pemesanan_nota_model->insert($data);
			// insert pemesanan nota detail
			$jenis_nota = $this->input->post('jenis_nota');
			$data_detail = array(
				'pemesanan_nota_id' => $insert_pemesanan,
				'huruf_nota' => $huruf_nota,
				'angka_awal' => $angka_awal,
				'angka_akhir' => $angka_akhir,
				'cabang_id' => $cabang_id,
				'jenis_nota' => $jenis_nota,
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			); 
			$insert_pemesanan_detail = $this->pemesanan_nota_detail_model->insert($data_detail);
			// insert nota berdasrakan awal dan akhir
			// get kode cabang
			$data_cabang = $this->cabang_model->getOneBy(['cabang.id' => $cabang_id]);
			$tanggal = date('my', strtotime($tanggal));
			$data_nota = [];
			if ($jenis_nota == 0) {
				for ($i = $angka_awal; $i <= $angka_akhir; $i++) {
					$data_nota[] = [
						'cabang_id' => $cabang_id,
						'pemesanan_nota_detail_id' => $insert_pemesanan_detail,
						'no_nota' => $huruf_nota.' NO '.$i.'~'.$data_cabang->kode_cabang,
						'jenis_nota' => $jenis_nota,
						'huruf_nota' => $huruf_nota,
						'status' => 0,
						// 'status_stok_nota' => 1,
						'pemesanan_nota_id' => $insert_pemesanan,
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					];
				}
			} else {
				for ($i = $angka_awal; $i <= $angka_akhir; $i++) {
					$data_nota[] = [
						'cabang_id' => $cabang_id,
						'pemesanan_nota_detail_id' => $insert_pemesanan_detail,
						'no_nota' => $huruf_nota.' NO '.$i.'~'.$data_cabang->kode_cabang,
						'jenis_nota' => $jenis_nota,
						'huruf_nota' => $huruf_nota,
						'pemesanan_nota_id' => $insert_pemesanan,
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					];
				}
			}
			
			$insert_nota = $this->db->insert_batch('nota', $data_nota);
			
			if ($insert_nota)
			{ 
				$this->session->set_flashdata('message', "Data nota Baru Berhasil Disimpan");
				redirect("nota_kantor/pemesanan_create_more/".$insert_pemesanan);
			}
			else
			{
				$this->session->set_flashdata('message_error',"Data nota Baru Gagal Disimpan");
				redirect("nota");
			}
		}else{  
			if($this->data['is_can_create']){ 
				$this->data['cabang_id'] = $cabang_id; 
				$this->data['content'] = 'admin/nota_kantor/pemesanan_create_v'; 
	        }else{
	            $this->data['content']  = 'errors/html/restrict'; 
	        } 
	        $this->load->view('admin/layouts/page',$this->data);
		}
	} 

	public function pemesanan_create_more($pemesanan_nota_id)
	{ 
		$this->form_validation->set_rules('pemesanan_nota_id',"pemesanan_nota_id Is Required", 'trim|required');
		 
		if ($this->form_validation->run() === TRUE)
		{ 
			$pemesanan_nota_id = $this->input->post('pemesanan_nota_id');
			$data_pemesanan = $this->pemesanan_nota_model->getOneBy(['pemesanan_nota.id' => $pemesanan_nota_id]);
			$tanggal = $this->input->post('tanggal');
			$angka_awal = $this->input->post('angka_awal');
			$angka_akhir = $this->input->post('angka_akhir');
			$huruf_nota = $this->input->post('huruf_nota');
			$jenis_nota = $this->input->post('jenis_nota');

			// insert pemesanan nota detail
			$jenis_nota = $this->input->post('jenis_nota');
			$data_detail = array(
				'pemesanan_nota_id' => $pemesanan_nota_id,
				'huruf_nota' => $huruf_nota,
				'angka_awal' => $angka_awal,
				'angka_akhir' => $angka_akhir,
				'jenis_nota' => $jenis_nota,
				'cabang_id' => $data_pemesanan->cabang_id,
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			); 
			$insert_pemesanan_detail = $this->pemesanan_nota_detail_model->insert($data_detail);
			// insert nota berdasrakan awal dan akhir
			// get kode cabang
			$data_cabang = $this->cabang_model->getOneBy(['cabang.id' => $data_pemesanan->cabang_id]);
			$tanggal = date('my', strtotime($tanggal));
			$data_nota = [];
			if ($jenis_nota == 0) {
				for ($i = $angka_awal; $i <= $angka_akhir; $i++) {
					$data_nota[] = [
						'cabang_id' => $data_pemesanan->cabang_id,
						'pemesanan_nota_detail_id' => $insert_pemesanan_detail,
						'no_nota' => $huruf_nota.' NO '.$i.'~'.$data_cabang->kode_cabang,
						'jenis_nota' => $jenis_nota,
						'huruf_nota' => $huruf_nota,
						'status' => 0,
						// 'status_stok_nota' => 1,
						'pemesanan_nota_id' => $pemesanan_nota_id,
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					];
				}
			}else{
				for ($i = $angka_awal; $i <= $angka_akhir; $i++) {
					$data_nota[] = [
						'pemesanan_nota_detail_id' => $insert_pemesanan_detail,
						'cabang_id' => $data_pemesanan->cabang_id,
						'no_nota' => $huruf_nota.' NO '.$i.'~'.$data_cabang->kode_cabang,
						'jenis_nota' => $jenis_nota,
						'huruf_nota' => $huruf_nota,
						'pemesanan_nota_id' => $pemesanan_nota_id,
						'created_by' => $this->data['users']->id,
						'updated_by' => $this->data['users']->id
					];
				}
			}
			$insert_nota = $this->db->insert_batch('nota', $data_nota);
			
			if ($insert_nota)
			{ 
				$this->session->set_flashdata('message', "Data nota Baru Berhasil Disimpan");
				redirect("nota_kantor/pemesanan_create_more/".$pemesanan_nota_id);
			}
			else
			{
				$this->session->set_flashdata('message_error',"Data nota Baru Gagal Disimpan");
				redirect("nota");
			}
		}else{  
			if($this->data['is_can_create']){ 
				$this->data['pemesanan_nota_id'] = $pemesanan_nota_id; 
				$this->data['pemesanan'] = $this->pemesanan_nota_model->getOneBy(['pemesanan_nota.id' => $pemesanan_nota_id]);
				$this->data['pemesanan_detail'] = $this->pemesanan_nota_detail_model->getAllById(['pemesanan_nota_id' => $pemesanan_nota_id]);
				$this->data['content'] = 'admin/nota_kantor/pemesanan_create_more_v'; 
	        }else{
	            $this->data['content']  = 'errors/html/restrict'; 
	        } 
	        $this->load->view('admin/layouts/page',$this->data);
		}
	} 

	public function dataListPemesanan()
	{
		$columns = array(
			0 => 'id',
			1 => 'cabang.kode_cabang',
			2 => 'cabang.nama_cabang',
			3 => 'cabang.alamat',
			4 => 'action'
		);

		$where = array();
		$cabang_id = $this->uri->segment(3);
		$where['pemesanan_nota.cabang_id'] = $cabang_id;
		// if(!$this->data['is_superadmin']){
		// 	$where['cabang.office_id'] = $this->data['users']->office_id;
		// }

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->pemesanan_nota_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		if (!empty($this->input->post('search')['value'])) {
			$search_value = $this->input->post('search')['value'];
			$search = array(
				"cabang.kode_cabang" => $search_value,
				"cabang.nama_cabang" => $search_value,
				"cabang.alamat" => $search_value,
			);
			$totalFiltered = $this->pemesanan_nota_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->pemesanan_nota_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$detail_url = "";
				$add_url = "";
     			
            	$add_url = "<a href='".base_url()."nota_kantor/pemesanan_create_more/".$data->id."' class='btn btn-sm btn-success' data-toggle='tooltip' title='Tambah Data' data-placement='bottom'><i class='fa fa-plus fa-w-20'></i></a>";
            	$detail_url = "<a href='".base_url()."nota_kantor/detail/".$data->id."' class='btn btn-sm btn-info' data-toggle='tooltip' title='Detail Data' data-placement='bottom'><i class='fa fa-info-circle fa-w-20'></i></a>";
				$nestedData['id'] = $start + $key + 1;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['action'] = $detail_url.' '.$add_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function detail($pemesanan_nota_id)
	{
		$this->load->helper('url');
		if($this->data['is_can_read']){
			$this->data['pemesanan_nota_id'] = $pemesanan_nota_id; 	
			$this->data['content'] = 'admin/nota_kantor/list_nota_v'; 	
		}else{
			$this->data['content'] = 'errors/html/restrict'; 
		}
		
		$this->load->view('admin/layouts/page',$this->data);  
	}

	public function dataListNota()
	{
		$columns = array(
			0 => 'id',
			1 => 'cabang.kode_cabang',
			2 => 'cabang.nama_cabang',
			3 => 'cabang.alamat',
			4 => 'action'
		);

		$where = array();
		$pemesanan_nota_id = $this->uri->segment(3);
		$where['nota.pemesanan_nota_id'] = $pemesanan_nota_id;
		$where['nota.status_stok_nota'] = 0;
		// if(!$this->data['is_superadmin']){
		// 	$where['cabang.office_id'] = $this->data['users']->office_id;
		// }

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->nota_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		$searchColumn = $this->input->post('columns');
        $isSearchColumn = false;

        if(!empty($searchColumn[0]['search']['value'])){
            $value = $searchColumn[0]['search']['value'];
            $isSearchColumn = true;
            $where['nota.huruf_nota'] = $value;
        }
        if(!empty($searchColumn[1]['search']['value'])){
            $value = $searchColumn[1]['search']['value'];
            $isSearchColumn = true;
            if ($value == 'pembukuan') {
            	$where['nota.jenis_nota'] = 0;
            } else {
            	$where['nota.jenis_nota'] = $value;
            }
            
            
        }
        
        if($isSearchColumn){
			$totalFiltered = $this->nota_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
			$totalData = $totalFiltered;
        }else{
        	$totalFiltered = $totalData;
        }

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->nota_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$nestedData['id'] = $start + $key + 1;
				$nestedData['no_nota'] = $data->no_nota;
				$nestedData['jenis_nota'] = $data->jenis_nota == 0 ? 'Pembukuan' : 'Transaksi Cabang';
				if ($data->status == 0) {
					$nestedData['status'] = 'Nota Baru';
				}elseif ($data->status == 1) {
					$nestedData['status'] = 'Nota Sudah Terjual';
				}elseif ($data->status == 2) {
					$nestedData['status'] = 'Nota Sudah Kembali';
				}elseif ($data->status == 3) {
					$nestedData['status'] = 'Nota Batal';
				}elseif ($data->status == 4) {
					$nestedData['status'] = 'Nota Tukar Plus';
				}elseif ($data->status == 5) {
					$nestedData['status'] = 'Nota Tukar Min';
				}elseif ($data->status == 6) {
					$nestedData['status'] = 'Nota Hilang 2R';
				}elseif ($data->status == 7) {
					$nestedData['status'] = 'Nota Hilang 3R';
				}elseif ($data->status == 8) {
					$nestedData['status'] = 'Nota Pembukuan Penjualan';
				}

				
				
				// $nestedData['action'] = $detail_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function get_nota(){

		$huruf_nota = $this->input->post('huruf_nota');
		$cabang_id = $this->input->post('cabang_id');
		$where['cabang_id'] = $cabang_id;
		$where['jenis_nota'] = 0;
		if (!$this->data['is_superadmin']) {
			$cabang = $this->cabang_model->getOneBy(['users_id' => $this->data['users']->id]);
			$where['cabang_id'] = $cabang->id;
			$where['jenis_nota'] = 1;
		}
		$where['huruf_nota'] = $huruf_nota;
		$where['status'] = 0;
		$data_nota = $this->nota_model->getOneBy($where);
		if($data_nota){
			$data['status'] = true;
			if (!$this->data['is_superadmin']) {
				$no_nota = explode('~', $data_nota->no_nota);
				$data['no_nota_view'] = $no_nota[0];
				$data['no_nota'] = $data_nota->no_nota;
			} else {
				$data['no_nota'] = $data_nota->no_nota;
			}
			
		}else{
			$data['status'] = false;
		}
		echo json_encode($data);
	}

	public function get_nota_pembukuan_bk(){
		$cabang_id = $this->input->get('cabang_id');
		$where_nota['nota.cabang_id'] = $cabang_id;
		$where_nota['nota.status'] = 1;
		$where_nota['nota.huruf_nota !='] = 'G';
		$where_nota['nota.jenis_nota'] = 0;
		$nota_pembukuan = $this->nota_model->getAllById($where_nota);
		$data = array();
		if($nota_pembukuan){
			$data['status'] = true;
			$data['data'] = $nota_pembukuan;
			$data['message'] = "Berhasil Ambil data nota pembukuan";
		}else{
			$data['status'] = false;
			$data['data'] = [];
			$data['message'] = "Gagal Ambil data nota pembukuan";
		}
		echo json_encode($data);
	}

	public function get_nota_pembukuan_penjualan(){
		$cabang_id = $this->input->get('cabang_id');
		$huruf_nota = $this->input->get('huruf_nota');
		$where_nota['nota.huruf_nota'] = $huruf_nota;
		$where_nota['nota.cabang_id'] = $cabang_id;
		$where_nota['nota.status'] = 0;
		// $where_nota['nota.huruf_nota !='] = 'G';
		$where_nota['nota.jenis_nota'] = 0;
		$nota_pembukuan = $this->nota_model->getAllById($where_nota);
		$data = array();
		if($nota_pembukuan){
			$data['status'] = true;
			$data['data'] = $nota_pembukuan;
			$data['message'] = "Berhasil Ambil data nota pembukuan";
		}else{
			$data['status'] = false;
			$data['data'] = [];
			$data['message'] = "Gagal Ambil data nota pembukuan";
		}
		echo json_encode($data);
	}

	public function get_nota_pembukuan_tukar(){
		$cabang_id = $this->input->get('cabang_id');
		$where_nota['nota.cabang_id'] = $cabang_id;
		$where_nota['nota.status'] = 0;
		$where_nota['nota.huruf_nota'] = 'G';
		$where_nota['nota.jenis_nota'] = 0;
		$nota_pembukuan = $this->nota_model->getAllById($where_nota);
		$data = array();
		if($nota_pembukuan){
			$data['status'] = true;
			$data['data'] = $nota_pembukuan;
			$data['message'] = "Berhasil Ambil data nota pembukuan";
		}else{
			$data['status'] = false;
			$data['data'] = [];
			$data['message'] = "Gagal Ambil data nota pembukuan";
		}
		echo json_encode($data);
	}

	// public function pemesanan_edit($pemesanan_detail_id){
	// 	echo $pemesanan_detail_id;
	// }
	public function pemesanan_edit()
	{
		$this->form_validation->set_rules('huruf_nota', "huruf_nota Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$id = $this->input->post('id');
			$angka_awal = $this->input->post('angka_awal');
			$angka_akhir = $this->input->post('angka_akhir');
			$huruf_nota = $this->input->post('huruf_nota');
			$jenis_nota = $this->input->post('jenis_nota');
			$jenis_nota = $this->input->post('jenis_nota');

			// insert pemesanan nota detail
			$data_detail = array(
				'huruf_nota' => $huruf_nota,
				'angka_awal' => $angka_awal,
				'angka_akhir' => $angka_akhir,
				'jenis_nota' => $jenis_nota,
				'updated_by' => $this->data['users']->id
			); 
			$update = $this->pemesanan_nota_detail_model->update($data_detail, array("id" => $id));

			$pemesanan_detail = $this->pemesanan_nota_detail_model->getOneBy(array("id" => $id));
			$pemesanan = $this->pemesanan_nota_model->getOneBy(['id' => $pemesanan_detail->pemesanan_nota_id]);
			$tanggal = date('my', strtotime($pemesanan->tanggal));
				if ($update) {
					$data_cabang = $this->cabang_model->getOneBy(['cabang.id' => $pemesanan->cabang_id]);
					//delete nota lama
					$delete = $this->nota_model->delete(['pemesanan_nota_detail_id' => $id]);
					if ($delete) {
						$data_nota = [];
						for ($i = $angka_awal; $i <= $angka_akhir; $i++) {
							$data_nota[] = [
								'cabang_id' => $pemesanan->cabang_id,
								'pemesanan_nota_detail_id' => $id,
								'no_nota' => $huruf_nota.' NO '.$i.'~'.$data_cabang->kode_cabang,
								'jenis_nota' => $jenis_nota,
								'huruf_nota' => $huruf_nota,
								'pemesanan_nota_id' => $pemesanan->id,
								'created_by' => $this->data['users']->id,
								'updated_by' => $this->data['users']->id
							];
						}
						$insert_nota = $this->db->insert_batch('nota', $data_nota);
					}
				
				}
			if ($update) {
				$this->session->set_flashdata('message', "Data pemesanan nota Berhasil Diedit");
				redirect("nota_kantor/pemesanan_create_more/".$pemesanan->id);
			} else {
				$this->session->set_flashdata('message_error', "Data pemesanan nota Gagal Diedit");
				redirect("nota_kantor/pemesanan_create_more/".$pemesanan->id);
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("cabang/edit/" . $id);
			} else {
				$this->data['id'] = $this->uri->segment(3);
				// echo $this->data['id'];
				// die();
				$this->data['detail'] = $this->pemesanan_nota_detail_model->getOneBy(array("id" => $this->data['id']));
				$this->data['data'] = $this->pemesanan_nota_model->getOneBy(['id' => $this->data['detail']->pemesanan_nota_id]);
				$this->data['content'] = 'admin/nota_kantor/pemesanan_edit_v';
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function delete($pemesanan_detail_id)
	{
		$pemesanan_detail = $this->pemesanan_nota_detail_model->getOneBy(array("id" => $pemesanan_detail_id));
		$pemesanan = $this->pemesanan_nota_model->getOneBy(['id' => $pemesanan_detail->pemesanan_nota_id]);
		
		if ($pemesanan_detail) {
			$delete_nota = $this->nota_model->delete(['nota.pemesanan_nota_detail_id' => $pemesanan_detail_id]);
			$delete_detail = $this->pemesanan_nota_detail_model->delete(['pemesanan_nota_detail.id' => $pemesanan_detail_id]);
			if ($delete_nota && $delete_detail) {
				$this->session->set_flashdata('message', "Data Pemesanan dan Nota Berhasil Dihapus");
				redirect("nota_kantor/pemesanan_create_more/".$pemesanan->id);
			} else {
				$this->session->set_flashdata('message', "Data Pemesanan dan Nota Gagal Dihapus");
				redirect("nota_kantor/pemesanan_create_more/".$pemesanan->id);
			}
			
		} else {
			$this->session->set_flashdata('message_error', "Delete Nota Gagal");
			redirect("nota_kantor/pemesanan_create_more/".$pemesanan->id);
			
		}
	}

}
