<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Sepuhan extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('sepuhan_model');
	}

	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$this->data['content'] = 'admin/sepuhan/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function create()
	{
		$this->form_validation->set_rules('tanggal', "tanggal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$data = array(
				'tanggal' => $this->input->post('tanggal'),
				'nama_cabang' => $this->input->post('nama_cabang'),
				'nama_barang' => $this->input->post('nama_barang'),
				'stok' => $this->input->post('stok'),
				'harga' => $this->input->post('harga'),
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			$insert = $this->sepuhan_model->insert($data);

			if ($insert) {
				$this->session->set_flashdata('message', "Data sepuhan Baru Berhasil Disimpan");
				redirect("sepuhan");
			} else {
				$this->session->set_flashdata('message_error', "Data sepuhan Baru Gagal Disimpan");
				redirect("sepuhan");
			}
		} else {
			if ($this->data['is_can_create']) {
				$this->data['content'] = 'admin/sepuhan/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function edit()
	{
		$this->form_validation->set_rules('tanggal', "tanggal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$id = $this->input->post('id');
			$data = array(
				'tanggal' => $this->input->post('tanggal'),
				'nama_cabang' => $this->input->post('nama_cabang'),
				'nama_barang' => $this->input->post('nama_barang'),
				'stok' => $this->input->post('stok'),
				'harga' => $this->input->post('harga'),
				'updated_by' => $this->data['users']->id
			);
			$update = $this->sepuhan_model->update($data, array("id" => $this->input->post('id')));
			if ($update) {
				$this->session->set_flashdata('message', "Data sepuhan Berhasil Diedit");
				redirect("sepuhan");
			} else {
				$this->session->set_flashdata('message_error', "Data sepuhan Gagal Diedit");
				redirect("sepuhan");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("sepuhan/edit/" . $id);
			} else {
				if ($this->data['is_can_edit']) {
					$this->data['id'] = $this->uri->segment(3);
					$this->data['sepuhan'] = $this->sepuhan_model->getOneBy(array("sepuhan.id" => $this->data['id']));
					$this->data['content'] = 'admin/sepuhan/edit_v';
				} else {
					$this->data['content']  = 'errors/html/restrict';
				}
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function detail()
	{
		$this->data['id'] = $this->uri->segment(3);
		$this->data['sepuhan'] = $this->sepuhan_model->getOneBy(array("sepuhan.id" => $this->data['id']));

		$this->data['content'] = 'admin/sepuhan/detail_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
			1 => 'sepuhan.tanggal',
			2 => 'sepuhan.nama_cabang',
			3 => 'sepuhan.nama_barang',
			4 => 'sepuhan.stok',
			5 => 'sepuhan.harga',
			4 => 'action'
		);

		$where = array();
		// if(!$this->data['is_superadmin']){
		// 	$where['sepuhan.office_id'] = $this->data['users']->office_id;
		// }

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->sepuhan_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		if (!empty($this->input->post('search')['value'])) {
			$search_value = $this->input->post('search')['value'];
			$search = array(
				"sepuhan.tanggal" => $search_value,
				"sepuhan.nama_cabang" => $search_value,
				"sepuhan.nama_barang" => $search_value,
				"sepuhan.stok" => $search_value,
				"sepuhan.harga" => $search_value
			);
			$totalFiltered = $this->sepuhan_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->sepuhan_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$edit_url = "";
				$delete_url = "";
				if ($this->data['is_can_edit'] && $data->is_deleted == 0) {
					// $edit_url = "<a href='".base_url()."sepuhan/edit/".$data->id."' class='btn btn-sm btn-info'>Ubah</a>";
					$edit_url = "<a href='" . base_url() . "sepuhan/edit/" . $data->id . "' class='btn btn-sm btn-warning' data-toggle='tooltip' title='Edit Data' data-placement='bottom'><i class='fa fa-edit fa-w-20'></i></a>";
				}
				if ($this->data['is_can_edit']) {
					if ($data->is_deleted == 0) {
						$delete_url = "<a href='#' 
	        				url='" . base_url() . "sepuhan/destroy/" . $data->id . "/" . $data->is_deleted . "' class='btn btn-sm btn-danger delete' data-toggle='tooltip' title='Non Aktifkan Data' data-placement='bottom'><i class='fa fa-times fa-w-20'></i></a>";
					} else {
						$delete_url = "<a href='#' 
	        				url='" . base_url() . "sepuhan/destroy/" . $data->id . "/" . $data->is_deleted . "' class='btn btn-sm btn-success delete' data-toggle='tooltip' title='Aktifkan Data' data-placement='bottom'><i class='fa fa-check fa-w-20'></i></a>";
					}
				}

				$nestedData['id'] = $start + $key + 1;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['nama_cabang'] = $data->nama_cabang;
				$nestedData['nama_barang'] = $data->nama_barang;
				$nestedData['stok'] = number_format($data->stok) . ' gram';
				$nestedData['harga'] = number_format($data->harga);
				$nestedData['action'] = $edit_url . " " . $delete_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function destroy()
	{
		$response_data = array();
		$response_data['status'] = false;
		$response_data['msg'] = "";
		$response_data['data'] = array();

		$id = $this->uri->segment(3);
		$is_deleted = $this->uri->segment(4);
		if (!empty($id)) {
			$this->load->model("sepuhan_model");
			$data = array(
				'is_deleted' => ($is_deleted == 1) ? 0 : 1
			);
			$update = $this->sepuhan_model->update($data, array("id" => $id));

			$response_data['data'] = $data;
			$response_data['status'] = true;
		} else {
			$response_data['msg'] = "ID Harus Diisi";
		}

		echo json_encode($response_data);
	}

	public function getsepuhan()
	{
		$where = array();
		$office_id = $this->input->get('office_id');

		if ($office_id != '') {
			$where['sepuhan.office_id'] = $office_id;
		}

		$sepuhan = $this->sepuhan_model->getAllById($where);

		$data = array();
		if ($sepuhan) {
			$data['status'] = true;
			$data['data'] = $sepuhan;
			$data['message'] = "Success get data sepuhan.";
		} else {
			$data['status'] = false;
			$data['data'] = [];
			$data['message'] = "Failed get data sepuhan.";
		}

		echo json_encode($data);
	}
}
