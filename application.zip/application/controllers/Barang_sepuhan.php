<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Barang_sepuhan extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('barang_sepuhan_model');
	}

	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$this->data['content'] = 'admin/barang_sepuhan/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function create()
	{
		$this->form_validation->set_rules('kode_sepuhan', "kode_sepuhan Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$data = array(
				'kode_sepuhan' => $this->input->post('kode_sepuhan'),
				'nama_barang' => $this->input->post('nama_barang'),
				'stok' => $this->input->post('stok'),
				'harga' => $this->input->post('harga'),
				'created_by' => $this->data['users']->id,
				'updated_by' => $this->data['users']->id
			);
			$insert = $this->barang_sepuhan_model->insert($data);

			if ($insert) {
				$this->session->set_flashdata('message', "Data Barang Sepuhan Baru Berhasil Disimpan");
				redirect("barang_sepuhan");
			} else {
				$this->session->set_flashdata('message_error', "Data Barang Sepuhan Baru Gagal Disimpan");
				redirect("barang_sepuhan");
			}
		} else {
			if ($this->data['is_can_create']) {
				$this->data['content'] = 'admin/barang_sepuhan/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function edit()
	{
		$this->form_validation->set_rules('kode_sepuhan', "kode_sepuhan Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$id = $this->input->post('id');
			$data = array(
				'kode_sepuhan' => $this->input->post('kode_sepuhan'),
				'nama_barang' => $this->input->post('nama_barang'),
				'stok' => $this->input->post('stok'),
				'harga' => $this->input->post('harga'),
				'updated_by' => $this->data['users']->id
			);
			$update = $this->barang_sepuhan_model->update($data, array("id" => $this->input->post('id')));
			if ($update) {
				$this->session->set_flashdata('message', "Data Barang Sepuhan Berhasil Diedit");
				redirect("barang_sepuhan");
			} else {
				$this->session->set_flashdata('message_error', "Data Barang Sepuhan Gagal Diedit");
				redirect("barang_sepuhan");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("barang_sepuhan/edit/" . $id);
			} else {
				if ($this->data['is_can_edit']) {
					$this->data['id'] = $this->uri->segment(3);
					$this->data['barang_sepuhan'] = $this->barang_sepuhan_model->getOneBy(array("barang_sepuhan.id" => $this->data['id']));
					$this->data['content'] = 'admin/barang_sepuhan/edit_v';
				} else {
					$this->data['content']  = 'errors/html/restrict';
				}
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function detail()
	{
		$this->data['id'] = $this->uri->segment(3);
		$this->data['barang_sepuhan'] = $this->barang_sepuhan_model->getOneBy(array("barang_sepuhan.id" => $this->data['id']));

		$this->data['content'] = 'admin/barang_sepuhan/detail_v';
		$this->load->view('admin/layouts/page', $this->data);
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
			1 => 'barang_sepuhan.kode_sepuhan',
			2 => 'barang_sepuhan.nama_barang',
			3 => 'barang_sepuhan.stok',
			4 => 'barang_sepuhan.harga',
			5 => 'action'
		);

		$where = array();
		// if(!$this->data['is_superadmin']){
		// 	$where['barang_sepuhan.office_id'] = $this->data['users']->office_id;
		// }

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->barang_sepuhan_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		if (!empty($this->input->post('search')['value'])) {
			$search_value = $this->input->post('search')['value'];
			$search = array(
				"barang_sepuhan.kode_sepuhan" => $search_value,
				"barang_sepuhan.nama_barang" => $search_value,
				"barang_sepuhan.stok" => $search_value,
				"barang_sepuhan.harga" => $search_value,
			);
			$totalFiltered = $this->barang_sepuhan_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->barang_sepuhan_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$edit_url = "";
				$delete_url = "";
				if ($this->data['is_can_edit'] && $data->is_deleted == 0) {
					// $edit_url = "<a href='".base_url()."barang_sepuhan/edit/".$data->id."' class='btn btn-sm btn-info'>Ubah</a>";
					$edit_url = "<a href='" . base_url() . "barang_sepuhan/edit/" . $data->id . "' class='btn btn-sm btn-warning' data-toggle='tooltip' title='Edit Data' data-placement='bottom'><i class='fa fa-edit fa-w-20'></i></a>";
				}
				if ($this->data['is_can_edit']) {
					if ($data->is_deleted == 0) {
						$delete_url = "<a href='#' 
	        				url='" . base_url() . "barang_sepuhan/destroy/" . $data->id . "/" . $data->is_deleted . "' class='btn btn-sm btn-danger delete' data-toggle='tooltip' title='Non Aktifkan Data' data-placement='bottom'><i class='fa fa-times fa-w-20'></i></a>";
					} else {
						$delete_url = "<a href='#' 
	        				url='" . base_url() . "barang_sepuhan/destroy/" . $data->id . "/" . $data->is_deleted . "' class='btn btn-sm btn-success delete' data-toggle='tooltip' title='Aktifkan Data' data-placement='bottom'><i class='fa fa-check fa-w-20'></i></a>";
					}
				}

				$nestedData['id'] = $start + $key + 1;
				$nestedData['kode_sepuhan'] = $data->kode_sepuhan;
				$nestedData['nama_barang'] = $data->nama_barang;
				$nestedData['stok'] = number_format($data->stok);
				$nestedData['harga'] = 'Rp. ' . number_format($data->harga);
				$nestedData['action'] = $edit_url . " " . $delete_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function destroy()
	{
		$response_data = array();
		$response_data['status'] = false;
		$response_data['msg'] = "";
		$response_data['data'] = array();

		$id = $this->uri->segment(3);
		$is_deleted = $this->uri->segment(4);
		if (!empty($id)) {
			$this->load->model("barang_sepuhan_model");
			$data = array(
				'is_deleted' => ($is_deleted == 1) ? 0 : 1
			);
			$update = $this->barang_sepuhan_model->update($data, array("id" => $id));

			$response_data['data'] = $data;
			$response_data['status'] = true;
		} else {
			$response_data['msg'] = "ID Harus Diisi";
		}

		echo json_encode($response_data);
	}

	public function getbarang_sepuhan()
	{
		$where = array();
		$office_id = $this->input->get('office_id');

		if ($office_id != '') {
			$where['barang_sepuhan.office_id'] = $office_id;
		}

		$barang_sepuhan = $this->barang_sepuhan_model->getAllById($where);

		$data = array();
		if ($barang_sepuhan) {
			$data['status'] = true;
			$data['data'] = $barang_sepuhan;
			$data['message'] = "Success get data barang_sepuhan.";
		} else {
			$data['status'] = false;
			$data['data'] = [];
			$data['message'] = "Failed get data barang_sepuhan.";
		}

		echo json_encode($data);
	}
	public function get_harga()
	{
		$barang_sepuhan_id = $this->input->get('barang_sepuhan_id');
		$where['id'] = $barang_sepuhan_id;
		$barang_sepuhan = $this->barang_sepuhan_model->getOneBy($where);
		if ($barang_sepuhan) {
			$data['status'] = true;
			$data['harga'] = $barang_sepuhan->harga;
		} else {
			$data['status'] = false;
			$data['harga'] = '';
		}
		echo json_encode($data);
	}
}
