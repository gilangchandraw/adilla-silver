<?php
defined('BASEPATH') or exit('No direct script access allowed');
require_once APPPATH . 'core/Admin_Controller.php';
class Tarik_stok_retur extends Admin_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('tarik_stok_retur_model');
		$this->load->model('cabang_model');
	}

	public function index()
	{
		$this->load->helper('url');
		if ($this->data['is_can_read']) {
			$this->data['content'] = 'admin/tarik_stok_retur/list_v';
		} else {
			$this->data['content'] = 'errors/html/restrict';
		}

		$this->load->view('admin/layouts/page', $this->data);
	}

	public function create()
	{
		$this->form_validation->set_rules('tanggal', "tanggal Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {

			$tanggal = $this->input->post('tanggal');
			$cabang_id = $this->input->post('cabang_id');
			$tarik_stok_retur_bk_925 = $this->input->post('tarik_stok_retur_bk_925');
			$tarik_stok_retur_pajang_925 = $this->input->post('tarik_stok_retur_pajang_925');
			$tarik_stok_retur_bk_sp = $this->input->post('tarik_stok_retur_bk_sp');
			$tarik_stok_retur_pajang_sp = $this->input->post('tarik_stok_retur_pajang_sp');
			// get data cabang
			$cabang = $this->cabang_model->getOneBy(['cabang.id' => $cabang_id]);
			$data = array(
				'users_id' => $this->data['users']->id,
				'cabang_id' => $cabang_id,
				'tanggal' => $tanggal,
				'tarik_stok_retur_bk_925' => $tarik_stok_retur_bk_925,
				'tarik_stok_retur_pajang_925' => $tarik_stok_retur_pajang_925,
				'tarik_stok_retur_bk_sp' => $tarik_stok_retur_bk_sp,
				'tarik_stok_retur_pajang_sp' => $tarik_stok_retur_pajang_sp,
				'created_by' => $this->data['users']->id,
			);
			$insert = $this->tarik_stok_retur_model->insert($data);
			
			//nambahin ke cabang
			// 925
			$update_retur_bk_925 = $cabang->stok_retur_bk_925 - $tarik_stok_retur_bk_925;
			$update_retur_pajang_925 = $cabang->stok_retur_pajang_925 - $tarik_stok_retur_pajang_925;
			// sp
			$update_retur_bk_sp = $cabang->stok_retur_bk_sp - $tarik_stok_retur_bk_sp;
			$update_retur_pajang_sp = $cabang->stok_retur_pajang_sp - $tarik_stok_retur_pajang_sp;

			$data_update = array(
				'stok_retur_bk_925' => $update_retur_bk_925,
				'stok_retur_pajang_925' => $update_retur_pajang_925,
				'stok_retur_bk_sp' => $update_retur_bk_sp,
				'stok_retur_pajang_sp' => $update_retur_pajang_sp,
			);
			$update = $this->cabang_model->update($data_update, array("cabang.id" => $cabang->id));

			if ($update) {
				$this->session->set_flashdata('message', "Data tarik stok retur Baru Berhasil Disimpan");
				redirect("tarik_stok_retur");
			} else {
				$this->session->set_flashdata('message_error', "Data tarik stok retur Baru Gagal Disimpan");
				redirect("tarik_stok_retur");
			}
		} else {
			if ($this->data['is_can_create']) {
				$this->data['cabang'] = $this->cabang_model->getAllById(['cabang.is_deleted' => 0]);
				$this->data['content'] = 'admin/tarik_stok_retur/create_v';
			} else {
				$this->data['content']  = 'errors/html/restrict';
			}
			$this->load->view('admin/layouts/page', $this->data);
		}
	}

	public function edit()
	{
		$this->form_validation->set_rules('nama_tarik_stok_retur', "nama_tarik_stok_retur Is Required", 'trim|required');

		if ($this->form_validation->run() === TRUE) {
			$id = $this->input->post('id');
			$data = array(
				'kode_tarik_stok_retur' => $this->input->post('kode_tarik_stok_retur'),
				'nama_tarik_stok_retur' => $this->input->post('nama_tarik_stok_retur'),
				'users_id' => $this->input->post('users_id'),
				'alamat' => $this->input->post('alamat'),
				'kas' => $this->input->post('kas'),
				// 'kas_awal' => $this->input->post('kas'),
				'stok_925' => $this->input->post('stok_925'),
				'stok_sp' => $this->input->post('stok_sp'),
				'kas_sepuhan' => $this->input->post('kas_sepuhan'),
				'updated_by' => $this->data['users']->id
			);
			$update = $this->tarik_stok_retur_model->update($data, array("id" => $id));
			if ($update) {
				$this->session->set_flashdata('message', "Data tarik_stok_retur Berhasil Diedit");
				redirect("tarik_stok_retur");
			} else {
				$this->session->set_flashdata('message_error', "Data tarik_stok_retur Gagal Diedit");
				redirect("tarik_stok_retur");
			}
		} else {
			if (!empty($_POST)) {
				$id = $this->input->post('id');
				$this->session->set_flashdata('message_error', validation_errors());
				return redirect("tarik_stok_retur/edit/" . $id);
			} else {
				if ($this->data['is_can_edit']) {
					$this->data['kepala_tarik_stok_retur'] = $this->user_model->getAllById(['roles.id' => 4, 'users.is_deleted' => 0]);
					$this->data['id'] = $this->uri->segment(3);
					$this->data['tarik_stok_retur'] = $this->tarik_stok_retur_model->getOneBy(array("tarik_stok_retur.id" => $this->data['id']));
					$this->data['content'] = 'admin/tarik_stok_retur/edit_v';
				} else {
					$this->data['content']  = 'errors/html/restrict';
				}
				$this->load->view('admin/layouts/page', $this->data);
			}
		}
	}

	public function dataList()
	{
		$columns = array(
			0 => 'id',
			1 => 'tarik_stok_retur.kode_tarik_stok_retur',
			2 => 'tarik_stok_retur.nama_tarik_stok_retur',
			3 => 'tarik_stok_retur.alamat',
			4 => 'action'
		);

		$where['tarik_stok_retur.is_deleted'] = 0;

		$order = $columns[$this->input->post('order')[0]['column']];
		$dir = $this->input->post('order')[0]['dir'];
		$search = array();
		$limit = 0;
		$start = 0;
		$totalData = $this->tarik_stok_retur_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);



		if (!empty($this->input->post('search')['value'])) {
			$search_value = $this->input->post('search')['value'];
			$search = array(
				"tarik_stok_retur.kode_tarik_stok_retur" => $search_value,
				"tarik_stok_retur.nama_tarik_stok_retur" => $search_value,
				"tarik_stok_retur.alamat" => $search_value,
			);
			$totalFiltered = $this->tarik_stok_retur_model->getCountAllBy($limit, $start, $search, $order, $dir, $where);
		} else {
			$totalFiltered = $totalData;
		}

		$limit = $this->input->post('length');
		$start = $this->input->post('start');
		$datas = $this->tarik_stok_retur_model->getAllBy($limit, $start, $search, $order, $dir, $where);

		$new_data = array();
		if (!empty($datas)) {
			foreach ($datas as $key => $data) {

				$delete_url = "";
				if ($this->data['is_can_edit']) {
					if ($data->is_deleted == 0) {
						$delete_url = "<a href='#' 
	        				url='" . base_url() . "tarik_stok_retur/destroy/" . $data->id . "/" . $data->is_deleted . "' class='btn btn-sm btn-danger delete' data-toggle='tooltip' title='Non Aktifkan Data' data-placement='bottom'><i class='fa fa-times fa-w-20'></i></a>";
					}
				}

				$nestedData['id'] = $start + $key + 1;
				$nestedData['tanggal'] = $data->tanggal;
				$nestedData['nama_cabang'] = $data->nama_cabang;
				$nestedData['tarik_stok_retur_bk_925'] = $data->tarik_stok_retur_bk_925;
				$nestedData['tarik_stok_retur_pajang_925'] = $data->tarik_stok_retur_pajang_925;
				$nestedData['tarik_stok_retur_bk_sp'] = $data->tarik_stok_retur_bk_sp;
				$nestedData['tarik_stok_retur_pajang_sp'] = $data->tarik_stok_retur_pajang_sp;
				$nestedData['action'] = $delete_url;
				$new_data[] = $nestedData;
			}
		}

		$json_data = array(
			"draw"            => intval($this->input->post('draw')),
			"recordsTotal"    => intval($totalData),
			"recordsFiltered" => intval($totalFiltered),
			"data"            => $new_data
		);

		echo json_encode($json_data);
	}

	public function destroy()
	{
		$response_data = array();
		$response_data['status'] = false;
		$response_data['msg'] = "";
		$response_data['data'] = array();

		$id = $this->uri->segment(3);
		$is_deleted = $this->uri->segment(4);
		if (!empty($id)) {
			$data_tarik = $this->tarik_stok_retur_model->getOneBy(['tarik_stok_retur.id' => $id]);

			$cabang = $this->cabang_model->getOneBy(['cabang.id' => $data_tarik->cabang_id]);
			//nambahin ke cabang
			// 925
			$update_retur_bk_925 = $cabang->stok_retur_bk_925 + $data_tarik->tarik_stok_retur_bk_925;
			$update_retur_pajang_925 = $cabang->stok_retur_pajang_925 + $data_tarik->tarik_stok_retur_pajang_925;
			// sp
			$update_retur_bk_sp = $cabang->stok_retur_bk_sp + $data_tarik->tarik_stok_retur_bk_sp;
			$update_retur_pajang_sp = $cabang->stok_retur_pajang_sp + $data_tarik->tarik_stok_retur_pajang_sp;

			$data_update = array(
				'stok_retur_bk_925' => $update_retur_bk_925,
				'stok_retur_pajang_925' => $update_retur_pajang_925,
				'stok_retur_bk_sp' => $update_retur_bk_sp,
				'stok_retur_pajang_sp' => $update_retur_pajang_sp,
			);
			$update = $this->cabang_model->update($data_update, array("cabang.id" => $cabang->id));
			$data = array(
				'is_deleted' => ($is_deleted == 1) ? 0 : 1
			);
			$update = $this->tarik_stok_retur_model->update($data, array("id" => $id));

			$response_data['data'] = $data;
			$response_data['status'] = true;
		} else {
			$response_data['msg'] = "ID Harus Diisi";
		}

		echo json_encode($response_data);
	}

	public function gettarik_stok_retur()
	{
		$where = array();
		$office_id = $this->input->get('office_id');

		if ($office_id != '') {
			$where['tarik_stok_retur.office_id'] = $office_id;
		}

		$tarik_stok_retur = $this->tarik_stok_retur_model->getAllById($where);

		$data = array();
		if ($tarik_stok_retur) {
			$data['status'] = true;
			$data['data'] = $tarik_stok_retur;
			$data['message'] = "Success get data tarik_stok_retur.";
		} else {
			$data['status'] = false;
			$data['data'] = [];
			$data['message'] = "Failed get data tarik_stok_retur.";
		}

		echo json_encode($data);
	}
}
