<?php 


 function sendNotification($to="all",$title="", $desc="", $category=0, $action = false, $data = array()){
	$fcm_server_key =  "AAAAxIY1rEs:APA91bHT3HFSmh6eR-K2nCGS7hs61HbcyA4uf40QlzwiQD45ZmLdUSNzhq17peeY3mzXE294jw2nGmG3Bw2O7ABJrqGn_1PiFijetHiWlOJiiNIFqTMARfgEwEwqkJ5un1Z-Z_ryzoGU"; 
      //firebase server url to send the curl request
    $url = 'https://fcm.googleapis.com/fcm/send';

    //building headers for the request
    $headers = array(
        'Authorization: key=' . $fcm_server_key,
        'Content-Type: application/json'
    ); 

    $payload = array(
            "to" => $to, //  /topics/all
            "priority" => "high",
            "notification" => array( 
                "title" => $title,
                "body" => $desc,
                "time" => date("H:i"),
                "category" => $category, //document, approval,invoice
                "date" => date("Y-m-d"),
                "click_action" =>"FCM_PLUGIN_ACTIVITY",
                "sound"=> "default"
            ),
            "data" => array( 
                "title" => $title, 
                "body" => $desc,
                "data" => $data,
                "time" => date("H:i"),
                "category" => $category, //document, approval,invoice
                "date" => date("Y-m-d"),
                "click_action" =>"FCM_PLUGIN_ACTIVITY",
                "sound"=> "default" 
            )
        );
    //Initializing curl to open a connection
    $ch = curl_init();

    //Setting the curl url
    curl_setopt($ch, CURLOPT_URL, $url);
    
    //setting the method as post
    curl_setopt($ch, CURLOPT_POST, true);

    //adding headers 
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

    //disabling ssl support
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    //adding the fields in json format 
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));

    //finally executing the curl request 
    $result = curl_exec($ch);

    //Now close the connection
    curl_close($ch);
 
    if($result){
		return $result;
	}

	return false;
 
}

function sendAppsNotification($to = '', $title = '', $message = '',$id='', $user_id = null, $role_id = null)
{
    $CI = get_instance();
    $CI->load->model('privilleges_model');
    $CI->load->model('users_model');

    $access = array();
    $category = "PPJK"; 
    // recipient selection
    if ($to == 'all') {
        $access = array('function_id' => 6);
    }else if ($to == 'admin_verifikasi') {
        $category = "data_lelang";
        $where['users_roles.role_id'] = 4;
    }else if ($to == 'pokja') {
        $category = "penentuan_pokja";
        $where['users_roles.role_id'] = 5;
        if($user_id){
            $where['users.id'] = $user_id;
        }
    }else if ($to == 'reviewer') {
        $category = "review";
        $where['users_roles.role_id'] = $role_id;
        if($user_id){
            $where['users.id'] = $user_id;
        }
    }else if ($to == 'ubah_kontrak') {
        $category = "data_lelang";
        $where['users_roles.role_id'] = $role_id;
        if($user_id){
            $where['users.id'] = $user_id;
        }
    }else if ($to == 'indikator_kinerja') { 
        $category = "data_lelang";
        $where['users_roles.role_id'] = $role_id;
        if($user_id){
            $where['users.id'] = $user_id;
        }
    }else if ($to == 'accept_lelang') { 
        $category = "data_lelang";
        $where['users_roles.role_id'] = $role_id;
        if($user_id){
            $where['users.id'] = $user_id;
        }
    }else if ($to == 'reject_lelang') { 
        $category = "data_lelang";
        $where['users_roles.role_id'] = $role_id;
        if($user_id){
            $where['users.id'] = $user_id;
        }
    }
    

    $users = $CI->users_model->getAllById($where);
    if ($users) {
        foreach ($users as $user) {
            $send_notification =  sendNotification($user->fcm_token, $title, $message, $category, $id);
        }
    }

    //get role from selection
    // $role_id = $CI->privilleges_model->getAllById($access);
    // $users = array();
    // foreach ($role_id as $key => $value) {
    //     $users = $CI->employee_model->getAllById(array('role_id' => $role_id));
    //     if ($users) {
    //         foreach ($users as $user) {
    //             $send_notification =  sendNotification($user->fcm_token, $title, $message, $category, $id);
    //         }
    //     }
    // }
}

function sendBoNotification($from = -1, $to = 'all', $title = '', $message = '', $reference_id = -1)
{
    if ($from != -1) {
        // Get a reference to the controller object
        $CI = get_instance();

        // You may need to load the model if it hasn't been pre-loaded
        $CI->load->model('notification_model');
        $CI->load->model('privilleges_model');

        // Call a function of the model
        if ($to == 'all') {
            $access = array('function_id' => 6);
            $role_id = ($CI->privilleges_model->getAllById($access));
            foreach ($role_id as $key => $value) {
                $dataInsert = array(
                    'from' => $from, 
                    'to' => $value->role_id, 
                    'title' => $title, 
                    'message' => $message, 
                    'category' => 'broadcast',
                    'created_at' => date("Y-m-d h:i:s", time()),
                    'created_by' => $from,
                );
                $CI->notification_model->insert($dataInsert);
            }
        }else if ($to == 'agent') {
            $access = array('menu_id' => 12,'function_id' => 6);
            $role_id = ($CI->privilleges_model->getAllById($access));
            foreach ($role_id as $key => $value) {
                $dataInsert = array(
                    'from' => $from, 
                    'to' => $value->role_id, 
                    'title' => $title, 
                    'message' => $message, 
                    'category' => 'agent',
                    'reference_id'=> $reference_id,
                    'created_at' => date("Y-m-d h:i:s", time()),
                    'created_by' => $from,
                );
                $CI->notification_model->insert($dataInsert);
            }
        }else if ($to == 'ppjk') {
            $access = array('menu_id' => 6,'function_id' => 6);
            $role_id = ($CI->privilleges_model->getAllById($access));

            foreach ($role_id as $key => $value) {
                $dataInsert = array(
                    'from' => $from, 
                    'to' => $value->role_id, 
                    'title' => $title, 
                    'message' => $message, 
                    'category' => 'ppjk',
                    'reference_id'=> $reference_id,
                    'created_at' => date("Y-m-d h:i:s", time()),
                    'created_by' => $from,
                );
                $CI->notification_model->insert($dataInsert);
            }
        }else if ($to == 'scheduler') {
            // access to create scheduler
            $access = array('menu_id' => 7,'function_id' => 1);
            $role_id = ($CI->privilleges_model->getAllById($access));

            foreach ($role_id as $key => $value) {
                $dataInsert = array(
                    'from' => $from, 
                    'to' => $value->role_id, 
                    'title' => $title, 
                    'message' => $message, 
                    'category' => 'scheduler',
                    'reference_id'=> $reference_id,
                    'created_at' => date("Y-m-d h:i:s", time()),
                    'created_by' => $from,
                );
                $CI->notification_model->insert($dataInsert);
            }
        }else if ($to == 'finance') {
            $access = array('menu_id' => 36,'function_id' => 1);
            $role_id = ($CI->privilleges_model->getAllById($access));

            foreach ($role_id as $key => $value) {
                $dataInsert = array(
                    'from' => $from, 
                    'to' => $value->role_id, 
                    'title' => $title, 
                    'message' => $message, 
                    'category' => 'finance',
                    'reference_id'=> $reference_id,
                    'created_at' => date("Y-m-d h:i:s", time()),
                    'created_by' => $from,
                );
                $CI->notification_model->insert($dataInsert);
            }
        }else if ($to == 'direktur') {
            $access = array('menu_id' => 46,'function_id' => 1);
            $role_id = ($CI->privilleges_model->getAllById($access));

            foreach ($role_id as $key => $value) {
                $dataInsert = array(
                    'from' => $from, 
                    'to' => $value->role_id, 
                    'title' => $title, 
                    'message' => $message, 
                    'category' => 'direktur',
                    'reference_id'=> $reference_id,
                    'created_at' => date("Y-m-d h:i:s", time()),
                    'created_by' => $from,
                );
                $CI->notification_model->insert($dataInsert);
            }
        }

    }
}