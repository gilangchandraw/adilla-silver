<?php
	$config['invoice_module'] = TRUE;
	$config['map_module'] = TRUE;
?>