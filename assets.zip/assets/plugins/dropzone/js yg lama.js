define([
    "jQuery",
    "mainJs",
    "jqvalidate",
    "datatables",
    "bootstrapDatepicker",
    "dropzone"
    ], function (
    $,
    mainJs,
    jqvalidate,
    datatables,
    bootstrapDatepicker,
    dropzone
    ) {
    return {  
        table:null,
        init: function () { 
            App.initFunc();
            App.initEvent();  
            App.initConfirm();
            // App.searchTable();
            // App.resetSearch();
            $(".loadingpage").hide();
            $('#table_filter').show();
        }, 
        initEvent : function(){
            
    
    // tab foto
            if($("#aksiFoto").val()=="tambah"){
                    gambar = [];
                    Dropzone.autoDiscover = false;                   
                    
                    var foto_upload = new Dropzone(".dropzone-foto", {
                        init: function () {
                            this.on("sending", function(file, xhr, data) {
                                data.append("id", $("#id-unit").val());
                            });
                        },
                        url: App.baseUrl+"kelola_jaringan_kota/proses_upload",
                        maxFilesize: 5,
                        method: "post",
                        acceptedFiles: "image/*",
                        paramName: "userfile",
                        dictInvalidFileType: "Type file ini tidak dizinkan",
                        addRemoveLinks: true,
                        success: function (file, response) {
                            var imgName = JSON.parse(response);
                            gambar.push(imgName.data.namafile + '|' + imgName.data.datafile);
                            $('#filename').val(gambar);
                        },
                    });

                    //Event ketika Memulai mengupload
                    foto_upload.on("sendingmultiple", function (data, xhr, formData) {
                        data.token = Math.random();
                        formData.append("token_foto", data.token); //Menmpersiapkan token untuk masing masing foto
                    });

                    //Event ketika foto dihapus
                    foto_upload.on("removedfile", function (a) {
                        var name = a.name;
                        var name_data = $("#filename").val().split(',');
                        for (let i = 0; i < name_data.length; i++) {
                            var name_data_real = name_data[i].split('|');
                            if (name == name_data_real[0]) {
                                var real_name = name_data_real[1];
                            }
                        }
                        $.ajax({
                            type: "post",
                            data: { name: real_name },
                            url: App.baseUrl + "kelola_jaringan_kota/remove_foto",
                            cache: false,
                            dataType: 'json',
                            success: function (response) {
                                var imgName = response;
                                var index = gambar.indexOf(name + '|' + imgName.data.namafile);
                                if (index !== -1) gambar.splice(index, 1);
                                $('#filename').val(gambar);
                                console.log("Foto terhapus");
                            },
                            error: function () {
                                console.log("Error");

                            }
                        });
                    });
                }

                if ($("#aksiFoto").val() == "edit"){
                    gambar = $("#filename").val().split(',');
                    Dropzone.autoDiscover = false;

                    var foto_upload = new Dropzone(".dropzone-foto", {
                        init: function () {
                            this.on("sending", function(file, xhr, data) {
                                data.append("id", $("#id-unit").val());
                            });
                        },
                        url: App.baseUrl+"kelola_jaringan_kota/proses_upload",
                        maxFilesize: 5,
                        method: "post",
                        thumbnailWidth: 250,
                        thumbnailHeight: 250,
                        acceptedFiles: "image/*",
                        paramName: "userfile",
                        dictInvalidFileType: "Type file ini tidak dizinkan",
                        addRemoveLinks: true,
                        success: function (file, response) {
                            var imgName = JSON.parse(response);
                            gambar.push(imgName.data.namafile + '|' + imgName.data.datafile);
                            $('#filename').val(gambar);
                        },
                    });

                    //Event ketika Memulai mengupload
                    foto_upload.on("sendingmultiple", function (data, xhr, formData) {
                        data.token = Math.random();
                        formData.append("token_foto", data.token); //Menmpersiapkan token untuk masing masing foto
                    });
                    
                    var name_data = $("#filename").val().split(',');
                    var filesize = $("#filesize").val().split(',');
                    for (let i = 0; i < name_data.length; i++) {
                        var name_data_real = name_data[i].split('|');
                        var mockFile = { name: name_data_real[1], size: filesize[i] };
                        foto_upload.emit("addedfile", mockFile);
                        foto_upload.emit("thumbnail", mockFile, App.baseUrl + 'file-upload/kelola-data/air-minum/jaringan-kota/' + name_data_real[1]);
                        foto_upload.emit("complete", mockFile);
                    }
                    

                    //Event ketika foto dihapus
                    foto_upload.on("removedfile", function (a) {
                        var name = a.name;
                        var name_data = $("#filename").val().split(',');
                        for (let i = 0; i < name_data.length; i++) {
                            var name_data_real = name_data[i].split('|');
                            if (name == name_data_real[0]) {
                                var real_name = name_data_real[1];
                            }
                        }
                        $.ajax({
                            type: "post",
                            data: { name: real_name, aksi:"edit" },
                            url: App.baseUrl + "kelola_jaringan_kota/remove_foto",
                            cache: false,
                            dataType: 'json',
                            success: function (response) {
                                var imgName = response;
                                console.log(name + '|' + imgName.data.namafile);
                                var index = gambar.indexOf(name + '|' + imgName.data.namafile);
                                if (index !== -1) gambar.splice(index, 1);
                                console.log(gambar);
                                $('#filename').val(gambar);
                                console.log("Foto terhapus");
                            },
                            error: function () {
                                console.log("Error");

                            }
                        });
                    });
                }

    // rencana abd
        if($("#aksiAbd").val()=="tambah" || $("#aksiAbd").val()=="edit"){
                    gambar = [];
                    Dropzone.autoDiscover = false;

                    
                    
                    var foto_upload = new Dropzone("#dropzone-abd", {
                        init: function () {
                            this.on("maxfilesreached", function(file) {
                              this.on("addedfile", function(file) {
                                  file.previewElement.addEventListener("click", function() {
                                    this.removeFile(file);
                                  });
                                });
                            });
                            
                            this.on("sending", function(file, xhr, data) {
                                data.append("id", $("#id-unit").val());
                            });
                        },
                        url: App.baseUrl+"kelola_jaringan_kota/proses_upload_abd",
                        maxFilesize: 20,
                        maxFiles: 1,
                        maxfilesexceeded: function (file) {
                            alert("Tidak bisa menambah file lagi");
                            file.previewElement.remove();
                        },
                        method: "post",
                        acceptedFiles: "image/*",
                        paramName: "userfile",
                        dictInvalidFileType: "Type file ini tidak dizinkan",
                        addRemoveLinks: true,
                        success: function (file, response) {
                            var imgName = JSON.parse(response);
                            gambar.push(imgName.data.namafile + '|' + imgName.data.datafile);
                            $('#filenameAbd').val(gambar);
                        },
                    });

                    //Event ketika Memulai mengupload
                    foto_upload.on("sendingmultiple", function (data, xhr, formData) {
                        data.token = Math.random();
                        formData.append("token_foto", data.token); //Menmpersiapkan token untuk masing masing foto
                    });
                    var name_data = $("#filenameAbd").val().split(',');
                    var filesize = $("#filesizeAbd").val().split(',');
                    //i= name_data.length;
                     for (let i = name_data.length; i < name_data.length; i++) {
                        var name_data_real = name_data[i].split('|');
                        var mockFile = { name: name_data_real[1], size: filesize[i] };
                        foto_upload.emit("addedfile", mockFile);
                        foto_upload.emit("thumbnail", mockFile, App.baseUrl + 'file-upload/kelola-data/air-minum/jaringan-kota/rencana-abd/' + name_data_real[1]);
                        foto_upload.emit("complete", mockFile);
                     }
                    //Event ketika foto dihapus
                    foto_upload.on("removedfile", function (a) {
                        var name = a.name;
                        var name_data = $("#filenameAbd").val().split(',');
                        for (let i = 0; i < name_data.length; i++) {
                            var name_data_real = name_data[i].split('|');
                            if (name == name_data_real[0]) {
                                var real_name = name_data_real[1];
                            }
                        }
                        $.ajax({
                            type: "post",
                            data: { name: real_name },
                            url: App.baseUrl + "kelola_jaringan_kota/remove_foto_abd",
                            cache: false,
                            dataType: 'json',
                            success: function (response) {
                                var imgName = response;
                                var index = gambar.indexOf(name + '|' + imgName.data.namafile);
                                if (index !== -1) gambar.splice(index, 1);
                                $('#filenameAbd').val(gambar);
                                console.log("Foto terhapus");
                            },
                            error: function () {
                                console.log("Error");

                            }
                        });
                    });
                }

                

                
        // rencana ded
                if($("#aksiDed").val()=="tambah"){
                    gambar = [];
                    Dropzone.autoDiscover = false;

                    
                    
                    var foto_upload = new Dropzone("#dropzone-ded", {
                        init: function () {
                            this.on("sending", function(file, xhr, data) {
                                data.append("id", $("#id-unit").val());
                            });
                        },
                        url: App.baseUrl+"kelola_jaringan_kota/proses_upload_ded",
                        maxFilesize: 20,
                        maxFiles: 1,
                        method: "post",
                        acceptedFiles: "image/*",
                        paramName: "userfile",
                        dictInvalidFileType: "Type file ini tidak dizinkan",
                        addRemoveLinks: true,
                        success: function (file, response) {
                            var imgName = JSON.parse(response);
                            gambar.push(imgName.data.namafile + '|' + imgName.data.datafile);
                            $('#filenameDed').val(gambar);
                        },
                    });

                    //Event ketika Memulai mengupload
                    foto_upload.on("sendingmultiple", function (data, xhr, formData) {
                        data.token = Math.random();
                        formData.append("token_foto", data.token); //Menmpersiapkan token untuk masing masing foto
                    });

                    //Event ketika foto dihapus
                    foto_upload.on("removedfile", function (a) {
                        var name = a.name;
                        var name_data = $("#filenameDed").val().split(',');
                        for (let i = 0; i < name_data.length; i++) {
                            var name_data_real = name_data[i].split('|');
                            if (name == name_data_real[0]) {
                                var real_name = name_data_real[1];
                            }
                        }
                        $.ajax({
                            type: "post",
                            data: { name: real_name },
                            url: App.baseUrl + "kelola_jaringan_kota/remove_foto_ded",
                            cache: false,
                            dataType: 'json',
                            success: function (response) {
                                var imgName = response;
                                var index = gambar.indexOf(name + '|' + imgName.data.namafile);
                                if (index !== -1) gambar.splice(index, 1);
                                $('#filenameDed').val(gambar);
                                console.log("Foto terhapus");
                            },
                            error: function () {
                                console.log("Error");

                            }
                        });
                    });
                }
        // rencana ded edit
        if ($("#aksiDed").val() == "edit"){
                    gambar = $("#filenameDed").val().split(',');
                    Dropzone.autoDiscover = false;

                    var foto_upload = new Dropzone(".dropzone-ded", {
                        init: function () {
                            this.on("sending", function(file, xhr, data) {
                                data.append("id", $("#id-unit").val());
                            });
                        },
                        url: App.baseUrl+"kelola_jaringan_kota/proses_upload_ded",
                        maxFilesize: 20,
                        maxFiles: 1,
                        method: "post",
                        thumbnailWidth: 250,
                        thumbnailHeight: 250,
                        acceptedFiles: "image/*",
                        paramName: "userfile",
                        dictInvalidFileType: "Type file ini tidak dizinkan",
                        addRemoveLinks: true,
                        success: function (file, response) {
                            var imgName = JSON.parse(response);
                            gambar.push(imgName.data.namafile + '|' + imgName.data.datafile);
                            $('#filenameDed').val(gambar);
                        },
                    });

                    //Event ketika Memulai mengupload
                    foto_upload.on("sendingmultiple", function (data, xhr, formData) {
                        data.token = Math.random();
                        formData.append("token_foto", data.token); //Menmpersiapkan token untuk masing masing foto
                    });
                    
                    var name_data = $("#filenameDed").val().split(',');
                    var filesize = $("#filesizeDed").val().split(',');
                    //i= name_data.length;
                     for (let i = name_data.length - 1; i < name_data.length; i++) {
                        var name_data_real = name_data[i].split('|');
                        var mockFile = { name: name_data_real[1], size: filesize[i] };
                        foto_upload.emit("addedfile", mockFile);
                        foto_upload.emit("thumbnail", mockFile, App.baseUrl + 'file-upload/kelola-data/air-minum/jaringan-kota/rencana-ded/' + name_data_real[1]);
                        foto_upload.emit("complete", mockFile);
                     }
                    

                    //Event ketika foto dihapus
                    foto_upload.on("removedfile", function (a) {
                        var name = a.name;
                        var name_data = $("#filenameDed").val().split(',');
                        for (let i = 0; i < name_data.length; i++) {
                            var name_data_real = name_data[i].split('|');
                            if (name == name_data_real[0]) {
                                var real_name = name_data_real[1];
                            }
                        }
                        $.ajax({
                            type: "post",
                            data: { name: real_name, aksi:"edit" },
                            url: App.baseUrl + "kelola_jaringan_kota/remove_foto_ded",
                            cache: false,
                            dataType: 'json',
                            success: function (response) {
                                var imgName = response;
                                console.log(name + '|' + imgName.data.namafile);
                                var index = gambar.indexOf(name + '|' + imgName.data.namafile);
                                if (index !== -1) gambar.splice(index, 1);
                                console.log(gambar);
                                $('#filenameDed').val(gambar);
                                console.log("Foto terhapus");
                            },
                            error: function () {
                                console.log("Error");

                            }
                        });
                    });
                }


    // init datepicker
            $('#kTahun1').datepicker({
                    uiLibrary: 'bootstrap4',
                    format: "yyyy",
                    viewMode: "years", 
                    minViewMode: "years"
            }); 
            $('#kTahun2').datepicker({
                    uiLibrary: 'bootstrap4',
                    format: "yyyy",
                    viewMode: "years", 
                    minViewMode: "years"
            }); 
            $('#kTahun3').datepicker({
                    uiLibrary: 'bootstrap4',
                    format: "yyyy",
                    viewMode: "years", 
                    minViewMode: "years"
            }); 
            $('#tahun_pembangunan').datepicker({
                    uiLibrary: 'bootstrap4',
                    format: "yyyy",
                    viewMode: "years", 
                    minViewMode: "years"
            }); 
            $('#tp').datepicker({
                    uiLibrary: 'bootstrap4',
                    format: "yyyy",
                    viewMode: "years", 
                    minViewMode: "years"
            }); 
            $('#tglSipa').datepicker({
                    uiLibrary: 'bootstrap4',
                    format: 'yyyy-mm-dd',
            });

            App.table = $('#table').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ baris per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Menampilkan _PAGE_ dari _PAGES_",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first":      "Pertama",
                        "last":       "Terakhir",
                        "next":       "Selanjutnya",
                        "previous":   "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax":{
                    "url": App.baseUrl+"kelola_jaringan_kota/dataList",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [
                    { "data": "unit" },
                    { "data": "terpasang" },
                    { "data": "produksi" },
                    { "data": "distribusi" },
                    { "data": "terjual" },
                    { "data": "belum_terpakai" },
                    { "data": "kehilangan" },
                    { "data": "jumlah_sr" },
                    { "data": "tgl" }
                    // { "data": "action" ,"orderable": false}
                ]      
            });

            //append button to datatables
            add_btn = '<a href="'+App.baseUrl+'role/create" class="btn btn-sm btn-primary ml-2 mt-1"><i class="fa fa-plus"></i> Jabatan</a>';
            $('#table_filter').append();

            if($("#form").length > 0){
                $("#save-btn").removeAttr("disabled");
                $("#form").validate({ 
                    rules: {
                        nama: {
                            required: true
                        },
                        kategori: {
                            required: true
                        },
                        pengelola: {
                            required: true
                        }
                    },
                    messages: {
                        nama: {
                            required: "Nama Unit Harus Diisi"
                        },
                        kategori: {
                            required: "Kategori Pelayanan Harus Dipilih"
                        },
                        pengelola: {
                            required: "Pengelola Harus Dipilih"
                        }
                    }, 
                    debug:true,
                    
                    errorPlacement: function(error, element) {
                        var name = element.attr('name');
                        var errorSelector = '.form-control-feedback[for="' + name + '"]';
                        var $element = $(errorSelector);
                        if ($element.length) { 
                            $(errorSelector).html(error.html());
                        } else {
                            error.insertAfter(element);
                        }
                    },
                    submitHandler : function(form) { 
                        form.submit();
                    }
                }); 
            }
            if($("#form-1").length > 0){
                $("#save-1").removeAttr("disabled");
                $("#form-1").validate({ 
                    rules: {
                        unit: {
                            required: true
                        },
                        ikk: {
                            required: true
                        },
                        n_berita: {
                            required: true
                        },
                        status_kelola: {
                            required: true
                        },
                        k_pelayanan: {
                            required: true
                        },
                        status_aset: {
                            required: true
                        },
                        alamat: {
                            required: true
                        },
                        telepon: {
                            required: true
                        },
                        status_verifikasi: {
                            required: true
                        },
                        long: {
                            required: true
                        },
                        dana: {
                            required: true
                        },
                        lat: {
                            required: true
                        },
                        n_aset: {
                            required: true
                        },
                        biaya: {
                            required: true
                        },
                        tahun_pembangunan: {
                            required: true
                        },
                        catatan: {
                            required: true
                        },
                        email: {
                            required: true
                        },
                        fungsi_fasilitas: {
                            required: true
                        },

                    },
                    messages: {
                        fungsi_fasilitas: {
                            required: "Keberfungsian Fasilitas Harus Dipilih"
                        },
                        email: {
                            required: "Email Harus Diisi"
                        },
                        catatan: {
                            required: "Catatan Harus Diisi"
                        },
                        tahun_pembangunan: {
                            required: "Tahun Pembangunan Harus Diisi"
                        },
                        biaya: {
                            required: "Biaya Harus Diisi"
                        },
                        n_aset: {
                            required: "Nomor Berita Acara Status Aset Harus Diisi"
                        },
                        lat: {
                            required: "Titik Koordinat Unit Produksi Latitude Harus Diisi"
                        },
                        dana: {
                            required: "Sumber Dana Harus Dipilih"
                        },
                        long: {
                            required: "Titik Koordinat Unit Produksi Longtitude Harus Diisi"
                        },
                        status_verifikasi: {
                            required: "Status Verifikasi Harus Diisi"
                        },
                        telepon: {
                            required: "Nomor Telepon Harus Diisi"
                        },
                        alamat: {
                            required: "Alamat Harus Diisi"
                        },
                        status_aset: {
                            required: "Berita Acara Status Aset Harus Dipilih"
                        },
                        k_pelayanan: {
                            required: "Kategori Pelayanan Harus Dipilih"
                        },
                        status_kelola: {
                            required: "Berita Acara Alih Status Kelola Harus Dipilih"
                        },
                        unit: {
                            required: "Nama Unit Harus Diisi"
                        },
                        ikk: {
                            required: "Nama Ikk Harus Diisi"
                        },
                        n_berita: {
                            required: "Nomor Berita Harus Diisi"
                        }
                    }, 
                    debug:true,
                    
                    errorPlacement: function(error, element) {
                        var name = element.attr('name');
                        var errorSelector = '.form-control-feedback[for="' + name + '"]';
                        var $element = $(errorSelector);
                        if ($element.length) { 
                            $(errorSelector).html(error.html());
                        } else {
                            error.insertAfter(element);
                        }
                    },
                    submitHandler : function(form) { 
                        form.submit();
                    }
                }); 
            }
            if($("#form-2").length > 0){
                $("#save-2").removeAttr("disabled");
                $("#form-2").validate({ 
                    rules: {
                        wilayah: {
                            required: true
                        },
                        pelayanan: {
                            required: true
                        },
                        target_pelayanan: {
                            required: true
                        },
                        jumlah_komersial: {
                            required: true
                        },
                        target_jiwa: {
                            required: true
                        },
                        jumlah_hidran: {
                            required: true
                        },
                        target_sr: {
                            required: true
                        },
                        jumlah_penduduk: {
                            required: true
                        },
                        jumlah_sr: {
                            required: true
                        }
                    },
                    messages: {
                        jumlah_penduduk: {
                            required: "Target Jumlah Harus Diisi"
                        },
                        target_sr: {
                            required: "Target Jumlah Harus Diisi"
                        },
                        jumlah_hidran: {
                            required: "Jumlah Hidran Harus Diisi"
                        },
                        target_jiwa: {
                            required: "Target Penduduk Harus Diisi"
                        },
                        jumlah_komersial: {
                            required: "Jumlah Sambungan Komersial Harus Diisi"
                        },
                        target_pelayanan: {
                            required: "Target Harus Diisi"
                        },
                        pelayanan: {
                            required: "Presentasi Pelayanan Harus Diisi"
                        },
                        wilayah: {
                            required: "Wilayah Pelayanan Harus Diisi"
                        },
                        jumlah_sr: {
                            required: "Jumlah Harus Diisi"
                        }
                    }, 
                    debug:true,

                    errorPlacement: function(error, element) {
                        var name = element.attr('name');
                        var errorSelector = '.form-control-feedback[for="' + name + '"]';
                        var $element = $(errorSelector);
                        if ($element.length) { 
                            $(errorSelector).html(error.html());
                        } else {
                            error.insertAfter(element);
                        }
                    },
                    submitHandler : function(form) { 
                        form.submit();
                    }
                }); 
            }
            if($("#form-3").length > 0){
                $("#save-3").removeAttr("disabled");
                $("#form-3").validate({ 
                    rules: {
                        terpasang: {
                            required: true
                        },
                        pelayanan: {
                            required: true
                        },
                        terjual: {
                            required: true
                        },
                        meter_induk: {
                            required: true
                        },
                        sumber_listrik: {
                            required: true
                        },
                        distribusi: {
                            required: true
                        },
                        jam: {
                            required: true
                        },
                        produksi: {
                            required: true
                        },
                        pengaliran: {
                            required: true
                        },
                        belum_terpakai: {
                            required: true
                        },
                        operasional: {
                            required: true
                        },
                        kehilangan: {
                            required: true
                        }
                    },
                    messages: {
                        kehilangan: {
                            required: "Jumlah Kehilangan Air Harus Diisi"
                        },
                        operasional: {
                            required: "Jam Operasional Harus Diisi"
                        },
                        belum_terpakai: {
                            required: "Kapasitas Air Belum Terpakai Harus Diisi"
                        },
                        produksi: {
                            required: "Kapasitas Air Produksi Harus Diisi"
                        },
                        jam: {
                            required: "Jam Dan Hari Harus Diisi"
                        },
                        distribusi: {
                            required: "Kapasitas Air Distribusi Harus Diisi"
                        },
                        sumber_listrik: {
                            required: "Sumber Daya Listrik Harus Dipilih"
                        },
                        meter_induk: {
                            required: "Meter Induksi Produksi Harus Dipilih"
                        },
                        terjual: {
                            required: "Kapasitas Air Terjual Harus Diisi"
                        },
                        pelayanan: {
                            required: "Presentasi Pelayanan Harus Diisi"
                        },
                        terpasang: {
                            required: "Kapasitas Air Terpasang Harus Diisi"
                        },
                        pengaliran: {
                            required: "Sistem Pengaliran Harus Dipilih"
                        }
                    }, 
                    debug:true,

                    errorPlacement: function(error, element) {
                        var name = element.attr('name');
                        var errorSelector = '.form-control-feedback[for="' + name + '"]';
                        var $element = $(errorSelector);
                        if ($element.length) { 
                            $(errorSelector).html(error.html());
                        } else {
                            error.insertAfter(element);
                        }
                    },
                    submitHandler : function(form) { 
                        form.submit();
                    }
                }); 
            }

            if($("#form-4").length > 0){
                $("#save-4").removeAttr("disabled");
                $("#form-4").validate({ 
                    rules: {
                        nama_pengelola: {
                            required: true
                        },
                        lat: {
                            required: true
                        },
                        jenis_pengelola: {
                            required: true
                        },
                        long: {
                            required: true
                        },
                        kondisi_pengelola: {
                            required: true
                        },
                        jumlahTeknis: {
                            required: true},
                        nama_ku: {
                            required: true
                        },
                        jumlahNon: {
                            required: true
                        },
                        namaCabang: {
                            required: true
                        }
                    },
                    messages: {
                        jumlahNon: {
                            required: "Jumlah Harus Diisi"
                        },
                        nama_ku: {
                            required: "Nama Harus Diisi"
                        },
                        jumlahTeknis: {
                            required: "Jumlah Harus Diisi"
                        },                        
                        kondisi_pengelola: {
                            required: "Kondisi Pengelola Harus Dipilih"
                        },
                        long: {
                            required: "Longtitude Harus Diisi"
                        },                        
                        jenis_pengelola: {
                            required: "Jenis Pengelola Harus Dipilih"
                        },
                        lat: {
                            required: "Latitude Harus Diisi"
                        },
                        nama_pengelola: {
                            required: "Nama Pengelola Harus Diisi"
                        },
                        namaCabang: {
                            required: "Nama Cabang Harus Diisi"
                        }
                    }, 
                    debug:true,

                    errorPlacement: function(error, element) {
                        var name = element.attr('name');
                        var errorSelector = '.form-control-feedback[for="' + name + '"]';
                        var $element = $(errorSelector);
                        if ($element.length) { 
                            $(errorSelector).html(error.html());
                        } else {
                            error.insertAfter(element);
                        }
                    },
                    submitHandler : function(form) { 
                        form.submit();
                    }
                }); 
            }

            if($("#form-5").length > 0){
                $("#save-5").removeAttr("disabled");
                $("#form-5").validate({ 
                    rules: {
                        dokGambar: {
                            required: true
                        },
                        rencanaTeknis: {
                            required: true
                        }
                        // gambarAbd: {
                        //     required: true
                        // },
                        // gambarDed: {
                        //     required: true
                        // }
                    },
                    messages: {
                        // gambarDed: {
                        //     required: "Rencana Teknis Harus Diisi"
                        // },                        
                        // gambarAbd: {
                        //     required: "Dokumen Gambar Harus Diisi"
                        // },
                        rencanaTeknis: {
                            required: "Rencana Teknis Harus Dipilih"
                        },
                        dokGambar: {
                            required: "Dokumen Gambar Harus Dipilih"
                        }
                    }, 
                    debug:true,

                    errorPlacement: function(error, element) {
                        var name = element.attr('name');
                        var errorSelector = '.form-control-feedback[for="' + name + '"]';
                        var $element = $(errorSelector);
                        if ($element.length) { 
                            $(errorSelector).html(error.html());
                        } else {
                            error.insertAfter(element);
                        }
                    },
                    submitHandler : function(form) { 
                        form.submit();
                    }
                }); 
            }

            if($("#form-7").length > 0){
                $("#save-7").removeAttr("disabled");
                $("#form-7").validate({ 
                    rules: {
                        jenisAir: {
                            required: true
                        },
                        tglSipa: {
                            required: true
                        },
                        namaAir: {
                            required: true
                        },
                        noInstansi: {
                            required: true
                        },
                        intake: {
                            required: true
                        },
                        airEksisting: {
                            required: true
                        },
                        kAlokasi: {
                            required: true
                        },
                        totalAirBaku: {
                            required: true
                        },
                        sumberDana: {
                            required: true
                        },
                        long: {
                            required: true
                        },
                        biaya: {
                            required: true
                        },
                        lat: {
                            required: true
                        },
                        tp: {
                            required: true
                        },
                        kIntake: {
                            required: true
                        }
                    },
                    messages: {
                        kIntake: {
                            required: "Kapasitas Total Harus Diisi"
                        },                        
                        tp: {
                            required: "Tahun Pelaksanaan Harus Diisi"
                        },
                        lat: {
                            required: "Latitude Harus Diisi"
                        },
                        biaya: {
                            required: "Indikasi Biaya Harus Diisi"
                        },
                        long: {
                            required: "Longtitude Harus Diisi"
                        },                        
                        sumberDana: {
                            required: "Sumber Pendanaan Harus Diisi"
                        },
                        totalAirBaku: {
                            required: "Kapasitas Total Harus Diisi"
                        },                        
                        kAlokasi: {
                            required: "Kebutuhan Alokasi Harus Diisi"
                        },
                        airEksisting: {
                            required: "Alokasi Kapasitas Air Baku Eksisting  Harus Diisi"
                        },
                        intake: {
                            required: "Kebutuhan Kapasitas Intake Harus Dipilih"
                        },
                        noInstansi: {
                            required: "Nomor/ Instansi Harus Diisi"
                        },                        
                        namaAir: {
                            required: "Nama Sumber Air Harus Diisi"
                        },
                        tglSipa: {
                            required: "Tanggal SIPA Harus Diisi"
                        },
                        jenisAir: {
                            required: "Jenis Sumber Air Harus Dipilih"
                        }
                    }, 
                    debug:true,

                    errorPlacement: function(error, element) {
                        var name = element.attr('name');
                        var errorSelector = '.form-control-feedback[for="' + name + '"]';
                        var $element = $(errorSelector);
                        if ($element.length) { 
                            $(errorSelector).html(error.html());
                        } else {
                            error.insertAfter(element);
                        }
                    },
                    submitHandler : function(form) { 
                        form.submit();
                    }
                }); 
            }
            if($("#form-8").length > 0){
                $("#save-8").removeAttr("disabled");
                $("#form-8").validate({ 
                    rules: {
                        jenisK3: {
                            required: true
                        },
                        kTahun3: {
                            required: true
                        },
                        anggaran3: {
                            required: true
                        },
                        jenisA3: {
                            required: true
                        },
                        kegiatan3: {
                            required: true
                        },
                        volumeK3: {
                            required: true
                        },
                        keterangan3: {
                            required: true
                        },
                        jenisK2: {
                            required: true
                        },
                        kTahun2: {
                            required: true
                        },
                        anggaran2: {
                            required: true
                        },
                        jenisA2: {
                            required: true
                        },
                        kegiatan2: {
                            required: true
                        },
                        volumeK2: {
                            required: true
                        },
                        keterangan2: {
                            required: true
                        },
                        jenisK1: {
                            required: true
                        },
                        kTahun1: {
                            required: true
                        },
                        anggaran1: {
                            required: true
                        },
                        jenisA1: {
                            required: true
                        },
                        kegiatan1: {
                            required: true
                        },
                        volumeK1: {
                            required: true
                        },
                        keterangan1: {
                            required: true
                        }
                    },
                    messages: {
                        keterangan3: {
                            required: "Kebutuhan Alokasi Harus Diisi"
                        },
                        volumeK3: {
                            required: "Volume Kegiatan  Harus Diisi"
                        },
                        kegiatan3: {
                            required: "Kegiatan Harus Diisi"
                        },
                        jenisA3: {
                            required: "Jenis Anggaran Harus Dipilih"
                        },                        
                        anggaran3: {
                            required: "Anggaran Harus Diisi"
                        },
                        kTahun3: {
                            required: "Tahun Harus Diisi"
                        },
                        jenisK3: {
                            required: "Jenis Kegiatan Harus Diisi"
                        },
                        keterangan2: {
                            required: "Kebutuhan Alokasi Harus Diisi"
                        },
                        volumeK2: {
                            required: "Volume Kegiatan  Harus Diisi"
                        },
                        kegiatan2: {
                            required: "Kegiatan Harus Diisi"
                        },
                        jenisA2: {
                            required: "Jenis Anggaran Harus Dipilih"
                        },                        
                        anggaran2: {
                            required: "Anggaran Harus Diisi"
                        },
                        kTahun2: {
                            required: "Tahun Harus Diisi"
                        },
                        jenisK2: {
                            required: "Jenis Kegiatan Harus Diisi"
                        },
                        keterangan1: {
                            required: "Kebutuhan Alokasi Harus Diisi"
                        },
                        volumeK1: {
                            required: "Volume Kegiatan  Harus Diisi"
                        },
                        kegiatan1: {
                            required: "Kegiatan Harus Diisi"
                        },
                        jenisA1: {
                            required: "Jenis Anggaran Harus Dipilih"
                        },                        
                        anggaran1: {
                            required: "Anggaran Harus Diisi"
                        },
                        kTahun1: {
                            required: "Tahun Harus Diisi"
                        },
                        jenisK1: {
                            required: "Jenis Kegiatan Harus Diisi"
                        }
                    }, 
                    debug:true,

                    errorPlacement: function(error, element) {
                        var name = element.attr('name');
                        var errorSelector = '.form-control-feedback[for="' + name + '"]';
                        var $element = $(errorSelector);
                        if ($element.length) { 
                            $(errorSelector).html(error.html());
                        } else {
                            error.insertAfter(element);
                        }
                    },
                    submitHandler : function(form) { 
                        form.submit();
                    }
                }); 
            }


            var group_id_selected = $("#group_id_selected").val();
            $( "#area_id" ).change(function() {
                var area_id = $(this).val();
                $.ajax({
                  method: "GET",
                  url: App.baseUrl+"group/getGroupsByArea",
                  data: { area_id: area_id}
                })
                .done(function( msg ) {
                    var response = JSON.parse(msg);
                    var groups = response.data;
                    if(response.status){
                        var html = '<option  >Pilih Departemen</option>';
                        for (var i = 0; i < groups.length; i++) { 
                            if(group_id_selected == groups[i].id){
                                html += "<option value='"+groups[i].id+"' selected>"+groups[i].name+"</option>";
                            }else{
                                html += "<option value='"+groups[i].id+"'>"+groups[i].name+"</option>";    
                            } 
                        }

                        $("#group_id").html(html);
                    }
                   
                });
            });

            $( "#area_id" ).trigger('change');
        },
        initConfirm :function(){
            $('#table tbody').on( 'click', '.delete', function () {
                var url = $(this).attr("url");
                App.confirm("Apakah Anda Yakin Untuk Mengubah Ini?",function(){
                   $.ajax({
                      method: "GET",
                      url: url
                    }).done(function( msg ) {
                        App.table.ajax.reload(null,true);
                    });        
                })
            });
        },
        // searchTable:function(){ 
        //     $('#search').on('click', function () {
        //         var name = $("#name").val();
        //         var ket = $("#ket").val();
                
                
        //         App.table.column(1).search(name,true,true);
        //         App.table.column(2).search(ket,true,true);
        //         App.table.draw();
                
        //     }); 
        // },
        // resetSearch:function(){
        //     $('#reset').on( 'click', function () {
        //         $("#name").val("");
        //         $("#ket").val("");
        //         App.table.search( '' ).columns().search( '' ).draw();
        //     });
        // },
	}
});