/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 * Old IE (v6, v7, v8) array polyfills for Highcharts v7+.
 *
 * (c) 2010-2018 Highsoft AS
 * Author: Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/oldie-polyfills.src.js';
