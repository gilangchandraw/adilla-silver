var App;
if(!window.console) {
	var console = {
		log : function(){},
		warn : function(){},
		error : function(){},
		time : function(){},
		timeEnd : function(){}
	}
}
var log = function() {};

require.config({
	paths: {
		// CORE //
		"jQuery": "../../plugins/architectui-core/jquery/jquery.min",
		"bootstrap": "../../plugins/architectui-core/bootstrap/js/bootstrap.bundle.min",
		"metisMenu": "../../plugins/architectui-core/metismenu/metisMenu.min",
		"architectui": "../../plugins/architectui-core/app.min",

		// CHARTS //
		"chartjs": "../../plugins/architectui-charts/Chart.bundle.min",
		"apexChart": "../../plugins/architectui-charts/apex-charts.min",
		"sparklinesChart": "../../plugins/architectui-charts/charts-sparklines.min",
		"Highcharts" : "../../plugins/highcharts/highcharts",
		"HighchartsTheme" : "../../plugins/highcharts/themes/grid-light",
		"HighchartsExporting" : "../../plugins/highcharts/modules/exporting",
		"HighchartsVariablePie" : "../../plugins/highcharts/modules/variable-pie",

		// FORMS //
		"bootstrapMultiSelect" : "../../plugins/architectui-form/bootstrap-multiselect.min",
		"select2" : "../../plugins/architectui-form/select2/select2.min",
		"ClipboardJS" : "../../plugins/architectui-form/clipboard.min",
		"datePicker" : "../../plugins/architectui-form/datepicker.min",
		"dateRangePicker" : "../../plugins/architectui-form/daterangepicker.min",
		"jValidation" : "../../plugins/architectui-form/form-validation.min",
		"SmartWizard" : "../../plugins/architectui-form/form-wizard.min",
		"inputMask" : "../../plugins/inputmask/jquery.inputmask.bundle.min",
		"moment" : "../../plugins/architectui-form/moment.min",
		"rangeSlider" : "../../plugins/architectui-form/range-slider.min",
		"textareaAutoSize" : "../../plugins/architectui-form/textarea-autosize.min",
		"bootstrapToggle" : "../../plugins/architectui-form/toggle-switch.min",
		"wnumb" : "../../plugins/architectui-form/wnumb.min",

		// COMPONENTS //
		"blockUI" : "../../plugins/architectui-component/blockui.min",
		"FullCalendar" : "../../plugins/architectui-component/calendar.min",
		"slick" : "../../plugins/architectui-component/carousel-slider.min",
		"circleProgress" : "../../plugins/architectui-component/circle-progress.min",
		"countUp" : "../../plugins/architectui-component/count-up.min",
		"cropperjs" : "../../plugins/architectui-component/cropper.min",
		"googlemaps" : "../../plugins/architectui-component/gmaps.min",
		"guidedTours" : "../../plugins/architectui-component/guided-tours.min",
		"jqueryCropper" : "../../plugins/architectui-component/jquery-cropper.min",
		"jvectormap" : "../../plugins/architectui-component/jvectormap.min",
		"laddaLoading" : "../../plugins/architectui-component/ladda-loading.min",
		"rating" : "../../plugins/architectui-component/rating.min",
		"PerfectScrollbar" : "../../plugins/architectui-component/scrollbar.min",
		"spin" : "../../plugins/architectui-component/spin.min",
		"bootstrapTables" : "../../plugins/architectui-component/tables.min",
		"treeview" : "../../plugins/architectui-component/treeview.min",
		"toastr" : "../../plugins/architectui-component/toastr/toastr.min",

		// TABLES //
		"datatables" : "../../plugins/architectui-tables/datatables/js/jquery.dataTables.min",
		"datatablesResponsive" : "../../plugins/architectui-tables/datatables/js/dataTables.responsive",
		"datatablesBootstrap4" : "../../plugins/architectui-tables/datatables/js/dataTables.bootstrap4.min",
		"bootstrapTables" : "../../plugins/architectui-component/tables.min",
		"Handsontable" : "../../plugins/handsontable/handsontable.full.min",

		// PROJECT CUSTOM //
		"tinymce" : "../../plugins/tinymce/js/tinymce/tinymce.min",
		"dropzone" : "../../plugins/dropzone/dropzone.min",
		"leaflet" : "../../plugins/map/leaflet",
		"leafletUTM" : "../../plugins/map/L.LatLng.UTM",
		"leafletSubFeatureGroup" : "../../plugins/map/subFeatureGroup",
		"leafletMarkerCluster" : "../../plugins/map/leaflet.markercluster",
		"leafletKML" : "../../plugins/map/L.KML",
		"JSZip" : "../../plugins/map/jszip",
		"toGeoJson" : "../../plugins/map/toGeoJson", 
		"geojson-vt" : "../../plugins/map/geojson-vt",
		"leaflet-pointable" : "../../plugins/map/leaflet-pointable",
		"leafletKMZ" : "../../plugins/map/leaflet-kmz-src",

	},
	waitSeconds: 0,
	// urlArgs: "bust=" + (new Date()).getTime(),
	shim: {
		// CORE //
		"jQuery": {
			exports: "jQuery",
			init: function(){
				console.log('JQuery inited..');
			}
		},
		"bootstrap": {
			deps: ["jQuery"],
			exports: "bootstrap",
			init: function(){
				console.log('bootstrap inited..');
			}
		},
		"metisMenu": {
			deps: ["jQuery"],
			exports: "metisMenu",
			init: function(){
				console.log('metisMenu inited..');
			}
		},
		"architectui": {
			deps: ["jQuery"],
			exports: "architectui",
			init: function(){
				console.log('themes inited..');
			}
		},
		// CHARTS //
		"chartjs": {
			deps: ["jQuery", "moment"],
			exports: "chartjs",
			init: function(){
				console.log('chartjs inited..');
			}
		},
		"apexChart": {
			deps: ["jQuery"],
			exports: "apexChart",
			init: function(){
				console.log('apexChart inited..');
			}
		},
		"sparklinesChart": {
			deps: ["jQuery"],
			exports: "sparklinesChart",
			init: function(){
				console.log('sparklinesChart inited..');
			}
		},
		"Highcharts": {
			deps: ["jQuery"],
			exports: "Highcharts",
			init: function(){
				console.log('highcharts inited..');
			}
		},
		"HighchartsTheme": {
			deps: ["jQuery","Highcharts"],
			exports: "HighchartsTheme",
			init: function(){
				console.log('HighchartsTheme inited..');
			}
		},
		"HighchartsExporting": {
			deps: ["jQuery","Highcharts"],
			exports: "HighchartsExporting",
			init: function(){
				console.log('HighchartsExporting inited..');
			}
		},
		"HighchartsVariablePie": {
			deps: ["jQuery","Highcharts"],
			exports: "HighchartsVariablePie",
			init: function(){
				console.log('HighchartsVariablePie inited..');
			}
		},
		// FORMS //
		"bootstrapMultiSelect": {
			deps: ["jQuery"],
			exports: "bootstrapMultiSelect",
			init: function(){
				console.log('bootstrapMultiSelect inited..');
			}
		},
		"select2": {
			deps: ["jQuery"],
			exports: "select2",
			init: function(){
				console.log('select2 inited..');
			}
		},
		"ClipboardJS": {
			deps: ["jQuery"],
			exports: "ClipboardJS",
			init: function(){
				console.log('ClipboardJS inited..');
			}
		},
		"datePicker": {
			deps: ["jQuery"],
			exports: "datePicker",
			init: function(){
				console.log('datePicker inited..');
			}
		},
		"dateRangePicker": {
			deps: ["jQuery", "moment"],
			exports: "dateRangePicker",
			init: function(){
				console.log('dateRangePicker inited..');
			}
		},
		"jValidation": {
			deps: ["jQuery"],
			exports: "jValidation",
			init: function(){
				console.log('jValidation inited..');
			}
		},
		"SmartWizard": {
			deps: ["jQuery"],
			exports: "SmartWizard",
			init: function(){
				console.log('SmartWizard inited..');
			}
		},
		"inputMask": {
			deps: ["jQuery"],
			exports: "inputMask",
			init: function(){
				console.log('inputMask inited..');
			}
		},
		"moment": {
			deps: ["jQuery"],
			exports: "moment",
			init: function(){
				console.log('moment inited..');
			}
		},
		"rangeSlider": {
			deps: ["jQuery"],
			exports: "rangeSlider",
			init: function(){
				console.log('rangeSlider inited..');
			}
		},
		"textareaAutosize": {
			deps: ["jQuery"],
			exports: "textareaAutosize",
			init: function(){
				console.log('textareaAutosize inited..');
			}
		},
		"bootstrapToggle": {
			deps: ["jQuery","bootstrap"],
			exports: "bootstrapToggle",
			init: function(){
				console.log('bootstrapToggle inited..');
			}
		},
		"wnumb": {
			deps: ["jQuery"],
			exports: "wnumb",
			init: function(){
				console.log('wnumb inited..');
			}
		},

		// COMPONENT //
		"blockUI": {
			deps: ["jQuery"],
			exports: "blockUI",
			init: function(){
				console.log('blockUI inited..');
			}
		},
		"FullCalendar": {
			deps: ["jQuery","moment"],
			exports: "FullCalendar",
			init: function(){
				console.log('FullCalendar inited..');
			}
		},
		"slick": {
			deps: ["jQuery","bootstrap"],
			exports: "slick",
			init: function(){
				console.log('slick inited..');
			}
		},
		"circleProgress": {
			deps: ["jQuery"],
			exports: "circleProgress",
			init: function(){
				console.log('circleProgress inited..');
			}
		},
		"countUp": {
			deps: ["jQuery"],
			exports: "countUp",
			init: function(){
				console.log('countUp inited..');
			}
		},
		"cropperjs": {
			deps: ["jQuery"],
			exports: "cropperjs",
			init: function(){
				console.log('cropperjs inited..');
			}
		},
		"googlemaps": {
			deps: ["jQuery"],
			exports: "googlemaps",
			init: function(){
				console.log('googlemaps inited..');
			}
		},
		"guidedTours": {
			deps: ["jQuery"],
			exports: "guidedTours",
			init: function(){
				console.log('guidedTours inited..');
			}
		},
		"jqueryCropper": {
			deps: ["jQuery","cropperjs"],
			exports: "jqueryCropper",
			init: function(){
				console.log('jqueryCropper inited..');
			}
		},
		"jvectormap": {
			deps: ["jQuery"],
			exports: "jvectormap",
			init: function(){
				console.log('jvectormap inited..');
			}
		},
		"laddaLoading": {
			deps: ["jQuery"],
			exports: "laddaLoading",
			init: function(){
				console.log('laddaLoading inited..');
			}
		},
		"rating": {
			deps: ["jQuery"],
			exports: "rating",
			init: function(){
				console.log('rating inited..');
			}
		},
		"PerfectScrollbar": {
			deps: ["jQuery"],
			exports: "PerfectScrollbar",
			init: function(){
				console.log('PerfectScrollbar inited..');
			}
		},
		"spin": {
			deps: ["jQuery"],
			exports: "spin",
			init: function(){
				console.log('spin inited..');
			}
		},
		"bootstrapTables": {
			deps: ["jQuery","bootstrap"],
			exports: "bootstrapTables",
			init: function(){
				console.log('bootstrapTables inited..');
			}
		},
		"treeview": {
			deps: ["jQuery"],
			exports: "treeview",
			init: function(){
				console.log('treeview inited..');
			}
		},
		"toastr": {
			deps: ["jQuery"],
			exports: "toastr",
			init: function(){
				console.log('toastr inited..');
			}
		},

		// TABLES //
		"datatables": {
			deps: ["jQuery"],
			exports: "datatables",
			init: function(){
				console.log('datatables inited..');
			}
		},
		"datatablesResponsive": {
			deps: ["jQuery","datatables"],
			exports: "datatablesResponsive",
			init: function(){
				console.log('datatablesResponsive inited..');
			}
		},
		"datatablesBootstrap4": {
			deps: ["jQuery","datatables"],
			exports: "datatablesBootstrap4",
			init: function(){
				console.log('datatablesBootstrap4 inited..');
			}
		},
		
		"bootstrapTables": {
			deps: ["jQuery","bootstrap"],
			exports: "bootstrapTables",
			init: function(){
				console.log('bootstrapTables inited..');
			}
		},
		"Handsontable": {
			deps: ["jQuery"],
			exports: "Handsontable",
			init: function(){
				console.log('Handsontable inited..');
			}
		},

		// PROJECT CUSTOM //
		"tinymce": {
			deps: ["jQuery"],
			exports: "tinymce",
			init: function(){
				console.log('tinymce inited..');
			}
		},
		"dropzone": {
			deps: ["jQuery"],
			exports: "dropzone",
			init: function(){
				console.log('dropzone inited..');
			}
		},
		"leaflet": {
			deps: ["jQuery"],
			exports: "leaflet",
			init: function(){
				console.log('leaflet inited..');
			}
		}, 
		"leafletUTM": {
			deps: ["jQuery", "leaflet"],
			exports: "leafletUTM",
			init: function(){
				console.log('leafletUTM inited..');
			}
		},
		"leafletSubFeatureGroup": {
			deps: ["jQuery", "leaflet"],
			exports: "leafletSubFeatureGroup",
			init: function(){
				console.log('leafletSubFeatureGroup inited..');
			}
		},
		"leafletMarkerCluster": {
			deps: ["jQuery", "leaflet"],
			exports: "leafletMarkerCluster",
			init: function(){
				console.log('leafletMarkerCluster inited..');
			}
		}, 
		"leafletKML": {
			deps: ["jQuery", "leaflet"],
			exports: "leafletKML",
			init: function(){
				console.log('leafletKML inited..');
			}
		},
		"JSZip": { 
			exports: "JSZip",
			init: function(){
				console.log('JSZip inited..');
			}
		},
		"toGeoJson": {
			deps: ["jQuery","leaflet"],
			exports: "toGeoJson",
			init: function(){
				console.log('toGeoJson inited..');
			}
		}, 
		"geojson-vt": {
			deps: ["jQuery","leaflet"],
			exports: "geojson-vt",
			init: function(){
				console.log('geojson-vt inited..');
			}
		},
		"leaflet-pointable": {
			deps: ["jQuery", "leaflet", "JSZip"],
			exports: "leaflet-pointable",
			init: function(){
				console.log('leaflet-pointable inited..');
			}
		},
		"leafletKMZ": {
			deps: ["jQuery", "leaflet"],
			exports: "leafletKMZ",
			init: function(){
				console.log('leafletKMZ inited..');
			}
		},
	}, 
	map: {
		'*': {
			'datatables.net': 'datatables',
			'datatables.net-responsive': 'datatablesResponsive',
			'googlemaps!': 'googlemaps',
			'@tmcw/togeojson': 'togeojson'
		}
	}
});