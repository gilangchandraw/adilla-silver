define([
    "jQuery",
    "bootstrap",
    "metisMenu",
    "architectui",
    "PerfectScrollbar",
    "datatables",
    "datatablesBootstrap4",
    "datatablesResponsive",
    "jValidation",
    "datePicker",
    "select2",
], function (
    $,
    bootstrap,
    metisMenu,
    architectui,
    PerfectScrollbar,
    datatables,
    datatablesBootstrap4,
    datatablesResponsive,
    jValidation,
    datePicker,
    select2,
) {
    return {
        table: null,
        init: function () {
            App.initFunc();
            App.initEvent();
            App.sidebarScroll();
            App.initPreview();
            $(".loadingpage").hide();
            // $("#hasil-laporan").hide();
            setTimeout(function () {
                $('.card-header').hide();
            }, 2500);
        },
        initPreview: function () {
            $('#preview-btn').on('click', function () {

                var cabang_id = $("#cabang_id").val();
                var tanggal = $("#tanggal").val();
                if (tanggal == "") {
                    App.alert('Pilih Filter terlebih dahulu');
                } else {

                }
                $.ajax({
                        url: App.baseUrl + 'laporan_pengeluaran/get_data',
                        type: 'GET',
                        data: {
                            cabang_id: cabang_id,
                            tanggal: tanggal,
                        },
                    })
                    .done(function (jqXHR) {
                        var data = JSON.parse(jqXHR);
                        if (data.status == true) {
                            var html_laporan = '';
                            html_laporan += '<div class="main-card mb-3 card">\
                            <div class="card-body">\
                                <section class="content">\
                                    <div class="box box-default color-palette-box">\
                                        <div class="box-body">\
                                            <div class="row" id="body_report">\
                                                <div class="col-md-12 mb-6" style="page-break-after: always; margin: auto; border: 8px; padding: 10px;">\
                                                    <div class="paycheck-container">\
                                                        <div class="full-width paycheck-logo">\
                                                            <p class="text-right"></p>\
                                                        </div>\
                                                        <div class="table-responsive">\
                                                        <table class="table table-border" align="center" border="1">\
                                                            <tbody>\
                                                                <tr>\
                                                                    <td rowspan="3"><img style="height: 50px" src="'+App.baseUrl+'assets/images/logo.png"></td>\
                                                                    <td class="text-center">ADILLA SILVER 925 GROUP</td>\
                                                                </tr>\
                                                                <tr>\
                                                                    <td align="center" class="text-center">Laporan Pengeluaran Harian Toko - '+data.bulan+' </td>\
                                                                </tr>\
                                                                <tr>\
                                                                    <td class="text-center"> Cabang : '+data.cabang+' </td>\
                                                                </tr>\
                                                            </tbody>\
                                                        </table>\
                                                        <table class="table table-border" border="1">\
                                                            <thead>\
                                                                <tr>\
                                                                    <th class="text-center">Tanggal</th>\
                                                                    <th class="text-center">KRW</th>\
                                                                    <th class="text-center">Kontrak Toko</th>\
                                                                    <th class="text-center">Listrik</th>\
                                                                    <th class="text-center">PDAM</th>\
                                                                    <th class="text-center">Gaji KRW</th>\
                                                                    <th class="text-center">Bonus</th>\
                                                                    <th class="text-center">Setor Kas</th>\
                                                                    <th class="text-center">Biaya Tidak Terduga</th>\
                                                                </tr>\
                                                            </thead>';
                                                            if (data.pengeluaran != null) {
                                                                for (var i = 0; i < data.pengeluaran.length; i++) {
                                                                    html_laporan += '<tr>';
                                                                    html_laporan += '<td class="text-center">'+data.pengeluaran[i].tanggal+'</td>';
                                                                    if (data.pengeluaran[i].jumlah_pengeluaran_1 == 0) {
                                                                        html_laporan += '<td class="text-center"></td>';
                                                                    } else {                                                                       
                                                                        html_laporan += '<td class="text-center">'+data.pengeluaran[i].jumlah_pengeluaran_1+'</td>';
                                                                    }
                                                                    if (data.pengeluaran[i].jumlah_pengeluaran_2 == 0) {
                                                                        html_laporan += '<td class="text-center"></td>';
                                                                    } else {                                                                       
                                                                        html_laporan += '<td class="text-center">'+data.pengeluaran[i].jumlah_pengeluaran_2+'</td>';
                                                                    }
                                                                    if (data.pengeluaran[i].jumlah_pengeluaran_5 == 0) {
                                                                        html_laporan += '<td class="text-center"></td>';
                                                                    } else {                                                                       
                                                                        html_laporan += '<td class="text-center">'+data.pengeluaran[i].jumlah_pengeluaran_5+'</td>';
                                                                    }
                                                                    if (data.pengeluaran[i].jumlah_pengeluaran_7 == 0) {
                                                                        html_laporan += '<td class="text-center"></td>';
                                                                    } else {                                                                       
                                                                        html_laporan += '<td class="text-center">'+data.pengeluaran[i].jumlah_pengeluaran_7+'</td>';
                                                                    }
                                                                    if (data.pengeluaran[i].jumlah_pengeluaran_4 == 0) {
                                                                        html_laporan += '<td class="text-center"></td>';
                                                                    } else {                                                                       
                                                                        html_laporan += '<td class="text-center">'+data.pengeluaran[i].jumlah_pengeluaran_4+'</td>';
                                                                    }
                                                                    if (data.pengeluaran[i].jumlah_pengeluaran_11 == 0) {
                                                                        html_laporan += '<td class="text-center"></td>';
                                                                    } else {                                                                       
                                                                        html_laporan += '<td class="text-center">'+data.pengeluaran[i].jumlah_pengeluaran_11+'</td>';
                                                                    }
                                                                    if (data.pengeluaran[i].jumlah_pengeluaran_12 == 0) {
                                                                        html_laporan += '<td class="text-center"></td>';
                                                                    } else {                                                                       
                                                                        html_laporan += '<td class="text-center">'+data.pengeluaran[i].jumlah_pengeluaran_12+'</td>';
                                                                    }
                                                                    if (data.pengeluaran[i].jumlah_pengeluaran_10 == 0) {
                                                                        html_laporan += '<td class="text-center"></td>';
                                                                    } else {                                                                       
                                                                        html_laporan += '<td class="text-center">'+data.pengeluaran[i].jumlah_pengeluaran_10+'</td>';
                                                                    }
                                                                                                                                        
                                                                    html_laporan += '</tr>\
                                                                    ';
                                                                }
                                                            }
                                                        html_laporan += '</table>\
                                                        </div>\
                                                    </div>\
                                                </div>\
                                            </div>\
                                        </div>\
                                    </div>\
                                </section>\
                            </div>\
                        </div>';

                            $('#hasil-report').html(html_laporan);
                            $("#hasil-report").show();
                            $("#hasil-laporan-tidak-ada").hide();
                            $('#print-pdf').attr('href', App.baseUrl + 'laporan_pengeluaran/print_pdf?cabang_id=' + cabang_id + '&tanggal=' + tanggal);



                        } else {
                            $("#hasil-report").hide();
                            html_laporan = '';
                            html_laporan += '<div class="main-card mb-3 card">\
                                            <div class="card-body">\
                                                <div class="row">\
                                                    <h4 class="text-center">Data Tidak Ditemukan</h4>\
                                                </div>\
                                            </div>\
                                        </div>';
                            $('#hasil-laporan-tidak-ada').html(html_laporan);
                            $("#hasil-laporan-tidak-ada").show();
                        }
                        // App.HitungPersentaseRencana($('#rencana_jumlah_penduduk').val(), data.jumlah_penduduk);
                    })
                    .fail(function () {
                        console.log("error");
                    })

            });
        },
        initEvent: function () {
            $('.select2').select2();

            $('.init-year-month').datepicker({
                   // format: "YYYY"
                   format: "mm-yyyy",
                    viewMode: "months", 
                    minViewMode: "months"
            });
        },

        sidebarScroll: function () {
            setTimeout(function () {
                if ($(".scrollbar-container")[0]) {
                    $('.scrollbar-container').each(function () {
                        const ps = new PerfectScrollbar($(this)[0], {
                            wheelSpeed: 2,
                            wheelPropagation: false,
                            minScrollbarLength: 20
                        });
                    });


                    const ps = new PerfectScrollbar('.scrollbar-sidebar', {
                        wheelSpeed: 2,
                        wheelPropagation: true,
                        minScrollbarLength: 20
                    });
                }
            }, 1000);
        },
    }
});