define([
    "jQuery",
    "bootstrap",
    "metisMenu",
    "architectui",
    "PerfectScrollbar",
    "datatables",
    "datatablesBootstrap4",
    "datatablesResponsive",
    "jValidation",
    "datePicker",
    "select2",
], function (
    $,
    bootstrap,
    metisMenu,
    architectui,
    PerfectScrollbar,
    datatables,
    datatablesBootstrap4,
    datatablesResponsive,
    jValidation,
    datePicker,
    select2,
) {
    return {
        table: null,
        init: function () {
            App.initFunc();
            App.initEvent();
            App.sidebarScroll();
            App.initConfirm();
            App.dataList();
            App.validationJs();
            $(".loadingpage").hide();
            $(".dataTables_filter").hide();
            setTimeout(function () {
                $('.card-header').hide();
            }, 2500);
        },
        initEvent: function() {
            $('.init-date').datepicker({
                uiLibrary: 'bootstrap4',
                format: 'YYYY-mm-dd'
            });

            $('.select2').select2();

            $('#cabang_id').change(function () {
                var cabang_id = $("#cabang_id").val();
                $.ajax({
                    type: 'GET',
                    url: App.baseUrl+'cabang/get_data_cabang',
                    data: {
                        'cabang_id': cabang_id,
                    },
                    success: function (jqXHR) {
                        var data = JSON.parse(jqXHR);
                        if(data.status == true){
                            $('#stok_retur_bk_cabang_925').val(data.stok_retur_bk_925);
                            $('#stok_retur_pajang_cabang_925').val(data.stok_retur_pajang_925);
                            $('#stok_retur_bk_cabang_sp').val(data.stok_retur_bk_sp);
                            $('#stok_retur_pajang_cabang_sp').val(data.stok_retur_pajang_sp);
                        }else{
                            $('#no_nota').val('');
                            $('#no_nota_view').val('');
                        }
                    }
                });

            });
        },

        sidebarScroll: function () {
            setTimeout(function () {
                if ($(".scrollbar-container")[0]) {
                    $('.scrollbar-container').each(function () {
                        const ps = new PerfectScrollbar($(this)[0], {
                            wheelSpeed: 2,
                            wheelPropagation: false,
                            minScrollbarLength: 20
                        });
                    });

                    const ps = new PerfectScrollbar('.scrollbar-sidebar', {
                        wheelSpeed: 2,
                        wheelPropagation: true,
                        minScrollbarLength: 20
                    });
                }
            }, 1000);
        },

        initConfirm: function () {
            $('#table').on('click', '.delete', function () {
                var url = $(this).attr("url");
                App.confirm("Apakah Anda Yakin Untuk Mengahpus Ini?", function () {
                    $.ajax({
                        method: "GET",
                        url: url
                    }).done(function (msg) {
                        $('.loadingpage').hide();
                        App.table.ajax.reload(null, true);
                    });
                })
            });
        },

        dataList: function () {
            App.table = $('#table').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first": "Pertama",
                        "last": "Terakhir",
                        "next": "Selanjutnya",
                        "previous": "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": App.baseUrl + "tarik_stok_retur/dataList",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [{
                        "data": "id"
                    },
                    {
                        "data": "tanggal",
                        "orderable": false
                    },
                    {
                        "data": "nama_cabang",
                        "orderable": false
                    },
                    {
                        "data": "tarik_stok_retur_bk_925",
                        "orderable": false
                    },
                    {
                        "data": "tarik_stok_retur_pajang_925",
                        "orderable": false
                    },
                    {
                        "data": "tarik_stok_retur_bk_sp",
                        "orderable": false
                    },
                    {
                        "data": "tarik_stok_retur_pajang_sp",
                        "orderable": false
                    },
                    {
                        "data": "action",
                        "orderable": false
                    }
                ],
                "columnDefs": [{
                    "targets": [0, 1, 2, 3, 4,5,6,7],
                    "className": "text-center"
                }, ]
            });

            //append button to datatables
            // add_btn = '<a href="'+App.baseUrl+'group/create" class="btn btn-sm btn-primary ml-2 mt-1"><i class="fa fa-plus"></i> Departemen</a>';
            // $('#table_filter').append(add_btn);
        },

        validationJs: function () {
            $("#form").validate({
                rules: {
                    tarik_stok_retur_pajang_925: {
                        required: true
                    },
                    tarik_stok_retur_bk_925: {
                        required: true
                    },                    
                    tarik_stok_retur_pajang_sp: {
                        required: true
                    },
                    tarik_stok_retur_bk_sp: {
                        required: true
                    },                    
                    cabang_id: {
                        required: true
                    },
                    tanggal: {
                        required: true
                    },
                },
                messages: {
                    tarik_stok_retur_pajang_sp: {
                        required: "*) harus diisi"
                    },
                    tarik_stok_retur_bk_sp: {
                        required: "*) harus diisi"
                    },
                    tarik_stok_retur_pajang_925: {
                        required: "*) harus diisi"
                    },
                    tarik_stok_retur_bk_925: {
                        required: "*) harus diisi"
                    },
                    tanggal: {
                        required: "*) harus diisi"
                    },
                    cabang_id: {
                        required: "*) harus diisi"
                    },
                },
                debug: true,
                errorElement: "em",
                errorPlacement: function (error, element) {
                    // Add the `invalid-feedback` class to the error element
                    error.addClass("invalid-feedback");
                    if (element.prop("type") === "checkbox") {
                        error.insertBefore(element.next("label"));
                    } else if (element.prop("type") === "radio") {
                        error.appendTo(element.parent().parent().parent());
                    } else {
                        error.insertBefore(element);
                    }
                },
                highlight: function (element, errorClass, validClass) {
                    $(element).addClass("is-invalid").removeClass("is-valid");
                },
                unhighlight: function (element, errorClass, validClass) {
                    $(element).addClass("is-valid").removeClass("is-invalid");
                },
                submitHandler: function (form) {
                    form.submit();
                }
            });
        },
    }
});