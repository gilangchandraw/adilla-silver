define([
    "jQuery",
    "bootstrap",
    "metisMenu",
    "architectui",
    "PerfectScrollbar",
    "datatables",
    "datatablesBootstrap4",
    "datatablesResponsive",
    "jValidation",
    "datePicker",
    "select2",
], function (
    $,
    bootstrap,
    metisMenu,
    architectui,
    PerfectScrollbar,
    datatables,
    datatablesBootstrap4,
    datatablesResponsive,
    jValidation,
    datePicker,
    select2,
) {
    return {
        table: null,
        init: function () {
            App.initFunc();
            App.initEvent();
            App.sidebarScroll();
            App.initConfirm();
            App.dataList();
            App.validationJs();
            $(".loadingpage").hide();
            $(".dataTables_filter").hide();
            setTimeout(function () {
                $('.card-header').hide();
            }, 2500);
        },
        initEvent: function() {
            $('.init-date').datepicker({
                uiLibrary: 'bootstrap4',
                format: 'YYYY-mm-dd'
            });

            $('.select2').select2();

            $('#cabang_id').change(function () {
                var cabang_id = $("#cabang_id").val();
                $.ajax({
                    type: 'GET',
                    url: App.baseUrl+'cabang/get_data_uang_nota',
                    data: {
                        'cabang_id': cabang_id,
                    },
                    success: function (jqXHR) {
                        var data = JSON.parse(jqXHR);
                        if(data.status == true){
                            $('#jumlah_uang_nota_cabang').val(data.total);
                        }else{
                            $('#jumlah_uang_nota_cabang').val('');
                        }
                    }
                });

            });

            // cek validasi penarikan
            $('input[name=jumlah_penarikan]').change(function() { 

                var jumlah_penarikan = $('#jumlah_penarikan').val();
                jumlah_penarikan = parseInt(jumlah_penarikan);
                var jumlah_uang_nota_cabang = $('#jumlah_uang_nota_cabang').val();
                jumlah_uang_nota_cabang = parseInt(jumlah_uang_nota_cabang);
                if (jumlah_penarikan > jumlah_uang_nota_cabang) {
                    App.alert('Jumlah Penarikan tidak boleh lebih dari jumlah uang nota di cabang!!!');
                    $('#jumlah_penarikan').val('');
                }
            });
        },

        sidebarScroll: function () {
            setTimeout(function () {
                if ($(".scrollbar-container")[0]) {
                    $('.scrollbar-container').each(function () {
                        const ps = new PerfectScrollbar($(this)[0], {
                            wheelSpeed: 2,
                            wheelPropagation: false,
                            minScrollbarLength: 20
                        });
                    });

                    const ps = new PerfectScrollbar('.scrollbar-sidebar', {
                        wheelSpeed: 2,
                        wheelPropagation: true,
                        minScrollbarLength: 20
                    });
                }
            }, 1000);
        },

        initConfirm: function () {
            $('#table').on('click', '.delete', function () {
                var id = $(this).attr("id");
                App.confirm("Apakah Anda Yakin Untuk Menghapus data Ini?", function () {
                    window.location.href = App.baseUrl+'tarik_uang_nota/delete/'+id;                    
                })
            });
        },

        dataList: function () {
            App.table = $('#table').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first": "Pertama",
                        "last": "Terakhir",
                        "next": "Selanjutnya",
                        "previous": "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": App.baseUrl + "tarik_uang_nota/dataList",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [{
                        "data": "id"
                    },
                    {
                        "data": "tanggal",
                        "orderable": false
                    },
                    {
                        "data": "nama_cabang",
                        "orderable": false
                    },
                    {
                        "data": "jumlah_penarikan",
                        "orderable": false
                    },
                    {
                        "data": "action",
                        "orderable": false
                    }
                ],
                "columnDefs": [{
                    "targets": [0, 1, 2, 3, 4],
                    "className": "text-center"
                }, ]
            });
        },

        validationJs: function () {
            $("#form").validate({
                rules: {
                    jumlah_penarikan: {
                        required: true
                    },                    
                    cabang_id: {
                        required: true
                    },
                    tanggal: {
                        required: true
                    },
                },
                messages: {
                    jumlah_penarikan: {
                        required: "*) harus diisi"
                    },
                    tanggal: {
                        required: "*) harus diisi"
                    },
                    cabang_id: {
                        required: "*) harus diisi"
                    },
                },
                debug: true,
                errorElement: "em",
                errorPlacement: function (error, element) {
                    // Add the `invalid-feedback` class to the error element
                    error.addClass("invalid-feedback");
                    if (element.prop("type") === "checkbox") {
                        error.insertBefore(element.next("label"));
                    } else if (element.prop("type") === "radio") {
                        error.appendTo(element.parent().parent().parent());
                    } else {
                        error.insertBefore(element);
                    }
                },
                highlight: function (element, errorClass, validClass) {
                    $(element).addClass("is-invalid").removeClass("is-valid");
                },
                unhighlight: function (element, errorClass, validClass) {
                    $(element).addClass("is-valid").removeClass("is-invalid");
                },
                submitHandler: function (form) {
                    form.submit();
                }
            });
        },
    }
});