define([
	"jQuery",
	"bootstrap",
	"metisMenu",
	"architectui",
	"PerfectScrollbar",
	"Highcharts",
	"HighchartsTheme",
	"HighchartsExporting",
	"HighchartsVariablePie",
	], function (
	$,
	bootstrap,
	metisMenu,
	architectui,
	PerfectScrollbar,
	Highcharts,
	HighchartsTheme,
	HighchartsExporting,
	HighchartsVariablePie,
	) {
	return {
		tahun:0,
		bulan:0,
		tanggal:1,
		init: function () { 
			App.initFunc();
			// App.initChart();
			App.sidebarScroll();
		},

		sidebarScroll: function () {
			setTimeout(function () {
		        if ($(".scrollbar-container")[0]) {
		            $('.scrollbar-container').each(function () {
		                const ps = new PerfectScrollbar($(this)[0], {
		                    wheelSpeed: 2,
		                    wheelPropagation: false,
		                    minScrollbarLength: 20
		                });
		            });

		            const ps = new PerfectScrollbar('.scrollbar-sidebar', {
		                wheelSpeed: 2,
		                wheelPropagation: true,
		                minScrollbarLength: 20
		            });
		        }
		    }, 1000);
		},

		// initChart: function () {
		// 	HighchartsTheme(Highcharts);
		// 	HighchartsExporting(Highcharts);
		// 	HighchartsVariablePie(Highcharts);
  //           App.initYearlyChart();
  //           App.initMonthlyChart();
			
		// },
  //       initYearlyChart: function (){
  //           var d = new Date();
  //           App.bulan = $('#selectBulanSurvei').val();
  //           App.tahun = $('#selectTahunSurvei').val();

  //           if(App.bulan == "")
  //           {
  //               selectBulan = d.getMonth() + 1;
  //               $('#selectBulanSurvei').val(selectBulan);
  //               App.bulan = $('#selectBulanSurvei').val();;
  //           }
  //           if(App.tahun == "")
  //           {
  //               selectTahun = d.getFullYear();
  //               console.log(selectTahun)
  //               $('#selectTahunSurvei').val(selectTahun);
  //               App.tahun = $('#selectTahunSurvei').val();;
  //           }
  //           App.chartKepemilikanJamban();
  //           App.chartKepemilikanTangki();
  //           App.chartKepemilikanJambanTanpaTangkiSeptik();
  //           App.chartAksesPenyedotanTinja();
  //           App.chartProgramLltt();
  //           App.chartBiayaPenyedotanTinja();
  //       },
  //       initMonthlyChart: function (){
  //           var d = new Date();
  //           App.bulan = $('#selectBulanSurvei').val();
  //           App.tahun = $('#selectTahunSurvei').val();

  //           if(App.bulan == "")
  //           {
  //               selectBulan = d.getMonth() + 1;
  //               $('#selectBulanSurvei').val(selectBulan);
  //               App.bulan = $('#selectBulanSurvei').val();;
  //           }
  //           if(App.tahun == "")
  //           {
  //               selectTahun = d.getFullYear();
  //               console.log(selectTahun)
  //               $('#selectTahunSurvei').val(selectTahun);
  //               App.tahun = $('#selectTahunSurvei').val();;
  //           }
  //           App.chartDataPerhari();
  //       },
  //       chartDataPerhari: function (){
			
		// 	$.ajax({
  //               url : App.baseUrl+'dashboard/total_kuesioner_per_hari/',
  //               type : 'GET',
  //               data:{
  //                       month       : App.bulan,
  //                       year        : App.tahun,
  //                   },
  //               dataType : 'json',
  //               success : function(result)
  //               {
  //               	Highcharts.chart('jumlah-data-perhari', {

		// 			    title: {
		// 			        text: 'Total Data Survei Bulan '+result.nama_bulan
		// 			    },

		// 			    // subtitle: {
		// 			    //     text: 'Source: thesolarfoundation.com'
		// 			    // },

		// 			    yAxis: {
		// 			        title: {
		// 			            text: 'Total Data'
		// 			        }
		// 			    },

		// 			    xAxis: {
		// 			    	categories: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12','13', '14', '15', '16', '17', '18', '19', '20', '21', '22', '23', '24','25','26','27','28','29','30','31']
		// 			    	// type: 'datetime',
		// 			    	// dateTimeLabelFormats: {
		// 		      //           millisecond: '%b %e'
		// 		      //       }
		// 			        // accessibility: {
		// 			        //     rangeDescription: 'Range: 2010 to 2020'
		// 			        // }
		// 			    },

		// 			    legend: {
		// 			        layout: 'vertical',
		// 			        align: 'right',
		// 			        verticalAlign: 'middle'
		// 			    },

		// 			    // plotOptions: {
		// 			    //     series: {
		// 			    //         pointStart: Date.UTC(App.tahun, App.bulan, App.tanggal),
		// 			    //         pointInterval: 24 * 3600 * 1000 // one day
					            
		// 			    //     }
		// 			    // },

		// 			    series: result.series,

		// 			    responsive: {
		// 			        rules: [{
		// 			            condition: {
		// 			                maxWidth: 500
		// 			            },
		// 			            chartOptions: {
		// 			                legend: {
		// 			                    layout: 'horizontal',
		// 			                    align: 'center',
		// 			                    verticalAlign: 'bottom'
		// 			                }
		// 			            }
		// 			        }]
		// 			    }

		// 			});
  //               }
  //           });
		// },
		// chartKepemilikanJamban : function(){
		// 	$.get(App.baseUrl + 'dashboard/kepemilikan_jamban',{ month: App.bulan, year: App.tahun }, function(result){
		// 		Highcharts.chart('kepemilikan-jamban', {
		// 			chart: {
		// 				type: 'variablepie',
		// 				plotBackgroundColor: null,
		// 				plotBorderWidth: null,
		// 				plotShadow: false,
		// 			},
		// 			title: {
		// 				text: 'Kepemilikan Jamban'
		// 			},
		// 			credits: {
		// 				enabled: false
		// 			},
		// 			plotOptions: {
		// 				series: {
		// 					dataLabels: {
		// 						enabled: true,
		// 						format: '{point.name}: {point.percentage:.2f} %'
		// 					}
		// 				},
		// 			},
		// 			tooltip: {
		// 				headerFormat: '',
		// 				pointFormat: 
		// 					'<span style="color:{point.color}">\u25CF</span>'+
		// 						'<b> {point.name}</b><br/>' +
		// 					'Persentase: <b>{point.percentage:.2f} %</b><br/>' +
		// 					'Total: <b>{point.z} </b><br/>'
		// 			},
		// 			series: [{
		// 				allowPointSelect: true,
		// 				minPointSize: 10,
		// 				innerSize: '25%',
		// 				showInLegend: true,
		// 				zMin: 0,
		// 				name: 'kepemilikan-jamban',
		// 				data: result.series
		// 			}]
		// 		});
		// 	}, 'json');
		// },

		// chartKepemilikanTangki : function(){
		// 	$.get(App.baseUrl + 'dashboard/kepemilikan_tangki',{ month: App.bulan, year: App.tahun }, function(result){
		// 		Highcharts.chart('kepemilikan-tangki', {
		// 			chart: {
		// 				type: 'variablepie',
		// 				plotBackgroundColor: null,
		// 				plotBorderWidth: null,
		// 				plotShadow: false,
		// 			},
		// 			title: {
		// 				text: 'Kepemilikan Dan Kondisi Tangki Septik'
		// 			},
		// 			credits: {
		// 				enabled: false
		// 			},
		// 			plotOptions: {
		// 				series: {
		// 					dataLabels: {
		// 						enabled: true,
		// 						format: '{point.name}: {point.percentage:.2f} %'
		// 					}
		// 				},
		// 			},
		// 			tooltip: {
		// 				headerFormat: '',
		// 				pointFormat: 
		// 					'<span style="color:{point.color}">\u25CF</span>'+
		// 						'<b> {point.name}</b><br/>' +
		// 					'Persentase: <b>{point.percentage:.2f} %</b><br/>' +
		// 					'Total: <b>{point.z} </b><br/>'
		// 			},
		// 			series: [{
		// 				allowPointSelect: true,
		// 				minPointSize: 10,
		// 				innerSize: '25%',
		// 				showInLegend: true,
		// 				zMin: 0,
		// 				name: 'kepemilikan-tangki',
		// 				data: result.series
		// 			}]
		// 		});
		// 	}, 'json');
		// },

		// chartKepemilikanJambanTanpaTangkiSeptik : function(){
		// 	$.get(App.baseUrl + 'dashboard/kepemilikan_jamban_tanpa_tangki_septik',{ month: App.bulan, year: App.tahun }, function(result){
		// 		Highcharts.chart('kepemilikan-jamban-tanpa-tangki-septik', {
		// 			chart: {
		// 				type: 'variablepie',
		// 				plotBackgroundColor: null,
		// 				plotBorderWidth: null,
		// 				plotShadow: false,
		// 			},
		// 			title: {
		// 				text: 'Kepemilikan Jamban Tanpa Tangki Septik'
		// 			},
		// 			credits: {
		// 				enabled: false
		// 			},
		// 			plotOptions: {
		// 				series: {
		// 					dataLabels: {
		// 						enabled: true,
		// 						format: '{point.name}: {point.percentage:.2f} %'
		// 					}
		// 				},
		// 			},
		// 			tooltip: {
		// 				headerFormat: '',
		// 				pointFormat: 
		// 					'<span style="color:{point.color}">\u25CF</span>'+
		// 						'<b> {point.name}</b><br/>' +
		// 					'Persentase: <b>{point.percentage:.2f} %</b><br/>' +
		// 					'Total: <b>{point.z} </b><br/>'
		// 			},
		// 			series: [{
		// 				allowPointSelect: true,
		// 				minPointSize: 10,
		// 				innerSize: '25%',
		// 				showInLegend: true,
		// 				zMin: 0,
		// 				name: 'kepemilikan-jamban-tanpa-tangki-septik',
		// 				data: result.series
		// 			}]
		// 		});
		// 	}, 'json');
		// },

		// chartAksesPenyedotanTinja : function(){
		// 	$.get(App.baseUrl + 'dashboard/akses_penyedotan_tinja',{ month: App.bulan, year: App.tahun }, function(result){
		// 		Highcharts.chart('akses-penyedotan-tinja', {
		// 			chart: {
		// 				type: 'variablepie',
		// 				plotBackgroundColor: null,
		// 				plotBorderWidth: null,
		// 				plotShadow: false,
		// 			},
		// 			title: {
		// 				text: 'Akses Jalan Untuk Penyedotan Tangki Septik'
		// 			},
		// 			credits: {
		// 				enabled: false
		// 			},
		// 			plotOptions: {
		// 				series: {
		// 					dataLabels: {
		// 						enabled: true,
		// 						format: '{point.name}: {point.percentage:.2f} %'
		// 					}
		// 				},
		// 			},
		// 			tooltip: {
		// 				headerFormat: '',
		// 				pointFormat: 
		// 					'<span style="color:{point.color}">\u25CF</span>'+
		// 						'<b> {point.name}</b><br/>' +
		// 					'Persentase: <b>{point.percentage:.2f} %</b><br/>' +
		// 					'Total: <b>{point.z} </b><br/>'
		// 			},
		// 			series: [{
		// 				allowPointSelect: true,
		// 				minPointSize: 10,
		// 				innerSize: '25%',
		// 				showInLegend: true,
		// 				zMin: 0,
		// 				name: 'akses-penyedotan-tinja',
		// 				data: result.series
		// 			}]
		// 		});
		// 	}, 'json');
		// },

		// chartProgramLltt : function(){
		// 	$.get(App.baseUrl + 'dashboard/program_lltt',{ month: App.bulan, year: App.tahun }, function(result){
		// 		Highcharts.chart('program-lltt', {
		// 			chart: {
		// 				type: 'variablepie',
		// 				plotBackgroundColor: null,
		// 				plotBorderWidth: null,
		// 				plotShadow: false,
		// 			},
		// 			title: {
		// 				text: 'Kesediaan Menggunakan Tangki Kedap Dan Mengikuti Program LLTT'
		// 			},
		// 			credits: {
		// 				enabled: false
		// 			},
		// 			plotOptions: {
		// 				series: {
		// 					dataLabels: {
		// 						enabled: true,
		// 						format: '{point.name}: {point.percentage:.2f} %'
		// 					}
		// 				},
		// 			},
		// 			tooltip: {
		// 				headerFormat: '',
		// 				pointFormat: 
		// 					'<span style="color:{point.color}">\u25CF</span>'+
		// 						'<b> {point.name}</b><br/>' +
		// 					'Persentase: <b>{point.percentage:.2f} %</b><br/>' +
		// 					'Total: <b>{point.z} </b><br/>'
		// 			},
		// 			series: [{
		// 				allowPointSelect: true,
		// 				minPointSize: 10,
		// 				innerSize: '25%',
		// 				showInLegend: true,
		// 				zMin: 0,
		// 				name: 'akses-penyedotan-tinja',
		// 				data: result.series
		// 			}]
		// 		});
		// 	}, 'json');
		// },

		// chartBiayaPenyedotanTinja : function(){
		// 	$.get(App.baseUrl + 'dashboard/biaya_penyedotan_tinja',{ month: App.bulan, year: App.tahun }, function(result){
		// 		Highcharts.chart('biaya-penyedotan-tinja', {
		// 			chart: {
		// 				type: 'variablepie',
		// 				plotBackgroundColor: null,
		// 				plotBorderWidth: null,
		// 				plotShadow: false,
		// 			},
		// 			title: {
		// 				text: 'Kesediaan Membayar Biaya Penyedotan Tangki Septik (Ability To Pay)'
		// 			},
		// 			credits: {
		// 				enabled: false
		// 			},
		// 			plotOptions: {
		// 				series: {
		// 					dataLabels: {
		// 						enabled: true,
		// 						format: '{point.name}: {point.percentage:.2f} %'
		// 					}
		// 				},
		// 			},
		// 			tooltip: {
		// 				headerFormat: '',
		// 				pointFormat: 
		// 					'<span style="color:{point.color}">\u25CF</span>'+
		// 						'<b> {point.name}</b><br/>' +
		// 					'Persentase: <b>{point.percentage:.2f} %</b><br/>' +
		// 					'Total: <b>{point.z} </b><br/>'
		// 			},
		// 			series: [{
		// 				allowPointSelect: true,
		// 				minPointSize: 10,
		// 				innerSize: '25%',
		// 				showInLegend: true,
		// 				zMin: 0,
		// 				name: 'akses-penyedotan-tinja',
		// 				data: result.series
		// 			}]
		// 		});
		// 	}, 'json');
		// },
	}
});