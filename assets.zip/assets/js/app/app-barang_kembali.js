define([
    "jQuery",
    "bootstrap",
    "metisMenu",
    "architectui",
    "PerfectScrollbar",
    "datatables",
    "datatablesBootstrap4",
    "datatablesResponsive",
    "jValidation",
    "datePicker",
    "select2",
], function (
    $,
    bootstrap,
    metisMenu,
    architectui,
    PerfectScrollbar,
    datatables,
    datatablesBootstrap4,
    datatablesResponsive,
    jValidation,
    datePicker,
    select2,
) {
    return {
        table: null,
        init: function () {
            App.initFunc();
            App.initCekNota();
            App.initEdit();
            App.initGetNota();
            App.sidebarScroll();
            App.initEvent();
            App.initConfirm();
            App.dataList();
            App.validationJs();
            $(".loadingpage").hide();
            $(".dataTables_filter").hide();
            $("#hasil_cek").hide();
            $("#nota_tambah_ada").hide();
            $("#barang-hilang").hide();
            $(".potongan-rusak").hide();
            App.perhitunganHarga();
            setTimeout(function () {
                $('.card-header').hide();
            }, 2500);
            App.onClickFilter();
            App.resetFilter();
        },
        initEdit: function() {
            $('input[name=potongan_rusak]').change(function() { 
                var potongan_rusak = $("#potongan_rusak").val();
                var potongan_rusak = parseInt(potongan_rusak);
                //
                var berat = $('#berat').val();
                var berat = parseFloat(berat);
                //
                var karat = $("#karat").val();
                var karat = karat+'000';
                var karat = parseInt(karat);
                hasil = berat * karat;
                hasil_akhir = hasil - potongan_rusak;
                $('#harga_barang_kembali').val(hasil_akhir);
            });

            $('input[name=potongan_rusak_edit]').change(function() { 
                var potongan_rusak = $("#potongan_rusak_edit").val();
                potongan_rusak = parseInt(potongan_rusak);
                //
                // //
                var potongan_rusak_lama = $("#potongan_rusak_lama").val();
                var potongan_rusak_lama = parseInt(potongan_rusak_lama);
                var harga_barang_kembali = $("#harga_barang_kembali").val();
                var harga_barang_kembali = parseInt(harga_barang_kembali);
                
                harga = harga_barang_kembali + potongan_rusak_lama;
                hasil_akhir = harga - potongan_rusak;
                $('#harga_barang_kembali').val(hasil_akhir);
            });

            $('input[name=berat_barang_hilang]').change(function() { 
                var berat_barang_hilang = $('#berat_barang_hilang').val();
                var berat_barang_hilang = parseFloat(berat_barang_hilang);
                //
                var berat = $('#berat').val();
                var berat = parseFloat(berat);
                //
                var karat = $("#karat").val();
                var karat = karat+'000';
                var hasil = parseInt(karat);
                sub_hasil = berat_barang_hilang * hasil;
                hasil_akhir = berat * hasil - sub_hasil;
                $('#potongan_hilang').val(sub_hasil);
                $('#harga_barang_kembali').val(hasil_akhir);
            });
        },
        perhitunganHarga: function() {
            $('#potongan').on('change', function (e) {
                var kualitas = $("#kualitas").val();
                //data barang
                var valueSelected = this.value;
                var potongan = parseInt(valueSelected);
                var harga_jenis = $('#harga_jenis').val();
                var harga_jenis = parseInt(harga_jenis);
                var berat = $('#berat').val();
                var berat = parseFloat(berat);
                if (kualitas == "1") {
                    $(".potongan-rusak").hide();
                    $("#barang-hilang").hide();
                    // perhitungan potongan
                    hasil = harga_jenis - potongan;
                    hasil_akhir = berat * hasil;
                    $('#harga_jenis_barang_kembali').val(hasil);
                    $('#harga_barang_kembali').val(hasil_akhir);
                }else if(kualitas == "2"){
                    $(".potongan-rusak").show();
                        
                    $('input[name=potongan_rusak]').change(function() { 
                        var potongan_rusak = $("#potongan_rusak").val();
                        var potongan_rusak = parseInt(potongan_rusak);
                        hasil = harga_jenis - potongan;
                        hasil_before_pengurangan = berat * hasil;
                        hasil_akhir = berat * hasil - potongan_rusak;
                        $('#hasil_before_pengurangan').val(hasil_before_pengurangan);
                        $('#harga_jenis_barang_kembali').val(hasil);
                        $('#harga_barang_kembali').val(hasil_akhir);
                    });
                }else if(kualitas == "3"){
                    $("#barang-hilang").show();
                    $('input[name=berat_barang_hilang]').change(function() { 
                        var berat_barang_hilang = $('#berat_barang_hilang').val();
                        var berat_barang_hilang = parseFloat(berat_barang_hilang);
                        hasil = harga_jenis - potongan;
                        hasil_before_pengurangan = berat * hasil;
                        sub_hasil = berat_barang_hilang * hasil;
                        hasil_akhir = berat * hasil - sub_hasil;
                        $('#hasil_before_pengurangan').val(hasil_before_pengurangan);
                        $('#harga_jenis_barang_kembali').val(hasil);
                        $('#potongan_hilang').val(sub_hasil);
                        $('#harga_barang_kembali').val(hasil_akhir);
                    });
                    
                }
            });
        },
        initCekNota: function() {
            $("#btn-cek").click(function() {
                var no_nota = $("#no_nota").val();
                var kode_cabang = $("#kode_cabang").val();
                if (no_nota == "" || kode_cabang == "") {
                    App.alert('Silahkan isi No Nota dan  pilih cabang terlebih dahulu!!!');
                } else {
                    $.ajax({
                        url: App.baseUrl+'barang_kembali/hasil_nota',
                        type: 'GET',
                        data: {no_nota: no_nota, kode_cabang: kode_cabang},
                    })
                    .done(function( jqXHR ) {
                        var data = JSON.parse(jqXHR);
                        if(data.status == true){
                            $('#nota_ada').val('No Nota : '+no_nota+' di cabang '+data.cabang+' Tersebut Belum Kembali Dan Bisa Melakukan Transaksi Barang Kembali');
                            $("#nota_tidak_ada").hide();
                            $("#nota_ada").show();
                            $("#hasil_cek").show();
                        }else{
                            $('#nota_tidak_ada').val('No Nota : '+no_nota+' di cabang '+data.cabang+' Tersebut Sudah Kembali atau belum ada belum melakukan penjualan');
                            $("#nota_ada").hide();
                            $("#nota_tidak_ada").show();
                            $("#hasil_cek").show();
                        }
                        // App.HitungPersentaseRencana($('#rencana_jumlah_penduduk').val(), data.jumlah_penduduk);
                    })
                    .fail(function() {
                        console.log("error");
                    })
                }
            });
        },
        initGetNota: function() {
            $("#btn_cek_tambah").click(function() {
                var no_nota_tambah = $("#no_nota_tambah").val();
                var kode_cabang = $("#kode_cabang").val();
                if (no_nota_tambah == "" || kode_cabang == "") {
                    App.alert('Silahkan isi No Nota dan  pilih cabang terlebih dahulu!!!');
                } else {
                    var no_nota_tambah = $("#no_nota_tambah").val();
                    $.ajax({
                        url: App.baseUrl+'penjualan/get_data_nota',
                        type: 'GET',
                        data: {no_nota_tambah: no_nota_tambah, kode_cabang: kode_cabang},
                    })
                    .done(function( jqXHR ) {
                        var data = JSON.parse(jqXHR);
                        if(data.status == true){
                            $('#cabang').html(data.cabang);
                            $('#tanggal_penjualan').html(data.tanggal);
                            $('#nama_karyawan').html(data.nama_karyawan);
                            $('#no_nota_html').html(data.no_nota_tukar);
                            $('#no_nota').val(data.no_nota);
                            $('#nama_jenis').html(data.nama_jenis);
                            $('#nama_barang').html(data.nama_barang);
                            $('#potong').html(data.potongan);
                            $('#berat_html').html(data.berat);
                            $('#berat').val(data.berat);
                            $('#harga').html(data.harga);
                            $('#harga_jenis').val(data.harga_jenis);
                            $('#penjualan_id').val(data.penjualan_id);
                            $("#nota_tambah_ada").show();
                            $("#hasil_cek").hide();
                            $("#nota_ada").hide();
                        }else{
                            $("#nota_tambah_ada").hide();
                            $('#nota_tidak_ada').val('No Nota : '+no_nota_tambah+' tersebut tidak ada pada data pada penjualan, atau Nota Batal, atau Nota Hilang 3R!!!');
                            $("#hasil_cek").show();
                        }
                        // App.HitungPersentaseRencana($('#rencana_jumlah_penduduk').val(), data.jumlah_penduduk);
                    })
                    .fail(function() {
                        console.log("error");
                    })
                }
                });
        },
        initEvent: function () {
            $('.init-date').datepicker({
                uiLibrary: 'bootstrap4',
                format: 'YYYY-mm-dd'
            });

            $('.select2').select2();
        },

        sidebarScroll: function () {
            setTimeout(function () {
                if ($(".scrollbar-container")[0]) {
                    $('.scrollbar-container').each(function () {
                        const ps = new PerfectScrollbar($(this)[0], {
                            wheelSpeed: 2,
                            wheelPropagation: false,
                            minScrollbarLength: 20
                        });
                    });

                    const ps = new PerfectScrollbar('.scrollbar-sidebar', {
                        wheelSpeed: 2,
                        wheelPropagation: true,
                        minScrollbarLength: 20
                    });
                }
            }, 1000);
        },

        initConfirm: function () {
            $('#table-utuh').on('click', '.delete-data', function () {
                var id = $(this).attr("detail_id");
                App.confirm("Apakah Anda Yakin Untuk Menghapus data Ini?", function () {
                    window.location.href = App.baseUrl+'barang_kembali/delete_utuh/'+id;                    
                })
            });

            $('#table-rusak').on('click', '.delete-rusak', function () {
                var id = $(this).attr("detail_id");
                App.confirm("Apakah Anda Yakin Untuk Menghapus data Ini?", function () {
                    window.location.href = App.baseUrl+'barang_kembali/delete_rusak/'+id;                    
                })
            });
            $('#table-admin').on('click', '.delete', function () {
                var url = $(this).attr("url");
                App.confirm("Apakah Anda Yakin Untuk Mengubah Ini?", function () {
                    $.ajax({
                        method: "GET",
                        url: url
                    }).done(function (msg) {
                        $('.loadingpage').hide();
                        App.table_admin.ajax.reload(null, true);
                    });
                })
            });
        },

        dataList: function () {
            App.table = $('#table').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first": "Pertama",
                        "last": "Terakhir",
                        "next": "Selanjutnya",
                        "previous": "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": App.baseUrl + "barang_kembali/dataList",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [{
                        "data": "id"
                    },
                    {
                        "data": "tanggal",
                        "orderable": false
                    },
                    {
                        "data": "jumlah_transaksi",
                        "orderable": false
                    },
                    {
                        "data": "total_berat",
                        "orderable": false
                    },
                    {
                        "data": "total_harga_keseluruhan",
                        "orderable": false
                    },
                    {
                        "data": "action",
                        "orderable": false
                    }
                ],
                "columnDefs": [{
                    "targets": [0, 1, 2, 3, 4,5],
                    "className": "text-center"
                }, ]
            });

            App.table_admin = $('#table-admin').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first": "Pertama",
                        "last": "Terakhir",
                        "next": "Selanjutnya",
                        "previous": "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": App.baseUrl + "barang_kembali/dataListAdmin",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [{
                        "data": "id"
                    },
                    {
                        "data": "cabang",
                        "orderable": false
                    },
                    {
                        "data": "tanggal",
                        "orderable": false
                    },
                    {
                        "data": "jumlah_transaksi",
                        "orderable": false
                    },
                    {
                        "data": "total_berat",
                        "orderable": false
                    },
                    {
                        "data": "total_harga_keseluruhan",
                        "orderable": false
                    },
                    {
                        "data": "status_audit",
                        "orderable": false
                    },
                    {
                        "data": "action",
                        "orderable": false
                    }
                ],
                "columnDefs": [{
                    "targets": [0, 1, 2, 3, 4,5,6,7],
                    "className": "text-center"
                }, ]
            });

            App.table_pembukuan = $('#table-pembukuan').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first": "Pertama",
                        "last": "Terakhir",
                        "next": "Selanjutnya",
                        "previous": "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": App.baseUrl + "pembukuan_barang_kembali/dataList",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [{
                        "data": "id"
                    },
                    {
                        "data": "cabang",
                        "orderable": false
                    },
                    {
                        "data": "tanggal",
                        "orderable": false
                    },
                    {
                        "data": "jumlah_transaksi",
                        "orderable": false
                    },
                    {
                        "data": "total_berat",
                        "orderable": false
                    },
                    {
                        "data": "total_harga_keseluruhan",
                        "orderable": false
                    },
                    {
                        "data": "action",
                        "orderable": false
                    }
                ],
                "columnDefs": [{
                    "targets": [0, 1, 2, 3, 4,5,6],
                    "className": "text-center"
                }, ]
            });

            //append button to datatables
            // add_btn = '<a href="'+App.baseUrl+'group/create" class="btn btn-sm btn-primary ml-2 mt-1"><i class="fa fa-plus"></i> Departemen</a>';
            // $('#table_filter').append(add_btn);
        },

        validationJs: function () {

            $('#btn-tambah').on('click', function () {

                $("#form").validate({
                    rules: {
                        tanggal: {
                            required: true
                        },
                        berat_barang_hilang: {
                            required: true
                        },
                        potongan_rusak: {
                            required: true
                        },
                        potongan: {
                            required: true
                        },
                        cabang_id: {
                            required: true
                        },
                        karyawan_id: {
                            required: true
                        },
                        kualitas: {
                            required: true
                        },
                    },
                    messages: {
                        cabang_id: {
                            required: "*) harus dipilih"
                        },
                        potongan: {
                            required: "*) harus dipilih"
                        },
                        kualitas: {
                            required: "*) harus dipilih"
                        },
                        karyawan_id: {
                            required: "*) harus dipilih"
                        },
                        berat_barang_hilang: {
                            required: "*) harus diisi"
                        },
                        potongan_rusak: {
                            required: "*) harus diisi"
                        },
                        tanggal: {
                            required: "*) harus diisi"
                        },
                    },
                    debug: true,
                    errorElement: "em",
                    errorPlacement: function (error, element) {
                        // Add the `invalid-feedback` class to the error element
                        error.addClass("invalid-feedback");
                        if (element.prop("type") === "checkbox") {
                            error.insertBefore(element.next("label"));
                        } else if (element.prop("type") === "radio") {
                            error.appendTo(element.parent().parent().parent());
                        } else {
                            error.insertBefore(element);
                        }
                    },
                    highlight: function (element, errorClass, validClass) {
                        $(element).addClass("is-invalid").removeClass("is-valid");
                    },
                    unhighlight: function (element, errorClass, validClass) {
                        $(element).addClass("is-valid").removeClass("is-invalid");
                    },
                    submitHandler: function (form) {
                        $('#value-btn-tambah').val(1);
                        form.submit();
                    }
                });
            });
        },

        onClickFilter : function (){
            $('#btn-filter').on('click', function () {
                var tanggal   = $("#tanggal").val();
                var cabang_id   = $("#cabang_id").val();
                var status_audit   = $("#status_audit").val();
                //pembukuan
                App.table_pembukuan.column(0).search(tanggal,true,true);
                App.table_pembukuan.draw();
                //transaksi
                App.table.column(0).search(tanggal,true,true);
                App.table.draw();
                //bk admin
                App.table_admin.column(0).search(tanggal,true,true);
                App.table_admin.column(1).search(cabang_id,true,true);
                App.table_admin.column(2).search(status_audit,true,true);
                App.table_admin.draw();

            });
        },

        resetFilter : function (){
            $('#btn-filter-clear').on( 'click', function () {
                $("#tanggal").val("").trigger('change');
                $("#cabang_id").val("").trigger('change');
                $("#status_audit").val("").trigger('change');
                $('#btn-filter').trigger('click');
            });
        },
    }
});