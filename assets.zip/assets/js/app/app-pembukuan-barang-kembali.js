define([
    "jQuery",
    "bootstrap",
    "metisMenu",
    "architectui",
    "PerfectScrollbar",
    "datatables",
    "datatablesBootstrap4",
    "datatablesResponsive",
    "jValidation",
    "datePicker",
    "select2",
], function (
    $,
    bootstrap,
    metisMenu,
    architectui,
    PerfectScrollbar,
    datatables,
    datatablesBootstrap4,
    datatablesResponsive,
    jValidation,
    datePicker,
    select2,
) {
    return {
        table: null,
        init: function () {
            App.initFunc();
            App.initEdit();
            App.initGetNota();
            App.sidebarScroll();
            App.initEvent();
            App.dataList();
            App.validationJs();
            $(".loadingpage").hide();
            $(".dataTables_filter").hide();
            $("#nota_tambah_tidak_ada").hide();
            $("#nota_tambah_ada").hide();
            setTimeout(function () {
                $('.card-header').hide();
            }, 2500);
            App.onClickFilter();
            App.resetFilter();
            App.initConfirm();
        },
        initConfirm: function () {
            $('#table').on('click', '.delete-data', function () {
                var id = $(this).attr("detail_id");
                App.confirm("Apakah Anda Yakin Untuk Menghapus data Ini?", function () {
                    window.location.href = App.baseUrl+'pembukuan_barang_kembali/delete/'+id;                    
                })
            });
        },
        initEdit: function() {
            $('input[name=potongan_rusak]').change(function() { 
                var potongan_rusak = $("#potongan_rusak").val();
                var potongan_rusak = parseInt(potongan_rusak);
                //
                var berat = $('#berat').val();
                var berat = parseFloat(berat);
                //
                var karat = $("#karat").val();
                var karat = karat+'000';
                var karat = parseInt(karat);
                hasil = berat * karat;
                hasil_akhir = hasil - potongan_rusak;
                $('#harga_barang_kembali').val(hasil_akhir);
            });

            $('input[name=berat_barang_hilang]').change(function() { 
                var berat_barang_hilang = $('#berat_barang_hilang').val();
                var berat_barang_hilang = parseFloat(berat_barang_hilang);
                //
                var berat = $('#berat').val();
                var berat = parseFloat(berat);
                //
                var karat = $("#karat").val();
                var karat = karat+'000';
                var hasil = parseInt(karat);
                sub_hasil = berat_barang_hilang * hasil;
                hasil_akhir = berat * hasil - sub_hasil;
                $('#potongan_hilang').val(sub_hasil);
                $('#harga_barang_kembali').val(hasil_akhir);
            });
        },
        initGetNota: function() {
            $("#btn_cek_tambah").click(function() {
                var cabang_id = $("#cabang_id").val();
                if (cabang_id == "") {
                    App.alert('Silahkan pilih cabang terlebih dahulu!!!');
                } else {
                    $.ajax({
                        url: App.baseUrl+'nota_kantor/get_nota_pembukuan_bk',
                        type: 'GET',
                        data: {cabang_id: cabang_id},
                    })
                    .done(function(jqXHR) {
                        var data = JSON.parse(jqXHR)
                        var option = '<option value="">Pilih No Nota</option>';
                        if(data.status == true){
                            data_nota = data.data;
                            for (var i = 0; i < data_nota.length; i++) {
                                option += "<option value="+data_nota[i].id+"> "+data_nota[i].no_nota+"</option>";
                            }
                        $('#no_nota_id').html(option);
                        $("#nota_tambah_ada").show();
                        $("#cabang_id_bk").val(cabang_id);
                        $("#nota_tambah_tidak_ada").hide();
                        }else{
                            $("#nota_tambah_ada").hide();
                            $("#nota_tambah_tidak_ada").show();
                        }
                    })
                    .fail(function() {
                        console.log("error");
                    });
                }
                });
        },
        initEvent: function () {
            $('.init-date').datepicker({
                uiLibrary: 'bootstrap4',
                format: 'YYYY-mm-dd'
            });

            $('.select2').select2();
        },

        sidebarScroll: function () {
            setTimeout(function () {
                if ($(".scrollbar-container")[0]) {
                    $('.scrollbar-container').each(function () {
                        const ps = new PerfectScrollbar($(this)[0], {
                            wheelSpeed: 2,
                            wheelPropagation: false,
                            minScrollbarLength: 20
                        });
                    });

                    const ps = new PerfectScrollbar('.scrollbar-sidebar', {
                        wheelSpeed: 2,
                        wheelPropagation: true,
                        minScrollbarLength: 20
                    });
                }
            }, 1000);
        },

        dataList: function () {
            App.table_pembukuan = $('#table-pembukuan').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first": "Pertama",
                        "last": "Terakhir",
                        "next": "Selanjutnya",
                        "previous": "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": App.baseUrl + "pembukuan_barang_kembali/dataList",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [{
                        "data": "id"
                    },
                    {
                        "data": "cabang",
                        "orderable": false
                    },
                    {
                        "data": "tanggal",
                        "orderable": false
                    },
                    {
                        "data": "jumlah_transaksi",
                        "orderable": false
                    },
                    {
                        "data": "action",
                        "orderable": false
                    }
                ],
                "columnDefs": [{
                    "targets": [0, 1, 2, 3, 4],
                    "className": "text-center"
                }, ]
            });

            //append button to datatables
            // add_btn = '<a href="'+App.baseUrl+'group/create" class="btn btn-sm btn-primary ml-2 mt-1"><i class="fa fa-plus"></i> Departemen</a>';
            // $('#table_filter').append(add_btn);
        },

        validationJs: function () {

            $('#btn-tambah').on('click', function () {

                $("#form").validate({
                    rules: {
                        tanggal: {
                            required: true
                        },
                        no_nota_id: {
                            required: true
                        },
                    },
                    messages: {
                        no_nota_id: {
                            required: "*) harus dipilih"
                        },
                        tanggal: {
                            required: "*) harus diisi"
                        },
                    },
                    debug: true,
                    errorElement: "em",
                    errorPlacement: function (error, element) {
                        // Add the `invalid-feedback` class to the error element
                        error.addClass("invalid-feedback");
                        if (element.prop("type") === "checkbox") {
                            error.insertBefore(element.next("label"));
                        } else if (element.prop("type") === "radio") {
                            error.appendTo(element.parent().parent().parent());
                        } else {
                            error.insertBefore(element);
                        }
                    },
                    highlight: function (element, errorClass, validClass) {
                        $(element).addClass("is-invalid").removeClass("is-valid");
                    },
                    unhighlight: function (element, errorClass, validClass) {
                        $(element).addClass("is-valid").removeClass("is-invalid");
                    },
                    submitHandler: function (form) {
                        $('#value-btn-tambah').val(1);
                        form.submit();
                    }
                });
            });
        },

        onClickFilter : function (){
            $('#btn-filter').on('click', function () {
                var tanggal   = $("#tanggal").val();
                var cabang_id   = $("#cabang_id").val();
                //pembukuan
                App.table_pembukuan.column(0).search(tanggal,true,true);
                App.table_pembukuan.column(1).search(cabang_id,true,true);
                App.table_pembukuan.draw();

            });
        },

        resetFilter : function (){
            $('#btn-filter-clear').on( 'click', function () {
                $("#tanggal").val("").trigger('change');
                $("#cabang_id").val("").trigger('change');
                $('#btn-filter').trigger('click');
            });
        },
    }
});