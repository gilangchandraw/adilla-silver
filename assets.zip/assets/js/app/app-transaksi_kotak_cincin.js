define([
    "jQuery",
    "bootstrap",
    "metisMenu",
    "architectui",
    "PerfectScrollbar",
    "datatables",
    "datatablesBootstrap4",
    "datatablesResponsive",
    "jValidation",
    "datePicker",
    "select2",

], function (
    $,
    bootstrap,
    metisMenu,
    architectui,
    PerfectScrollbar,
    datatables,
    datatablesBootstrap4,
    datatablesResponsive,
    jValidation,
    datePicker,
    select2,
) {
    return {
        table: null,
        init: function () {
            App.initFunc();
            App.sidebarScroll();
            App.initEvent();
            App.initConfirm();
            App.dataList();
            App.validationJs();
            App.initPerhitungan();
            $(".loadingpage").hide();
            $(".dataTables_filter").hide();
            setTimeout(function () {
                $('.card-header').hide();
            }, 2500);
            App.onClickFilter();
            App.resetFilter();
        },
        onClickFilter : function (){
            $('#btn-filter').on('click', function () {
                var tanggal   = $("#tanggal").val();
                var cabang_id   = $("#cabang_id").val();
                var status_audit   = $("#status_audit").val();
                
                //transaksicabang
                App.table.column(0).search(tanggal,true,true);
                App.table.draw();

                //transaksi admin
                App.table_admin.column(0).search(tanggal,true,true);
                App.table_admin.column(1).search(cabang_id,true,true);
                App.table_admin.column(2).search(status_audit,true,true);
                App.table_admin.draw();

            });
        },

        resetFilter : function (){
            $('#btn-filter-clear').on( 'click', function () {
                $("#tanggal").val("").trigger('change');
                $("#cabang_id").val("").trigger('change');
                $("#status_audit").val("").trigger('change');
                $('#btn-filter').trigger('click');
            });
        },
        
        initPerhitungan: function () {
            $('input[name=qty]').change(function() { 
                var qty = $('#qty').val();
                var kotak_cincin_id = $('#kotak_cincin_id').val();
                // cek stok dari cabang
                $.ajax({
                    url: App.baseUrl + 'stok_kotak_cincin/cek_stok',
                    type: 'GET',
                    data: {
                        kotak_cincin_id: kotak_cincin_id,
                        qty: qty,
                    },
                })
                .done(function (jqXHR) {
                    var data = JSON.parse(jqXHR);
                    if (data.status == true) {
                        //get harga
                        $.ajax({
                            url: App.baseUrl+'barang_kotak_cincin/get_harga',
                            type: 'GET',
                            data: {barang_kotak_cincin_id: kotak_cincin_id},
                        })
                        .done(function( jqXHR ) {
                            var data = JSON.parse(jqXHR);
                            if(data.status == true){
                                var harga = parseInt(qty) * parseInt(data.harga);
                                $('#harga').val(harga);
                                
                            }else{
                                $('#harga').val('');
                            }
                        })
                        .fail(function() {
                            console.log("error");
                        });                       

                    } else {
                        $('#harga').val('');
                        App.alert('Stok barang kotak cincin yang dipilih tidak mencukupi, silahkan hubungi Admin Adilla 925');
                    }
                })
                .fail(function () {
                    console.log("error");
                });
            });
        },
        initEvent: function () {
            $('.init-date').datepicker({
                uiLibrary: 'bootstrap4',
                format: 'YYYY-mm-dd'
            });
            $('.select2').select2();
        },

        sidebarScroll: function () {
            setTimeout(function () {
                if ($(".scrollbar-container")[0]) {
                    $('.scrollbar-container').each(function () {
                        const ps = new PerfectScrollbar($(this)[0], {
                            wheelSpeed: 2,
                            wheelPropagation: false,
                            minScrollbarLength: 20
                        });
                    });

                    const ps = new PerfectScrollbar('.scrollbar-sidebar', {
                        wheelSpeed: 2,
                        wheelPropagation: true,
                        minScrollbarLength: 20
                    });
                }
            }, 1000);
        },

        initConfirm: function () {
            $('#table-detail').on('click', '.delete-data', function () {
                var id = $(this).attr("detail_id");
                App.confirm("Apakah Anda Yakin Untuk Menghapus data Ini?", function () {
                    window.location.href = App.baseUrl+'transaksi_kotak_cincin/delete/'+id;                    
                })
            });
            $('#table-admin').on( 'click', '.delete', function () {
                var url = $(this).attr("url");
                App.confirm("Apakah Anda Yakin Untuk Mengubah Ini?",function(){
                   $.ajax({
                      method: "GET",
                      url: url
                    }).done(function( msg ) {
                        $('.loadingpage').hide();
                        App.table_admin.ajax.reload(null,true);
                    });
                })
            });
        },

        dataList: function () {
            App.table = $('#table').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first": "Pertama",
                        "last": "Terakhir",
                        "next": "Selanjutnya",
                        "previous": "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": App.baseUrl + "transaksi_kotak_cincin/dataList",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [{
                        "data": "id"
                    },
                    {
                        "data": "tanggal",
                        "orderable": false
                    },
                    {
                        "data": "total_harga_keseluruhan",
                        "orderable": false
                    },
                    {
                        "data": "action",
                        "orderable": false
                    }
                ],
                "columnDefs": [{
                    "targets": [0, 1, 2, 3],
                    "className": "text-center"
                }, ]
            });

            //adminn
            App.table_admin = $('#table-admin').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first": "Pertama",
                        "last": "Terakhir",
                        "next": "Selanjutnya",
                        "previous": "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": App.baseUrl + "transaksi_kotak_cincin/dataListAdmin",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [{
                        "data": "id"
                    },
                    {
                        "data": "cabang",
                        "orderable": false
                    },
                    {
                        "data": "tanggal",
                        "orderable": false
                    },
                    {
                        "data": "total_harga_keseluruhan",
                        "orderable": false
                    },
                    {
                        "data": "status_audit",
                        "orderable": false
                    },
                    {
                        "data": "action",
                        "orderable": false
                    }
                ],
                "columnDefs": [{
                    "targets": [0, 1, 2, 3, 4,5],
                    "className": "text-center"
                }, ]
            });

            //append button to datatables
            // add_btn = '<a href="'+App.baseUrl+'group/create" class="btn btn-sm btn-primary ml-2 mt-1"><i class="fa fa-plus"></i> Departemen</a>';
            // $('#table_filter').append(add_btn);
        },

        validationJs: function () {
            $("#form").validate({
                rules: {
                    tanggal: {
                        required: true
                    },
                    kotak_cincin_id: {
                        required: true
                    },
                    qty: {
                        required: true
                    },
                    harga: {
                        required: true
                    },
                    cabang_id: {
                        required: true
                    },

                },
                messages: {
                    tanggal: {
                        required: "*) harus diisi"
                    },
                    kotak_cincin_id: {
                        required: "*) harus dipilih"
                    },
                    qty: {
                        required: "*) harus diisi"
                    },
                    harga: {
                        required: "*) harus diisi"
                    },
                    cabang_id: {
                        required: "*) harus dipilih"
                    },
                },
                debug: true,
                errorElement: "em",
                errorPlacement: function (error, element) {
                    // Add the `invalid-feedback` class to the error element
                    error.addClass("invalid-feedback");
                    if (element.prop("type") === "checkbox") {
                        error.insertBefore(element.next("label"));
                    } else if (element.prop("type") === "radio") {
                        error.appendTo(element.parent().parent().parent());
                    } else {
                        error.insertBefore(element);
                    }
                },
                highlight: function (element, errorClass, validClass) {
                    $(element).addClass("is-invalid").removeClass("is-valid");
                },
                unhighlight: function (element, errorClass, validClass) {
                    $(element).addClass("is-valid").removeClass("is-invalid");
                },
                submitHandler: function (form) {
                    form.submit();
                }
            });
        },
    }
});