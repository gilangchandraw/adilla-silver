define([
    "jQuery",
    "bootstrap",
    "metisMenu",
    "architectui",
    "PerfectScrollbar",
    "datatables",
    "datatablesBootstrap4",
    "datatablesResponsive",
    ], function (
    $,
    bootstrap,
    metisMenu,
    architectui,
    PerfectScrollbar,
    datatables,
    datatablesBootstrap4,
    datatablesResponsive,
    ) {
    return {
        table:null,
        init: function () { 
            App.initFunc();
            App.sidebarScroll();
            App.initConfirm();
            App.dataList();
            App.selectAllCheckbox();
            App.selectFuncCheckbox();
            $(".loadingpage").hide();
            setTimeout(function(){
                $('.card-header').hide();
            }, 2500);
        },

        sidebarScroll: function () {
            setTimeout(function () {
                if ($(".scrollbar-container")[0]) {
                    $('.scrollbar-container').each(function () {
                        const ps = new PerfectScrollbar($(this)[0], {
                            wheelSpeed: 2,
                            wheelPropagation: false,
                            minScrollbarLength: 20
                        });
                    });

                    const ps = new PerfectScrollbar('.scrollbar-sidebar', {
                        wheelSpeed: 2,
                        wheelPropagation: true,
                        minScrollbarLength: 20
                    });
                }
            }, 1000);
        }, 

        initConfirm :function(){
            $('#table').on( 'click', '.delete', function () {
                var url = $(this).attr("url");
                App.confirm("Apakah Anda Yakin Untuk Mengubah Ini?",function(){
                   $.ajax({
                      method: "GET",
                      url: url
                    }).done(function( msg ) {
                        $('.loadingpage').hide();
                        App.table.ajax.reload(null,true);
                    });
                })
            });
        },
        
        dataList : function(){
            App.table = $('#table').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first":      "Pertama",
                        "last":       "Terakhir",
                        "next":       "Selanjutnya",
                        "previous":   "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax":{
                    "url": App.baseUrl+"privileges/dataList",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [
                    { "data": "id" },
                    { "data": "role_name" },
                    // { "data": "groups" },
                    { "data": "action" ,"orderable": false}
                ],
                "columnDefs": [
                    {"targets": [0,1,2], "className": "text-center"},
                ] 
            });

            //append button to datatables
            // add_btn = '<a href="'+App.baseUrl+'group/create" class="btn btn-sm btn-primary ml-2 mt-1"><i class="fa fa-plus"></i> Departemen</a>';
            // $('#table_filter').append(add_btn);
        },
        

        selectAllCheckbox:function(){
            _tot = $(".cb-element").length
            _tot_checked = $(".cb-element:checked").length;
            if(_tot != _tot_checked){
                $("#checkAll").prop('checked',false);
            }else{
                $("#checkAll").prop('checked',true);
            }
        },

        selectFuncCheckbox:function(){
            $("#checkAll").change(function () {
                $("input:checkbox.cb-element").prop('checked', $(this).prop("checked"));
                $("input:checkbox.cb-element-child").prop('checked', $(this).prop("checked"));
            });

            $(".cb-element").change(function () {
                App.selectAllCheckbox();
                $parent = $(this).closest( "tr" ).find(".cb-element-child");
                $parent.prop('checked', $(this).prop("checked"));
            });

            $(".cb-element-child").change(function () {
                $parent = $(this).closest( "tr" ).find(".cb-element");
                $child = $(this).closest( "tr" ).find(".cb-element-child");
                $childChecked = $(this).closest( "tr" ).find(".cb-element-child:checked");

                _tot = $child.length
                _tot_checked = $childChecked.length;
                if(_tot != _tot_checked){
                    $parent.prop('checked',false);
                }else{
                   $parent.prop('checked',true);
                }
                App.selectAllCheckbox();
            });

            $('.cb-element-child').on('click', function(){
                parent = $(this).closest('.function-parent');
                var checked = $(this).is(':checked') ? true : false;

                if ($(this).val() == 1)
                {
                    parent.find('.function-2').prop('checked', checked);
                    parent.find('.function-5').prop('checked', checked);
                }else if($(this).val() == 2){

                    parent.find('.function-5').prop('checked', checked);
                }else if($(this).val() == 3){

                    parent.find('.function-2').prop('checked', checked);
                    parent.find('.function-5').prop('checked', checked);
                }else if($(this).val() == 4){
                    parent.find('.function-2').prop('checked', checked);
                    parent.find('.function-5').prop('checked', checked);
                }else if($(this).val() == 5){
                    parent.find('.function-2').prop('checked', checked);
                }else if($(this).val() == 6){
                    parent.find('.function-2').prop('checked', checked);
                    parent.find('.function-5').prop('checked', checked);
                }else if($(this).val() == 7){
                    parent.find('.function-2').prop('checked', checked);
                    parent.find('.function-5').prop('checked', checked);
                }
            });
        },
	}
});
