define([
    "jQuery",
    "bootstrap",
    "metisMenu",
    "architectui",
    "PerfectScrollbar",
    "datatables",
    "datatablesBootstrap4",
    "datatablesResponsive",
    "jValidation",
    "datePicker",
    "select2",
    ], function (
    $,
    bootstrap,
    metisMenu,
    architectui,
    PerfectScrollbar,
    datatables,
    datatablesBootstrap4,
    datatablesResponsive,
    jValidation,
    datePicker,
    select2,
    ) {
    return {
        table:null,
        init: function () { 
            App.initFunc();
            App.sidebarScroll();
            App.initEvent();
            App.initConfirm();
            App.dataList();
            App.validationJs();
            App.getNota();
            $(".dataTables_filter").hide();
            $(".loadingpage").hide();
            setTimeout(function(){
                $('.card-header').hide();
            }, 2500);
            App.onClickFilter();
            App.resetFilter();
            App.initCekNota();
            
        },

        initCekNota: function() {
            $("#btn-cek").click(function() {
                var no_nota = $("#no_nota").val();
                var kode_cabang = $("#kode_cabang").val();
                if (no_nota == "" || kode_cabang == "") {
                    App.alert('Silahkan isi No Nota dan  pilih cabang terlebih dahulu!!!');
                } else {
                    $.ajax({
                        url: App.baseUrl+'pembukuan_penjualan/hasil_nota',
                        type: 'GET',
                        data: {no_nota: no_nota, kode_cabang: kode_cabang},
                    })
                    .done(function( jqXHR ) {
                        var data = JSON.parse(jqXHR);
                        if(data.status == true){
                            var html = '';
                            html += '<h5 class="card-title">Histori Data Penjualan</h5><div class="table-responsive">\
                        <table class="table table-striped table-hover table-bordered responsive w-100" id="table-detail">\
                            <thead>\
                                <th class="text-center">Tanggal Penjualan</th>\
                                <th class="text-center">Karyawan</th>\
                                <th class="text-center">No Nota</th>\
                                <th class="text-center">Karat</th>\
                                <th class="text-center">Nama Perhiasan</th>\
                                <th class="text-center">Potong</th>\
                                <th class="text-center">Potongan</th>\
                                <th class="text-center">Berat/Gram</th>\
                                <th class="text-center">Harga</th>\
                                <th class="text-center">Status</th>\
                                <th class="text-center">Status Print</th>\
                            </thead>\
                            <tbody>\
                                <tr>\
                                    <td class="text-center">'+data.tanggal+'</td>\
                                    <td class="text-center">'+data.nama_karyawan+'</td>\
                                    <td class="text-center">'+data.no_nota+'</td>\
                                    <td class="text-center">'+data.harga_jenis+'</td>\
                                    <td class="text-center">'+data.nama_barang+'</td>\
                                    <td class="text-center">'+data.potong+'</td>\
                                    <td class="text-center">'+data.potongan+'</td>\
                                    <td class="text-center">'+data.berat+'</td>\
                                    <td class="text-center">'+data.harga+'</td>\
                                    <td class="text-center">'+data.status_+'</td>\
                                    <td class="text-center">'+data.status_print+'</td>\
                                </tr>\
                            </tbody>\
                        </table>\
                    </div>';
                            $('#hasil_cek').html(html);
                        }else{
                            var html = '';
                            html += '<div class="position-relative form-group">\
                                <label for="no_nota">Hasil Cek No Nota</label>\
                                <textarea class="form-control" type="text" style="background-color: #FF0000;color:white;"  readonly>No Nota tersebut Tidak ada di penjualan</textarea>\
                            </div>';
                            $('#hasil_cek').html(html);
                        }
                        // App.HitungPersentaseRencana($('#rencana_jumlah_penduduk').val(), data.jumlah_penduduk);
                    })
                    .fail(function() {
                        console.log("error");
                    })
                }
            });
        },

        initEvent: function () {
            $('.init-date').datepicker({
                uiLibrary: 'bootstrap4',
                format: 'YYYY-mm-dd'
            });

            $('.select2').select2();

            $('input[name=berat]').change(function() { 
                // alert(App.harga_satuan);
                var berat = $('#berat').val();
                var jenis_transaksi_id = $('#jenis_transaksi_id').val();
                //get harga
                $.ajax({
                    url: App.baseUrl+'enum_transaksi_barang/get_harga',
                    type: 'GET',
                    data: {jenis_transaksi_id: jenis_transaksi_id},
                })
                .done(function( jqXHR ) {
                    var data = JSON.parse(jqXHR);
                    if(data.status == true){
                        var harga = berat * parseInt(data.harga);
                        var nota_sebelum = $('input[name="nota_sebelum"]:checked').val();
                        
                        if (nota_sebelum == "1") {
                            var harga = parseInt(harga) + 5000;   
                        }
                        $('#harga').val(harga);
                        $('#total_harga_keseluruhan').val(harga);
                        // $('#stok').val(data.stok);
                        // harga_satuan = data.harga.replace(",", "");
                        // App.harga_satuan = harga_satuan;
                        // App.stok = data.stok;
                        
                        
                        
                    }else{
                        $('#harga').val('');
                    }
                    // App.HitungPersentaseRencana($('#rencana_jumlah_penduduk').val(), data.jumlah_penduduk);
                })
                .fail(function() {
                    console.log("error");
                })

                var harga_satuan = App.harga_satuan.replace(",", "");
                var banyak = parseInt(berat);
                if (banyak > App.stok) {
                    alert('Stok Tidak Mencukupi');
                    $('#total_harga').val('');
                    $('#harga').val('');
                } else {
                    var total = berat * harga_satuan;
                    $('#total_harga').val('Rp. '+total);    
                    var total_harga_keseluruhan = $('#total_harga_keseluruhan').val();
                    $('#harga').val(total);
                    var total_akhir = parseInt(total_harga_keseluruhan) + total;
                    $('#total_harga_keseluruhan').val(total_akhir);
                }
            });

            $('input[name=berat_edit]').change(function() { 
                // alert(App.harga_satuan);
                var berat = $('#berat_edit').val();
                var jenis_transaksi_id = $('#jenis_transaksi_id').val();
                // alert(jenis_transaksi_id)
                //get harga
                $.ajax({
                    url: App.baseUrl+'enum_transaksi_barang/get_harga',
                    type: 'GET',
                    data: {jenis_transaksi_id: jenis_transaksi_id},
                })
                .done(function( jqXHR ) {
                    var data = JSON.parse(jqXHR);
                    if(data.status == true){
                        var harga = berat * parseInt(data.harga);
                        var nota_sebelum = $('input[name="nota_sebelum"]:checked').val();
                        
                        if (nota_sebelum == "1") {
                            var harga = parseInt(harga) + 5000;   
                        }
                        $('#harga').val(harga);
                        $('#total_harga_keseluruhan').val(harga);
                        // $('#stok').val(data.stok);
                        // harga_satuan = data.harga.replace(",", "");
                        // App.harga_satuan = harga_satuan;
                        // App.stok = data.stok;
                        
                        
                        
                    }else{
                        $('#harga').val('');
                    }
                    // App.HitungPersentaseRencana($('#rencana_jumlah_penduduk').val(), data.jumlah_penduduk);
                })
                .fail(function() {
                    console.log("error");
                })

                var harga_satuan = App.harga_satuan.replace(",", "");
                var banyak = parseInt(berat);
                if (banyak > App.stok) {
                    alert('Stok Tidak Mencukupi');
                    $('#total_harga').val('');
                    $('#harga').val('');
                } else {
                    var total = berat * harga_satuan;
                    $('#total_harga').val('Rp. '+total);    
                    var total_harga_keseluruhan = $('#total_harga_keseluruhan').val();
                    $('#harga').val(total);
                    var total_akhir = parseInt(total_harga_keseluruhan) + total;
                    $('#total_harga_keseluruhan').val(total_akhir);
                }
            });

            $('input[type=radio][name=status_nota]').change(function() {
                if (this.value == '1') {
                    $(".nota-batal").show();
                }
                else if (this.value == '2') {
                    $(".nota-batal").hide();
                }
                else if (this.value == '3') {
                    $(".nota-batal").hide();
                }
                else if (this.value == '4') {
                    $(".nota-batal").show();
                }
                else if (this.value == '5') {
                    $(".nota-batal").hide();
                }
            });
        },

        sidebarScroll: function () {
            setTimeout(function () {
                if ($(".scrollbar-container")[0]) {
                    $('.scrollbar-container').each(function () {
                        const ps = new PerfectScrollbar($(this)[0], {
                            wheelSpeed: 2,
                            wheelPropagation: false,
                            minScrollbarLength: 20
                        });
                    });

                    const ps = new PerfectScrollbar('.scrollbar-sidebar', {
                        wheelSpeed: 2,
                        wheelPropagation: true,
                        minScrollbarLength: 20
                    });
                }
            }, 1000);
        }, 

        initConfirm: function () {
            $('#table-detail').on('click', '.delete-data', function () {
                var id = $(this).attr("detail_id");
                App.confirm("Apakah Anda Yakin Untuk Menghapus data Ini?", function () {
                    window.location.href = App.baseUrl+'pembukuan_penjualan/delete/'+id;                    
                })
            });
            $('#table-pembukuan').on('click', '.delete', function () {
                var url = $(this).attr("url");
                App.confirm("Apakah Anda Yakin Untuk Mengubah Ini?", function () {
                    $.ajax({
                        method: "GET",
                        url: url
                    }).done(function (msg) {
                        $('.loadingpage').hide();
                        App.table_pembukuan.ajax.reload(null, true);
                    });
                })
            });
        },
        
        dataList : function(){
            App.table = $('#table').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first":      "Pertama",
                        "last":       "Terakhir",
                        "next":       "Selanjutnya",
                        "previous":   "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax":{
                    "url": App.baseUrl+"penjualan/dataList",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [
                    { "data": "id" },
                    { "data": "tanggal","orderable": false },
                    { "data": "jumlah_transaksi","orderable": false },
                    { "data": "total_berat","orderable": false },
                    { "data": "total_harga_keseluruhan","orderable": false },
                    { "data": "action" ,"orderable": false}
                ],
                "columnDefs": [
                    {"targets": [0,1,2,3,4,5], "className": "text-center"},
                ] 
            });
            App.table_admin = $('#table-admin').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first":      "Pertama",
                        "last":       "Terakhir",
                        "next":       "Selanjutnya",
                        "previous":   "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax":{
                    "url": App.baseUrl+"penjualan/dataListAdmin",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [
                    { "data": "id" },
                    { "data": "cabang","orderable": false },
                    { "data": "tanggal","orderable": false },
                    { "data": "jumlah_transaksi","orderable": false },
                    { "data": "total_berat","orderable": false },
                    { "data": "total_harga_keseluruhan","orderable": false },
                    { "data": "action" ,"orderable": false}
                ],
                "columnDefs": [
                    {"targets": [0,1,2,3,4,5,6], "className": "text-center"},
                ] 
            });

            App.table_pembukuan = $('#table-pembukuan').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first":      "Pertama",
                        "last":       "Terakhir",
                        "next":       "Selanjutnya",
                        "previous":   "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax":{
                    "url": App.baseUrl+"pembukuan_penjualan/dataList",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [
                    { "data": "id" },
                    { "data": "cabang","orderable": false },
                    { "data": "tanggal","orderable": false },
                    { "data": "jumlah_transaksi","orderable": false },
                    { "data": "total_berat","orderable": false },
                    { "data": "total_harga_keseluruhan","orderable": false },
                    { "data": "action" ,"orderable": false}
                ],
                "columnDefs": [
                    {"targets": [0,1,2,3,4,5,6], "className": "text-center"},
                ] 
            });

            //append button to datatables
            // add_btn = '<a href="'+App.baseUrl+'group/create" class="btn btn-sm btn-primary ml-2 mt-1"><i class="fa fa-plus"></i> Departemen</a>';
            // $('#table_filter').append(add_btn);
        },

        validationJs : function(){    
            $('#btn-simpan').on('click', function(){
                            
                $("#form").validate({
                    rules: {
                        tanggal: {
                            required: true
                        },
                        karyawan_id: {
                            required: true
                        },
                        no_nota: {
                            required: true
                        },
                        jenis_transaksi_id: {
                            required: true
                        },
                        barang_id: {
                            required: true
                        },
                        berat: {
                            required: true
                        },
                        potong: {
                            required: true
                        },
                    },
                    messages: {
                        berat: {
                            required: "*) harus diisi"
                        },
                        potong: {
                            required: "*) harus diisi"
                        },
                        barang_id: {
                            required: "*) harus dipilih"
                        },
                        jenis_transaksi_id: {
                            required: "*) harus dipilih"
                        },
                        no_nota: {
                            required: "*) harus diisi"
                        },
                        karyawan_id: {
                            required: "*) harus dipilih"
                        },
                        tanggal: {
                            required: "*) harus diisi"
                        },
                    },
                    debug:true,
                    errorElement: "em",
                    errorPlacement: function ( error, element ) {
                        // Add the `invalid-feedback` class to the error element
                        error.addClass( "invalid-feedback" );
                        if ( element.prop( "type" ) === "checkbox" ) {
                            error.insertBefore( element.next( "label" ) );
                        } else if ( element.prop( "type" ) === "radio" ) {
                            error.appendTo( element.parent().parent().parent());
                        } else {
                            error.insertBefore( element );
                        }
                    },
                    highlight: function ( element, errorClass, validClass ) {
                        $( element ).addClass( "is-invalid" ).removeClass( "is-valid" );
                    },
                    unhighlight: function (element, errorClass, validClass) {
                        $( element ).addClass( "is-valid" ).removeClass( "is-invalid" );
                    },
                    submitHandler : function(form) {
                        $('#value-btn-simpan').val(1);
                        form.submit();
                    }
                });
            });

            $('#btn-tambah').on('click', function(){
                            
                $("#form").validate({
                    rules: {
                        tanggal: {
                            required: true
                        },
                        karyawan_id: {
                            required: true
                        },
                        no_nota: {
                            required: true
                        },
                        jenis_transaksi_id: {
                            required: true
                        },
                        barang_id: {
                            required: true
                        },
                        cabang_id: {
                            required: true
                        },
                        berat: {
                            required: true
                        },
                        potong: {
                            required: true
                        },
                    },
                    messages: {
                        berat: {
                            required: "*) harus diisi"
                        },
                        potong: {
                            required: "*) harus diisi"
                        },
                        cabang_id: {
                            required: "*) harus dipilih"
                        },
                        barang_id: {
                            required: "*) harus dipilih"
                        },
                        jenis_transaksi_id: {
                            required: "*) harus dipilih"
                        },
                        no_nota: {
                            required: "*) harus diisi"
                        },
                        karyawan_id: {
                            required: "*) harus dipilih"
                        },
                        tanggal: {
                            required: "*) harus diisi"
                        },
                    },
                    debug:true,
                    errorElement: "em",
                    errorPlacement: function ( error, element ) {
                        // Add the `invalid-feedback` class to the error element
                        error.addClass( "invalid-feedback" );
                        if ( element.prop( "type" ) === "checkbox" ) {
                            error.insertBefore( element.next( "label" ) );
                        } else if ( element.prop( "type" ) === "radio" ) {
                            error.appendTo( element.parent().parent().parent());
                        } else {
                            error.insertBefore( element );
                        }
                    },
                    highlight: function ( element, errorClass, validClass ) {
                        $( element ).addClass( "is-invalid" ).removeClass( "is-valid" );
                    },
                    unhighlight: function (element, errorClass, validClass) {
                        $( element ).addClass( "is-valid" ).removeClass( "is-invalid" );
                    },
                    submitHandler : function(form) {
                        $('#value-btn-tambah').val(1);
                        form.submit();
                    }
                });
            });
        },
        getNota : function(){
            // $('#huruf_nota').change(function () {
            //     var cabang_id = $("#cabang_id").val();
            //     var huruf_nota = $("#huruf_nota").val();
            //     $.ajax({
            //             url: App.baseUrl+'nota_kantor/get_nota_pembukuan_penjualan',
            //             type: 'GET',
            //             data: {
            //                     cabang_id: cabang_id,
            //                     huruf_nota: huruf_nota,
            //                 },
            //         })
            //         .done(function(jqXHR) {
            //             var data = JSON.parse(jqXHR)
            //             var option = '<option value="">Pilih No Nota</option>';
            //             if(data.status == true){
            //                 data_nota = data.data;
            //                 for (var i = 0; i < data_nota.length; i++) {
            //                     option += "<option value="+data_nota[i].id+"> "+data_nota[i].no_nota+"</option>";
            //                 }
            //             $('#no_nota').html(option);
            //             }
            //         })
            //         .fail(function() {
            //             console.log("error");
            //         });
            // });
            // $('#huruf_nota').change(function () {
            //     var huruf_nota = $("#huruf_nota").val();
            //     var cabang_id = $("#cabang_id").val();
            //     $.ajax({
            //         type: 'POST',
            //         url: App.baseUrl+'nota/get_nota',
            //         data: {
            //             'huruf_nota': huruf_nota,
            //             'cabang_id': cabang_id,
            //         },
            //         success: function (jqXHR) {
            //             var data = JSON.parse(jqXHR);
            //             if(data.status == true){
            //                 $('#no_nota').val(data.no_nota);
            //                 $('#no_nota_view').val(data.no_nota_view);
            //             }else{
            //                 $('#no_nota').val('');
            //                 $('#no_nota_view').val('');
            //             }
            //         }
            //     });

            // });
        },

        onClickFilter : function (){
            $('#btn-filter').on('click', function () {
                var tanggal   = $("#tanggal").val();
                var cabang_id   = $("#cabang_id").val();
                //pembukuan
                App.table_pembukuan.column(0).search(tanggal,true,true);
                App.table_pembukuan.column(1).search(cabang_id,true,true);
                // App.table_pembukuan.column(1).search(cabang_id,true,true);
                App.table_pembukuan.draw();
                //penjualan cabang
                App.table.column(0).search(tanggal,true,true);
                App.table.draw();
                //penjualan admin
                App.table_admin.column(0).search(tanggal,true,true);
                App.table_admin.column(1).search(cabang_id,true,true);
                App.table_admin.draw();

            });
        },

        resetFilter : function (){
            $('#btn-filter-clear').on( 'click', function () {
                $("#tanggal").val("").trigger('change');
                $("#cabang_id").val("").trigger('change');
                $('#btn-filter').trigger('click');
            });
        },
    }
});
