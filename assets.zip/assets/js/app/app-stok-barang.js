define([
    "jQuery",
    "bootstrap",
    "metisMenu",
    "architectui",
    "PerfectScrollbar",
    "datatables",
    "datatablesBootstrap4",
    "datatablesResponsive",
    "select2",
    "datePicker",
], function (
    $,
    bootstrap,
    metisMenu,
    architectui,
    PerfectScrollbar,
    datatables,
    datatablesBootstrap4,
    datatablesResponsive,
    select2,
    datePicker,
) {
    return {
        table: null,
        init: function () {
            App.initFunc();
            App.sidebarScroll();
            App.dataList();
            $(".dataTables_filter").hide();
            $(".loadingpage").hide();
            setTimeout(function () {
                $('.card-header').hide();
            }, 2500);
            App.onClickFilter();
            App.resetFilter();
            App.initEvent();


        },

        initEvent: function () {
            $('.select2').select2();
            $('.init-date').datepicker({
                uiLibrary: 'bootstrap4',
                format: 'YYYY-mm-dd'
            });
        },
        sidebarScroll: function () {
            setTimeout(function () {
                if ($(".scrollbar-container")[0]) {
                    $('.scrollbar-container').each(function () {
                        const ps = new PerfectScrollbar($(this)[0], {
                            wheelSpeed: 2,
                            wheelPropagation: false,
                            minScrollbarLength: 20
                        });
                    });

                    const ps = new PerfectScrollbar('.scrollbar-sidebar', {
                        wheelSpeed: 2,
                        wheelPropagation: true,
                        minScrollbarLength: 20
                    });
                }
            }, 1000);
        },

        dataList: function () {
            App.table = $('#table').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first": "Pertama",
                        "last": "Terakhir",
                        "next": "Selanjutnya",
                        "previous": "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": App.baseUrl + "stok_barang/dataList",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [{
                        "data": "id"
                    },
                    {
                        "data": "tanggal",
                        "orderable": false
                    },
                    {
                        "data": "cabang",
                        "orderable": false
                    },

                    // 925
                    {
                        "data": "stok_925_awal",
                        "orderable": false
                    },
                    {
                        "data": "stok_925_penjualan",
                        "orderable": false
                    },
                    {
                        "data": "stok_925_kembali",
                        "orderable": false
                    },
                    {
                        "data": "total_stok_925",
                        "orderable": false
                    },
                    {
                        "data": "stok_925_akhir",
                        "orderable": false
                    },
                    // sp
                    {
                        "data": "stok_sp_awal",
                        "orderable": false
                    },
                    {
                        "data": "stok_sp_penjualan",
                        "orderable": false
                    },
                    {
                        "data": "stok_sp_kembali",
                        "orderable": false
                    },
                    {
                        "data": "total_stok_sp",
                        "orderable": false
                    },
                    {
                        "data": "stok_sp_akhir",
                        "orderable": false
                    },
                    // retur dan modifikasi
                    {
                        "data": "stok_925_reparasi",
                        "orderable": false
                    },
                    {
                        "data": "stok_925_retur",
                        "orderable": false
                    },
                    {
                        "data": "stok_sp_reparasi",
                        "orderable": false
                    },
                    {
                        "data": "stok_sp_retur",
                        "orderable": false
                    },
                ],
                "columnDefs": [{
                    "targets": [0, 1, 2, 3, 4, 5, 6],
                    "className": "text-center"
                }, ]
            });
            // App.table_admin = $('#table-admin').DataTable({
            //     "language": {
            //         "search": "Cari",
            //         "lengthMenu": "Tampilkan _MENU_ data per halaman",
            //         "zeroRecords": "Data tidak ditemukan",
            //         "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
            //         "infoEmpty": "Tidak ada data yang ditampilkan ",
            //         "infoFiltered": "(pencarian dari _MAX_ total records)",
            //         "paginate": {
            //             "first":      "Pertama",
            //             "last":       "Terakhir",
            //             "next":       "Selanjutnya",
            //             "previous":   "Sebelum"
            //         },
            //     },
            //     "processing": true,
            //     "serverSide": true,
            //     "ajax":{
            //         "url": App.baseUrl+"penjualan/dataListAdmin",
            //         "dataType": "json",
            //         "type": "POST",
            //     },
            //     "columns": [
            //         { "data": "id" },
            //         { "data": "cabang","orderable": false },
            //         { "data": "tanggal","orderable": false },
            //         { "data": "jumlah_transaksi","orderable": false },
            //         { "data": "total_berat","orderable": false },
            //         { "data": "total_harga_keseluruhan","orderable": false },
            //         { "data": "action" ,"orderable": false}
            //     ],
            //     "columnDefs": [
            //         {"targets": [0,1,2,3,4,5,6], "className": "text-center"},
            //     ] 
            // });

            // App.table_pembukuan = $('#table-pembukuan').DataTable({
            //     "language": {
            //         "search": "Cari",
            //         "lengthMenu": "Tampilkan _MENU_ data per halaman",
            //         "zeroRecords": "Data tidak ditemukan",
            //         "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
            //         "infoEmpty": "Tidak ada data yang ditampilkan ",
            //         "infoFiltered": "(pencarian dari _MAX_ total records)",
            //         "paginate": {
            //             "first":      "Pertama",
            //             "last":       "Terakhir",
            //             "next":       "Selanjutnya",
            //             "previous":   "Sebelum"
            //         },
            //     },
            //     "processing": true,
            //     "serverSide": true,
            //     "ajax":{
            //         "url": App.baseUrl+"pembukuan_penjualan/dataList",
            //         "dataType": "json",
            //         "type": "POST",
            //     },
            //     "columns": [
            //         { "data": "id" },
            //         { "data": "cabang","orderable": false },
            //         { "data": "tanggal","orderable": false },
            //         { "data": "jumlah_transaksi","orderable": false },
            //         { "data": "total_berat","orderable": false },
            //         { "data": "total_harga_keseluruhan","orderable": false },
            //         { "data": "action" ,"orderable": false}
            //     ],
            //     "columnDefs": [
            //         {"targets": [0,1,2,3,4,5,6], "className": "text-center"},
            //     ] 
            // });

            //append button to datatables
            // add_btn = '<a href="'+App.baseUrl+'group/create" class="btn btn-sm btn-primary ml-2 mt-1"><i class="fa fa-plus"></i> Departemen</a>';
            // $('#table_filter').append(add_btn);
        },

        onClickFilter: function () {
            $('#btn-filter').on('click', function () {
                var tanggal = $("#tanggal").val();
                var cabang_id = $("#cabang_id").val();
                //penjualan cabang
                App.table.column(0).search(tanggal, true, true);
                App.table.column(1).search(cabang_id, true, true);
                App.table.draw();

            });
        },

        resetFilter: function () {
            $('#btn-filter-clear').on('click', function () {
                $("#tanggal").val("").trigger('change');
                $("#cabang_id").val("").trigger('change');
                $('#btn-filter').trigger('click');
            });
        },
    }
});