define([
    "jQuery",
    "bootstrap",
    "metisMenu",
    "architectui",
    "PerfectScrollbar",
    "datatables",
    "datatablesBootstrap4",
    "datatablesResponsive",
    "jValidation",
    "datePicker",
    "select2",
], function (
    $,
    bootstrap,
    metisMenu,
    architectui,
    PerfectScrollbar,
    datatables,
    datatablesBootstrap4,
    datatablesResponsive,
    jValidation,
    datePicker,
    select2,
) {
    return {
        table: null,
        init: function () {
            App.initFunc();
            App.sidebarScroll();
            App.initEvent();
            App.initConfirm();
            App.dataList();
            App.validationJs();
            $(".dataTables_filter").hide();
            $(".loadingpage").hide();
            $(".hide-keterangan").hide();
            setTimeout(function () {
                $('.card-header').hide();
            }, 2500);
            App.onClickFilter();
            App.resetFilter();

        },

        initEvent: function () {
            $('.init-date').datepicker({
                uiLibrary: 'bootstrap4',
                format: 'YYYY-mm-dd'
            });

            $('.select2').select2();
            
        },

        sidebarScroll: function () {
            setTimeout(function () {
                if ($(".scrollbar-container")[0]) {
                    $('.scrollbar-container').each(function () {
                        const ps = new PerfectScrollbar($(this)[0], {
                            wheelSpeed: 2,
                            wheelPropagation: false,
                            minScrollbarLength: 20
                        });
                    });

                    const ps = new PerfectScrollbar('.scrollbar-sidebar', {
                        wheelSpeed: 2,
                        wheelPropagation: true,
                        minScrollbarLength: 20
                    });
                }
            }, 1000);
        },

        initConfirm: function () {
            $('#table-admin').on('click', '.delete', function () {
                var url = $(this).attr("url");
                App.confirm("Apakah Anda Yakin Untuk Mengubah Ini?", function () {
                    $.ajax({
                        method: "GET",
                        url: url
                    }).done(function (msg) {
                        $('.loadingpage').hide();
                        App.table_admin.ajax.reload(null, true);
                    });
                })
            });
        },

        dataList: function () {
            App.table = $('#table').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first": "Pertama",
                        "last": "Terakhir",
                        "next": "Selanjutnya",
                        "previous": "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": App.baseUrl + "uang_laci/dataList",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [{
                        "data": "id"
                    },
                    {
                        "data": "tanggal",
                        "orderable": false
                    },
                    {
                        "data": "action",
                        "orderable": false
                    }
                ],
                "columnDefs": [{
                    "targets": [0, 1, 2],
                    "className": "text-center"
                }, ]
            });

            App.table_admin = $('#table-admin').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first": "Pertama",
                        "last": "Terakhir",
                        "next": "Selanjutnya",
                        "previous": "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": App.baseUrl + "uang_laci/dataListAdmin",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [{
                        "data": "id"
                    },
                    {
                        "data": "cabang",
                        "orderable": false
                    },
                    {
                        "data": "tanggal",
                        "orderable": false
                    },
                    {
                        "data": "status_audit",
                        "orderable": false
                    },
                    {
                        "data": "action",
                        "orderable": false
                    }
                ],
                "columnDefs": [{
                    "targets": [0, 1, 2, 3,4],
                    "className": "text-center"
                }, ]
            });
        },

        validationJs: function () {
            $('#btn-tambah').on('click', function () {

                $("#form").validate({
                    rules: {
                        uang_kas_pagi: {
                            required: true
                        },
                        uda: {
                            required: true
                        },
                        uang_setor: {
                            required: true
                        },
                        uang_jelek: {
                            required: true
                        },
                        uang_brangkas: {
                            required: true
                        },
                        rp_500: {
                            required: true
                        },
                        rp_1000: {
                            required: true
                        },
                        rp_2000: {
                            required: true
                        },
                        rp_5000: {
                            required: true
                        },
                        rp_10000: {
                            required: true
                        },
                        rp_20000: {
                            required: true
                        },
                        rp_50000: {
                            required: true
                        },
                        rp_100000: {
                            required: true
                        },
                        
                    },
                    messages: {
                        rp_100000: {
                            required: "*) harus diisi"
                        },
                        rp_50000: {
                            required: "*) harus diisi"
                        },
                        rp_20000: {
                            required: "*) harus diisi"
                        },
                        rp_10000: {
                            required: "*) harus diisi"
                        },
                        rp_5000: {
                            required: "*) harus diisi"
                        },
                        rp_2000: {
                            required: "*) harus diisi"
                        },
                        rp_1000: {
                            required: "*) harus diisi"
                        },
                        rp_500: {
                            required: "*) harus diisi"
                        },
                        uang_brangkas: {
                            required: "*) harus diisi"
                        },
                        uang_jelek: {
                            required: "*) harus diisi"
                        },
                        uang_setor: {
                            required: "*) harus diisi"
                        },
                        uda: {
                            required: "*) harus diisi"
                        },
                        uang_kas_pagi: {
                            required: "*) harus diisi"
                        },
                        
                    },
                    debug: true,
                    errorElement: "em",
                    errorPlacement: function (error, element) {
                        // Add the `invalid-feedback` class to the error element
                        error.addClass("invalid-feedback");
                        if (element.prop("type") === "checkbox") {
                            error.insertBefore(element.next("label"));
                        } else if (element.prop("type") === "radio") {
                            error.appendTo(element.parent().parent().parent());
                        } else {
                            error.insertBefore(element);
                        }
                    },
                    highlight: function (element, errorClass, validClass) {
                        $(element).addClass("is-invalid").removeClass("is-valid");
                    },
                    unhighlight: function (element, errorClass, validClass) {
                        $(element).addClass("is-valid").removeClass("is-invalid");
                    },
                    submitHandler: function (form) {
                        $('#value-btn-tambah').val(1);
                        form.submit();
                    }
                });
            });
        },

        onClickFilter : function (){
            $('#btn-filter').on('click', function () {
                var tanggal   = $("#tanggal").val();
                var cabang_id   = $("#cabang_id").val();
                var status_audit   = $("#status_audit").val();
                
                //transaksi
                App.table.column(0).search(tanggal,true,true);
                App.table.draw();
                //uang laci admin
                App.table_admin.column(0).search(tanggal,true,true);
                App.table_admin.column(1).search(cabang_id,true,true);
                App.table_admin.column(2).search(status_audit,true,true);
                App.table_admin.draw();

            });
        },

        resetFilter : function (){
            $('#btn-filter-clear').on( 'click', function () {
                $("#tanggal").val("").trigger('change');
                $("#cabang_id").val("").trigger('change');
                $("#status_audit").val("").trigger('change');
                $('#btn-filter').trigger('click');
            });
        },
    }
});