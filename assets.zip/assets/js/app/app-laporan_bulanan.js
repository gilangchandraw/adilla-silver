define([
    "jQuery",
    "bootstrap",
    "metisMenu",
    "architectui",
    "PerfectScrollbar",
    "datePicker",
    "select2",
], function (
    $,
    bootstrap,
    metisMenu,
    architectui,
    PerfectScrollbar,
    datePicker,
    select2,
) {
    return {
        table: null,
        init: function () {
            App.initFunc();
            App.initEvent();
            App.sidebarScroll();
            $(".loadingpage").hide();
            setTimeout(function () {
                $('.card-header').hide();
            }, 2500);
            App.initPreview();
        },
        initPreview: function() {
            $('#preview-btn').on('click', function () {

                var laporan   = $("#laporan").val();
                var cabang_id     = $("#cabang_id").val();
                var tanggal     = $("#tanggal").val();
                if (laporan == "" || cabang_id == "" || tanggal == "") {
                    App.alert('Pilih Filter terlebih dahulu');
                } else {

                }
                $.ajax({
                    url: App.baseUrl+'laporan_bulanan/get_data',
                    type: 'GET',
                    data: {
                            laporan: laporan,
                            cabang_id: cabang_id,
                            tanggal: tanggal,
                        },
                })
                .done(function( jqXHR ) {
                    var data = JSON.parse(jqXHR);
                    if(data.status == true){
                        var html_laporan = '';
                        html_laporan += '<div class="main-card mb-3 card">\
                                            <div class="card-body">\
                                                <section class="content">\
                                                    <div class="box box-default color-palette-box">\
                                                        <div class="box-body">\
                                                            <div class="row" id="body_report">\
                                                                <div class="col-md-6 mb-15" style="page-break-after: always; margin: auto; width: 50%; border: 3px; padding: 10px;">\
                                                                    <div class="paycheck-container" style="padding: 15px; border:1px solid #ebebeb;">\
                                                                        <div class="full-width paycheck-logo">\
                                                                            <span></span>\
                                                                            <p class="text-right"></p>\
                                                                        </div>\
                                                                        <table class="table-paycheck table table-border" align="center">\
                                                                            <tbody>\
                                                                                <tr>\
                                                                                    <td rowspan="4"><img style="height: 50px" src="'+App.baseUrl+'assets/images/logo.png"></\td>\
                                                                                    <td class="text-center">ADILLA SILVER 925 GROUP</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td align="center" class="text-center">Laporan Bulanan</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td class="text-center">'+data.cabang+'</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td class="text-center"> Bulan '+data.bulan+'</td>\
                                                                                </tr>\
                                                                            </tbody>\
                                                                        </table>\
                                                                        <table class="table-paycheck table table-border" border="1">\
                                                                            <tbody>\
                                                                                <tr align="center">\
                                                                                    <td class="text-center" style="background-color:#87CEEB;"> <strong>\
                                                                                            TRANSAKSI</strong></td>\
                                                                                    <td class="text-center" style="background-color:#87CEEB;">\
                                                                                        <strong>KARAT</strong>\
                                                                                    </td>\
                                                                                    <td class="text-center" style="background-color:#87CEEB;">\
                                                                                        <strong>GRAM</strong></td>\
                                                                                    <td class="text-center" style="background-color:#87CEEB;">\
                                                                                        <strong>Rp</strong></td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td style="background-color:#87CEEB;" align="center" class="text-center" rowspan="3"> <strong>PENJUALAN</strong> </td>\
                                                                                    <td class="text-center">[25]</td>\
                                                                                    <td class="text-center">'+data.berat_penjualan_25+'</td>\
                                                                                    <td class="text-center">'+data.harga_penjualan_25+'</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td class="text-center">[30]</td>\
                                                                                    <td class="text-center">'+data.berat_penjualan_30+'</td>\
                                                                                    <td class="text-center">'+data.harga_penjualan_30+'</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td class="text-center">[35]</td>\
                                                                                    <td class="text-center">'+data.berat_penjualan_35+'</td>\
                                                                                    <td class="text-center">'+data.harga_penjualan_35+'</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td style="background-color:#87CEEB;" align="center" class="text-center" rowspan="3"> <strong> TUKAR [+]</strong></td>\
                                                                                    <td class="text-center">[25]</td>\
                                                                                    <td class="text-center">'+data.berat_tukar_25+'</td>\
                                                                                    <td class="text-center">'+data.harga_tukar_25+'</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td class="text-center">[30]</td>\
                                                                                    <td class="text-center">'+data.berat_tukar_30+'</td>\
                                                                                    <td class="text-center">'+data.harga_tukar_30+'</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td class="text-center">[35]</td>\
                                                                                    <td class="text-center">'+data.berat_tukar_35+'</td>\
                                                                                    <td class="text-center">'+data.harga_tukar_35+'</td>\
                                                                                </tr>\
                                                                                <tr style="background-color:#98FB98;">\
                                                                                    <td align="center" colspan="2" class="text-center"> <strong>TOTAL PENJUALAN\
                                                                                        </strong> </td>\
                                                                                    <td class="text-center">'+data.total_berat_penjualan+'</td>\
                                                                                    <td class="text-center">'+data.total_harga_penjualan+'</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td style="background-color:#87CEEB;" class="text-center" colspan="2"><strong>SEPUHAN</strong></td>\
                                                                                    <td style="background-color:#87CEEB;" class="text-center" colspan="2">'+data.total_sepuhan+'</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td style="background-color:#87CEEB;" class="text-center" colspan="2"><strong>BARANG RUSAK</strong></td>\
                                                                                    <td style="background-color:#87CEEB;" class="text-center">'+data.total_berat_rusak+'</td>\
                                                                                    <td style="background-color:#87CEEB;" class="text-center">'+data.total_harga_rusak+'</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td style="background-color:#87CEEB;" class="text-center" rowspan="12"> <strong> BARANG KEMBALI</strong></td>\
                                                                                    <td class="text-center">[17]</td>\
                                                                                    <td class="text-center">'+data.berat_bk_17+'</td>\
                                                                                    <td class="text-center">'+data.harga_bk_17+'</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td class="text-center">[18]</td>\
                                                                                    <td class="text-center">'+data.berat_bk_18+'</td>\
                                                                                    <td class="text-center">'+data.harga_bk_18+'</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td class="text-center">[19]</td>\
                                                                                    <td class="text-center">'+data.berat_bk_19+'</td>\
                                                                                    <td class="text-center">'+data.harga_bk_19+'</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td class="text-center">[20]</td>\
                                                                                    <td class="text-center">'+data.berat_bk_20+'</td>\
                                                                                    <td class="text-center">'+data.harga_bk_20+'</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td class="text-center">[22]</td>\
                                                                                    <td class="text-center">'+data.berat_bk_22+'</td>\
                                                                                    <td class="text-center">'+data.harga_bk_22+'</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td class="text-center">[23]</td>\
                                                                                    <td class="text-center">'+data.berat_bk_23+'</td>\
                                                                                    <td class="text-center">'+data.harga_bk_23+'</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td class="text-center">[24]</td>\
                                                                                    <td class="text-center">'+data.berat_bk_24+'</td>\
                                                                                    <td class="text-center">'+data.harga_bk_24+'</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td class="text-center">[25]</td>\
                                                                                    <td class="text-center">'+data.berat_bk_25+'</td>\
                                                                                    <td class="text-center">'+data.harga_bk_25+'</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td class="text-center">[27]</td>\
                                                                                    <td class="text-center">'+data.berat_bk_27+'</td>\
                                                                                    <td class="text-center">'+data.harga_bk_27+'</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td class="text-center">[28]</td>\
                                                                                    <td class="text-center">'+data.berat_bk_28+'</td>\
                                                                                    <td class="text-center">'+data.harga_bk_28+'</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td class="text-center">[29]</td>\
                                                                                    <td class="text-center">'+data.berat_bk_29+'</td>\
                                                                                    <td class="text-center">'+data.harga_bk_29+'</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td class="text-center">[30]</td>\
                                                                                    <td class="text-center">'+data.berat_bk_30+'</td>\
                                                                                    <td class="text-center">'+data.harga_bk_30+'</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td style="background-color:#87CEEB;" class="text-center"> <strong>STOK BARANG DI TOKO</strong></td>\
                                                                                    <td style="background-color:#87CEEB;" class="text-center"> <strong>TOTAL BARANG KEMBALI</strong> </td>\
                                                                                    <td class="text-center">'+data.total_berat_bk+'</td>\
                                                                                    <td class="text-center">'+data.total_harga_bk+' </td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td style="background-color:#87CEEB;" colspan="2" class="text-center"> <strong>POTONGAN BK</strong></td>\
                                                                                    <td colspan="2" class="text-center">'+data.potong_bk+' Pot</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td style="background-color:#87CEEB;" colspan="2" class="text-center"> <strong>POTONGAN PENJUALAN</strong></td>\
                                                                                    <td colspan="2" class="text-center">'+data.total_potong_penjualan+' Pot</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                                    <td style="background-color:#87CEEB;" class="text-center" rowspan="'+data.jumlah_pengeluaran+'"> <strong> PENGELUARAN</strong>\
                                                                                    </td>\
                                                                                    <td class="text-center">\
                                                                                        <strong>\
                                                                                            Nama</strong></td>\
                                                                                    <td colspan="3" class="text-center"> <strong> Rp</strong></td>\
                                                                                </tr>';
                                                                                //
                                                                                html_laporan += '<tr>';
                                                                                html_laporan += '<td class="text-center">KARYAWAN</td>';
                                                                                html_laporan += '<td colspan="2" class="text-center">'+data.total_pengeluaran_1+'</td>';
                                                                                html_laporan += '</tr>';
                                                                                //
                                                                                html_laporan += '<tr>';
                                                                                html_laporan += '<td class="text-center">KONTRAK TOKO</td>';
                                                                                html_laporan += '<td colspan="2" class="text-center">'+data.total_pengeluaran_2+'</td>';
                                                                                html_laporan += '</tr>';
                                                                                //
                                                                                html_laporan += '<tr>';
                                                                                html_laporan += '<td class="text-center">MOBIL</td>';
                                                                                html_laporan += '<td colspan="2" class="text-center">'+data.total_pengeluaran_3+'</td>';
                                                                                html_laporan += '</tr>';
                                                                                //
                                                                                html_laporan += '<tr>';
                                                                                html_laporan += '<td class="text-center">GAJI KARYAWAN</td>';
                                                                                html_laporan += '<td colspan="2" class="text-center">'+data.total_pengeluaran_4+'</td>';
                                                                                html_laporan += '</tr>';
                                                                                //
                                                                                html_laporan += '<tr>';
                                                                                html_laporan += '<td class="text-center">LISTRIK</td>';
                                                                                html_laporan += '<td colspan="2" class="text-center">'+data.total_pengeluaran_5+'</td>';
                                                                                html_laporan += '</tr>';
                                                                                //
                                                                                html_laporan += '<tr>';
                                                                                html_laporan += '<td class="text-center">SANITIZER</td>';
                                                                                html_laporan += '<td colspan="2" class="text-center">'+data.total_pengeluaran_6+'</td>';
                                                                                html_laporan += '</tr>';
                                                                                //
                                                                                html_laporan += '<tr>';
                                                                                html_laporan += '<td class="text-center">PDAM</td>';
                                                                                html_laporan += '<td colspan="2" class="text-center">'+data.total_pengeluaran_7+'</td>';
                                                                                html_laporan += '</tr>';
                                                                                //
                                                                                html_laporan += '<tr>';
                                                                                html_laporan += '<td class="text-center">WIFI</td>';
                                                                                html_laporan += '<td colspan="2" class="text-center">'+data.total_pengeluaran_8+'</td>';
                                                                                html_laporan += '</tr>';
                                                                                //
                                                                                html_laporan += '<tr>';
                                                                                html_laporan += '<td class="text-center">SEPUHAN</td>';
                                                                                html_laporan += '<td colspan="2" class="text-center">'+data.total_pengeluaran_9+'</td>';
                                                                                html_laporan += '</tr>';
                                                                                //
                                                                                html_laporan += '<tr>';
                                                                                html_laporan += '<td class="text-center">BONUS</td>';
                                                                                html_laporan += '<td colspan="2" class="text-center">'+data.total_pengeluaran_11+'</td>';
                                                                                html_laporan += '</tr>';
                                                                                //
                                                                                html_laporan += '<tr>';
                                                                                html_laporan += '<td class="text-center">SETOR KAS</td>';
                                                                                html_laporan += '<td colspan="2" class="text-center">'+data.total_pengeluaran_12+'</td>';
                                                                                html_laporan += '</tr>';
                                                                                if (data.pengeluaran != null) {
                                                                                    for (var i = 0; i < data.pengeluaran.length; i++) {
                                                                                        html_laporan += '<tr>';
                                                                                            html_laporan += '<td class="text-center"> Tidak Terduga -> '+data.pengeluaran[i].keterangan+'</td>';
                                                                                            html_laporan += '<td colspan="2" class="text-center">'+App.toRp(data.pengeluaran[i].harga)+'</td>';
                                                                                            html_laporan += '</tr>';
                                                                                    }
                                                                                }

                                                                                
                                                                                html_laporan += '<tr style="background-color:#98FB98;">\
                                                                                    <td colspan="2" class="text-center"> <strong>TOTAL PENGELUARAN\
                                                                                        </strong>\
                                                                                    </td>\
                                                                                    <td colspan="3" class="text-center">'+data.total_pengeluaran+'</td>\
                                                                                </tr>\
                                                                                <tr>\
                                                                            </tbody>\
                                                                        </table>\
                                                                    </div>\
                                                                </div>\
                                                            </div>\
                                                        </div>\
                                                    </div>\
                                                </section>\
                                            </div>\
                                        </div>';

                        $('#hasil-report').html(html_laporan);
                        $("#hasil-report").show();
                        $("#hasil-laporan-tidak-ada").hide();
                        $('#print-pdf').attr('href', App.baseUrl+'laporan_bulanan/print_pdf?cabang_id='+cabang_id+'&tanggal='+tanggal);
                        
                        
                        
                    }else{
                        $("#hasil-report").hide();
                        html_laporan = '';
                        html_laporan +='<div class="main-card mb-3 card">\
                                            <div class="card-body">\
                                                <div class="row">\
                                                    <h4 class="text-center">Data Tidak Ditemukan</h4>\
                                                </div>\
                                            </div>\
                                        </div>';
                        $('#hasil-laporan-tidak-ada').html(html_laporan);
                        $("#hasil-laporan-tidak-ada").show();
                    }
                })
                .fail(function() {
                    console.log("error");
                })

            });
        },
        initEvent: function () {
            $('.select2').select2();

            $('.init-date').datepicker({
                uiLibrary: 'bootstrap4',
                format: 'YYYY-mm-dd'
            });
            $('.init-year-month').datepicker({
                   format: "mm-yyyy",
                    viewMode: "months", 
                    minViewMode: "months"
            });
        },

        sidebarScroll: function () {
            setTimeout(function () {
                if ($(".scrollbar-container")[0]) {
                    $('.scrollbar-container').each(function () {
                        const ps = new PerfectScrollbar($(this)[0], {
                            wheelSpeed: 2,
                            wheelPropagation: false,
                            minScrollbarLength: 20
                        });
                    });


                    const ps = new PerfectScrollbar('.scrollbar-sidebar', {
                        wheelSpeed: 2,
                        wheelPropagation: true,
                        minScrollbarLength: 20
                    });
                }
            }, 1000);
        },
    }
});