define([
    "jQuery",
    "bootstrap",
    "metisMenu",
    "architectui",
    "PerfectScrollbar",
    "jValidation",
    ], function (
    $,
    bootstrap,
    metisMenu,
    architectui,
    PerfectScrollbar,
    jValidation,
    ) {
    return {  
        init: function () { 
            App.initFunc();
            App.sidebarScroll();
            App.validationJs();
            $(".loadingpage").hide();
            setTimeout(function(){
                $('.card-header').hide();
            }, 2500);
        },

        sidebarScroll: function () {
            setTimeout(function () {
                if ($(".scrollbar-container")[0]) {
                    $('.scrollbar-container').each(function () {
                        const ps = new PerfectScrollbar($(this)[0], {
                            wheelSpeed: 2,
                            wheelPropagation: false,
                            minScrollbarLength: 20
                        });
                    });

                    const ps = new PerfectScrollbar('.scrollbar-sidebar', {
                        wheelSpeed: 2,
                        wheelPropagation: true,
                        minScrollbarLength: 20
                    });
                }
            }, 1000);
        }, 

        validationJs : function(){    
            $("#form1").validate({
                rules: {
                    nama_lengkap: {
                        required: true
                    },
                    user_name: {
                        required: true,
                        minlength: 8
                    },
                    email: {
                        required: true,
                    },
                    phone: {
                        required: true,
                    },
                    address: {
                        required: true,
                    }   
                },
                messages: {
                    nama_lengkap: {
                        required: "*) harus diisi"
                    },
                    user_name: {
                        required: "*) harus diisi",
                        minlength : "Minimal 8"
                    },
                    email: {
                        required: "*) harus diisi",
                    },
                    phone: {
                        required: "*) harus diisi"
                    },
                    address: {
                        required: "*) harus diisi"
                    }
                },
                debug:true,
                errorElement: "em",
                errorPlacement: function ( error, element ) {
                    // Add the `invalid-feedback` class to the error element
                    error.addClass( "invalid-feedback" );
                    if ( element.prop( "type" ) === "checkbox" ) {
                        error.insertBefore( element.next( "label" ) );
                    } else if ( element.prop( "type" ) === "radio" ) {
                        error.appendTo( element.parent().parent().parent());
                    } else {
                        error.insertBefore( element );
                    }
                },
                highlight: function ( element, errorClass, validClass ) {
                    $( element ).addClass( "is-invalid" ).removeClass( "is-valid" );
                },
                unhighlight: function (element, errorClass, validClass) {
                    $( element ).addClass( "is-valid" ).removeClass( "is-invalid" );
                },
                submitHandler : function(form) {
                    form.submit();
                }
            });

            $("#form2").validate({
                rules: {
                    old_password: {
                        required: true
                    },
                    new_password: {
                        required: true,
                        minlength: 8
                    },
                    confirm_password: {
                        required: true,
                        equalTo: "#new_password",
                        minlength: 8
                    },   
                },
                messages: {
                    name: {
                        required: "*) harus diisi"
                    },
                    old_password: {
                        required: "*) harus diisi"
                    },
                    new_password: {
                        required: "*) harus diisi",
                        minlength: "Minimal 8"
                    },
                    confirm_password: {
                        required: "*) harus diisi",
                        equalTo: "Konfirmasi Password tidak sama dengan Password Baru",
                        minlength: "Minimal 8"
                    }
                },
                debug:true,
                errorElement: "em",
                errorPlacement: function ( error, element ) {
                    // Add the `invalid-feedback` class to the error element
                    error.addClass( "invalid-feedback" );
                    if ( element.prop( "type" ) === "checkbox" ) {
                        error.insertBefore( element.next( "label" ) );
                    } else if ( element.prop( "type" ) === "radio" ) {
                        error.appendTo( element.parent().parent().parent());
                    } else {
                        error.insertBefore( element );
                    }
                },
                highlight: function ( element, errorClass, validClass ) {
                    $( element ).addClass( "is-invalid" ).removeClass( "is-valid" );
                },
                unhighlight: function (element, errorClass, validClass) {
                    $( element ).addClass( "is-valid" ).removeClass( "is-invalid" );
                },
                submitHandler : function(form) {
                    form.submit();
                }
            });
        },
	}
});
