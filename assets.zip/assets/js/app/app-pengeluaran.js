define([
    "jQuery",
    "bootstrap",
    "metisMenu",
    "architectui",
    "PerfectScrollbar",
    "datatables",
    "datatablesBootstrap4",
    "datatablesResponsive",
    "jValidation",
    "datePicker",
    "select2",
], function (
    $,
    bootstrap,
    metisMenu,
    architectui,
    PerfectScrollbar,
    datatables,
    datatablesBootstrap4,
    datatablesResponsive,
    jValidation,
    datePicker,
    select2,
) {
    return {
        table: null,
        init: function () {
            App.initFunc();
            App.sidebarScroll();
            App.initConfirm();
            App.dataList();
            App.validationJs();
            $(".dataTables_filter").hide();
            $(".loadingpage").hide();
            $(".hide-keterangan").hide();
            setTimeout(function () {
                $('.card-header').hide();
            }, 2500);
            App.initEvent();
            App.onClickFilter();
            App.resetFilter();

        },

        initEvent: function () {
            $('.init-date').datepicker({
                uiLibrary: 'bootstrap4',
                format: 'YYYY-mm-dd'
            });

            $('.select2').select2();

            $('input[name=berat]').change(function () {
                // alert(App.harga_satuan);
                var berat = $('#berat').val();
                var jenis_transaksi_id = $('#jenis_transaksi_id').val();
                //get harga
                $.ajax({
                        url: App.baseUrl + 'enum_transaksi_barang/get_harga',
                        type: 'GET',
                        data: {
                            jenis_transaksi_id: jenis_transaksi_id
                        },
                    })
                    .done(function (jqXHR) {
                        var data = JSON.parse(jqXHR);
                        if (data.status == true) {
                            var harga = berat * parseInt(data.harga);
                            $('#harga').val(App.toRp(harga));
                            $('#total_harga_keseluruhan').val(App.toRp(harga));
                            // $('#stok').val(data.stok);
                            // harga_satuan = data.harga.replace(",", "");
                            // App.harga_satuan = harga_satuan;
                            // App.stok = data.stok;



                        } else {
                            $('#harga').val('');
                        }
                        // App.HitungPersentaseRencana($('#rencana_jumlah_penduduk').val(), data.jumlah_penduduk);
                    })
                    .fail(function () {
                        console.log("error");
                    })

                var harga_satuan = App.harga_satuan.replace(",", "");
                var banyak = parseInt(berat);
                if (banyak > App.stok) {
                    alert('Stok Tidak Mencukupi');
                    $('#total_harga').val('');
                    $('#harga').val('');
                } else {
                    var total = berat * harga_satuan;
                    $('#total_harga').val('Rp. ' + App.toRp(total));
                    var total_harga_keseluruhan = $('#total_harga_keseluruhan').val();
                    $('#harga').val(total);
                    var total_akhir = parseInt(total_harga_keseluruhan) + total;
                    $('#total_harga_keseluruhan').val(total_akhir);
                }
            });

            $('#enum_pengeluaran_id').change(function () {
                var enum_pengeluaran_id = $("#enum_pengeluaran_id").val();
                if (enum_pengeluaran_id == '10') {
                    $('.hide-keterangan').show();
                } else {
                    $('.hide-keterangan').hide();
                }
                // $.ajax({
                //     type: 'POST',
                //     url: App.baseUrl+'nota/get_nota',
                //     data: {
                //         'huruf_nota': huruf_nota,
                //         'cabang_id': cabang_id,
                //     },
                //     success: function (jqXHR) {
                //         var data = JSON.parse(jqXHR);
                //         if(data.status == true){
                //             $('#no_nota').val(data.no_nota);
                //             $('#no_nota_view').val(data.no_nota_view);
                //         }else{
                //             $('#no_nota').val('');
                //             $('#no_nota_view').val('');
                //         }
                //     }
                // });

            });
            var enum_pengeluaran_id = $("#enum_pengeluaran_id").val();
            enum_pengeluaran_id = parseInt(enum_pengeluaran_id);
            // alert(enum_pengeluaran_id)
            if (enum_pengeluaran_id == 10) {
                $('.hide-keterangan').show();
                // alert('b')
            } else {
                $('.hide-keterangan').hide();
                // alert('a')
            }
        },

        sidebarScroll: function () {
            setTimeout(function () {
                if ($(".scrollbar-container")[0]) {
                    $('.scrollbar-container').each(function () {
                        const ps = new PerfectScrollbar($(this)[0], {
                            wheelSpeed: 2,
                            wheelPropagation: false,
                            minScrollbarLength: 20
                        });
                    });

                    const ps = new PerfectScrollbar('.scrollbar-sidebar', {
                        wheelSpeed: 2,
                        wheelPropagation: true,
                        minScrollbarLength: 20
                    });
                }
            }, 1000);
        },

        initConfirm: function () {
            $('#table-admin').on('click', '.delete', function () {
                var url = $(this).attr("url");
                App.confirm("Apakah Anda Yakin Untuk Mengubah Ini?", function () {
                    $.ajax({
                        method: "GET",
                        url: url
                    }).done(function (msg) {
                        $('.loadingpage').hide();
                        App.table_admin.ajax.reload(null, true);
                    });
                })
            });
        },

        dataList: function () {
            App.table = $('#table').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first": "Pertama",
                        "last": "Terakhir",
                        "next": "Selanjutnya",
                        "previous": "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": App.baseUrl + "pengeluaran/dataList",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [{
                        "data": "id"
                    },
                    {
                        "data": "tanggal",
                        "orderable": false
                    },
                    {
                        "data": "total_harga_keseluruhan",
                        "orderable": false
                    },
                    {
                        "data": "action",
                        "orderable": false
                    }
                ],
                "columnDefs": [{
                    "targets": [0, 1, 2, 3],
                    "className": "text-center"
                }, ]
            });
            App.table_admin = $('#table-admin').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first": "Pertama",
                        "last": "Terakhir",
                        "next": "Selanjutnya",
                        "previous": "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": App.baseUrl + "pengeluaran/dataListAdmin",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [{
                        "data": "id"
                    },
                    {
                        "data": "cabang",
                        "orderable": false
                    },
                    {
                        "data": "tanggal",
                        "orderable": false
                    },
                    {
                        "data": "total_harga_keseluruhan",
                        "orderable": false
                    },
                    {
                        "data": "status_audit",
                        "orderable": false
                    },
                    {
                        "data": "action",
                        "orderable": false
                    }
                ],
                "columnDefs": [{
                    "targets": [0, 1, 2, 3, 4,5],
                    "className": "text-center"
                }, ]
            });

            App.table_pembukuan = $('#table_pembukuan').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first": "Pertama",
                        "last": "Terakhir",
                        "next": "Selanjutnya",
                        "previous": "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": App.baseUrl + "pembukuan_pengeluaran/dataList",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [{
                        "data": "id"
                    },
                    {
                        "data": "tanggal",
                        "orderable": false
                    },
                    {
                        "data": "total_harga_keseluruhan",
                        "orderable": false
                    },
                    {
                        "data": "action",
                        "orderable": false
                    }
                ],
                "columnDefs": [{
                    "targets": [0, 1, 2, 3],
                    "className": "text-center"
                }, ]
            });
        },

        validationJs: function () {
            $('#btn-tambah').on('click', function () {

                $("#form").validate({
                    rules: {
                        tanggal: {
                            required: true
                        },
                        enum_pengeluaran_id: {
                            required: true
                        },
                        harga: {
                            required: true
                        },
                        keterangan: {
                            required: true
                        },
                    },
                    messages: {
                        tanggal: {
                            required: "*) harus diisi"
                        },
                        enum_pengeluaran_id: {
                            required: "*) harus dipilih"
                        },
                        keterangan: {
                            required: "*) harus diisi"
                        },
                        harga: {
                            required: "*) harus diisi"
                        },
                    },
                    debug: true,
                    errorElement: "em",
                    errorPlacement: function (error, element) {
                        // Add the `invalid-feedback` class to the error element
                        error.addClass("invalid-feedback");
                        if (element.prop("type") === "checkbox") {
                            error.insertBefore(element.next("label"));
                        } else if (element.prop("type") === "radio") {
                            error.appendTo(element.parent().parent().parent());
                        } else {
                            error.insertBefore(element);
                        }
                    },
                    highlight: function (element, errorClass, validClass) {
                        $(element).addClass("is-invalid").removeClass("is-valid");
                    },
                    unhighlight: function (element, errorClass, validClass) {
                        $(element).addClass("is-valid").removeClass("is-invalid");
                    },
                    submitHandler: function (form) {
                        $('#value-btn-tambah').val(1);
                        form.submit();
                    }
                });
            });
        },

        onClickFilter: function () {
            $('#btn-filter').on('click', function () {
                var tanggal = $("#tanggal").val();
                var cabang_id = $("#cabang_id").val();
                var status_audit   = $("#status_audit").val();
                //pembukuan
                App.table_pembukuan.column(0).search(tanggal, true, true);
                App.table_pembukuan.draw();
                //transaksi
                App.table.column(0).search(tanggal, true, true);
                App.table.draw();

                //pengeluaran admin
                App.table_admin.column(0).search(tanggal, true, true);
                App.table_admin.column(1).search(cabang_id, true, true);
                App.table_admin.column(2).search(status_audit,true,true);
                App.table_admin.draw();

            });
        },

        resetFilter: function () {
            $('#btn-filter-clear').on('click', function () {
                $("#tanggal").val("").trigger('change');
                $("#cabang_id").val("").trigger('change');
                $("#status_audit").val("").trigger('change');
                $('#btn-filter').trigger('click');
            });
        },
    }
});