define([
    "jQuery",
    "bootstrap",
    "metisMenu",
    "architectui",
    "PerfectScrollbar",
    "slick",
    "jValidation",
    ], function (
    $,
    bootstrap,
    metisMenu,
    architectui,
    PerfectScrollbar,
    slick,
    jValidation,
    ) {
	return {

		init: function () { 
			App.reponsiveLogo(); 
			// App.initFunc();
			App.validationJs(); 
			App.carouselJS(); 
			App.initShowPass(); 
			console.log("loaded");
			// $("#responsive-logo-adilla").hide();
		},
		initShowPass : function () {
			const togglePassword = document.querySelector('#togglePassword');
			const password = document.querySelector('#password');

			togglePassword.addEventListener('click', function (e) {
			    // toggle the type attribute
			    const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
			    password.setAttribute('type', type);
			    // toggle the eye slash icon
			    this.classList.toggle('fa-eye-slash');
			});
		},
		reponsiveLogo : function(){
            var width = $(window).width();
            // var height = $(window).height();
            if (width < 728) {
            	var html = '';
            	html += '<img src="'+App.baseUrl+'assets/images/logo.png"> <br><br>';
            	$('#responsive-logo-adilla').html(html);
                $("#responsive-logo-adilla").show();
            } else {
                $("#responsive-logo-adilla").hide();
            }
        },

		validationJs : function(){	
			$("#form").validate({
				rules: {
					username: {
						required: true
					},
					password: {
						required: true
					}
				},
				messages: {
					username: {
						required: "*)Harus Diisi"
					},
					password: {
						required: "*)Harus Diisi"
					}
				}, 
				debug:true,
                errorElement: "em",
                errorPlacement: function ( error, element ) {
                    // Add the `invalid-feedback` class to the error element
                    error.addClass( "invalid-feedback" );
                    if ( element.prop( "type" ) === "checkbox" ) {
                        error.insertBefore( element.next( "label" ) );
                    } else if ( element.prop( "type" ) === "radio" ) {
                        error.appendTo( element.parent().parent().parent());
                    } else {
                        error.insertBefore( element );
                    }
                },
                highlight: function ( element, errorClass, validClass ) {
                    $( element ).addClass( "is-invalid" ).removeClass( "is-valid" );
                },
                unhighlight: function (element, errorClass, validClass) {
                    $( element ).addClass( "is-valid" ).removeClass( "is-invalid" );
                },
                submitHandler : function(form) {
                    form.submit();
                }
			});
		},

		carouselJS : function(){
			setTimeout(function () {
		        $(".slick-slider").slick({
		            dots: true,
		            slidesToShow: 1,
		            slidesToScroll: 1
		        });

		        $(".slick-slider-3").slick({
		            dots: true,
		            slidesToShow: 1,
		            slidesToScroll: 1
		        });

		        $(".slick-slider-2").slick({
		            className: "center",
		            centerMode: true,
		            infinite: true,
		            centerPadding: "60px",
		            slidesToShow: 3,
		            speed: 500,
		            dots: true
		        });

		        $(".slick-slider-variable").slick({
		            className: "slider variable-width",
		            dots: true,
		            infinite: true,
		            centerMode: true,
		            slidesToShow: 1,
		            slidesToScroll: 1,
		            variableWidth: true
		        });

		        $(".slick-slider-responsive").slick({
		            dots: true,
		            infinite: false,
		            speed: 500,
		            slidesToShow: 4,
		            slidesToScroll: 4,
		            initialSlide: 0,
		            responsive: [
		                {
		                    breakpoint: 1024,
		                    settings: {
		                        slidesToShow: 3,
		                        slidesToScroll: 3,
		                        infinite: true,
		                        dots: true
		                    }
		                },
		                {
		                    breakpoint: 600,
		                    settings: {
		                        slidesToShow: 2,
		                        slidesToScroll: 2,
		                        initialSlide: 2
		                    }
		                },
		                {
		                    breakpoint: 480,
		                    settings: {
		                        slidesToShow: 1,
		                        slidesToScroll: 1
		                    }
		                }
		            ]
		        });

		        $(".slick-slider-inverted").slick({
		            infinite: true,
		            slidesToShow: 1,
		            speed: 500,
		            dots: true,
		            adaptiveHeight: true
		        });

		    }, 100);
		}
	}
});