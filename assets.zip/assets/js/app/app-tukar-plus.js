define([
    "jQuery",
    "bootstrap",
    "metisMenu",
    "architectui",
    "PerfectScrollbar",
    "datatables",
    "datatablesBootstrap4",
    "datatablesResponsive",
    "jValidation",
    "datePicker",
    "select2",
], function (
    $,
    bootstrap,
    metisMenu,
    architectui,
    PerfectScrollbar,
    datatables,
    datatablesBootstrap4,
    datatablesResponsive,
    jValidation,
    datePicker,
    select2,
) {
    return {
        table: null,
        init: function () {
            App.initFunc();
            App.initCekNota();
            App.initGetNota();
            App.sidebarScroll();
            App.initEvent();
            App.initConfirm();
            App.dataList();
            App.validationJs();
            App.getNota();
            $(".loadingpage").hide();
            $("#tukar-min").hide();
            $("#label-berat-plus").hide();
            $("#label-berat-min").hide();
            $("#label-harga-plus").hide();
            $("#label-harga-min").hide();
            $(".dataTables_filter").hide();
            $("#hasil_cek").hide();
            $("#nota_tambah_ada").hide();
            setTimeout(function () {
                $('.card-header').hide();
            }, 2500);
            App.initPerhitunganTukarPlus();
            App.onClickFilter();
            App.resetFilter();
            App.initEditMin();
        },
        initEditMin: function () {
            $('input[name=berat_tp_min]').change(function () {
                //tukar min

                    var berat_tp_min = $('#berat_tp_min').val();
                    berat_tp_min = parseFloat(berat_tp_min);
                    var harga_jenis = $('#harga_jenis').val();
                    harga_jenis_min = parseInt(harga_jenis);
                    var potongan = $('#potongan').val();
                    harga_jenis_min = harga_jenis_min - potongan;
                    potongan = parseInt(potongan);
                    
                    //harga di nota
                    harga_di_nota = harga_jenis_min * berat_tp_min;
                    $("#harga_tp").val(harga_di_nota);
                    var harga_jenis = $('#harga_jenis').val();
                    harga_jenis = parseInt(harga_jenis);
                    //harga jenis kurangin potongan
                    
                    // alert(harga_jenis)
                    
                    // alert(harga_jenis)
                    //masukan selisih untuk perkalian ke BK dan hitung
                    var berat = $('#berat').val();
                    berat = parseFloat(berat);
                    selisih_berat = berat - berat_tp_min;
                    selisih_harga = selisih_berat * harga_jenis;
                    $("#selisih_berat").val(selisih_berat);
                    $("#selisih_harga").val(selisih_harga);
                    $("#harga_jenis_barang_kembali").val(harga_jenis);
                    sub_hasil = selisih_berat * harga_jenis;
                    var potongan_rusak = $('#potongan_rusak').val();
                    potongan_rusak = parseInt(potongan_rusak);
                    if (potongan_rusak != 0) {
                        sub_hasil = sub_hasil - potongan_rusak;
                    }
                    $("#harga_konsumen").val(sub_hasil);
            });
        },
        initPerhitunganTukarPlus: function () {
            $('input[name=berat_tp]').change(function () {
                var jenis_tukar = $('#jenis_tukar').val();
                if (jenis_tukar == "1") {
                    var berat_tp = $('#berat_tp').val();
                    var harga_penjualan = $('#harga_penjualan').val();
                    harga_penjualan = parseInt(harga_penjualan);
                    berat_tp = parseFloat(berat_tp);
                    var harga_jenis = $('#harga_jenis').val();
                    harga_jenis = parseInt(harga_jenis);
                    sub_hasil = berat_tp * harga_jenis;
                    //harga ke konsumen
                    harga_di_nota = sub_hasil + harga_penjualan;
                    $("#harga_tp").val(harga_di_nota);
                    sub_hasil = sub_hasil + 5000;
                    var potongan_rusak = $('#potongan_rusak').val();
                    potongan_rusak = parseInt(potongan_rusak);
                    if (potongan_rusak != 0) {
                        sub_hasil = sub_hasil + potongan_rusak;
                    }
                    $("#harga_konsumen").val(sub_hasil);
                } else {
                    //tukar min

                    var berat_tp = $('#berat_tp').val();
                    berat_tp = parseFloat(berat_tp);
                    var harga_jenis = $('#harga_jenis').val();
                    harga_jenis = parseInt(harga_jenis);
                    //harga di nota
                    harga_di_nota = harga_jenis * berat_tp;
                    $("#harga_tp").val(harga_di_nota);
                    var potongan = $('#potongan').val();
                    potongan = parseInt(potongan);
                    //harga jenis kurangin potongan
                    harga_jenis = harga_jenis - potongan;
                    var edit_enum = $('#edit_enum').val();
                    edit_enum = parseInt(edit_enum);
                    if (edit_enum == 1) {
                        var harga_jenis = $('#harga_jenis').val();
                        harga_jenis = parseInt(harga_jenis);
                        harga_jenis = harga_jenis;
                    }
                    // alert(harga_jenis)
                    //masukan selisih untuk perkalian ke BK dan hitung
                    var berat = $('#berat').val();
                    berat = parseFloat(berat);
                    selisih_berat = berat - berat_tp;
                    selisih_harga = selisih_berat * harga_jenis;
                    $("#selisih_berat").val(selisih_berat);
                    $("#selisih_harga").val(selisih_harga);
                    $("#harga_jenis_barang_kembali").val(harga_jenis);
                    sub_hasil = selisih_berat * harga_jenis;
                    var potongan_rusak = $('#potongan_rusak').val();
                    potongan_rusak = parseInt(potongan_rusak);
                    if (potongan_rusak != 0) {
                        sub_hasil = sub_hasil - potongan_rusak;
                    }
                    $("#harga_konsumen").val(sub_hasil);


                }
            });
        },
        initCekNota: function () {
            $("#btn-cek").click(function () {
                var no_nota = $("#no_nota").val();
                $.ajax({
                        url: App.baseUrl + 'barang_kembali/hasil_nota',
                        type: 'GET',
                        data: {
                            no_nota: no_nota
                        },
                    })
                    .done(function (jqXHR) {
                        var data = JSON.parse(jqXHR);
                        if (data.status == true) {
                            $('#nota_ada').val('No Nota : ' + no_nota + ' Sudah Kembali Dan Tidak Bisa Melakukan Transaksi Barang Kembali');
                            $("#nota_tidak_ada").hide();
                            $("#nota_ada").show();
                            $("#hasil_cek").show();
                        } else {
                            $('#nota_tidak_ada').val('No Nota : ' + no_nota + ' Belum Kembali Dan Bisa Melakukan Transaksi Barang Kembali');
                            $("#nota_ada").hide();
                            $("#nota_tidak_ada").show();
                            $("#hasil_cek").show();
                        }
                        // App.HitungPersentaseRencana($('#rencana_jumlah_penduduk').val(), data.jumlah_penduduk);
                    })
                    .fail(function () {
                        console.log("error");
                    })
            });
        },
        initGetNota: function () {
            $("#btn_cek_tambah").click(function () {
                var no_nota_tambah = $("#no_nota_tambah").val();
                var kode_cabang = $("#kode_cabang").val();
                if (no_nota_tambah == "" || kode_cabang == "") {
                    App.alert('Silahkan isi No Nota dan  pilih cabang terlebih dahulu!!!');
                } else {
                    $.ajax({
                            url: App.baseUrl + 'penjualan/get_data_nota',
                            type: 'GET',
                            data: {
                                no_nota_tambah: no_nota_tambah,
                                kode_cabang: kode_cabang
                            },
                        })
                        .done(function (jqXHR) {
                            var data = JSON.parse(jqXHR);
                            if (data.status == true) {
                                $('#tanggal_penjualan').html(data.tanggal);
                                $('#nama_karyawan').html(data.nama_karyawan);
                                $('#no_nota_html').html(data.no_nota_tukar);
                                $('#no_nota_penjualan').val(data.no_nota);
                                $('#nama_jenis').html(data.nama_jenis);
                                $('#nama_barang').html(data.nama_barang);
                                $('#potong_data').html(data.potongan);
                                $('#berat_html').html(data.berat);
                                $('#berat').val(data.berat);
                                $('#harga').html(data.harga);
                                $('#harga_jenis').val(data.harga_jenis);
                                $('#penjualan_id').val(data.penjualan_id);
                                $('#jenis_transaksi_id').val(data.jenis_transaksi_id);
                                $('#harga_penjualan').val(data.harga);
                                $("#nota_tambah_ada").show();
                                $("#hasil_cek").hide();
                            } else {
                                $("#nota_tambah_ada").hide();
                                $('#nota_ada').val('No Nota : ' + no_nota_tambah + ' tersebut tidak ada pada data pada penjualan, atau Nota Batal, atau Nota Hilang 3R!!!');
                                $("#nota_tidak_ada").hide();
                                $("#nota_ada").show();
                                $("#hasil_cek").show();
                            }
                            // App.HitungPersentaseRencana($('#rencana_jumlah_penduduk').val(), data.jumlah_penduduk);
                        })
                        .fail(function () {
                            console.log("error");
                        })
                }
            });
        },
        initEvent: function () {
            $('#jenis_tukar').on('change', function (e) {
                var valueSelected = this.value;
                if (valueSelected == '1') {
                    $("#tukar-min").hide();
                    $("#label-berat-plus").show();
                    $("#label-berat-min").hide();
                    $("#label-harga-plus").show();
                    $("#label-harga-min").hide();
                    $('#harga_tp').val('');
                    $('#harga_konsumen').val('');
                } else {
                    $('#harga_tp').val('');
                    $('#harga_konsumen').val('');
                    $("#label-berat-plus").hide();
                    $("#label-berat-min").show();
                    $("#label-harga-plus").hide();
                    $("#label-harga-min").show();
                    $("#tukar-min").show();
                }
            });
            $('.init-date').datepicker({
                uiLibrary: 'bootstrap4',
                format: 'YYYY-mm-dd'
            });

            $('.select2').select2();


        },

        sidebarScroll: function () {
            setTimeout(function () {
                if ($(".scrollbar-container")[0]) {
                    $('.scrollbar-container').each(function () {
                        const ps = new PerfectScrollbar($(this)[0], {
                            wheelSpeed: 2,
                            wheelPropagation: false,
                            minScrollbarLength: 20
                        });
                    });

                    const ps = new PerfectScrollbar('.scrollbar-sidebar', {
                        wheelSpeed: 2,
                        wheelPropagation: true,
                        minScrollbarLength: 20
                    });
                }
            }, 1000);
        },

        initConfirm: function () {
            $('#table-tukar-plus').on('click', '.batal-plus', function () {
                var id = $(this).attr("detail_id");
                App.confirm("Apakah Anda Yakin Untuk Mengubah data ini?", function () {
                    window.location.href = App.baseUrl+'tukar_plus/nota_batal_plus/'+id;                    
                })
            });
            $('#table-tukar-min').on('click', '.batal-plus', function () {
                var id = $(this).attr("detail_id");
                App.confirm("Apakah Anda Yakin Untuk Mengubah data ini?", function () {
                    window.location.href = App.baseUrl+'tukar_plus/nota_batal_min/'+id;                    
                })
            });
            $('#table-detail').on('click', '.ubah-data', function () {
                var id = $(this).attr("detail_id");
                App.confirm("Apakah Anda Yakin Untuk Mengubah data ini?", function () {
                    window.location.href = App.baseUrl+'tukar_plus/nota_batal/'+id;                    
                })
            });
            $('#table-admin').on('click', '.delete', function () {
                var url = $(this).attr("url");
                App.confirm("Apakah Anda Yakin Untuk Mengubah Ini?", function () {
                    $.ajax({
                        method: "GET",
                        url: url
                    }).done(function (msg) {
                        $('.loadingpage').hide();
                        App.table_admin.ajax.reload(null, true);
                    });
                })
            });
        },

        dataList: function () {
            App.table = $('#table').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first": "Pertama",
                        "last": "Terakhir",
                        "next": "Selanjutnya",
                        "previous": "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": App.baseUrl + "tukar_plus/dataList",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [{
                        "data": "id"
                    },
                    {
                        "data": "tanggal",
                        "orderable": false
                    },
                    // {
                    //     "data": "jumlah_transaksi",
                    //     "orderable": false
                    // },
                    // {
                    //     "data": "total_berat",
                    //     "orderable": false
                    // },
                    // {
                    //     "data": "total_harga_keseluruhan",
                    //     "orderable": false
                    // },
                    {
                        "data": "action",
                        "orderable": false
                    }
                ],
                "columnDefs": [{
                    "targets": [0, 1, 2],
                    // "targets": [0, 1, 2, 3, 4, 5],
                    "className": "text-center"
                }, ]
            });

            App.table_admin = $('#table-admin').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first": "Pertama",
                        "last": "Terakhir",
                        "next": "Selanjutnya",
                        "previous": "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": App.baseUrl + "tukar_plus/dataListAdmin",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [{
                        "data": "id"
                    },
                    {
                        "data": "cabang",
                        "orderable": false
                    },
                    {
                        "data": "tanggal",
                        "orderable": false
                    },
                    // {
                    //     "data": "jumlah_transaksi",
                    //     "orderable": false
                    // },
                    // {
                    //     "data": "total_berat",
                    //     "orderable": false
                    // },
                    // {
                    //     "data": "total_harga_keseluruhan",
                    //     "orderable": false
                    // },
                    {
                        "data": "status_audit",
                        "orderable": false
                    },
                    {
                        "data": "action",
                        "orderable": false
                    }
                ],
                "columnDefs": [{
                    // "targets": [0, 1, 2, 3, 4, 5,6,7],
                    "targets": [0, 1, 2, 3, 4],
                    "className": "text-center"
                }, ]
            });

            App.table_pembukuan = $('#table-pembukuan').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first": "Pertama",
                        "last": "Terakhir",
                        "next": "Selanjutnya",
                        "previous": "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": App.baseUrl + "pembukuan_tukar_plus/dataList",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [{
                        "data": "id"
                    },
                    {
                        "data": "tanggal",
                        "orderable": false
                    },
                    {
                        "data": "jumlah_transaksi",
                        "orderable": false
                    },
                    // {
                    //     "data": "total_berat",
                    //     "orderable": false
                    // },
                    // {
                    //     "data": "total_harga_keseluruhan",
                    //     "orderable": false
                    // },
                    {
                        "data": "action",
                        "orderable": false
                    }
                ],
                "columnDefs": [{
                    "targets": [0, 1, 2, 3],
                    "className": "text-center"
                }, ]
            });

            //append button to datatables
            // add_btn = '<a href="'+App.baseUrl+'group/create" class="btn btn-sm btn-primary ml-2 mt-1"><i class="fa fa-plus"></i> Departemen</a>';
            // $('#table_filter').append(add_btn);
        },

        validationJs: function () {
            $('#btn-tambah').on('click', function () {

                $("#form").validate({
                    rules: {
                        tanggal: {
                            required: true
                        },
                        karyawan_id: {
                            required: true
                        },
                        no_nota: {
                            required: true
                        },
                        jenis_transaksi_id: {
                            required: true
                        },
                        barang_id: {
                            required: true
                        },
                        cabang_id: {
                            required: true
                        },
                        jenis_tukar: {
                            required: true
                        },
                        berat_tp: {
                            required: true
                        },
                        potong: {
                            required: true
                        },
                        potongan_rusak: {
                            required: true
                        },
                    },
                    messages: {
                        berat_tp: {
                            required: "*) harus diisi"
                        },
                        potong: {
                            required: "*) harus diisi"
                        },
                        jenis_tukar: {
                            required: "*) harus dipilih"
                        },
                        cabang_id: {
                            required: "*) harus dipilih"
                        },
                        barang_id: {
                            required: "*) harus dipilih"
                        },
                        jenis_transaksi_id: {
                            required: "*) harus dipilih"
                        },
                        no_nota: {
                            required: "*) harus diisi"
                        },
                        karyawan_id: {
                            required: "*) harus dipilih"
                        },
                        tanggal: {
                            required: "*) harus diisi"
                        },
                        potongan_rusak: {
                            required: "*) harus diisi"
                        },
                    },
                    debug: true,
                    errorElement: "em",
                    errorPlacement: function (error, element) {
                        // Add the `invalid-feedback` class to the error element
                        error.addClass("invalid-feedback");
                        if (element.prop("type") === "checkbox") {
                            error.insertBefore(element.next("label"));
                        } else if (element.prop("type") === "radio") {
                            error.appendTo(element.parent().parent().parent());
                        } else {
                            error.insertBefore(element);
                        }
                    },
                    highlight: function (element, errorClass, validClass) {
                        $(element).addClass("is-invalid").removeClass("is-valid");
                    },
                    unhighlight: function (element, errorClass, validClass) {
                        $(element).addClass("is-valid").removeClass("is-invalid");
                    },
                    submitHandler: function (form) {
                        $('#value-btn-tambah').val(1);
                        form.submit();
                    }
                });
            });
        },
        getNota: function () {
            $('#huruf_nota_form').change(function () {
                var huruf_nota = $("#huruf_nota_form").val();
                $.ajax({
                    type: 'GET',
                    url: App.baseUrl + 'tukar_plus/get_nota',
                    data: {
                        'huruf_nota': huruf_nota,
                    },
                    success: function (jqXHR) {
                        var data = JSON.parse(jqXHR);
                        if (data.status == true) {
                            $('#no_nota').val(data.no_nota);
                            $('#no_nota_view').val(data.no_nota_view);
                        } else {
                            $('#no_nota').val('');
                            $('#no_nota_view').val('');
                            App.alert('Nota '+huruf_nota+' Tidak Ada, Silahkan Hubungi Admin Kantor Adilla 925')
                        }
                    }
                });

            });
        },

        onClickFilter : function (){
            $('#btn-filter').on('click', function () {
                var tanggal   = $("#tanggal").val();
                var cabang_id   = $("#cabang_id").val();
                var status_audit   = $("#status_audit").val();
                //pembukuan
                App.table_pembukuan.column(0).search(tanggal,true,true);
                App.table_pembukuan.draw();
                //transaksi
                App.table.column(0).search(tanggal,true,true);
                App.table.draw();
                //tukar plus admin
                App.table_admin.column(0).search(tanggal,true,true);
                App.table_admin.column(1).search(cabang_id,true,true);
                App.table_admin.column(2).search(status_audit,true,true);
                App.table_admin.draw();

            });
        },

        resetFilter : function (){
            $('#btn-filter-clear').on( 'click', function () {
                $("#tanggal").val("").trigger('change');
                $("#cabang_id").val("").trigger('change');
                $("#status_audit").val("").trigger('change');
                $('#btn-filter').trigger('click');
            });
        },
    }
});