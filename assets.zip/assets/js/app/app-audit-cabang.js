define([
    "jQuery",
    "bootstrap",
    "metisMenu",
    "architectui",
    "PerfectScrollbar",
    "datatables",
    "datatablesBootstrap4",
    "datatablesResponsive",
    "jValidation",
    "datePicker",
    "select2",
], function (
    $,
    bootstrap,
    metisMenu,
    architectui,
    PerfectScrollbar,
    datatables,
    datatablesBootstrap4,
    datatablesResponsive,
    jValidation,
    datePicker,
    select2,
) {
    return {
        table: null,
        init: function () {
            App.initFunc();
            App.initEvent();
            App.sidebarScroll();
            App.initConfirm();
            App.dataList();
            App.validationJs();
            $(".loadingpage").hide();
            setTimeout(function () {
                $('.card-header').hide();
            }, 2500);
            $(".dataTables_filter").hide();
            App.onClickFilter();
            App.resetFilter();
        },

        onClickFilter : function (){
            $('#btn-filter').on('click', function () {
                var tanggal   = $("#tanggal").val();
                var cabang_id   = $("#cabang_id").val();
                App.table.column(0).search(tanggal,true,true);
                App.table.column(1).search(cabang_id,true,true);
                App.table.draw();

            });
        },

        resetFilter : function (){
            $('#btn-filter-clear').on( 'click', function () {
                $("#tanggal").val("").trigger('change');
                $("#cabang_id").val("").trigger('change');
                $('#btn-filter').trigger('click');
            });
        },
        initEvent: function() {
             $('.init-date').datepicker({
                uiLibrary: 'bootstrap4',
                format: 'YYYY-mm-dd'
            });
             $('.select2').select2();
        },

        sidebarScroll: function () {
            setTimeout(function () {
                if ($(".scrollbar-container")[0]) {
                    $('.scrollbar-container').each(function () {
                        const ps = new PerfectScrollbar($(this)[0], {
                            wheelSpeed: 2,
                            wheelPropagation: false,
                            minScrollbarLength: 20
                        });
                    });

                    const ps = new PerfectScrollbar('.scrollbar-sidebar', {
                        wheelSpeed: 2,
                        wheelPropagation: true,
                        minScrollbarLength: 20
                    });
                }
            }, 1000);
        },

        initConfirm: function () {
            $('#table').on('click', '.delete', function () {
                var url = $(this).attr("url");
                App.confirm("Apakah Anda Yakin Untuk Mengubah Ini?", function () {
                    $.ajax({
                        method: "GET",
                        url: url
                    }).done(function (msg) {
                        $('.loadingpage').hide();
                        App.table.ajax.reload(null, true);
                    });
                })
            });
        },

        dataList: function () {
            App.table = $('#table').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first": "Pertama",
                        "last": "Terakhir",
                        "next": "Selanjutnya",
                        "previous": "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": App.baseUrl + "audit_cabang/dataList",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [{
                        "data": "id"
                    },
                    {
                        "data": "tanggal",
                        "orderable": false
                    },
                    {
                        "data": "tanggal_awal",
                        "orderable": false
                    },
                    {
                        "data": "tanggal_akhir",
                        "orderable": false
                    },
                    {
                        "data": "cabang",
                        "orderable": false
                    },
                    {
                        "data": "action",
                        "orderable": false
                    },
                ],
                "columnDefs": [{
                    "targets": [0, 1, 2, 3, 4, 5],
                    "className": "text-center"
                }, ]
            });

            //append button to datatables
            // add_btn = '<a href="'+App.baseUrl+'group/create" class="btn btn-sm btn-primary ml-2 mt-1"><i class="fa fa-plus"></i> Departemen</a>';
            // $('#table_filter').append(add_btn);
        },

        validationJs: function () {
            $("#form").validate({
                rules: {
                    uang_bayar_barang: {
                        required: true
                    },
                    uang_mobil: {
                        required: true
                    },
                    uang_setor: {
                        required: true
                    },
                    uang_kotak_cincin: {
                        required: true
                    },
                    uang_potongan: {
                        required: true
                    },
                    total: {
                        required: true
                    },
                    dll: {
                        required: true
                    },
                    uang_kantor: {
                        required: true
                    },
                    k_toko: {
                        required: true
                    },
                    krw_uda: {
                        required: true
                    },
                    cabang_id: {
                        required: true
                    },
                    tanggal_akhir: {
                        required: true
                    },
                    tanggal_awal: {
                        required: true
                    },

                },
                messages: {
                    tanggal_awal: {
                        required: "*) harus diisi"
                    },
                    tanggal_akhir: {
                        required: "*) harus diisi"
                    },
                    cabang_id: {
                        required: "*) harus diisi"
                    },
                    krw_uda: {
                        required: "*) harus diisi"
                    },
                    k_toko: {
                        required: "*) harus diisi"
                    },
                    uang_kantor: {
                        required: "*) harus diisi"
                    },
                    dll: {
                        required: "*) harus diisi"
                    },
                    total: {
                        required: "*) harus diisi"
                    },
                    uang_potongan: {
                        required: "*) harus diisi"
                    },
                    uang_kotak_cincin: {
                        required: "*) harus diisi"
                    },
                    uang_setor: {
                        required: "*) harus diisi"
                    },
                    uang_bayar_barang: {
                        required: "*) harus diisi"
                    },
                    uang_mobil: {
                        required: "*) harus diisi"
                    },
                },
                debug: true,
                errorElement: "em",
                errorPlacement: function (error, element) {
                    // Add the `invalid-feedback` class to the error element
                    error.addClass("invalid-feedback");
                    if (element.prop("type") === "checkbox") {
                        error.insertBefore(element.next("label"));
                    } else if (element.prop("type") === "radio") {
                        error.appendTo(element.parent().parent().parent());
                    } else {
                        error.insertBefore(element);
                    }
                },
                highlight: function (element, errorClass, validClass) {
                    $(element).addClass("is-invalid").removeClass("is-valid");
                },
                unhighlight: function (element, errorClass, validClass) {
                    $(element).addClass("is-valid").removeClass("is-invalid");
                },
                submitHandler: function (form) {
                    form.submit();
                }
            });
        },
    }
});