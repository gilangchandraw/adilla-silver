define([
    "jQuery",
    "bootstrap",
    "metisMenu",
    "architectui",
    "PerfectScrollbar",
    "datatables",
    "datatablesBootstrap4",
    "datatablesResponsive",
    "jValidation",
    "datePicker",
    "select2",
    ], function (
    $,
    bootstrap,
    metisMenu,
    architectui,
    PerfectScrollbar,
    datatables,
    datatablesBootstrap4,
    datatablesResponsive,
    jValidation,
    datePicker,
    select2,
    ) {
    return {
        table:null,
        init: function () { 
            App.initFunc();
            App.sidebarScroll();
            App.initEvent();
            App.initConfirm();
            App.dataList();
            App.validationJs();
            App.getNota();
            $(".dataTables_filter").hide();
            $(".loadingpage").hide();
            setTimeout(function(){
                $('.card-header').hide();
            }, 2500);
            App.onClickFilter();
            App.resetFilter();
            
        },

        initEvent: function () {
            $('#print_nota').on('click', function () {
                location.reload();

            });
            $('.init-date').datepicker({
                uiLibrary: 'bootstrap4',
                format: 'YYYY-mm-dd'
            });

            $('.select2').select2();

            $('input[name=berat]').change(function() { 
                // alert(App.harga_satuan);
                var berat = $('#berat').val();
                var jenis_transaksi_id = $('#jenis_transaksi_id').val();
                //get harga
                $.ajax({
                    url: App.baseUrl+'enum_transaksi_barang/get_harga',
                    type: 'GET',
                    data: {jenis_transaksi_id: jenis_transaksi_id},
                })
                .done(function( jqXHR ) {
                    var data = JSON.parse(jqXHR);
                    if(data.status == true){
                        var harga = berat * parseInt(data.harga);
                        var nota_sebelum = $('input[name="nota_sebelum"]:checked').val();
                        
                        if (nota_sebelum == "1") {
                            var harga = parseInt(harga) + 5000;   
                        }
                        $('#harga').val(harga);
                        $('#total_harga_keseluruhan').val(harga);
                        // $('#stok').val(data.stok);
                        // harga_satuan = data.harga.replace(",", "");
                        // App.harga_satuan = harga_satuan;
                        // App.stok = data.stok;
                        
                        
                        
                    }else{
                        $('#harga').val('');
                    }
                    // App.HitungPersentaseRencana($('#rencana_jumlah_penduduk').val(), data.jumlah_penduduk);
                })
                .fail(function() {
                    console.log("error");
                })

                var harga_satuan = App.harga_satuan.replace(",", "");
                var banyak = parseInt(berat);
                if (banyak > App.stok) {
                    alert('Stok Tidak Mencukupi');
                    $('#total_harga').val('');
                    $('#harga').val('');
                } else {
                    var total = berat * harga_satuan;
                    $('#total_harga').val('Rp. '+total);    
                    var total_harga_keseluruhan = $('#total_harga_keseluruhan').val();
                    $('#harga').val(total);
                    var total_akhir = parseInt(total_harga_keseluruhan) + total;
                    $('#total_harga_keseluruhan').val(total_akhir);
                }
            });

            $('input[name=berat_edit]').change(function() { 
                // alert(App.harga_satuan);
                var berat = $('#berat_edit').val();
                var jenis_transaksi_id = $('#jenis_transaksi_id_edit').val();
                //get harga
                $.ajax({
                    url: App.baseUrl+'enum_transaksi_barang/get_harga',
                    type: 'GET',
                    data: {jenis_transaksi_id: jenis_transaksi_id},
                })
                .done(function( jqXHR ) {
                    var data = JSON.parse(jqXHR);
                    if(data.status == true){
                        var harga = berat * parseInt(data.harga);
                        var nota_sebelum = $('input[name="nota_sebelum"]:checked').val();
                        
                        if (nota_sebelum == "1") {
                            var harga = parseInt(harga) + 5000;   
                        }
                        $('#harga').val(harga);
                        $('#total_harga_keseluruhan').val(harga);
                        // $('#stok').val(data.stok);
                        // harga_satuan = data.harga.replace(",", "");
                        // App.harga_satuan = harga_satuan;
                        // App.stok = data.stok;
                        
                        
                        
                    }else{
                        $('#harga').val('');
                    }
                    // App.HitungPersentaseRencana($('#rencana_jumlah_penduduk').val(), data.jumlah_penduduk);
                })
                .fail(function() {
                    console.log("error");
                })

                // var harga_satuan = App.harga_satuan.replace(",", "");
                // var banyak = parseInt(berat);
                // if (banyak > App.stok) {
                //     alert('Stok Tidak Mencukupi');
                //     $('#total_harga').val('');
                //     $('#harga').val('');
                // } else {
                //     var total = berat * harga_satuan;
                //     $('#total_harga').val('Rp. '+total);    
                //     var total_harga_keseluruhan = $('#total_harga_keseluruhan').val();
                //     $('#harga').val(total);
                //     var total_akhir = parseInt(total_harga_keseluruhan) + total;
                //     $('#total_harga_keseluruhan').val(total_akhir);
                // }
            });

            $('#jenis_transaksi_id_edit').change(function () {
                var jenis_transaksi_id = $("#jenis_transaksi_id_edit").val();
                var berat = $('#berat_edit').val();

                //get harga
                $.ajax({
                    url: App.baseUrl+'enum_transaksi_barang/get_harga',
                    type: 'GET',
                    data: {jenis_transaksi_id: jenis_transaksi_id},
                })
                .done(function( jqXHR ) {
                    var data = JSON.parse(jqXHR);
                    if(data.status == true){
                        var harga = berat * parseInt(data.harga);
                        var nota_sebelum = $('input[name="nota_sebelum"]:checked').val();
                        
                        if (nota_sebelum == "1") {
                            var harga = parseInt(harga) + 5000;   
                        }
                        $('#harga').val(harga);
                        $('#total_harga_keseluruhan').val(harga);
                        // $('#stok').val(data.stok);
                        // harga_satuan = data.harga.replace(",", "");
                        // App.harga_satuan = harga_satuan;
                        // App.stok = data.stok;
                        
                        
                        
                    }else{
                        $('#harga').val('');
                    }
                    // App.HitungPersentaseRencana($('#rencana_jumlah_penduduk').val(), data.jumlah_penduduk);
                })
                .fail(function() {
                    console.log("error");
                })

                // var harga_satuan = App.harga_satuan.replace(",", "");
                // var banyak = parseInt(berat);
                // if (banyak > App.stok) {
                //     alert('Stok Tidak Mencukupi');
                //     $('#total_harga').val('');
                //     $('#harga').val('');
                // } else {
                //     var total = berat * harga_satuan;
                //     $('#total_harga').val('Rp. '+total);    
                //     var total_harga_keseluruhan = $('#total_harga_keseluruhan').val();
                //     $('#harga').val(total);
                //     var total_akhir = parseInt(total_harga_keseluruhan) + total;
                //     $('#total_harga_keseluruhan').val(total_akhir);
                // }
            });

            // $('input[type=radio][name=status_nota]').change(function() {
            //     if (this.value == '1') {
            //         $(".nota-batal").show();
            //     }
            //     else if (this.value == '2') {
            //         $(".nota-batal").hide();
            //     }
            // });
        },

        sidebarScroll: function () {
            setTimeout(function () {
                if ($(".scrollbar-container")[0]) {
                    $('.scrollbar-container').each(function () {
                        const ps = new PerfectScrollbar($(this)[0], {
                            wheelSpeed: 2,
                            wheelPropagation: false,
                            minScrollbarLength: 20
                        });
                    });

                    const ps = new PerfectScrollbar('.scrollbar-sidebar', {
                        wheelSpeed: 2,
                        wheelPropagation: true,
                        minScrollbarLength: 20
                    });
                }
            }, 1000);
        }, 

        initConfirm :function(){
            $('#table-detail').on('click', '.ubah-data', function () {
                var id = $(this).attr("detail_id");
                App.confirm("Apakah Anda Yakin Untuk Mengubah data ini?", function () {
                    window.location.href = App.baseUrl+'penjualan/nota_batal/'+id;                    
                })
            });
            $('#table-detail-cadangan').on('click', '.ubah-data', function () {
                var id = $(this).attr("detail_id");
                App.confirm("Apakah Anda Yakin Untuk Mengubah data ini?", function () {
                    window.location.href = App.baseUrl+'penjualan/nota_batal/'+id;                    
                })
            });
            $('#table-admin').on( 'click', '.delete', function () {
                var url = $(this).attr("url");
                App.confirm("Apakah Anda Yakin Untuk Mengubah Ini?",function(){
                   $.ajax({
                      method: "GET",
                      url: url
                    }).done(function( msg ) {
                        $('.loadingpage').hide();
                        App.table_admin.ajax.reload(null,true);
                    });
                })
            });
        },
        
        dataList : function(){
            App.table = $('#table').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first":      "Pertama",
                        "last":       "Terakhir",
                        "next":       "Selanjutnya",
                        "previous":   "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax":{
                    "url": App.baseUrl+"penjualan/dataList",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [
                    { "data": "id" },
                    { "data": "tanggal","orderable": false },
                    { "data": "jumlah_transaksi","orderable": false },
                    { "data": "total_berat","orderable": false },
                    { "data": "total_harga_keseluruhan","orderable": false },
                    { "data": "action" ,"orderable": false}
                ],
                "columnDefs": [
                    {"targets": [0,1,2,3,4,5], "className": "text-center"},
                ] 
            });
            App.table_admin = $('#table-admin').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first":      "Pertama",
                        "last":       "Terakhir",
                        "next":       "Selanjutnya",
                        "previous":   "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax":{
                    "url": App.baseUrl+"penjualan/dataListAdmin",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [
                    { "data": "id" },
                    { "data": "cabang","orderable": false },
                    { "data": "tanggal","orderable": false },
                    { "data": "jumlah_transaksi","orderable": false },
                    { "data": "total_berat","orderable": false },
                    { "data": "total_harga_keseluruhan","orderable": false },
                    { "data": "status_audit","orderable": false },
                    { "data": "action" ,"orderable": false}
                ],
                "columnDefs": [
                    {"targets": [0,1,2,3,4,5,6,7], "className": "text-center"},
                ] 
            });

            App.table_pembukuan = $('#table-pembukuan').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first":      "Pertama",
                        "last":       "Terakhir",
                        "next":       "Selanjutnya",
                        "previous":   "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax":{
                    "url": App.baseUrl+"pembukuan_penjualan/dataList",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [
                    { "data": "id" },
                    { "data": "cabang","orderable": false },
                    { "data": "tanggal","orderable": false },
                    { "data": "jumlah_transaksi","orderable": false },
                    { "data": "total_berat","orderable": false },
                    { "data": "total_harga_keseluruhan","orderable": false },
                    { "data": "action" ,"orderable": false}
                ],
                "columnDefs": [
                    {"targets": [0,1,2,3,4,5,6], "className": "text-center"},
                ] 
            });

            //append button to datatables
            // add_btn = '<a href="'+App.baseUrl+'group/create" class="btn btn-sm btn-primary ml-2 mt-1"><i class="fa fa-plus"></i> Departemen</a>';
            // $('#table_filter').append(add_btn);
        },

        validationJs : function(){    
            $('#btn-simpan').on('click', function(){
                            
                $("#form").validate({
                    rules: {
                        tanggal: {
                            required: true
                        },
                        karyawan_id: {
                            required: true
                        },
                        no_nota: {
                            required: true
                        },
                        jenis_transaksi_id: {
                            required: true
                        },
                        barang_id: {
                            required: true
                        },
                        berat: {
                            required: true
                        },
                        potong: {
                            required: true
                        },
                        potongan: {
                            required: true
                        },
                        huruf_nota: {
                            required: true
                        },
                    },
                    messages: {
                        berat: {
                            required: "*) harus diisi"
                        },
                        potongan: {
                            required: "*) harus diisi"
                        },
                        huruf_nota: {
                            required: "*) harus diisi"
                        },
                        potong: {
                            required: "*) harus diisi"
                        },
                        barang_id: {
                            required: "*) harus dipilih"
                        },
                        jenis_transaksi_id: {
                            required: "*) harus dipilih"
                        },
                        no_nota: {
                            required: "*) harus diisi"
                        },
                        karyawan_id: {
                            required: "*) harus dipilih"
                        },
                        tanggal: {
                            required: "*) harus diisi"
                        },
                    },
                    debug:true,
                    errorElement: "em",
                    errorPlacement: function ( error, element ) {
                        // Add the `invalid-feedback` class to the error element
                        error.addClass( "invalid-feedback" );
                        if ( element.prop( "type" ) === "checkbox" ) {
                            error.insertBefore( element.next( "label" ) );
                        } else if ( element.prop( "type" ) === "radio" ) {
                            error.appendTo( element.parent().parent().parent());
                        } else {
                            error.insertBefore( element );
                        }
                    },
                    highlight: function ( element, errorClass, validClass ) {
                        $( element ).addClass( "is-invalid" ).removeClass( "is-valid" );
                    },
                    unhighlight: function (element, errorClass, validClass) {
                        $( element ).addClass( "is-valid" ).removeClass( "is-invalid" );
                    },
                    submitHandler : function(form) {
                        $('#value-btn-simpan').val(1);
                        form.submit();
                    }
                });
            });

            $('#btn-tambah').on('click', function(){
                            
                $("#form").validate({
                    rules: {
                        tanggal: {
                            required: true
                        },
                        karyawan_id: {
                            required: true
                        },
                        no_nota: {
                            required: true
                        },
                        jenis_transaksi_id: {
                            required: true
                        },
                        barang_id: {
                            required: true
                        },
                        cabang_id: {
                            required: true
                        },
                        berat: {
                            required: true
                        },
                        potong: {
                            required: true
                        },
                    },
                    messages: {
                        berat: {
                            required: "*) harus diisi"
                        },
                        potong: {
                            required: "*) harus diisi"
                        },
                        cabang_id: {
                            required: "*) harus dipilih"
                        },
                        barang_id: {
                            required: "*) harus dipilih"
                        },
                        jenis_transaksi_id: {
                            required: "*) harus dipilih"
                        },
                        no_nota: {
                            required: "*) harus diisi"
                        },
                        karyawan_id: {
                            required: "*) harus dipilih"
                        },
                        tanggal: {
                            required: "*) harus diisi"
                        },
                    },
                    debug:true,
                    errorElement: "em",
                    errorPlacement: function ( error, element ) {
                        // Add the `invalid-feedback` class to the error element
                        error.addClass( "invalid-feedback" );
                        if ( element.prop( "type" ) === "checkbox" ) {
                            error.insertBefore( element.next( "label" ) );
                        } else if ( element.prop( "type" ) === "radio" ) {
                            error.appendTo( element.parent().parent().parent());
                        } else {
                            error.insertBefore( element );
                        }
                    },
                    highlight: function ( element, errorClass, validClass ) {
                        $( element ).addClass( "is-invalid" ).removeClass( "is-valid" );
                    },
                    unhighlight: function (element, errorClass, validClass) {
                        $( element ).addClass( "is-valid" ).removeClass( "is-invalid" );
                    },
                    submitHandler : function(form) {
                        $('#value-btn-tambah').val(1);
                        form.submit();
                    }
                });
            });
        },
        getNota : function(){
            $('#huruf_nota').change(function () {
                var huruf_nota = $("#huruf_nota").val();
                var cabang_id = $("#cabang_id").val();
                var cabang_id_admin = $("#cabang_id_admin").val();
                $.ajax({
                    type: 'POST',
                    url: App.baseUrl+'nota/get_nota',
                    data: {
                        'huruf_nota': huruf_nota,
                        'cabang_id': cabang_id,
                        'cabang_id_admin': cabang_id_admin,
                    },
                    success: function (jqXHR) {
                        var data = JSON.parse(jqXHR);
                        if(data.status == true){
                            $('#no_nota').val(data.no_nota);
                            $('#no_nota_view').val(data.no_nota_view);
                        }else{
                            $('#no_nota').val('');
                            $('#no_nota_view').val('');
                        }
                    }
                });

            });
        },

        onClickFilter : function (){
            $('#btn-filter').on('click', function () {
                var tanggal   = $("#tanggal").val();
                var cabang_id   = $("#cabang_id").val();
                var status_audit   = $("#status_audit").val();
                //pembukuan
                App.table_pembukuan.column(0).search(tanggal,true,true);
                App.table_pembukuan.column(1).search(cabang_id,true,true);
                // App.table_pembukuan.column(1).search(cabang_id,true,true);
                App.table_pembukuan.draw();
                //penjualan cabang
                App.table.column(0).search(tanggal,true,true);
                App.table.draw();
                //penjualan admin
                App.table_admin.column(0).search(tanggal,true,true);
                App.table_admin.column(1).search(cabang_id,true,true);
                App.table_admin.column(2).search(status_audit,true,true);
                App.table_admin.draw();

            });
        },

        resetFilter : function (){
            $('#btn-filter-clear').on( 'click', function () {
                $("#tanggal").val("").trigger('change');
                $("#cabang_id").val("").trigger('change');
                $("#status_audit").val("").trigger('change');
                $('#btn-filter').trigger('click');
            });
        },
    }
});
