define([
    "jQuery",
    "bootstrap",
    "metisMenu",
    "architectui",
    "PerfectScrollbar",
    "datatables",
    "datatablesBootstrap4",
    "datatablesResponsive",
    "jValidation",
    "datePicker",
    "select2",
], function (
    $,
    bootstrap,
    metisMenu,
    architectui,
    PerfectScrollbar,
    datatables,
    datatablesBootstrap4,
    datatablesResponsive,
    jValidation,
    datePicker,
    select2,
) {
    return {
        table: null,
        init: function () {
            App.initFunc();
            App.sidebarScroll();
            App.initEvent();
            App.initConfirm();
            App.dataList();
            App.validationJs();
            $(".loadingpage").hide();
            $("#barang_view").hide();
            $("#barang_sepuhan_view").hide();
            $("#barang_kotak_cincin_view").hide();
            setTimeout(function () {
                $('.card-header').hide();
            }, 2500);
            $(".dataTables_filter").hide();
        },

        sidebarScroll: function () {
            setTimeout(function () {
                if ($(".scrollbar-container")[0]) {
                    $('.scrollbar-container').each(function () {
                        const ps = new PerfectScrollbar($(this)[0], {
                            wheelSpeed: 2,
                            wheelPropagation: false,
                            minScrollbarLength: 20
                        });
                    });

                    const ps = new PerfectScrollbar('.scrollbar-sidebar', {
                        wheelSpeed: 2,
                        wheelPropagation: true,
                        minScrollbarLength: 20
                    });
                }
            }, 1000);
        },
        initEvent: function () {
            $('.init-date').datepicker({
                uiLibrary: 'bootstrap4',
                format: 'YYYY-mm-dd'
            });
            $('.select2').select2();

            $('input[type=radio][name=status_sk]').change(function () {
                if (this.value == '1') {
                    $("#barang_view").show();
                    $("#barang_sepuhan_view").hide();
                    $("#barang_kotak_cincin_view").hide();
                } else if (this.value == '2') {
                    $("#barang_view").hide();
                    $("#barang_sepuhan_view").show();
                    $("#barang_kotak_cincin_view").hide();
                } else if (this.value == '3') {
                    $("#barang_view").hide();
                    $("#barang_sepuhan_view").hide();
                    $("#barang_kotak_cincin_view").show();
                }

            });
        },

        initConfirm: function () {
            $('#table').on('click', '.delete', function () {
                var url = $(this).attr("url");
                App.confirm("Apakah Anda Yakin Untuk Menghapus data Ini?", function () {
                    $.ajax({
                        method: "GET",
                        url: url
                    }).done(function (msg) {
                        $('.loadingpage').hide();
                        App.table.ajax.reload(null, true);
                    });
                })
            });
        },

        dataList: function () {
            App.table = $('#table').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first": "Pertama",
                        "last": "Terakhir",
                        "next": "Selanjutnya",
                        "previous": "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": App.baseUrl + "barang_masuk/dataList",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [{
                        "data": "id"
                    },
                    {
                        "data": "tanggal"
                    },
                    {
                        "data": "supplier_id"
                    },
                    {
                        "data": "nama_barang"
                    },
                    {
                        "data": "jumlah_barang"
                    },
                    {
                        "data": "action",
                        "orderable": false
                    }
                ],
                "columnDefs": [{
                    "targets": [0, 1, 2, 3, 4, 5],
                    "className": "text-center"
                }, ]
            });

            //append button to datatables
            // add_btn = '<a href="'+App.baseUrl+'group/create" class="btn btn-sm btn-primary ml-2 mt-1"><i class="fa fa-plus"></i> Departemen</a>';
            // $('#table_filter').append(add_btn);
        },

        validationJs: function () {
            $("#form").validate({
                rules: {
                    tanggal: {
                        required: true
                    },
                    nama_supplier: {
                        required: true
                    },
                    nama_barang: {
                        required: true
                    },
                    jumlah_barang: {
                        required: true
                    },

                },
                messages: {
                    tanggal: {
                        required: "*) harus diisi"
                    },
                    nama_supplier: {
                        required: "*) harus dipilih"
                    },
                    nama_barang: {
                        required: "*) harus dipilih"
                    },
                    jumlah_barang: {
                        required: "*) harus diisi"
                    },
                },
                debug: true,
                errorElement: "em",
                errorPlacement: function (error, element) {
                    // Add the `invalid-feedback` class to the error element
                    error.addClass("invalid-feedback");
                    if (element.prop("type") === "checkbox") {
                        error.insertBefore(element.next("label"));
                    } else if (element.prop("type") === "radio") {
                        error.appendTo(element.parent().parent().parent());
                    } else {
                        error.insertBefore(element);
                    }
                },
                highlight: function (element, errorClass, validClass) {
                    $(element).addClass("is-invalid").removeClass("is-valid");
                },
                unhighlight: function (element, errorClass, validClass) {
                    $(element).addClass("is-valid").removeClass("is-invalid");
                },
                submitHandler: function (form) {
                    form.submit();
                }
            });
        },
    }
});