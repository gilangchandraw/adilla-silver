define([
	"jQuery",
	"bootstrap",
	"metisMenu",
	"architectui",
	"PerfectScrollbar",
	"Highcharts",
	"HighchartsTheme",
	"HighchartsExporting",
	"HighchartsVariablePie",
	], function (
	$,
	bootstrap,
	metisMenu,
	architectui,
	PerfectScrollbar,
	Highcharts,
	HighchartsTheme,
	HighchartsExporting,
	HighchartsVariablePie,
	) {
	return {
		tahun:0,
		bulan:0,
		tanggal:1,
		init: function () { 
			App.initFunc();
			// App.initChart();
			App.sidebarScroll();
			App.chartHargaTransaksi();
			App.chartberatTransaksi();
            App.chartTotalHargaTransaksi();
            App.chartTotalberatTransaksi();
			App.dashboard();
		},
		dashboard : function() {
			// HARGA TRANSAKSI
			$('#bulan-harga-transaksi').on('change', function(event) {
                var bulan_harga_transaksi = $('#bulan-harga-transaksi').val();
                var tahun_harga_transaksi = $('#tahun-harga-transaksi').val();

                App.chartHargaTransaksi(bulan_harga_transaksi,tahun_harga_transaksi);
            });
            $('#tahun-harga-transaksi').on('change', function(event) {
                var bulan_harga_transaksi = $('#bulan-harga-transaksi').val();
                var tahun_harga_transaksi = $('#tahun-harga-transaksi').val();

                App.chartHargaTransaksi(bulan_harga_transaksi,tahun_harga_transaksi);
            });
            // BERAT TRANSAKSI
            $('#bulan-berat-transaksi').on('change', function(event) {
                var bulan_berat_transaksi = $('#bulan-berat-transaksi').val();
                var tahun_berat_transaksi = $('#tahun-berat-transaksi').val();

                App.chartberatTransaksi(bulan_berat_transaksi,tahun_berat_transaksi);
            });
            $('#tahun-berat-transaksi').on('change', function(event) {
                var bulan_berat_transaksi = $('#bulan-berat-transaksi').val();
                var tahun_berat_transaksi = $('#tahun-berat-transaksi').val();

                App.chartberatTransaksi(bulan_berat_transaksi,tahun_berat_transaksi);
            });
            // TOTAL HARGA TRANSAKSI
            $('#tahun-total-harga-transaksi').on('change', function(event) {
                var tahun_total_harga_transaksi = $('#tahun-total-harga-transaksi').val();

                App.chartTotalHargaTransaksi(tahun_total_harga_transaksi);
            });
            // TOTAL BERAT TRANSAKSI
            $('#tahun-total-berat-transaksi').on('change', function(event) {
                var tahun_total_berat_transaksi = $('#tahun-total-berat-transaksi').val();

                App.chartTotalberatTransaksi(tahun_total_berat_transaksi);
            });
		},

		chartHargaTransaksi : function(bulan_harga_transaksi,tahun_harga_transaksi){
            $.ajax({
                url: App.baseUrl+'dashboard/getDataHargaTransaksi',
                type: 'GET',
                data: { 
                        bulan: bulan_harga_transaksi,
                        tahun: tahun_harga_transaksi,
                    },
            })
            .done(function( jqXHR ) {
                var data = JSON.parse(jqXHR)
                Highcharts.chart('harga-transaksi', {
                    chart: {
                        type: 'column',

                        // inverted: true // bikin chart jadi horizontal
                    },
                    // hilangkan credits
        //             credits: {
				    //         enabled: false
				    //     },
				    //     exporting: { 
				    //         enabled: false
				    // },
				    credits: {
					    text: 'jagif.com',
					    href: 'https://api.whatsapp.com/send?phone=6281214817992'
					},
                    title: {
                        text: 'Harga Transaksi Bulan '+data.nama_bulan+' Tahun '+data.tahun
                    },
                    xAxis: {
                        categories: data.data_cabang,
                        crosshair: true
                    },
                    yAxis: {
                        min: 0,
                        title: {
                            text: 'Rp'
                        }
                    },
                    tooltip: {
                        
                        formatter: function() {
                                return '<b>'+ this.x +'</b><br/>'+
                                    this.series.name +': '+ Highcharts.numberFormat(this.y, 0, ',') +'<br/>'
                                
                            }
                    },
                    plotOptions: {
                        column: {
                                // stacking: 'normal',
                                dataLabels: {
                                    enabled: true,
                                    color:'#ffffff',
                                    formatter: function() {
                                        if ( this.y > 1000000 ) return Highcharts.numberFormat( this.y/1000000, 1) + " m";  // maybe only switch if > 1000
                                        //if ( this.y > 10000000 ) return Highcharts.numberFormat( this.y/10000000, 1) + "b"; 
                                        return Highcharts.numberFormat(this.y,0);
                                    }  
     
                                }
                            }
                    },
                    series: [
	                    {
	                        name: 'Penjualan',
	                        data: data.penjualan,
	                        color: '#6495ED',
	                        // stack: 'Actual'
	                    },
	                    {
	                        name: 'Barang Kembali',
	                        data: data.barang_kembali,
	                        color: '#FF6347',
	                        // stack: 'Actual'
	                    },
                    ]
                });
            })
            .fail(function() {
                console.log("error");
            });
        },
        chartberatTransaksi : function(bulan_berat_transaksi,tahun_berat_transaksi){
            $.ajax({
                url: App.baseUrl+'dashboard/getDataberatTransaksi',
                type: 'GET',
                data: { 
                        bulan: bulan_berat_transaksi,
                        tahun: tahun_berat_transaksi,
                    },
            })
            .done(function( jqXHR ) {
                var data = JSON.parse(jqXHR)
                Highcharts.chart('berat-transaksi', {
                    chart: {
                        type: 'column',

                        // inverted: true // bikin chart jadi horizontal
                    },
                    // hilangkan credits
        //             credits: {
				    //         enabled: false
				    //     },
				    //     exporting: { 
				    //         enabled: false
				    // },
				    credits: {
					    text: 'jagif.com',
					    href: 'https://api.whatsapp.com/send?phone=6281214817992'
					},
                    title: {
                        text: 'berat Transaksi Bulan '+data.nama_bulan+' Tahun '+data.tahun
                    },
                    xAxis: {
                        categories: data.data_cabang,
                        crosshair: true
                    },
                    yAxis: {
                        min: 0,
                        title: {
                            text: 'Gram'
                        }
                    },
                    tooltip: {
                        
                        formatter: function() {
                                return '<b>'+ this.x +'</b><br/>'+
                                    this.series.name +': '+ Highcharts.numberFormat(this.y, 0, ',') +'<br/>'
                                
                            }
                    },
                    plotOptions: {
                        column: {
                                // stacking: 'normal',
                                dataLabels: {
                                    enabled: true,
                                    color:'#ffffff',
                                    formatter: function() {
                                        if ( this.y > 1000000 ) return Highcharts.numberFormat( this.y/1000000, 1) + " m";  // maybe only switch if > 1000
                                        //if ( this.y > 10000000 ) return Highcharts.numberFormat( this.y/10000000, 1) + "b"; 
                                        return Highcharts.numberFormat(this.y,0);
                                    }  
     
                                }
                            }
                    },
                    series: [
	                    {
	                        name: 'Penjualan',
	                        data: data.penjualan,
	                        color: '#6495ED',
	                        // stack: 'Actual'
	                    },
	                    {
	                        name: 'Barang Kembali',
	                        data: data.barang_kembali,
	                        color: '#FF6347',
	                        // stack: 'Actual'
	                    },
                    ]
                });
            })
            .fail(function() {
                console.log("error");
            });
        },

        chartTotalHargaTransaksi : function(tahun_total_harga_transaksi){
            $.ajax({
                url: App.baseUrl+'dashboard/getDataTotalHargaTransaksi',
                type: 'GET',
                data: { 
                        tahun: tahun_total_harga_transaksi,
                    },
            })
            .done(function( jqXHR ) {
                var data = JSON.parse(jqXHR)
                Highcharts.chart('total-harga-transaksi', {
                    chart: {
                        type: 'column',

                        // inverted: true // bikin chart jadi horizontal
                    },
                    // hilangkan credits
        //             credits: {
                    //         enabled: false
                    //     },
                    //     exporting: { 
                    //         enabled: false
                    // },
                    credits: {
                        text: 'jagif.com',
                        href: 'https://api.whatsapp.com/send?phone=6281214817992'
                    },
                    title: {
                        text: 'Total Harga Transaksi Tahun '+data.tahun
                    },
                    xAxis: {
                        categories: data.array_month,
                        crosshair: true
                    },
                    yAxis: {
                        min: 0,
                        title: {
                            text: 'Rp'
                        }
                    },
                    tooltip: {
                        
                        formatter: function() {
                                return '<b>'+ this.x +'</b><br/>'+
                                    this.series.name +': '+ Highcharts.numberFormat(this.y, 0, ',') +'<br/>'
                                
                            }
                    },
                    plotOptions: {
                        column: {
                                // stacking: 'normal',
                                dataLabels: {
                                    enabled: true,
                                    color:'#ffffff',
                                    formatter: function() {
                                        if ( this.y > 1000000 ) return Highcharts.numberFormat( this.y/1000000, 1) + " m";  // maybe only switch if > 1000
                                        //if ( this.y > 10000000 ) return Highcharts.numberFormat( this.y/10000000, 1) + "b"; 
                                        return Highcharts.numberFormat(this.y,0);
                                    }  
     
                                }
                            }
                    },
                    series: [
                        {
                            name: 'Penjualan',
                            data: data.penjualan,
                            color: '#228B22',
                            // stack: 'Actual'
                        },
                        {
                            name: 'Barang Kembali',
                            data: data.barang_kembali,
                            color: '#FFD700',
                            // stack: 'Actual'
                        },
                    ]
                });
            })
            .fail(function() {
                console.log("error");
            });
        },

        chartTotalberatTransaksi : function(tahun_total_berat_transaksi){
            $.ajax({
                url: App.baseUrl+'dashboard/getDataTotalberatTransaksi',
                type: 'GET',
                data: { 
                        tahun: tahun_total_berat_transaksi,
                    },
            })
            .done(function( jqXHR ) {
                var data = JSON.parse(jqXHR)
                Highcharts.chart('total-berat-transaksi', {
                    chart: {
                        type: 'column',

                        // inverted: true // bikin chart jadi horizontal
                    },
                    // hilangkan credits
        //             credits: {
                    //         enabled: false
                    //     },
                    //     exporting: { 
                    //         enabled: false
                    // },
                    credits: {
                        text: 'jagif.com',
                        href: 'https://api.whatsapp.com/send?phone=6281214817992'
                    },
                    title: {
                        text: 'Total berat Transaksi Tahun '+data.tahun
                    },
                    xAxis: {
                        categories: data.array_month,
                        crosshair: true
                    },
                    yAxis: {
                        min: 0,
                        title: {
                            text: 'Gram'
                        }
                    },
                    tooltip: {
                        
                        formatter: function() {
                                return '<b>'+ this.x +'</b><br/>'+
                                    this.series.name +': '+ Highcharts.numberFormat(this.y, 0, ',') +'<br/>'
                                
                            }
                    },
                    plotOptions: {
                        column: {
                                // stacking: 'normal',
                                dataLabels: {
                                    enabled: true,
                                    color:'#ffffff',
                                    formatter: function() {
                                        if ( this.y > 1000000 ) return Highcharts.numberFormat( this.y/1000000, 1) + " m";  // maybe only switch if > 1000
                                        //if ( this.y > 10000000 ) return Highcharts.numberFormat( this.y/10000000, 1) + "b"; 
                                        return Highcharts.numberFormat(this.y,0);
                                    }  
     
                                }
                            }
                    },
                    series: [
                        {
                            name: 'Penjualan',
                            data: data.penjualan,
                            color: '#228B22',
                            // stack: 'Actual'
                        },
                        {
                            name: 'Barang Kembali',
                            data: data.barang_kembali,
                            color: '#FFD700',
                            // stack: 'Actual'
                        },
                    ]
                });
            })
            .fail(function() {
                console.log("error");
            });
        },

		sidebarScroll: function () {
			setTimeout(function () {
		        if ($(".scrollbar-container")[0]) {
		            $('.scrollbar-container').each(function () {
		                const ps = new PerfectScrollbar($(this)[0], {
		                    wheelSpeed: 2,
		                    wheelPropagation: false,
		                    minScrollbarLength: 20
		                });
		            });

		            const ps = new PerfectScrollbar('.scrollbar-sidebar', {
		                wheelSpeed: 2,
		                wheelPropagation: true,
		                minScrollbarLength: 20
		            });
		        }
		    }, 1000);
		},



		
	}
});