define([
    "jQuery",
    "bootstrap",
    "metisMenu",
    "architectui",
    "PerfectScrollbar",
    "datatables",
    "datatablesBootstrap4",
    "datatablesResponsive",
    "jValidation",
    "datePicker",
    "select2",
], function (
    $,
    bootstrap,
    metisMenu,
    architectui,
    PerfectScrollbar,
    datatables,
    datatablesBootstrap4,
    datatablesResponsive,
    jValidation,
    datePicker,
    select2,
) {
    return {
        table: null,
        init: function () {
            App.initFunc();
            App.initCekNota();
            App.initGetNota();
            App.sidebarScroll();
            App.initEvent();
            App.initConfirm();
            App.dataList();
            App.validationJs();
            $(".loadingpage").hide();
            $(".dataTables_filter").hide();
            $("#nota_tambah_ada").hide();
            $("#nota_tambah_tidak_ada").hide();
            setTimeout(function () {
                $('.card-header').hide();
            }, 2500);
            App.initPerhitunganTukarPlus();
            App.onClickFilter();
            App.resetFilter();
        },
        initPerhitunganTukarPlus: function () {
            $('input[name=berat_tp]').change(function () {
                var jenis_tukar = $('#jenis_tukar').val();
                if (jenis_tukar == "1") {
                    var berat_tp = $('#berat_tp').val();
                    berat_tp = parseFloat(berat_tp);
                    var harga_jenis = $('#harga_jenis').val();
                    harga_jenis = parseInt(harga_jenis);
                    sub_hasil = berat_tp * harga_jenis;
                    sub_hasil = sub_hasil + 5000;
                    var potongan_rusak = $('#potongan_rusak').val();
                    potongan_rusak = parseInt(potongan_rusak);
                    if (potongan_rusak != 0) {
                        sub_hasil = sub_hasil - potongan_rusak;
                    }
                    $("#harga_tp").val(sub_hasil);
                } else {
                    //tukar min

                    var berat_tp = $('#berat_tp').val();
                    berat_tp = parseFloat(berat_tp);
                    var harga_jenis = $('#harga_jenis').val();
                    harga_jenis = parseInt(harga_jenis);
                    var potongan = $('#potongan').val();
                    potongan = parseInt(potongan);
                    //harga jenis kurangin potongan
                    harga_jenis = harga_jenis - potongan;
                    var edit_enum = $('#edit_enum').val();
                    edit_enum = parseInt(edit_enum);
                    if (edit_enum == 1) {
                        var harga_jenis = $('#harga_jenis').val();
                        harga_jenis = parseInt(harga_jenis);
                        harga_jenis = harga_jenis;
                    }
                    // alert(harga_jenis)
                    //masukan selisih untuk perkalian ke BK dan hitung
                    var berat = $('#berat').val();
                    berat = parseFloat(berat);
                    selisih_berat = berat - berat_tp;
                    selisih_harga = selisih_berat * harga_jenis;
                    $("#selisih_berat").val(selisih_berat);
                    $("#selisih_harga").val(selisih_harga);
                    $("#harga_jenis_barang_kembali").val(harga_jenis);
                    sub_hasil = berat_tp * harga_jenis + 5000;
                    var potongan_rusak = $('#potongan_rusak').val();
                    potongan_rusak = parseInt(potongan_rusak);
                    if (potongan_rusak != 0) {
                        sub_hasil = sub_hasil - potongan_rusak;
                    }
                    $("#harga_tp").val(sub_hasil);


                }
            });
        },
        initCekNota: function () {
            $("#btn-cek").click(function () {
                var no_nota = $("#no_nota").val();
                $.ajax({
                        url: App.baseUrl + 'barang_kembali/hasil_nota',
                        type: 'GET',
                        data: {
                            no_nota: no_nota
                        },
                    })
                    .done(function (jqXHR) {
                        var data = JSON.parse(jqXHR);
                        if (data.status == true) {
                            $('#nota_ada').val('No Nota : ' + no_nota + ' Sudah Kembali Dan Tidak Bisa Melakukan Transaksi Barang Kembali');
                            $("#nota_tidak_ada").hide();
                            $("#nota_ada").show();
                            $("#hasil_cek").show();
                        } else {
                            $('#nota_tidak_ada').val('No Nota : ' + no_nota + ' Belum Kembali Dan Bisa Melakukan Transaksi Barang Kembali');
                            $("#nota_ada").hide();
                            $("#nota_tidak_ada").show();
                            $("#hasil_cek").show();
                        }
                        // App.HitungPersentaseRencana($('#rencana_jumlah_penduduk').val(), data.jumlah_penduduk);
                    })
                    .fail(function () {
                        console.log("error");
                    })
            });
        },
        initGetNota: function () {
            $("#btn_cek_tambah").click(function () {
                var cabang_id = $("#cabang_id").val();
                if (cabang_id == "") {
                    App.alert('pilih cabang terlebih dahulu!!!');
                } else {
                    $.ajax({
                            url: App.baseUrl+'nota_kantor/get_nota_pembukuan_tukar',
                            type: 'GET',
                            data: {
                                cabang_id: cabang_id
                            },
                        })
                        .done(function (jqXHR) {
                            var data = JSON.parse(jqXHR)
                            var option = '<option value="">Pilih No Nota</option>';
                            if(data.status == true){
                                data_nota = data.data;
                                for (var i = 0; i < data_nota.length; i++) {
                                    option += "<option value="+data_nota[i].id+"> "+data_nota[i].no_nota+"</option>";
                                }
                            $('#no_nota_id').html(option);
                            $("#nota_tambah_ada").show();
                            $("#cabang_id_tukar").val(cabang_id);
                            $("#nota_tambah_tidak_ada").hide();
                            }else{
                                $("#nota_tambah_ada").hide();
                                $("#nota_tambah_tidak_ada").show();
                            }
                        })
                        .fail(function () {
                            console.log("error");
                        })
                }
            });
            // $("#btn_cek_tambah").click(function () {
            //     var no_nota_tambah = $("#no_nota_tambah").val();
            //     var kode_cabang = $("#kode_cabang").val();
            //     if (no_nota_tambah == "" || kode_cabang == "") {
            //         App.alert('Silahkan isi No Nota dan  pilih cabang terlebih dahulu!!!');
            //     } else {
            //         $.ajax({
            //                 url: App.baseUrl + 'penjualan/get_data_nota',
            //                 type: 'GET',
            //                 data: {
            //                     no_nota_tambah: no_nota_tambah,
            //                     kode_cabang: kode_cabang
            //                 },
            //             })
            //             .done(function (jqXHR) {
            //                 var data = JSON.parse(jqXHR);
            //                 if (data.status == true) {
            //                     $('#tanggal_penjualan').html(data.tanggal);
            //                     $('#nama_karyawan').html(data.nama_karyawan);
            //                     $('#no_nota_html').html(data.no_nota_tukar);
            //                     $('#no_nota_penjualan').val(data.no_nota);
            //                     $('#nama_jenis').html(data.nama_jenis);
            //                     $('#nama_barang').html(data.nama_barang);
            //                     $('#potong_data').html(data.potong);
            //                     $('#berat_html').html(data.berat);
            //                     $('#berat').val(data.berat);
            //                     $('#harga').html(data.harga);
            //                     $('#harga_jenis').val(data.harga_jenis);
            //                     $('#penjualan_id').val(data.penjualan_id);
            //                     $('#jenis_transaksi_id').val(data.jenis_transaksi_id);
            //                     $('#harga_penjualan').val(data.harga);
            //                     $("#nota_tambah_ada").show();
            //                     $("#hasil_cek").hide();
            //                 } else {
            //                     $("#nota_tambah_ada").hide();
            //                     $('#nota_ada').val('No Nota : ' + no_nota_tambah + ' tersebut tidak ada pada data pada penjualan, atau Nota Batal, atau Nota Hilang 3R!!!');
            //                     $("#nota_tidak_ada").hide();
            //                     $("#nota_ada").show();
            //                     $("#hasil_cek").show();
            //                 }
            //                 // App.HitungPersentaseRencana($('#rencana_jumlah_penduduk').val(), data.jumlah_penduduk);
            //             })
            //             .fail(function () {
            //                 console.log("error");
            //             })
            //     }
            // });
        },
        initEvent: function () {
            $('.select2').select2();
            $('.init-date').datepicker({
                uiLibrary: 'bootstrap4',
                format: 'YYYY-mm-dd'
            });

        },

        sidebarScroll: function () {
            setTimeout(function () {
                if ($(".scrollbar-container")[0]) {
                    $('.scrollbar-container').each(function () {
                        const ps = new PerfectScrollbar($(this)[0], {
                            wheelSpeed: 2,
                            wheelPropagation: false,
                            minScrollbarLength: 20
                        });
                    });

                    const ps = new PerfectScrollbar('.scrollbar-sidebar', {
                        wheelSpeed: 2,
                        wheelPropagation: true,
                        minScrollbarLength: 20
                    });
                }
            }, 1000);
        },

        initConfirm: function () {
            $('#table').on('click', '.delete', function () {
                var url = $(this).attr("url");
                App.confirm("Apakah Anda Yakin Untuk Mengubah Ini?", function () {
                    $.ajax({
                        method: "GET",
                        url: url
                    }).done(function (msg) {
                        $('.loadingpage').hide();
                        App.table.ajax.reload(null, true);
                    });
                })
            });
        },

        dataList: function () {
            
            App.table_pembukuan = $('#table-pembukuan').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first": "Pertama",
                        "last": "Terakhir",
                        "next": "Selanjutnya",
                        "previous": "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": App.baseUrl + "pembukuan_tukar_plus/dataList",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [{
                        "data": "id"
                    },
                    {
                        "data": "cabang",
                        "orderable": false
                    },
                    {
                        "data": "tanggal",
                        "orderable": false
                    },
                    {
                        "data": "jumlah_transaksi",
                        "orderable": false
                    },
                    {
                        "data": "action",
                        "orderable": false
                    }
                ],
                "columnDefs": [{
                    "targets": [0, 1, 2, 3,4],
                    "className": "text-center"
                }, ]
            });

            //append button to datatables
            // add_btn = '<a href="'+App.baseUrl+'group/create" class="btn btn-sm btn-primary ml-2 mt-1"><i class="fa fa-plus"></i> Departemen</a>';
            // $('#table_filter').append(add_btn);
        },

        validationJs: function () {
            $('#btn-tambah').on('click', function () {

                $("#form").validate({
                    rules: {
                        tanggal: {
                            required: true
                        },
                        no_nota_id: {
                            required: true
                        },
                        jenis_tukar: {
                            required: true
                        },
                    },
                    messages: {
                        tanggal: {
                            required: "*) harus diisi"
                        },
                        no_nota_id: {
                            required: "*) harus dipilih"
                        },
                        jenis_tukar: {
                            required: "*) harus dipilih"
                        },
                    },
                    debug: true,
                    errorElement: "em",
                    errorPlacement: function (error, element) {
                        // Add the `invalid-feedback` class to the error element
                        error.addClass("invalid-feedback");
                        if (element.prop("type") === "checkbox") {
                            error.insertBefore(element.next("label"));
                        } else if (element.prop("type") === "radio") {
                            error.appendTo(element.parent().parent().parent());
                        } else {
                            error.insertBefore(element);
                        }
                    },
                    highlight: function (element, errorClass, validClass) {
                        $(element).addClass("is-invalid").removeClass("is-valid");
                    },
                    unhighlight: function (element, errorClass, validClass) {
                        $(element).addClass("is-valid").removeClass("is-invalid");
                    },
                    submitHandler: function (form) {
                        $('#value-btn-tambah').val(1);
                        form.submit();
                    }
                });
            });
        },

        onClickFilter : function (){
            $('#btn-filter').on('click', function () {
                var tanggal   = $("#tanggal").val();
                var cabang_id   = $("#cabang_id").val();
                //pembukuan
                App.table_pembukuan.column(0).search(tanggal,true,true);
                App.table_pembukuan.column(1).search(cabang_id,true,true);
                App.table_pembukuan.draw();
               

            });
        },

        resetFilter : function (){
            $('#btn-filter-clear').on( 'click', function () {
                $("#tanggal").val("").trigger('change');
                $("#cabang_id").val("").trigger('change');
                $('#btn-filter').trigger('click');
            });
        },
    }
});