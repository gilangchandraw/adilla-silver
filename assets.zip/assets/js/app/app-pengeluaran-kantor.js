define([
    "jQuery",
    "bootstrap",
    "metisMenu",
    "architectui",
    "PerfectScrollbar",
    "datatables",
    "datatablesBootstrap4",
    "datatablesResponsive",
    "jValidation",
    "datePicker",
    "select2",
], function (
    $,
    bootstrap,
    metisMenu,
    architectui,
    PerfectScrollbar,
    datatables,
    datatablesBootstrap4,
    datatablesResponsive,
    jValidation,
    datePicker,
    select2,
) {
    return {
        table: null,
        init: function () {
            App.initFunc();
            App.sidebarScroll();
            App.initConfirm();
            App.dataList();
            App.validationJs();
            $(".dataTables_filter").hide();
            $(".loadingpage").hide();
            // $(".hide-keterangan").hide();
            setTimeout(function () {
                $('.card-header').hide();
            }, 2500);
            App.initEvent();
            App.onClickFilter();
            App.resetFilter();

        },

        initEvent: function () {
            $('.init-date').datepicker({
                uiLibrary: 'bootstrap4',
                format: 'YYYY-mm-dd'
            });

            $('.select2').select2();

            $('input[name=berat]').change(function () {
                // alert(App.harga_satuan);
                var berat = $('#berat').val();
                var jenis_transaksi_id = $('#jenis_transaksi_id').val();
                //get harga
                $.ajax({
                        url: App.baseUrl + 'enum_transaksi_barang/get_harga',
                        type: 'GET',
                        data: {
                            jenis_transaksi_id: jenis_transaksi_id
                        },
                    })
                    .done(function (jqXHR) {
                        var data = JSON.parse(jqXHR);
                        if (data.status == true) {
                            var harga = berat * parseInt(data.harga);
                            $('#harga').val(App.toRp(harga));
                            $('#total_harga_keseluruhan').val(App.toRp(harga));
                            // $('#stok').val(data.stok);
                            // harga_satuan = data.harga.replace(",", "");
                            // App.harga_satuan = harga_satuan;
                            // App.stok = data.stok;



                        } else {
                            $('#harga').val('');
                        }
                        // App.HitungPersentaseRencana($('#rencana_jumlah_penduduk').val(), data.jumlah_penduduk);
                    })
                    .fail(function () {
                        console.log("error");
                    })

                var harga_satuan = App.harga_satuan.replace(",", "");
                var banyak = parseInt(berat);
                if (banyak > App.stok) {
                    alert('Stok Tidak Mencukupi');
                    $('#total_harga').val('');
                    $('#harga').val('');
                } else {
                    var total = berat * harga_satuan;
                    $('#total_harga').val('Rp. ' + App.toRp(total));
                    var total_harga_keseluruhan = $('#total_harga_keseluruhan').val();
                    $('#harga').val(total);
                    var total_akhir = parseInt(total_harga_keseluruhan) + total;
                    $('#total_harga_keseluruhan').val(total_akhir);
                }
            });

            // $('#enum_pemasukan_id').change(function () {
            //     var enum_pemasukan_id = $("#enum_pemasukan_id").val();
            //     if (enum_pemasukan_id == '12') {
            //         $('.hide-keterangan').show();
            //     } else {
            //         $('.hide-keterangan').hide();
            //     }
                

            // });
            // var enum_pemasukan_id = $("#enum_pemasukan_id").val();
            // enum_pemasukan_id = parseInt(enum_pemasukan_id);
            // // alert(enum_pemasukan_id)
            // if (enum_pemasukan_id == 12) {
            //     $('.hide-keterangan').show();
            //     // alert('b')
            // } else {
            //     $('.hide-keterangan').hide();
            //     // alert('a')
            // }
        },

        sidebarScroll: function () {
            setTimeout(function () {
                if ($(".scrollbar-container")[0]) {
                    $('.scrollbar-container').each(function () {
                        const ps = new PerfectScrollbar($(this)[0], {
                            wheelSpeed: 2,
                            wheelPropagation: false,
                            minScrollbarLength: 20
                        });
                    });

                    const ps = new PerfectScrollbar('.scrollbar-sidebar', {
                        wheelSpeed: 2,
                        wheelPropagation: true,
                        minScrollbarLength: 20
                    });
                }
            }, 1000);
        },

        initConfirm: function () {
            $('#table-detail').on('click', '.delete-data', function () {
                var id = $(this).attr("detail_id");
                App.confirm("Apakah Anda Yakin Untuk Menghapus data Ini?", function () {
                    window.location.href = App.baseUrl+'pengeluaran_kantor/delete/'+id;                    
                })
            });
            $('#table').on('click', '.delete', function () {
                var id = $(this).attr("id");
                App.confirm("Apakah Anda Yakin Untuk Menghapus data Ini?", function () {
                    window.location.href = App.baseUrl+'pengeluaran_kantor/delete_master/'+id;                    
                })
            });
        },

        dataList: function () {
            App.table = $('#table').DataTable({
                "language": {
                    "search": "Cari",
                    "lengthMenu": "Tampilkan _MENU_ data per halaman",
                    "zeroRecords": "Data tidak ditemukan",
                    "info": "Halaman _PAGE_ dari _PAGES_ (total _MAX_ data )",
                    "infoEmpty": "Tidak ada data yang ditampilkan ",
                    "infoFiltered": "(pencarian dari _MAX_ total records)",
                    "paginate": {
                        "first": "Pertama",
                        "last": "Terakhir",
                        "next": "Selanjutnya",
                        "previous": "Sebelum"
                    },
                },
                "processing": true,
                "serverSide": true,
                "ajax": {
                    "url": App.baseUrl + "pengeluaran_kantor/dataList",
                    "dataType": "json",
                    "type": "POST",
                },
                "columns": [{
                        "data": "id"
                    },
                    {
                        "data": "tanggal",
                        "orderable": false
                    },
                    {
                        "data": "action",
                        "orderable": false
                    }
                ],
                "columnDefs": [{
                    "targets": [0, 1, 2],
                    "className": "text-center"
                }, ]
            });
        },

        validationJs: function () {
            $('#btn-tambah').on('click', function () {

                $("#form").validate({
                    rules: {
                        tanggal: {
                            required: true
                        },
                        enum_pengeluaran_kantor_id: {
                            required: true
                        },
                        harga: {
                            required: true
                        },
                        keterangan: {
                            required: true
                        },
                    },
                    messages: {
                        tanggal: {
                            required: "*) harus diisi"
                        },
                        enum_pengeluaran_kantor_id: {
                            required: "*) harus dipilih"
                        },
                        keterangan: {
                            required: "*) harus diisi"
                        },
                        harga: {
                            required: "*) harus diisi"
                        },
                    },
                    debug: true,
                    errorElement: "em",
                    errorPlacement: function (error, element) {
                        // Add the `invalid-feedback` class to the error element
                        error.addClass("invalid-feedback");
                        if (element.prop("type") === "checkbox") {
                            error.insertBefore(element.next("label"));
                        } else if (element.prop("type") === "radio") {
                            error.appendTo(element.parent().parent().parent());
                        } else {
                            error.insertBefore(element);
                        }
                    },
                    highlight: function (element, errorClass, validClass) {
                        $(element).addClass("is-invalid").removeClass("is-valid");
                    },
                    unhighlight: function (element, errorClass, validClass) {
                        $(element).addClass("is-valid").removeClass("is-invalid");
                    },
                    submitHandler: function (form) {
                        $('#value-btn-tambah').val(1);
                        form.submit();
                    }
                });
            });
        },

        onClickFilter: function () {
            $('#btn-filter').on('click', function () {
                var tanggal = $("#tanggal").val();
                
                App.table.column(0).search(tanggal, true, true);
                App.table.draw();

            });
        },

        resetFilter: function () {
            $('#btn-filter-clear').on('click', function () {
                $("#tanggal").val("").trigger('change');
                $('#btn-filter').trigger('click');
            });
        },
    }
});