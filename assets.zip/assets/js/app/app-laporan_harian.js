define([
    "jQuery",
    "bootstrap",
    "metisMenu",
    "architectui",
    "PerfectScrollbar",
    "datatables",
    "datatablesBootstrap4",
    "datatablesResponsive",
    "jValidation",
    "datePicker",
    "select2",
], function (
    $,
    bootstrap,
    metisMenu,
    architectui,
    PerfectScrollbar,
    datatables,
    datatablesBootstrap4,
    datatablesResponsive,
    jValidation,
    datePicker,
    select2,
) {
    return {
        table: null,
        init: function () {
            App.initFunc();
            App.initEvent();
            App.sidebarScroll();
            App.initPreview();
            $(".loadingpage").hide();
            setTimeout(function () {
                $('.card-header').hide();
            }, 2500);
        },
        initPreview: function() {
            $('#preview-btn').on('click', function () {

                var laporan   = $("#laporan").val();
                var cabang_id     = $("#cabang_id").val();
                var tanggal     = $("#tanggal").val();
                if (laporan == "" || cabang_id == "" || tanggal == "") {
                    App.alert('Pilih Filter terlebih dahulu');
                } else {

                }
                $.ajax({
                    url: App.baseUrl+'laporan_harian/get_data',
                    type: 'GET',
                    data: {
                            laporan: laporan,
                            cabang_id: cabang_id,
                            tanggal: tanggal,
                        },
                })
                .done(function( jqXHR ) {
                    var data = JSON.parse(jqXHR);
                    if(data.status == true){
                        var html_laporan = '';
                        html_laporan += '<div class="main-card mb-3 card">\
                            <div class="card-body">\
                                <div class="row">\
                                    <table border="1" align="center" cellspacing="0" cellpadding="5">\
                                        <td colspan="5">\
                                            <img src="'+App.baseUrl+'assets/images/logo.png" alt="Logo" class="center" width="90" height="50">\
                                            <strong>\
                                                ADILLA SILVER 925 GROUP\
                                            </strong>\
                                            <p align="right">Laporan Harian</p>\
                                            <p align="right">'+data.cabang+'</p>\
                                            <p align="right">'+tanggal+'</p>\
                                        </td>\
                                        <tr align="center">\
                                            <td colspan="5">\
                                                <strong>\
                                                    LAPORAN AKTIVITAS\
                                                </strong></td>\
                                        </tr>\
                                        <tr align="center">\
                                        <td style="background-color:#87CEEB;">Transaksi</td>\
                                        <td style="background-color:#87CEEB;">Karat</td>\
                                        <td style="background-color:#87CEEB;">Gram</td>\
                                        <td colspan="2" style="background-color:#87CEEB;">Rp</td>\
                                        </tr>\
                                        <tr>\
                                            <td rowspan="3" style="background-color:#87CEEB;" width="200" class="text-center"> <strong>Penjualan</strong></td>\
                                            <td width="120" class="text-center">[25]</td>\
                                            <td class="text-center">'+data.berat_penjualan_25+'</td>\
                                            <td colspan="2" class="text-center">'+data.harga_penjualan_25+'</td>\
                                        </tr>\
                                        <tr>\
                                            <td width="120" class="text-center">[30]</td>\
                                            <td class="text-center">'+data.berat_penjualan_30+'</td>\
                                            <td colspan="2" class="text-center">'+data.harga_penjualan_30+'</td>\
                                        </tr>\
                                        <tr>\
                                            <td width="120" class="text-center">[35]</td>\
                                            <td class="text-center">'+data.berat_penjualan_35+'</td>\
                                            <td colspan="2" class="text-center">'+data.harga_penjualan_35+'</td>\
                                        </tr>\
                                        <tr>\
                                            <td rowspan="3" style="background-color:#87CEEB;" width="200" class="text-center"> <strong>Tukar [+]</strong></td>\
                                            <td width="120" class="text-center">[25]</td>\
                                            <td class="text-center">'+data.berat_tukar_25+'</td>\
                                            <td colspan="2" class="text-center">'+data.harga_tukar_25+'</td>\
                                        </tr>\
                                        <tr>\
                                            <td width="120" class="text-center">[30]</td>\
                                            <td class="text-center">'+data.berat_tukar_30+'</td>\
                                            <td colspan="2" class="text-center">'+data.harga_tukar_30+'</td>\
                                        </tr>\
                                        <tr>\
                                            <td width="120" class="text-center">[35]</td>\
                                            <td class="text-center">'+data.berat_tukar_35+'</td>\
                                            <td colspan="2" class="text-center">'+data.harga_tukar_35+'</td>\
                                        </tr>\
                                        <tr>\
                                            <td width="120" colspan="2" style="background-color:#98FB98;" class="text-center">Total Penjualan</td>\
                                            <td style="background-color:#98FB98;" class="text-center">'+data.total_berat_penjualan+'</td>\
                                            <td colspan="2" style="background-color:#98FB98;" class="text-center">'+data.total_harga_penjualan+'</td>\
                                        </tr>\
                                        <tr>\
                                            <td style="background-color:#87CEEB;" rowspan="12" width="200" class="text-center"> <strong>Barang Kembali</strong></td>\
                                            <td width="120" class="text-center">[17]</td>\
                                            <td class="text-center">'+data.berat_bk_17+'</td>\
                                            <td  colspan="2"class="text-center">'+data.harga_bk_17+'</td>\
                                        </tr>\
                                        <tr>\
                                            <td width="120" class="text-center">[18]</td>\
                                            <td class="text-center">'+data.berat_bk_18+'</td>\
                                            <td  colspan="2"class="text-center">'+data.harga_bk_18+'</td>\
                                        </tr>\
                                        <tr>\
                                            <td width="120" class="text-center">[19]</td>\
                                            <td class="text-center">'+data.berat_bk_19+'</td>\
                                            <td  colspan="2"class="text-center">'+data.harga_bk_19+'</td>\
                                        </tr>\
                                        <tr>\
                                            <td width="120" class="text-center">[20]</td>\
                                            <td class="text-center">'+data.berat_bk_20+'</td>\
                                            <td  colspan="2"class="text-center">'+data.harga_bk_20+'</td>\
                                        </tr>\
                                        <tr>\
                                            <td width="120" class="text-center">[22]</td>\
                                            <td class="text-center">'+data.berat_bk_22+'</td>\
                                            <td colspan="2" class="text-center">'+data.harga_bk_22+'</td>\
                                        </tr>\
                                        <tr>\
                                            <td width="120" class="text-center">[23]</td>\
                                            <td class="text-center">'+data.berat_bk_23+'</td>\
                                            <td colspan="2" class="text-center">'+data.harga_bk_23+'</td>\
                                        </tr>\
                                        <tr>\
                                            <td width="120" class="text-center">[24]</td>\
                                            <td class="text-center">'+data.berat_bk_24+'</td>\
                                            <td colspan="2" class="text-center">'+data.harga_bk_24+'</td>\
                                        </tr>\
                                        <tr>\
                                            <td width="120" class="text-center">[25]</td>\
                                            <td class="text-center">'+data.berat_bk_25+'</td>\
                                            <td  colspan="2" class="text-center">'+data.harga_bk_25+'</td>\
                                        </tr>\
                                        <tr>\
                                            <td width="120" class="text-center">[27]</td>\
                                            <td class="text-center">'+data.berat_bk_27+'</td>\
                                            <td colspan="2" class="text-center">'+data.harga_bk_27+'</td>\
                                        </tr>\
                                        <tr>\
                                            <td width="120" class="text-center">[28]</td>\
                                            <td class="text-center">'+data.berat_bk_28+'</td>\
                                            <td colspan="2" class="text-center">'+data.harga_bk_28+'</td>\
                                        </tr>\
                                        <tr>\
                                            <td width="120" class="text-center">[29]</td>\
                                            <td class="text-center">'+data.berat_bk_29+'</td>\
                                            <td colspan="2" class="text-center">'+data.harga_bk_29+'</td>\
                                        </tr>\
                                        <tr>\
                                            <td width="120" class="text-center">[30]</td>\
                                            <td class="text-center">'+data.berat_bk_30+'</td>\
                                            <td colspan="2" class="text-center">'+data.harga_bk_30+'</td>\
                                        </tr>\
                                        <tr>\
                                            <td width="120" colspan="2" style="background-color:#98FB98;" class="text-center">Total Barang Kembali</td>\
                                            <td style="background-color:#98FB98;" class="text-center">'+data.total_berat_bk+'</td>\
                                            <td colspan="2" style="background-color:#98FB98;" class="text-center">'+data.total_harga_bk+'</td>\
                                        </tr>\
                                        <tr>\
                                            <td width="120" style="background-color:#87CEEB;" colspan="2" rowspan="'+data.jumlah_pengeluaran+'" class="text-center">Pengeluaran</td>\
                                            <td style="background-color:#87CEEB;" class="text-center">Nama</td>\
                                            <td style="background-color:#87CEEB;" colspan="2" class="text-center">Rp</td>\
                                        </tr>';
                                        if (data.pengeluaran != null) {
                                            for (var i = 0; i < data.pengeluaran.length; i++) {
                                                html_laporan += '<tr>';
                                                    if (data.pengeluaran[i].enum_pengeluaran_id == 10) {
                                                        html_laporan += '<td class="text-center">'+data.pengeluaran[i].keterangan+'</td>';
                                                    }else{
                                                        html_laporan += '<td class="text-center">'+data.pengeluaran[i].nama_pengeluaran+'</td>';
                                                    }
                                                    html_laporan += '<td colspan="2" class="text-center">'+App.toRp(data.pengeluaran[i].harga)+'</td>\
                                                </tr>';
                                            }
                                        }

                                    html_laporan += '<tr>\
                                            <td width="120" colspan="3" style="background-color:#98FB98;" class="text-center">Total Pengeluaran</td>\
                                            <td colspan="2" style="background-color:#98FB98;" class="text-center">'+App.toRp(data.total_pengeluaran)+'</td>\
                                            <tr>\
                                                <td width="120"  colspan="3" style="background-color:#98FB98;" class="text-center">KAS</td>\
                                                <td colspan="2" style="background-color:#98FB98;" class="text-center">'+App.toRp(data.kas)+'</td>\
                                            </tr>\
                                            <tr>\
                                                <td width="120" colspan="5" style="background-color:#87CEEB;" class="text-center">Barang Rusak</td>\
                                            </tr>\
                                            <tr>\
                                                <td width="120" class="text-center">Nama Barang</td>\
                                                <td width="120" class="text-center">Gram</td>\
                                                <td width="120" class="text-center">POT</td>\
                                                <td width="120" colspan="2" class="text-center">Rp</td>\
                                            </tr>';
                                            if (data.barang_rusak != null) {
                                                for (var i = 0; i < data.barang_rusak.length; i++) {
                                                    html_laporan += '<tr>\
                                                        <td width="120" class="text-center"> BK - '+data.barang_rusak[i].nama_barang+'</td>\
                                                        <td width="120" class="text-center">'+data.barang_rusak[i].berat+'</td>\
                                                        <td width="120" class="text-center">'+data.barang_rusak[i].potong+'</td>\
                                                        <td width="120" colspan="2" class="text-center">'+App.toRp(data.barang_rusak[i].potongan_rusak)+'</td>\
                                                    </tr>';
                                                }
                                            }
                                    html_laporan +='<tr>\
                                            <td width="120" style="background-color:#98FB98;" class="text-center">Total</td>\
                                            <td width="120" style="background-color:#98FB98;" class="text-center">'+data.total_gram_br+'</td>\
                                            <td width="120" style="background-color:#98FB98;" class="text-center">'+data.total_potong_br+'</td>\
                                            <td colspan="2" width="120" style="background-color:#98FB98;" class="text-center">'+data.total_harga_br+'</td>\
                                            </tr>\
                                            <tr>\
                                                <td width="120" colspan="5" style="background-color:#87CEEB;" class="text-center">Barang Hilang</td>\
                                            </tr>\
                                            <tr>\
                                                <td class="text-center">Nama Barang</td>\
                                                <td class="text-center">Gram Awal</td>\
                                                <td class="text-center">Selisih</td>\
                                                <td class="text-center">Gram Akhir</td>\
                                                <td class="text-center">Rp</td>\
                                            </tr>';
                                            if (data.barang_hilang != null) {
                                                total_gram_akhir_bh = 0;
                                                for (var i = 0; i < data.barang_hilang.length; i++) {
                                                    gram_akhir = data.barang_hilang[i].gram_awal - data.barang_hilang[i].berat;
                                                    total_gram_akhir_bh += gram_akhir;
                                                    html_laporan += '<tr>\
                                                        <td class="text-center">'+data.barang_hilang[i].nama_barang+'</td>\
                                                        <td class="text-center">'+parseFloat(data.barang_hilang[i].gram_awal).toFixed(2)+'</td>\
                                                        <td class="text-center">'+parseFloat(data.barang_hilang[i].berat).toFixed(2)+'</td>\
                                                        <td class="text-center">'+parseFloat(gram_akhir).toFixed(2)+'</td>\
                                                        <td class="text-center">'+App.toRp(data.barang_hilang[i].potongan_hilang)+'</td>\
                                                    </tr>';
                                                }
                                            }
                                    html_laporan +='<tr>\
                                    <td style="background-color:#98FB98;" class="text-center">Total</td>\
                                    <td style="background-color:#98FB98;" class="text-center">'+data.total_gram_awal_bh+'</td>\
                                    <td style="background-color:#98FB98;" class="text-center">'+data.total_selisih_bh+'</td>\
                                    <td style="background-color:#98FB98;" class="text-center">'+total_gram_akhir_bh.toFixed(2)+'</td>\
                                    <td style="background-color:#98FB98;" class="text-center">'+data.total_harga_bh+'</td>\
                                    </tr>\
                                    <tr>\
                                        <td width="120" colspan="5" style="background-color:#87CEEB;" class="text-center">Sepuhan</td>\
                                    </tr>\
                                    <tr>\
                                        <td class="text-center">Pemasukan</td>\
                                        <td class="text-center">Rp</td>\
                                        <td class="text-center">Pengeluaran</td>\
                                        <td class="text-center">Harga</td>\
                                        <td class="text-center">Sisa Kas Sepuhan</td>\
                                    </tr>';
                                    if (data.sepuhan != null) {
                                        total_harga_pemasukan = 0;
                                        total_harga_pengeluaran = 0;
                                        total_kas_sepuhan = 0;
                                        for (var i = 0; i < data.sepuhan.length; i++) {
                                            total_harga_pemasukan += parseInt(data.sepuhan[i].harga_pemasukan);
                                            total_harga_pengeluaran += parseInt(data.sepuhan[i].harga_pengeluaran);
                                            total_kas_sepuhan += parseInt(data.sepuhan[i].kas_sepuhan_akhir);

                                            html_laporan += '<tr>';
                                            html_laporan += '<td class="text-center">'+data.sepuhan[i].nama_pemasukan+'</td>';
                                            html_laporan += '<td class="text-center">'+App.toRp(data.sepuhan[i].harga_pemasukan)+'</td>';
                                            html_laporan += '<td class="text-center">'+data.sepuhan[i].nama_pengeluaran+'</td>';
                                            html_laporan += '<td class="text-center">'+App.toRp(data.sepuhan[i].harga_pengeluaran)+'</td>';
                                            html_laporan += '<td class="text-center">'+App.toRp(data.sepuhan[i].kas_sepuhan_akhir)+'</td>\
                                            </tr>';
                                        }
                                    }
                                    html_laporan +='<tr>\
                                        <td style="background-color:#98FB98;" class="text-center">Total</td>\
                                        <td style="background-color:#98FB98;" class="text-center">'+App.toRp(total_harga_pemasukan)+'</td>\
                                        <td style="background-color:#98FB98;" class="text-center">Total</td>\
                                        <td style="background-color:#98FB98;" class="text-center">'+App.toRp(total_harga_pengeluaran)+'</td>\
                                        <td style="background-color:#98FB98;" class="text-center">'+App.toRp(total_kas_sepuhan)+'</td>\
                                    </tr>\
                                    <tr>\
                                        <td width="120" colspan="5" style="background-color:#87CEEB;" class="text-center">Kotak Cincin</td>\
                                    </tr>\
                                    <tr>\
                                        <td colspan="2" class="text-center">Nama Barang</td>\
                                        <td class="text-center">Qty</td>\
                                        <td colspan="2" class="text-center">Harga</td>\
                                    </tr>';
                                    if (data.kc != null) {
                                        total_qty_kc = 0;
                                        total_harga_kc = 0;
                                        for (var i = 0; i < data.kc.length; i++) {
                                            total_qty_kc += parseInt(data.kc[i].qty);
                                            total_harga_kc += parseInt(data.kc[i].harga);

                                            html_laporan += '<tr>';
                                            html_laporan += '<td class="text-center" colspan="2">'+data.kc[i].nama_kotak_cincin+'</td>';
                                            html_laporan += '<td class="text-center">'+data.kc[i].qty+'</td>';
                                            html_laporan += '<td class="text-center" colspan="2">'+App.toRp(data.kc[i].harga)+'</td>\
                                            </tr>';
                                        }
                                    }
                                    html_laporan +='<tr>\
                                        <td style="background-color:#98FB98;" colspan="2" class="text-center">Total</td>\
                                        <td style="background-color:#98FB98;" class="text-center">'+total_qty_kc+'</td>\
                                        <td style="background-color:#98FB98;" colspan="2" class="text-center">'+App.toRp(total_harga_kc)+'</td>\
                                    </tr>\
                                    <tr>\
                                        <td colspan="3" style="background-color:#87CEEB;" class="text-center">Uang Laci</td>\
                                        <td colspan="2" style="background-color:#87CEEB;" class="text-center">Uang Brangkas</td>\
                                    </tr>\
                                    <tr>\
                                        <td class="text-center">Rp. 100,000</td>\
                                        <td colspan="2" class="text-center">'+data.rp_100000+'</td>\
                                        <td colspan="2" class="text-center">'+data.uang_brangkas+'</td>\
                                    </tr>\
                                    <tr>\
                                        <td class="text-center">Rp. 50,000</td>\
                                        <td colspan="2" class="text-center">'+data.rp_50000+'</td>\
                                        <td colspan="2" style="background-color:#87CEEB;" class="text-center">Uang Jelek</td>\
                                    </tr>\
                                    <tr>\
                                        <td class="text-center">Rp. 20,000</td>\
                                        <td colspan="2" class="text-center">'+data.rp_20000+'</td>\
                                        <td colspan="2" class="text-center">'+data.uang_jelek+'</td>\
                                    </tr>\
                                    <tr>\
                                        <td class="text-center">Rp. 10,000</td>\
                                        <td colspan="2" class="text-center">'+data.rp_10000+'</td>\
                                        <td colspan="2" style="background-color:#87CEEB;" class="text-center">U.D.A</td>\
                                    </tr>\
                                    <tr>\
                                        <td class="text-center">Rp. 5,000</td>\
                                        <td colspan="2" class="text-center">'+data.rp_5000+'</td>\
                                        <td colspan="2" class="text-center">'+data.uda+'</td>\
                                    </tr>\
                                    <tr>\
                                        <td class="text-center">Rp. 2,000</td>\
                                        <td colspan="2" class="text-center">'+data.rp_2000+'</td>\
                                        <td colspan="2" style="background-color:#87CEEB;" class="text-center">Uang Setor</td>\
                                    </tr>\
                                    <tr>\
                                        <td class="text-center">Rp. 1,000</td>\
                                        <td colspan="2" class="text-center">'+data.rp_1000+'</td>\
                                        <td colspan="2" class="text-center">'+data.uang_setor+'</td>\
                                    </tr>\
                                    <tr>\
                                        <td rowspan="2" class="text-center">Rp. 500</td>\
                                        <td rowspan="2" colspan="2" class="text-center">'+data.rp_500+'</td>\
                                        <td colspan="2" style="background-color:#87CEEB;" class="text-center">U. Kas Pagi</td>\
                                    </tr>\
                                    <tr>\
                                        <td colspan="2" class="text-center">'+data.uang_kas_pagi+'</td>\
                                    </tr>\
                                    </table>\
                                </div>\
                            </div>\
                        </div>';

                        $('#hasil-report').html(html_laporan);
                        $("#hasil-report").show();
                        $("#hasil-laporan-tidak-ada").hide();
                        $('#print-pdf').attr('href', App.baseUrl+'laporan_harian/print_pdf?laporan='+laporan+'&cabang_id='+cabang_id+'&tanggal='+tanggal);
                        
                        
                        
                    }else{
                        $("#hasil-report").hide();
                        html_laporan = '';
                        html_laporan +='<div class="main-card mb-3 card">\
                                            <div class="card-body">\
                                                <div class="row">\
                                                    <h4 class="text-center">Data Tidak Ditemukan</h4>\
                                                </div>\
                                            </div>\
                                        </div>';
                        $('#hasil-laporan-tidak-ada').html(html_laporan);
                        $("#hasil-laporan-tidak-ada").show();
                    }
                })
                .fail(function() {
                    console.log("error");
                })

            });
        },
        initEvent: function () {
            $('.select2').select2();
            
            $('.init-date').datepicker({
                uiLibrary: 'bootstrap4',
                format: 'YYYY-mm-dd'
            });
        },

        sidebarScroll: function () {
            setTimeout(function () {
                if ($(".scrollbar-container")[0]) {
                    $('.scrollbar-container').each(function () {
                        const ps = new PerfectScrollbar($(this)[0], {
                            wheelSpeed: 2,
                            wheelPropagation: false,
                            minScrollbarLength: 20
                        });
                    });


                    const ps = new PerfectScrollbar('.scrollbar-sidebar', {
                        wheelSpeed: 2,
                        wheelPropagation: true,
                        minScrollbarLength: 20
                    });
                }
            }, 1000);
        },
    }
});