require(["../common"], function (common) {
    require(["main-function", "../app/app-histori_kas"], function (func, application) {
        App = $.extend(application, func);
        App.init();
    });
});