require(["../common" ], function (common) {  
    require(["main-function","../app/app-dashboard-chart"], function (func,application) { 
    App = $.extend(application,func);
        App.init();  
    }); 
});