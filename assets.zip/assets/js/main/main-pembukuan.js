require(["../common"], function (common) {
    require(["main-function", "../app/app-pembukuan"], function (func, application) {
        App = $.extend(application, func);
        App.init();
    });
});