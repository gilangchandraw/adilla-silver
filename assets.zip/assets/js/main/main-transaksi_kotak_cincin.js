require(["../common"], function (common) {
    require(["main-function", "../app/app-transaksi_kotak_cincin"], function (func, application) {
        App = $.extend(application, func);
        App.init();
    });
});