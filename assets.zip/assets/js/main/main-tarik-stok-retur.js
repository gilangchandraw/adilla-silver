require(["../common"], function (common) {
    require(["main-function", "../app/app-tarik-stok-retur"], function (func, application) {
        App = $.extend(application, func);
        App.init();
    });
});