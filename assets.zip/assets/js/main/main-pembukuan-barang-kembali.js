require(["../common"], function (common) {
    require(["main-function", "../app/app-pembukuan-barang-kembali"], function (func, application) {
        App = $.extend(application, func);
        App.init();
    });
});