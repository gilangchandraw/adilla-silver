require(["../common"], function (common) {
    require(["main-function", "../app/app-stok-sepuhan"], function (func, application) {
        App = $.extend(application, func);
        App.init();
    });
});