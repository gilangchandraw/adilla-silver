require(["../common"], function (common) {
    require(["main-function", "../app/app-pengeluaran-kantor"], function (func, application) {
        App = $.extend(application, func);
        App.init();
    });
});