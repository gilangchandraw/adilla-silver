require(["../common"], function (common) {
    require(["main-function", "../app/app-supplier"], function (func, application) {
        App = $.extend(application, func);
        App.init();
    });
});