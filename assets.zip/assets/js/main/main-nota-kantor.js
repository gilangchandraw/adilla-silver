require(["../common" ], function (common) {  
    require(["main-function","../app/app-nota-kantor"], function (func,application) { 
    App = $.extend(application,func);
        App.init();  
    }); 
});