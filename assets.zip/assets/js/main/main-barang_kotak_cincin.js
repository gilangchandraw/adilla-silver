require(["../common"], function (common) {
    require(["main-function", "../app/app-barang_kotak_cincin"], function (func, application) {
        App = $.extend(application, func);
        App.init();
    });
});